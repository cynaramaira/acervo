---
id: 12372034
data_publicacao: "2006-07-31 16:58:00"
data_alteracao: "None"
materia_tags: "Desembargadores,votação"
categoria: "Notícias"
titulo: "Freitas abre votação para escolha de desembargador"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Começou agora a votação para escolha do novo desembargador do Tribunal de Justiça de Pernambuco. Toda a cúpula do governo Mendonça Filho (PFL) e a equipe do ex, Jarbas Vasconcelos (PMDB), acompanham a indicação dos nomes da lista tr?plice a ser encaminhada a Mendonça, que nomeará o 37º membro do Poder.</FONT></P></p>
<p><P><FONT face=Verdana>O presidente do TJ, Fausto Freitas, fez questão de abrir o processo de escolha citando os artigos da Constituição que determinam uma votação secreta. Freitas fez campanha no Tribunal para que o procurador estadual Pedro Henrique Alves esteja na lista tr?plice. Ele é o candidato do governo. Ver nota publicada abaixo.</FONT></P></p>
<p><P><FONT face=Verdana>Trinta e três dos 36 desembargadores do TJ votarão hoje. Zamir Fernandes está em férias. Alexandre Aquino, aposentado por invalidez. Etério Galvão, afastado.</FONT></P> </p>
