---
id: 12372356
data_publicacao: "2006-07-15 12:55:00"
data_alteracao: "None"
materia_tags: "Louro José,Wolney Queiroz"
categoria: "Notícias"
titulo: "José Queiroz otimista"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Apesar dos números, o presidente do PDT está entusiasmado. Diz que&nbsp;Eduardo tem mais chances de crescimento por ter o menor ?ndice de rejeição e uma estrutura ampla no interior. Ele acredita que o socialista chegará ao segundo turno contra Mendonça.</P> </p>
