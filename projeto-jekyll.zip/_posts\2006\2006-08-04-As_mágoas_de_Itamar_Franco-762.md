---
id: 12371935
data_publicacao: "2006-08-04 15:07:00"
data_alteracao: "None"
materia_tags: "Elcio Franco,Itamaraty"
categoria: "Notícias"
titulo: "As mágoas de Itamar Franco"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana>O ex-presidente está mesmo indignado com Lula. </FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana></FONT></SPAN>&nbsp;</P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana>No almoço com Alckmin, agora há pouco, disse a Cec?lia Ramos, repórter do <STRONG>Blog</STRONG>, que ficou decepcionado e triste, principalmente depois&nbsp;de Lula ter rebatido cr?ticas dele afirmando: “Eu acho que a pessoa depois dos 75 anos pode falar o que quiser.???<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana>Itamar abriu a caixa de ressentimentos: </FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana></FONT></SPAN>&nbsp;</P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana>“O presidente Lula é hoje um pobre de esp?rito. Quando ele chegar na minha faixa (etária), não vou cometer a mesma indelicadeza. Ele é um homem pretensioso com as idades, haja visto o que ele faz com os aposentados brasileiros???.<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana>O ex-presidente rompeu com Lula depois que o governo dinamitou a candidatura de Itamar ao Senado dentro do PMDB de Minas Gerais, apoiando o ex-governador Newton Cardoso.<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana>Itamar disse, no entanto, que o rompimento não ocorreu por fato espec?fico como a interferência na eleição mineira. Ele foi percebendo vários aspectos negativos de Lula. <o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></SPAN></P><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana>“O que era bonito em Lula era a humildade. Ele hoje é um homem muito importante, que gosta de palácios???, ironizou.</FONT></SPAN> </p>
