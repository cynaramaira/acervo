---
id: 12372277
data_publicacao: "2006-07-19 18:30:00"
data_alteracao: "None"
materia_tags: "jorge jesus"
categoria: "Notícias"
titulo: "Zé Jorge tá demais"
sutia: "None"
chapeu: "None"
autor: "jamildo"
imagem: "None"
---
<p>O vice de Alckmin n&atilde;o parou hoje e deixou para Mendon&ccedil;a Filho e Jarbas Vasconcelos um caminho sem sa?da.</p>
<p>Jos&eacute; Jorge disse, segundo Jamildo Melo, rep&oacute;rter especial do JC, que Lula ter&aacute; que ir, de qualquer maneira, aos debates entre os presidenci&aacute;veis. "Se ele n&atilde;o for, vai ser uma mistura de ast&uacute;cia com covardia", atacou.</p>
<p>Para Jos&eacute; Jorge, essa &eacute; uma quest&atilde;o de coer&ecirc;ncia. "Na elei&ccedil;&atilde;o passada, quando FHC deixou de ir a alguns debates, ele (Lula) disse que era covardia. N&atilde;o tem porque n&atilde;o ir. Estamos torcendo para que ele v&aacute; a todos. At&eacute; porque ser&aacute; a oportunidade para que explique &agrave; popula&ccedil;&atilde;o as promessas que n&atilde;o cumpriu e os problemas de corrup&ccedil;&atilde;o", observou.</p>
<p>Resultado: seguindo a mesma l&oacute;gica de Jos&eacute; Jorge, n&atilde;o restar&aacute; a Mendon&ccedil;a Filho e a Jarbas outro caminho que n&atilde;o seja o de participar de todos os debates em Pernambuco.</p>
