---
id: 12371942
data_publicacao: "2006-08-04 07:40:00"
data_alteracao: "None"
materia_tags: "campanha,geraldo Alckmin"
categoria: "Notícias"
titulo: "Aliança promete mais engajamento na campanha de Alckmin"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Depois de um mês de campanha oficial, em que a aliança jarbista esteve completamente apática na defesa da candidatura de Geraldo Alckmin (PSDB) à Presidência, finalmente hoje os principais caciques pol?ticos do grupo participarão de uma extensa e expressiva agenda eleitoral com o presidenciável tucano. </FONT></P></p>
<p><P><FONT face=Verdana>A contenda que se abateu sobre aliancistas como o ex-governador Jarbas Vasconcelos (PMDB) e o atual governador e candidato à reeleição Mendonça Filho (PFL) promete dar lugar a discursos mais incisivos em defesa de Alckmin, e certamente munidos de uma pitada a mais de ataques ao principal adversário do tucano na sucessão presidencial: o presidente Lula (PT) que disputa a reeleição.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://jc3.uol.com.br/jornal/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinates JC e UOL).</FONT></P> </p>
