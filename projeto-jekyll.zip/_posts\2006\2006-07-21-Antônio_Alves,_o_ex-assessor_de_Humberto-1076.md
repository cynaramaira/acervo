---
id: 12372249
data_publicacao: "2006-07-21 13:25:00"
data_alteracao: "None"
materia_tags: "Antonio Conte,daniel alves,Humberto Costa"
categoria: "Notícias"
titulo: "Antônio Alves, o ex-assessor de Humberto"
sutia: "None"
chapeu: "None"
autor: "jamildo"
imagem: "None"
---
<p>Chama-se Ant&ocirc;nio Alves de Souza o ex-assessor de Humberto Costa apontado pelo empres&aacute;rio Luiz Ant&ocirc;nio Trevisan Vedoin, da Planam, como tendo sido o destinat&aacute;rio de R$ 22.431,38 em hospedagens para ele e outras seis pessoas. Alves foi chefe de gabinete e secret&aacute;rio executivo de Humberto no Minist&eacute;rio da Sa&uacute;de. Continua l&aacute;. Hoje ocupa o cargo de secret&aacute;rio de Gest&atilde;o Paticipativa.</p>
<p>Vedoin &eacute; apontado como o chefe da quadrilha das ambul&acirc;ncias. Passou dez diz depondo e dando informa&ccedil;&otilde;es ao Minist&eacute;rio P&uacute;blico, na esperan&ccedil;a de conquistar o direito &agrave; dela&ccedil;&atilde;o premiada - mecanismo por meio do qual os criminosos conseguem reduzir suas penas em troca de informa&ccedil;&otilde;es sobre os crimes praticados e seus envolvidos.</p>
<p>O empres&aacute;rio diz em determinado trecho do depoimento que pagou os R$ 22 mil em hospedagens e passagens como parte do que gastou em propinas para ver liberados, em 2003, cerca de R$ 8 milh&otilde;es em emendas parlamentares destinadas &agrave; compra de ambul&acirc;ncias.</p>
<p>Tranq&uuml;ilo e municiado de informa&ccedil;&otilde;es sobre todas as agendas que cumpriu em 2003, Ant&ocirc;nio Alves disse ao Blog, por telefone, de Bras?lia, que n&atilde;o conhece nem jamais recebeu qualquer coisa do empres&aacute;rio Luiz Vedoin.</p>
<p>"Repilo com veem&ecirc;ncia essa acusa&ccedil;&atilde;o. N&atilde;o viajei nem nunca me hospedei em nenhum lugar pago por esse esse senhor. Nem o conhe&ccedil;o. Tenho como provar isso. Fiz pouqu?ssimas viagens em 2003. Quase todas a trabalho, registradas aqui no minist&eacute;rio, com di&aacute;rias pagas", explica. "Ou algu&eacute;m usou meu nome ou n&atilde;o sei o que houve", ressalta.</p>
<p>Alves disse h&aacute; pouco que n&atilde;o tem ainda uma c&oacute;pia do depoimento de Vedoin. Mas v&aacute;rios trechos j&aacute; circulam entre a imprensa, em Bras?lia. Segundo ele, os R$ 22.431,38 teriam sido pagos a uma empresa de turismo de Fortaleza.</p>
<p>No depoimento, segundo trechos aos quais o pr&oacute;prio Ant&ocirc;nio Alves teve acesso, por meio de jornalistas, o empres&aacute;rio afirma que Humberto Costa teria dito que n&atilde;o poderia liberar os recursos por conta do contingenciamento. E teria mandado chamar Alves para apresent&aacute;-lo. Ant&ocirc;nio Alves nega isso.</p>
<p>Em outros trechos, j&aacute; divulgados pela imprensa, Vedoin diz que a rela&ccedil;&atilde;o dele com Jos&eacute; Airton Cirilo, candidato do PT derrotado ao governo do Cear&aacute; em 2002, teria come&ccedil;ado por meio de dois intermedi&aacute;rios, Jos&eacute; Caubi Diniz e Raimundo Lacerda Filho, sobrinho de Cirilo. Eles teriam oferecido o apoio de Cirilo, como lobista, para a libera&ccedil;&atilde;o de emendas destinadas &agrave; compra de 130 ambul&acirc;ncias. Em troca, teriam cobrado 5%.</p>
<p>Ant&ocirc;nio Alves garante estar tranq&uuml;ilo tamb&eacute;m sobre a libera&ccedil;&atilde;o dos recursos. Havia, segundo ele, R$ 19 milh&otilde;es de restos a pagar de 2002 (governo FHC) destinados a ambul&acirc;ncias. O que foi pago, garante, n&atilde;o representou qualquer tipo de exce&ccedil;&atilde;o. Foi pago em conformidade com o que previa o decreto de contingenciamento - bloqueio de recursos p&uacute;blicos.</p>
