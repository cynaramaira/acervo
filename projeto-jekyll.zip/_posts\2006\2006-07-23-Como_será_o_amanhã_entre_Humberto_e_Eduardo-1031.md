---
id: 12372204
data_publicacao: "2006-07-23 11:11:00"
data_alteracao: "None"
materia_tags: "como jogar,eduardo,entrega,Humberto Costa,Serasa"
categoria: "Notícias"
titulo: "Como será o amanhã entre Humberto e Eduardo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Estou curioso para ver como ficará a relação entre os militantes de Humberto e Eduardo a partir de hoje à tarde, quando Lula for embora.</FONT></P></p>
<p><P><FONT face=Verdana>Agora há pouco, na Academia Santa Gertrudes, em Olinda, Cec?lia Ramos, repórter do <STRONG>Blog</STRONG>, testemunhou a seguinte cena. Eduardo&nbsp;conversava com os jornalistas, esperando o in?cio do encontro com Lula, quando chegou Luciano Siqueira, o candidato ao Senado de Humberto.</FONT></P></p>
<p><P><FONT face=Verdana>Siqueira fez expressão de que falaria algo grave e soltou: \"Vou sair de perto dessa conversa aqui porque senão mudo meu voto.\" Eduardo aproveitou a deixa, escapou dos repórteres e saiu abraçado ao comunista.</FONT></P></p>
<p><P><FONT face=Verdana>Neste momento, está juntinho de Humberto, ouvindo Ciro Gomes - que já perguntou quantas horas dispunha ainda para falar.</FONT></P></FONT> </p>
