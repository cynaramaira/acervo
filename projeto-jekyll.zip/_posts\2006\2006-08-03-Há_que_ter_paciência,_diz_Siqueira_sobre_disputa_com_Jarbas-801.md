---
id: 12371974
data_publicacao: "2006-08-03 08:00:00"
data_alteracao: "None"
materia_tags: "Fafy Siqueira,jarbas vasconcelos"
categoria: "Notícias"
titulo: "Há que ter paciência, diz Siqueira sobre disputa com Jarbas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>blog de</STRONG> <STRONG>Luciano Siqueira</STRONG><BR>(www.lucianosiqueira.blogspot.com)</FONT></P></p>
<p><P><FONT face=Verdana>Os primeiros cumprimentos da manhã vêm permeados de perguntas sobre a pesquisa Ibope divulgada pelo <I>Jornal do Commercio</I> de hoje (ontem). Muita gente animada com o distanciamento de Humberto Costa em relação ao terceiro colocado na disputa pelo governo estadual, Eduardo Campos. </FONT></P></p>
<p><P><FONT face=Verdana>Porém, a preocupação é geral, entre os nossos apoiadores, acerca dos números revelados para o Senado. Até quando a diferença permanecerá tão grande? Que fazer para melhorar nossos ?ndices? De uma técnica da Prefeitura do Recife, a observação:<BR><BR>- Por que você se mantém tão sereno assim?<BR><BR>Bom, a? são outros quinhentos. Quem sabe o tamanho da empreitada não pode se assustar com dificuldades momentâneas. E, além disso, para que nosso nome cresça junto ao eleitorado, não há mágica: teremos que juntar volume de campanha nas ruas com a TV e o rádio, a partir do dia 15 próximo. </FONT></P></p>
<p><P><FONT face=Verdana>O volume de campanha se obtém num crescendo, na medida em que a sociedade como um todo comece a se interessar pelo fato eleitoral. Há que ter paciência. Agora, quanto à TV e o rádio, teremos que usar com competência de conteúdo e de forma os 2,18 minutos de que disporemos. </FONT></P></p>
<p><P><FONT face=Verdana>Pois é necessário falar para quase seis milhões de eleitores em apenas dois meses. No mais, é saber se entre o candidato (que ainda é um ilustre desconhecido para o grande público) e os eleitores se estabelecerá, ou não, uma relação de empatia que resulte em intenção de voto.</FONT></P><FONT face=Arial></p>
<p><P><FONT face=Verdana><STRONG>Comentário meu:</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Luciano Siqueira, candidato ao Senado na chapa de Humberto Costa (PT), obteve 3% na pesquisa Ibope, divulgada pela TV Globo anteontem, contra 4% de Jorge Gomes (PSB), candidato de Eduardo Campos, e 67% do ex-governador Jarbas Vasconcelos (PMDB), da chapa de Mendonça Filho (PFL). Os números são semelhantes aos do JC/Vox Populi, de 15 de julho.</FONT></P></FONT> </p>
