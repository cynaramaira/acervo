---
id: 12372013
data_publicacao: "2006-08-01 07:59:00"
data_alteracao: "None"
materia_tags: "caminhão,campanha"
categoria: "Notícias"
titulo: "Bandeira de Mello: Fiz minha campanha por mim"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Cec?lia Ramos</STRONG><BR>Repórter do Blog</FONT></P></p>
<p><P><FONT face=Verdana>Nomeado desembargador do Tribunal de Justiça de Pernambuco (TJPE) pelo governador e candidato à reeleição Mendonça Filho (PFL), o advogado Francisco Bandeira de Mello&nbsp;foi evasivo ao comentar, em conversa com o <STRONG>Blog</STRONG>, a vitória dele sobre Pedro Henrique Alves, preferido de Mendonça e de Jarbas Vasconcelos.</FONT></P></p>
<p><P><FONT face=Verdana>\"Não posso supor a escolha do governador. Só ele pode falar\", disse, ao ser questionado sobre os motivos que pesaram para a nomeação dele - Jorge Neves e Edgar Moury Neto também faziam parte da lista tr?plice encaminhada a Mendonça.</FONT></P></p>
<p><P><FONT face=Verdana>Bandeira de Mello é como um afilhado para o senador Marco Maciel (PFL). Seu pai é amigo pessoal e um dos principais assessores do pefelista. O 37º desembargador do TJPE também é sócio do presidente da Ordem dos Advogados do Brasil (OAB), Júlio Oliveira, com quem divide, há 16 anos, o escritório de Advocacia Oliveira e Bandeira. </FONT></P></p>
<p><P><FONT face=Verdana>Formado na Faculdade de Direito do Recife e advogado militante há 19 anos, Bandeira de Mello atua nas áreas civil e comercial, nos segmentos judicial, contratual e consultivo. Tem especialização em Direito Tributário pela Universidade Federal de Pernambuco (UFPE) e é procurador do Estado, concursado há 13 anos. </FONT></P></p>
<p><P><FONT face=Verdana>Já atuou nas Procuradorias da Fazenda e de Apoio Jur?dico e Legislativo, além de ter exercido as funções de chefe de Centro de Estudos Jur?dicos, de coordenador do Núcleo de Projetos Especiais e procurador-chefe do Contencioso Civil do Estado. Foi ainda procurador concursado do Tribunal de Contas do Estado (TCE).</FONT></P><B></p>
<p><P><FONT face=Verdana>O que pesou para o senhor ser o escolhido do governador Mendonça Filho?</FONT></P></B></p>
<p><P><FONT face=Verdana>Não quero ser deselegante com você. O que pesou é melhor você perguntar a ele. Fiz minha campanha por mim. </FONT></P><B></p>
<p><P><FONT face=Verdana>Mas a sua relação com o senador Marco Maciel e a sociedade com o presidente da OAB, Júlio Oliveira, não teriam influência?</FONT></P></B></p>
<p><P><FONT face=Verdana>Não sei dizer. Não posso supor a escolha do governador. Só ele pode falar. Eu tive 26 votos dos 33 desembargadores. Isso foi um reconhecimento à minha atuação. É um reconhecimento do Tribunal, dentro também dessa lista sextupla. </FONT></P><B></p>
<p><P><FONT face=Verdana>Qual é a sua relação com Marco Maciel?</p>
<p> </FONT></P></B></p>
<p><P><FONT face=Verdana>Uma relação de amizade, tal qual meu pai. </FONT></P><B></p>
<p><P><FONT face=Verdana>O resultado foi o esperado? </FONT></P></B></p>
<p><P><FONT face=Verdana>Quem é candidato nesse processo, apenas coloca o nome. Não tem expectativa nem positiva nem negativa. Eu não posso dizer que estava confiante no resultado, mas eu tinha o desejo de ganhar. </FONT></P><B></p>
<p><P><FONT face=Verdana>Como será sua atuação? </FONT></P></B></p>
<p><P><FONT face=Verdana>Vou iniciar uma vida nova como magistrado. Trabalharei para honrar a confiança da Ordem (OAB), do Tribunal, do governador e dos advogados que depositaram confiança em mim. </FONT></P><B></p>
<p><P><FONT face=Verdana>O senhor está comemorando, neste momento (a entrevista foi concedida ontem à noite)? </FONT></P></B></p>
<p><P><FONT face=Verdana>Estou jantando com amigos. Não é exatamente comemoração, até porque não teve tempo hábil para isso. Estão aqui comigo alguns amigos que vieram me parabenizar. No momento, Júlio (Oliveira) não está, mas ele ficou de vir. </FONT></P></p>
<p><P><FONT face=Verdana>*Bandeira de Mello pede desculpas por interromper a entrevista. \"Agora tenho que desligar, para dar um abraço em um amigo que concorreu comigo. Edgar Moury Neto acabou de chegar\" </FONT></P> </p>
