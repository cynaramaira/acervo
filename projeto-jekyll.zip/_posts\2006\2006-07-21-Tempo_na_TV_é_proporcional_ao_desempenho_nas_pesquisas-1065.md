---
id: 12372238
data_publicacao: "2006-07-21 19:52:00"
data_alteracao: "None"
materia_tags: "pesquisas,tempo"
categoria: "Notícias"
titulo: "Tempo na TV é proporcional ao desempenho nas pesquisas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><H1 class=Titulo><FONT face=Verdana size=2>Por Angela Lacerda</FONT></H1></p>
<p><P><FONT face=Verdana>(AGÊNCIA ESTADO) - O número de inserções - programas de 30 segundos distribu?dos na programação das emissoras de rádio e televisão - dos três principais candidatos ao governo de Pernambuco é equivalente à preferência do eleitorado apontadas pelas recentes pesquisas eleitorais.<BR><BR>O governador Mendonça Filho (PFL), que aparece em primeiro lugar na intenção de votos, com lugar praticamente garantido no segundo turno, terá 193 (35,7%) do total de 540 inserções a serem realizadas durante o per?odo de campanha na m?dia.<BR><BR>Humberto Costa (PT) disputa a outra vaga no segundo turno palmo a palmo com Eduardo Campos (PSB), ambos aliados de Lula. Costa terá 115 inserções (21,3%) e Eduardo 106 (20%).</FONT></P> </p>
