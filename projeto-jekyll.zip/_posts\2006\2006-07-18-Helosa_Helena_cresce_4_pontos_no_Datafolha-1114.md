---
id: 12372287
data_publicacao: "2006-07-18 20:52:00"
data_alteracao: "None"
materia_tags: "Datafolha"
categoria: "Notícias"
titulo: "Helo?sa Helena cresce 4 pontos no Datafolha"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Pesquisa divulgada agora no Jornal Nacional e que será publicada amanhã na Folha de S.Paulo mostra Lula com uma vantagem estável sobre Alckmin. Ele tinha 46% das intenções de voto em junho e agora tem 44%. Alckmin estava com 29%. Hoje, 28%.</P></p>
<p><P>Helo?sa Helena é que cresceu de 6% para 10%. O PT teme ver a senadora alagoana se tornar um fator desestabilizador da eleição. Ela poderá provocar o segundo turno.</P></p>
<p><P>No segundo turno, Lula teria 50% (em junho eram 51%) e Alckmin manteve os mesmos 40% de junho. Há uma diferença apertada. Mais tempo de campanha, com uma prorrogação, poderia complicar as coisas. </P></p>
<p><P>A margem de erro da pesquisa é de 2% para mais ou para menos.</P></FONT> </p>
