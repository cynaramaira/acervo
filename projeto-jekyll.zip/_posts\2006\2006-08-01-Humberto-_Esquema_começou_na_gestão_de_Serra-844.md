---
id: 12372017
data_publicacao: "2006-08-01 08:56:00"
data_alteracao: "None"
materia_tags: "esquema criminoso,Humberto Costa,Serrana"
categoria: "Notícias"
titulo: "Humberto: Esquema começou na gestão de Serra"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=\"Courier New\"></p>
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>O ex-ministro da Saúde e candidato ao governo do Estado pela frente Melhor pra Pernambuco, Humberto Costa (PT), afirmou que o esquema da Máfia das Sanguessugas começou na gestão de José Serra, atual candidato a governador de São Paulo (PSDB), no governo FHC, em 2000, e que, portanto, se a CPI quer investigar o Ministério da Saúde, \"tem que ouvir a todos (ex-ocupantes)\". </FONT></P></p>
<p><P><FONT face=Verdana>Humberto fez a colocação ao saber que a CPI das Sanguessugas decidiu investigar o Executivo, depois que concluir as investigações sobre parlamentares.</FONT></P></p>
<p><P><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Verdana; mso-bidi-font-family: Arial\">Leia <EM><B><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></B></EM> o texto completo (assinantes JC e UOL).<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></SPAN></P></FONT> </p>
