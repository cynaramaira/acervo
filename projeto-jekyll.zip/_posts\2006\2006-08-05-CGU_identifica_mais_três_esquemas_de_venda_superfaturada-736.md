---
id: 12371909
data_publicacao: "2006-08-05 09:30:00"
data_alteracao: "None"
materia_tags: "venda"
categoria: "Notícias"
titulo: "CGU identifica mais três esquemas de venda superfaturada"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>BRAS??LIA – O ministro-chefe da Controladoria Geral da União (CGU), Jorge Hage, disse ontem que identificou uma nova ramificação do esquema de fraudes na venda de ambulâncias superfaturadas que atuava, a partir do Paraná, em vários estados.</FONT></P></p>
<p><P><FONT face=Verdana>Segundo Hage, o fio da meada nas investigações da CGU foi puxado a partir de uma carta inclu?da na prestação de contas do munic?pio de Guaraciaba, em Minas Gerais. O documento coloca em cena o nome do deputado Nárcio Rodrigues (PSDB-MG), que não integra o grupo dos investigados pela CPI d&lt;WC&gt;a&lt;WC1&gt;s Sanguessugas, e a empresa Domanski</FONT></P></p>
<p><P><FONT face=Verdana>Leia o </FONT><A href=\"https://jc3.uol.com.br/jornal/\" target=_blank><B><I><U><FONT color=#0000ff><FONT face=Verdana>texto</FONT></B></I></U></FONT></A><FONT face=Verdana> completo em Pol?tica, no JC (assinantes JC e UOL).</FONT></P> </p>
