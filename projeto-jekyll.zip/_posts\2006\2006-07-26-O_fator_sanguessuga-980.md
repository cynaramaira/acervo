---
id: 12372153
data_publicacao: "2006-07-26 09:54:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "O fator sanguessuga"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Os principais atores da disputa pelo governo de Pernambuco esperam ter na próxima semana um quadro um pouco mais claro sobre o efeito do escândalo das sanguessugas na sucessão estadual.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>As not?cias envolvendo o candidato do PT e ex-ministro Humberto Costa com o caso terão, certamente, repercussão na campanha.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>A questão agora é saber qual será esse impacto e quando ele virá. Ele será pol?tico, eleitoral ou ambos? </FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Os analistas ouvidos pelo <B>Blog</B>, todos acostumados com o manejo de pesquisas eleitorais, são unânimes em alguns pontos:</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt 36pt; TEXT-INDENT: -18pt; mso-list: l0 level1 lfo1; tab-stops: list 36.0pt\"><FONT face=Verdana>1)<FONT size=2><SPAN style=\"FONT: 7pt \Times New Roman\\\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </SPAN>É cedo para saber os preju?zos de Humberto. O eleitor leva algum tempo para digerir as not?cias que recebe. Ele precisa de mais análises e informações;</FONT></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt 18pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt 36pt; TEXT-INDENT: -18pt; mso-list: l0 level1 lfo1; tab-stops: list 36.0pt\"><FONT face=Verdana>2)<FONT size=2><SPAN style=\"FONT: 7pt \Times New Roman\\\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </SPAN>O caso ganhou destaque a partir da última sexta-feira. Mas só alcançou escala maior com reportagens na TV, principalmente na Globo – no Fantástico, domingo, e no Bom Dia Brasil e Jornal Hoje, na segunda-feira;</FONT></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt 36pt; TEXT-INDENT: -18pt; mso-list: l0 level1 lfo1; tab-stops: list 36.0pt\"><FONT face=Verdana>3)<FONT size=2><SPAN style=\"FONT: 7pt \Times New Roman\\\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </SPAN>A crise vivida por Humberto ainda não se encerrou. Ele luta hoje para se defender e mostrar que não tem relação com a quadrilha das ambulâncias. Os adversários, porém, vão atacá-lo mais e mais. Dia 15 começa o guia eleitoral e o tema voltará com intensidade;</FONT></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt 36pt; TEXT-INDENT: -18pt; mso-list: l0 level1 lfo1; tab-stops: list 36.0pt\"><FONT face=Verdana>4)<FONT size=2><SPAN style=\"FONT: 7pt \Times New Roman\\\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </SPAN>O caso das sanguessugas fragiliza Humberto porque representa uma reca?da, um novo surto de relação com escândalos nacionais. O último deles havia sido o do mensalão, quando a ex-assessora Eristela Feitosa foi apontada como destinatária de recursos do esquema de Marcos Valério/Delúbio Soares. Antes disse, houve a Operação Vampiro. Para os dois casos, Humberto tem respostas e explicações consistentes. O problema é como o conjunto de acusações chega ao eleitor. Além de respostas, ele precisa ter muita munição contra as versões.</FONT></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Até a semana que vem deverão ser realizadas pesquisas por encomenda do próprio Humberto ou de seus principais concorrentes – o governador Mendonça Filho (PFL) e o deputado Eduardo Campos (PSB).</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Os números mostrarão se há efeitos eleitorais imediatos. Humberto pode cair nas pesquisas logo ou perder pontos apenas mais adiante. Pode também não cair. Ele recebeu 22% na última JC/Vox Populi, divulgada no dia 15, contra 21% de Eduardo e 35% de Mendonça.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2>Além do preju?zo eleitoral, o ex-ministro deverá sofrer preju?zos pol?ticos. L?deres como o presidente Lula podem se distanciar dele para não serem contaminados pela crise.</FONT></SPAN> </p>
