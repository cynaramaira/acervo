---
id: 12372215
data_publicacao: "2006-07-22 18:43:00"
data_alteracao: "None"
materia_tags: "eduardo"
categoria: "Notícias"
titulo: "Eduardo, o generoso"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2><FONT face=Verdana><FONT size=2></p>
<p><P>Eduardo teve um surto de generosidade com Humberto. Ele estava autografando todas as bandeiras que os militantes jogavam no palco. Ele, Lula e dona Marisa Let?cia. Resolveu então chamar Humberto, que passou a assinar também, usando o joelho de Dudu como apoio.</P></p>
<p><P>Sete pessoas já discursaram. Até agora, só alto astral e nada de referências a Humberto, que vive um de seus piores momentos, com o envolvimento do nome dele com os principais personagens do escândalo das sanguessugas.</P></p>
<p><P>Há pouco, falou Aldo Rebelo (PCdoB), presidente da Câmara dos Deputados. Fez um discurso enfadonho e chamou os adversários de Lula de vingativos e preconceituosos.</FONT></FONT></P></FONT> </p>
