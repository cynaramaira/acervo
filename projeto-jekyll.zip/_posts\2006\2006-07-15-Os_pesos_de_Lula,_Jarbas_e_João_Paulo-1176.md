---
id: 12372349
data_publicacao: "2006-07-15 17:15:00"
data_alteracao: "None"
materia_tags: "jarbas vasconcelos,joão d,Lula,Paulo"
categoria: "Notícias"
titulo: "Os pesos de Lula, Jarbas e João Paulo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Por Sérgio Montenegro Filho<BR>Repórter especial do JC</P></p>
<p><P>O presidente Luiz Inácio Lula da Silva (PT), o ex-governador Jarbas Vasconcelos (PMDB) e o prefeito do Recife, João Paulo (PT), além de manterem uma boa popularidade, continuam sendo valiosos cabos eleitorais para seus candidatos no pleito deste ano. De acordo com a nova pesquisa Vox Populi, um nome que conte com o apoio de um dos três ganha mais credibilidade na disputa. </P></p>
<p><P>No caso de Lula e Jarbas, a situação é praticamente a mesma. Questionados pelo Vox Populi</p>
<p> sobre a possibilidade de votar num candidato apoiado pelo presidente da República, 50% dos entrevistados responderam que essa peculiaridade aumentaria as chances, enquanto apenas 13% disseram que o apoio de Lula diminui sua vontade de votar num determinado postulante a governador. Outros 36% afirmaram que a presença do presidente no palanque não interfere na sua escolha. </P></p>
<p><P>Quando o candidato recebe o apoio de Jarbas Vasconcelos, as respostas equivalem. Para 50% dos entrevistados, o aval do peemedebista aumenta as chances de votar num determinado nome, enquanto 11% disseram que diminui. Outros 37% garantiram que o apoio do ex-governador a um candidato não influi na sua escolha. </P></p>
<p><P>Os números obtidos pelo prefeito João Paulo como \"cabo eleitoral de luxo\" são um pouco mais modestos que os de Lula e Jarbas Vasconcelos, mas nem por isso deixam de ser uma boa moeda de campanha: 27% dos entrevistados admitem que o apoio do petista aumenta as chances de votar num candidato, enquanto 13% advertem que se João Paulo estiver no palanque, as chances do candidato receber seu voto diminuem.</P> </p>
