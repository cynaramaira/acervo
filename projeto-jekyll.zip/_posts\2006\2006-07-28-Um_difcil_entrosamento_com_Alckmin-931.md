---
id: 12372104
data_publicacao: "2006-07-28 10:25:00"
data_alteracao: "None"
materia_tags: "geraldo Alckmin"
categoria: "Notícias"
titulo: "Um dif?cil entrosamento com Alckmin"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Só a uma semana do desembarque de Geraldo Alckmin (PSDB) em Pernambuco, no evento que vai marcar a inauguração do comitê tucano do Estado na sexta-feira (4), as coordenações das campanhas do presidenciável e da União Por Pernambuco iniciaram, ontem, o que denominam de \"entrosamento\" entre os grupos para só então definir como atuarão conjuntamente na campanha de Alckmin em Pernambuco. </FONT></P></p>
<p><P><FONT face=Verdana>O tucano tem sido omitido – ou citado discretamente – pelas principais lideranças pol?ticas nos eventos de campanha da União realizados até o momento. Mesmo amargando baixa popularidade no Nordeste e diante de um entendimento, quase que consensual, de que o ingresso dos caciques eleitorais pra valer na campanha é fundamental para alavancar Alckmin nas pesquisas de intenção de voto.</FONT></P></p>
<p><P><FONT face=Verdana>Hoje haverá uma segunda rodada da reunião de \"entrosamento\", já para definir a agenda do tucano no Recife na próxima sexta-feira (4). </FONT></P></p>
<p><P><FONT face=Verdana>A assessoria do candidato a presidente do PSDB ainda não fechou seus compromissos em Pernambuco. Sabe-se apenas que ele deve ficar, todo o dia da sexta-feira, envolvido em um seminário sobre um programa de gestão para o Nordeste. </FONT></P></p>
<p><P><FONT face=Verdana>E já está pré-agendado que o governador e candidato à reeleição Mendonça Filho (PFL) será representado nesse per?odo da visita de Alckmin pelo seu candidato a vice Evandro Avelar (PSDB). </FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></EM></STRONG> texto completo (assinantes JC e UOL).</FONT></P> </p>
