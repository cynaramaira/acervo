---
id: 12372105
data_publicacao: "2006-07-28 11:01:00"
data_alteracao: "None"
materia_tags: "Iván Duque"
categoria: "Notícias"
titulo: "Niguém conhece Eymael na Duque de Caxias"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>O candidato do PSDC a presidente da República ainda não conseguiu ser reconhecido no centro do Recife. José Maria Eymael percorre o comércio da Duque de Caxias neste momento ao lado do vereador Luiz Vidal, que disputa o governo de Pernambuco.</FONT></P></p>
<p><P><FONT face=Verdana>Com eles, apenas os figurantes pagos para gritar \"Ey, ey, ey, Eymael\" e fazer número para as imagens do guia eleitoral. Segundo Arthur Cunha, repórter de Pol?tica do JC, o presidenciável fala agora com aposentados e soletra o nome dele.</FONT></P> </p>
