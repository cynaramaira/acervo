---
id: 12371877
data_publicacao: "2006-08-07 16:22:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Coligação arrecadou R$ 1,3 milhão"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>O governador e candidato à reeleição Mendonça Filho (PFL) já encaminhou para o Tribunal Regional Eleitoral a primeira prestação de contas da campanha.</FONT></P></p>
<p><P><FONT face=Verdana>Os números são os seguintes (em R$):</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Arrecadação total</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1.384.172,40</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Despesas</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 551.000</FONT></P></p>
<p><P><FONT face=Verdana>-----------------------------</FONT></P></p>
<p><P><FONT face=Verdana>Principais gastos</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Produção/m?dia</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 200.000</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Publicidade</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 126.400</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Publicidade/impressos</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;97.475</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Transportes</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;25.167,53</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Locações/carros, <BR></STRONG></FONT><FONT face=Verdana><STRONG>equipamentos </STRONG></FONT><FONT face=Verdana><STRONG>e imóvel</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;22.900</FONT></P></p>
<p><P><FONT face=Verdana>Veja os números dos outros candidatos (dados do Jornal do Commercio):</FONT></P><FONT color=#333333></p>
<p><P><FONT face=Verdana>A campanha de Humberto Costa (PT) informou ter arrecadado R$ 87.300,00 e tido um total de despesas bem maior: R$ 340.899,00. Os gastos/receitas estimados pela coligação são de R$ 14 milhões.</FONT></P></p>
<p><P><FONT face=Verdana>De acordo com a assessoria petista, a legislação permite que sejam celebrados contratos e estipulados prazos para pagamentos futuros, da? o déficit no relatório. </FONT></P></FONT></p>
<p><P><FONT face=Verdana>Já a campanha de Eduardo Campos (PSB) informou ao TRE ter arrecadado bem mais do que a do petista: R$ 868 mil. O total de gastos no per?odo – a maior parte com a produção do guia eleitoral – foi de R$ 756 mil.</FONT></P></p>
<p><P><FONT face=Verdana>Os gastos/receitas estimados pelo PSB são de R$&nbsp;8 milhões. E os da coligação de Mendonça, R$ 15 milhões.</FONT></P> </p>
