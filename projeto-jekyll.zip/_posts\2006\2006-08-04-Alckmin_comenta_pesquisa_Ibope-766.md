---
id: 12371939
data_publicacao: "2006-08-04 11:47:00"
data_alteracao: "None"
materia_tags: "geraldo Alckmin,Ibope,pesquisa"
categoria: "Notícias"
titulo: "Alckmin comenta pesquisa Ibope"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>“Faltam seis pontos percentuais para ter segundo turno. E a campanha nem começou???,&nbsp;disse ele agora, no programa de Geraldo Freire, na Rádio Jornal, avaliando os números que acabam de ser divulgados pela Confederação Nacional da Indústria (CNI/Ibope).</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>E continua Alckmin: “Somando os 25 meus mais os 11 (de Helo?sa Helena) mais 2 dos demais dá 38%. Tá todo mundo na margem de erro. Isso mostra o seguinte: a campanha só vai começar quando começar o que vocês chamam aqui em Pernambuco de guia eleitoral???.</FONT></P> </p>
