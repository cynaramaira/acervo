---
id: 12372301
data_publicacao: "2006-07-18 12:49:00"
data_alteracao: "None"
materia_tags: "esquema criminoso,Evandro Carvalho"
categoria: "Notícias"
titulo: "Quem é Evandro Avelar?"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Ganha um brinde quem conseguir identificar o rosto do vice de Mendonça Filho, o engenheiro Evandro Avelar, no <STRONG><A href=\"https://www.mendonca25.can.br/\" target=_blank>site</A></STRONG> da campanha.</P></p>
<p><P>Amanhã deve ser inaugurado o site de Eduardo Campos. O de Humberto Costa ainda não tem data definida para entrar na rede.</P> </p>
