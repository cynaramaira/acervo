---
id: 12372053
data_publicacao: "2006-07-29 21:05:00"
data_alteracao: "None"
materia_tags: "cerveja,Débora Dantas"
categoria: "Notícias"
titulo: "Débora Daggy mentiu para a Veja"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>A modelo, ex-namorada do ex-governador Jarbas Vasconcelos e candidata a deputada estadual pelo PSB&nbsp;disse à Veja que foi enganada pelo fotógrafo do JC, Marcos Michael, responsável pelo ensaio publicado aqui no <STRONG>Blog</STRONG>, na segunda-feira passada. (Leia nota postada abaixo).</FONT></P></p>
<p><P><FONT face=Verdana>Isso não é verdade. O ensaio já estava programado havia dias. Tudo foi feito com a inteira concordância dela. E Michael é um dos profissionais mais respeitados do Jornal do Commercio. Ele foi extremamente correto com ela.</FONT></P></p>
<p><P><FONT face=Verdana>Nada do que foi realizado representou surpresa. Talvez&nbsp;Daggy tenha sentido os efeitos da repercussão das declarações que deu.</FONT></P></p>
<p><P><FONT face=Verdana>Veja <STRONG><EM><A href=\"https://jc3.uol.com.br/blogs/jc/2006/07/24/index.php#248\">aqui</A></EM></STRONG> o ensaio e a entrevista com a modelo.</FONT></P> </p>
