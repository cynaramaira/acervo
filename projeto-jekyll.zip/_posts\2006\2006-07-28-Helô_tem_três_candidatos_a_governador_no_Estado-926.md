---
id: 12372099
data_publicacao: "2006-07-28 08:00:00"
data_alteracao: "None"
materia_tags: "candidatos,Estado,GOVERNADORES"
categoria: "Notícias"
titulo: "Helô tem três candidatos a governador no Estado"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Do <STRONG>Jornal do Commercio</STRONG></P></p>
<p><P>A senadora Helo?sa Helena (P-SOL) faz campanha para a Presidência da República hoje no Recife apoiada por três candidatos ao governo do Estado. </P></p>
<p><P>Além de Edilson Silva (P-SOL) e Kátia Telles (PSTU), da coligação dela, também aderiu Renê Patriota, do PV, cuja candidatura encontra-se sub judice no Tribunal Regional Eleitoral (TRE). </P></p>
<p><P>O esforço dos três será para fortalecer o palanque da candidata em Pernambuco, mas nas entrelinhas, entretanto, demonstram que o clima de disputa entre si vai permanecer.</P></p>
<p><P>Oficialmente, o candidato apoiado por Helo?sa Helena é Edilson Silva, de acordo com a coordenação nacional da campanha. Kátia Telles, no entanto, cobra um posicionamento a favor também do PSTU. </P></p>
<p><P>\"Se estamos nessa frente nacional, ela tem que apoiar os dois. Queremos que ela esteja tanto na campanha do P-SOL quanto na nossa\", afirmou.</P></FONT> </p>
