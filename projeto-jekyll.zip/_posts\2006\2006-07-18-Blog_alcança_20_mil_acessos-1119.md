---
id: 12372292
data_publicacao: "2006-07-18 17:33:00"
data_alteracao: "None"
materia_tags: "blogs jc"
categoria: "Notícias"
titulo: "Blog alcança 20 mil acessos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Desde 11h de sábado, o blog já acumula 20.374 acessos. Veja o balanço:</P></p>
<p><P>Sábado&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4.376 </P></p>
<p><P>Domingo&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2.903 </P></p>
<p><P>Segunda&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 7.688</P></p>
<p><P>Hoje&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5.407 (até às 17h)</P></p>
<p><P>Total&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;20.374</P></FONT> </p>
