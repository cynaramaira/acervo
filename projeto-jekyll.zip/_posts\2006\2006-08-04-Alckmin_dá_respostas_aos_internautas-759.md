---
id: 12371932
data_publicacao: "2006-08-04 15:54:00"
data_alteracao: "None"
materia_tags: "geraldo Alckmin"
categoria: "Notícias"
titulo: "Alckmin dá respostas aos internautas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>O <STRONG>Blog</STRONG> pediu ontem e hoje aos internautas para apresentar o que gostariam de perguntar a Geraldo Alckmin, presidenciável do PSDB.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Recebemos mais de 20 questões. Apenas uma parte delas pôde ser apresentada a Alckmin, durante a vista dele ao <EM>Jornal do Commercio</EM>, no final da manhã.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>O tucano, assim como Lula, anda sempre acompanhado por um batalhão de repórteres dos principais jornais do pa?s. </FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Por isso, qualquer entrevista é sempre complicada. Acaba se transformando numa coletiva de imprensa e o tempo fica curto.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Daqui a pouco postarei mais respostas.<BR></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana size=3><STRONG>“Não houve nenhum mensalinho???</STRONG></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><BR><STRONG>Pergunta de Rodrigo Vidal Torres de Sousa</STRONG>: “Por que o senhor acha que não investigaram o suficiente o mensalinho da votação da reeleição? Será que naquela época era mais dif?cil provar a safadeza contra o povo?</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><STRONG>Alckmin -</STRONG> Não houve nenhum mensalinho, nem mensalão. Na realidade, a reeleição também nem foi para o presidente Fernando Henrique. O que foi votado é um princ?pio constitucional, que permitiu a reeleição para os prefeitos do Brasil inteiro, para os governadores do Brasil inteiro e para o presidente. Também ninguém é obrigado a ser reeleito. Você só está dando ao povo, ao eleitor mais um instrumento. Se ele quiser reeleger ele era proibido antes da mudança constitucional. Hoje ele pode, se ele achar que é um bom governo.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><BR>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana size=3><STRONG>“Eu não manteria a reeleição???</STRONG></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><BR>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><STRONG>Pergunta de Djalma Junior</STRONG> (aquele que desde cedo nos cobra as respostas): “O sr. é contra ou a favor da reeleição????</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT</p>
<p> face=Verdana><STRONG>Alckmin -</STRONG> Do jeito que está hoje eu não manteria a reeleição. Até sou favorável a essa decisão do Congresso Nacional (de instituir a reeleição). Veja que ela não foi regulamentada até hoje. Se ela for regulamentada, ela é mais um instrumento saudável na vida pública.<BR></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><BR>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana size=3><STRONG>“Pretendo fazer uma mudança de qualidade na saúde???</STRONG></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><BR><o:p></o:p></FONT>&nbsp;</P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><STRONG>Pergunta de quem assinou Fortalecimento do SUS</STRONG>: “Pretende intervir em Estados cuja administração pública da saúde é ineficiente? </FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><STRONG>Comentário meu:</STRONG> a pergunta do internauta era mais longa e não foi poss?vel apresentá-la completamente a Alckmin. Apresentamos apenas o trecho acima. O que ficou de fora foi o seguinte: “(Pernambuco é um exemplo clássico, onde um grande número de pacientes morreram aguardando vaga em UTI, e o Estado por incompetência administrativa deixa que isto aconteça...Outro exemplo é o do Hospital da Restauração, onde mais de 200 pacientes se amontoam em macas emuitas vezes no chão, num local onde somente cabe 70 pacientes. Muitos morrem em cadeiras sem a m?nima dignidade humana)? Neste caso é cab?vel uma intervenção federal????</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><STRONG>Alckmin -</STRONG> Mas é claro, o governo federal...não é intervenção, ele tira a gestão plena. Se tiver um sistema de saúde caótico, o governo pode, tanto no munic?pio, ouvindo a comissão tripartite, ele pode cancelar a gestão plena, que estabelece todo o comando ou para o munic?pio ou para o Estado. Eu pretendo, na área de saúde, fazer uma mudança de qualidade.<BR></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><BR>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana size=3><STRONG>“Ajudaria muito a quebrar essa comunicação do crime???</STRONG></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><BR>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><STRONG><SPAN style=\"FONT-WEIGHT: normal; FONT-SIZE: 10pt; COLOR: black; FONT-FAMILY: Verdana\"><STRONG>Pergunta de quem assinou Bloquear Celulares nos Pres?dios</STRONG>:</SPAN></STRONG><STRONG><SPAN style=\"FONT-SIZE: 10pt; COLOR: black; FONT-FAMILY: Verdana\"> </SPAN></STRONG><SPAN style=\"FONT-SIZE: 10pt; COLOR: black; FONT-FAMILY: Verdana\">\"Sou Engenheiro Eletrônico da USP. Embutir chapas de metal nos muros dos pres?dios e cobrir os forros e telhados com telas metálicas resolveriam o problema. Qualquer professor mediano de telecomunicações sabe disso ( princ?pio gaiola de faraday - século XVIII ). O custo é baixo e a implantação fácil. Porque isso ainda não foi feito?\"</SPAN><SPAN style=\"COLOR: black\"><o:p></o:p></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"COLOR: black\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><STRONG>Alckmin -</STRONG> Esse é o grande desafio. Nas penitenciárias de segurança máxima, não tem acesso (aos celulares). Agora, nas penitenciárias maiores, perto de 800, 900 presos, é mais dif?cil. Então o caminho é o tecnológico. Os bloqueadores de celulares não têm agido com tanta eficiência. Tecnologicamente você consegue um bom resultado, por exemplo, numa sala de cinema, num teatro, mas numa penitenciária que é praticamente uma cidade, é mais dif?cil. Eu entendo que a Anatel e as concessionárias de telefonia precisam ajudar mais no sentido de bloquear essas áreas de pres?dio. Isso ajudaria muito a quebrar essa comunicação do crime.</FONT></P> </p>
