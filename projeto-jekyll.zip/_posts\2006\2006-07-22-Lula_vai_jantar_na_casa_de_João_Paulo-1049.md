---
id: 12372222
data_publicacao: "2006-07-22 18:06:00"
data_alteracao: "None"
materia_tags: "casa,jantar,joão d,Lula,Paulo"
categoria: "Notícias"
titulo: "Lula vai jantar na casa de João Paulo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Lula vai falar com a imprensa depois do com?cio. Mais tarde, passa no hotel e segue para jantar no apartamento do prefeito João Paulo, nas Graças.</FONT></P></p>
<p><P></P></FONT> </p>
