---
id: 12372245
data_publicacao: "2006-07-21 10:04:00"
data_alteracao: "None"
materia_tags: "Humberto Costa,investigações"
categoria: "Notícias"
titulo: "Investigações complicam situação de Humberto"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>(Do Jornal do Commercio, com Agência Estado)</FONT></P></p>
<p><P><FONT face=Verdana></FONT><FONT size=2><FONT size=1><FONT size=2></p>
<p><DIV id=corpo style=\"FONT-SIZE: 90%\"><FONT face=Verdana><I>Luiz Vedoin, da Planam, disse que teria pago, em 2003, despesas de assessor do então ministro Humberto Costa, no valor de R$ 22 mil</B></I></I><BR><BR></FONT><I></p>
<p><P></I><FONT face=Verdana>BRAS??LIA – O empresário Luiz Antônio Vedoin, um dos donos da Planam, empresa ligada à máfia das ambulâncias, afirmou à Justiça que em julho de 2003 teria pago despesas de hospedagem de um assessor do então ministro da Saúde e candidato a governador em Pernambuco pelo PT, Humberto Costa, e de mais seis pessoas ligadas a esse assessor, no valor de R$ 22 mil. </FONT></p>
<p><P><FONT face=Verdana>Vedoin afirmou ainda que, por intermédio do petista José A?rton Cirilo (integrante do Diretório Nacional do PT e fundador do partido no Ceará), teve contatos com o primeiro escalão dos governos do PT de Mato Grosso do Sul e Piau?. Os encontros teriam se destinado à discussão de projetos para compra de ambulâncias e unidades odontológicas, comercializadas pelo esquema. Vedoin diz que teria ido ao gabinete do governador do Piau?, Wellington Dias, durante a assinatura de projetos destinados a esse fim. </FONT></p>
<p><P><FONT face=Verdana>O depoimento de Vedoin traz também uma outra revelação: por intermédio de José Airton, o grupo teria tentado operar para ter acesso a dotações orçamentárias do próprio Ministério da Saúde, não originárias de emendas parlamentares, em valor superior a R$ 20 milhões. Até o momento, sabia-se que o esquema operava apenas com emendas ao orçamento apresentadas por parlamentares ou bancadas da Câmara. </FONT></p>
<p><P><FONT face=Verdana>Ainda conforme Vedoin, um intermediário de José A?rton informou que, para dar à Planam acesso àqueles recursos extras, a comissão seria maior, de 15% sobre o valor liberado. Em uma suposta negociação anterior, Vedoin teria pago 5% de propina a intermediários de José A?rton em troca da liberação de recursos para pagar 130 ambulâncias já entregues. </FONT></p>
<p><P><FONT face=Verdana>De acordo com autoridades que acompanham o caso e tiveram acesso ao depoimento, o empresário não explica como sabe que as despesas de hospedagem de R$ 22 mil se referiam ao assessor de Humberto ou os motivos pelos quais foram pagas, mas apresentou como comprovante um recibo emitido pela empresa Aeroway, uma operadora de turismo com sede em Fortaleza, no Ceará. </FONT></p>
<p><P><FONT face=Verdana>“Desconheço essa história, confio nos meus assessores diretos. Estive de fato com José A?rton em quase todas as vezes que fui ao Ceará, porque ele é um representante do PT no Estado, mas nunca discuti liberações de recursos para ambulâncias com ele???, defendeu-se Humberto Costa. </FONT></p>
<p><P><FONT face=Verdana>Os documentos e comprovantes apresentados por Vedoin em seu depoimento ainda precisam ser checados em investigações pela Pol?cia Federal e pela CPI das Sanguessugas,</p>
<p> que recebeu a documentação da Justiça na última semana.</B></I> </FONT></P></DIV></FONT></p>
<p><P><FONT face=Verdana></FONT></P></FONT></FONT> </p>
