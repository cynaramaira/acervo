---
id: 12372217
data_publicacao: "2006-07-22 19:04:00"
data_alteracao: "None"
materia_tags: "Humberto Costa"
categoria: "Notícias"
titulo: "Humberto retribui"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>O ex-ministro da Saúde devolveu a generosidade de Eduardo. </FONT></P></p>
<p><P><FONT face=Verdana>No discurso que acaba de encerrar, fez questão de puxá-lo para seu lado e afirmou, dirigindo-se a Lula:</FONT></P></p>
<p><P><FONT face=Verdana>\"Presidente, firmo agora um compromisso com o sr. Aqui estão duas candidaturas aliadas. E quem está esperando por briga não vai ver, não.\" Todos se juntaram a Eduardo nos aplausos. \"Estamos tranqüilos. Não vai ter briga\", concluiu.</FONT></P></p>
<p><P><FONT face=Verdana>Agora, é esperar para ver o que não vai sair nos guias de Lula, Humberto e Eduardo.</FONT></P></FONT> </p>
