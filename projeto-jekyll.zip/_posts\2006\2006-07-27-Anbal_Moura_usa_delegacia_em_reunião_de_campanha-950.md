---
id: 12372123
data_publicacao: "2006-07-27 07:11:00"
data_alteracao: "None"
materia_tags: "campanha,Mourão,reunião"
categoria: "Notícias"
titulo: "An?bal Moura usa delegacia em reunião de campanha"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Mônica Crisóstomo</STRONG><BR></FONT><FONT face=Verdana>Repórter do JC</FONT></P></p>
<p><P><FONT face=Verdana>Embora esteja licenciado de suas atividades profissionais, em cumprimento à legislação eleitoral, o delegado e ex-chefe da Pol?cia Civil, An?bal Moura (PSDB) - que disputa uma vaga na Assembléia Legislativa -, continua freqüentando, rotineiramente, as delegacias da Região Metropolitana do Recife. Segundo fontes ligadas à Pol?cia, o tucano estaria realizando reuniões pol?ticas com aliados e cabos eleitorais nas sedes dos distritos.</FONT></P></p>
<p><P><FONT face=Verdana>Ontem, depois de receber informações sobre a ida de An?bal Moura à delegacia do Ipsep, a reportagem do <B>Jornal do Commercio</B> esteve no local, constatou sua presença e confirmou a realização de uma reunião entre ele, o titular da delegacia, Ocidir Pote Vale, e pelo menos outras três pessoas. O candidato, no entanto, negou o caráter pol?tico do encontro. \"Fiz uma visita a um policial amigo. Conversamos e depois fomos almoçar. Sou ético e decente em tudo o que faço. Jamais faria campanha dentro de uma delegacia. O problema é que a minha candidatura está incomodando muita gente e por isso esse tipo de denúncia aparece. Mas é tudo sem sentido\", destacou.</FONT></P></p>
<p><P><FONT face=Verdana>Depois de aproximadamente uma hora e meia de permanência no local, An?bal Moura deixou a delegacia acompanhado do delegado Ocidir - que em 2002 foi candidato ao Senado pelo PAN - e um outro homem. Os três seguiram no automóvel Honda Civic, de placa KLI</p>
<p> 1805, registrado do Detran em nome de An?bal Moura. </FONT></P></p>
<p><P><FONT face=Verdana>Após menos de dois minutos, uma mulher e um rapaz - que carregava vários cartazes dobrados, também deixaram a delegacia. Nenhum dos dois quis se identificar. A mulher, no entanto, afirmou que a dupla trabalhava na campanha de An?bal e que teria ido ao distrito para participar de uma reunião. Ao ser abordado pela equipe de reportagem, visivelmente nervoso, o rapaz deixou um dos cartazes se abrir e a foto de An?bal ficou vis?vel. </FONT></P></p>
<p><P><FONT face=Verdana>Questionado sobre o destino do material de campanha, o rapaz recusou-se a falar e saiu apressado. O tucano confirmou que tem feito visitas rotineiras nas delegacias da RMR, mas sem caráter eleitoral. \"Estou indo conversar com amigos. Não existe legislação que diga que isso é proibido. Já disse e repito, não sou nenhuma criança para cometer atos de ilegais, sejam eles eleitorais ou não\", sentenciou.</FONT></P> </p>
