---
id: 12371933
data_publicacao: "2006-08-04 14:28:00"
data_alteracao: "None"
materia_tags: "comércio,geraldo Alckmin,Itamaraty"
categoria: "Notícias"
titulo: "Itamar foi comer a cabidela com Alckmin"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Jarbas Vasconcelos só chegou no final do almoço, no Mourisco, em Olinda.</FONT></P></p>
<p><P><FONT face=Verdana>Itamar, não. O ex-presidente comeu com Alckmin e&nbsp;se divertiu. Os dois estão de muito bom humor.</FONT></P></p>
<p><P><FONT face=Verdana>Estão saindo agora para o centro de convenções, onde o tucano vai apresentar suas promessas de um novo</p>
<p> Nordeste, ao lado do senador José Jorge (à esquerda).</FONT></P> </p>
