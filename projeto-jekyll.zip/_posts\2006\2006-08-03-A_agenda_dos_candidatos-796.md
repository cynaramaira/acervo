---
id: 12371969
data_publicacao: "2006-08-03 06:50:00"
data_alteracao: "None"
materia_tags: "candidatos,reagendamentos"
categoria: "Notícias"
titulo: "A agenda dos candidatos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><B><FONT size=2><FONT face=Verdana>MENDONÇA FILHO (PFL)</FONT></P></B></FONT><FONT size=2></p>
<p><P><FONT face=Verdana><B>Às 20h30</B>, janta com lideranças pol?ticas de Pesqueira, no Hotel Estação Cruzeiro. Acompanham Mendonça o candidato a vice-governador, Evandro Avelar, e o candidato ao Senado, Jarbas Vasconcelos (PMDB). </FONT></P><B></p>
<p><P><FONT face=Verdana>Às 22h</FONT></B><FONT face=Verdana>, participa das festividades do Circuito do Frio de Pesqueira. </FONT></P></FONT><B><FONT face=Verdana size=2></p>
<p><P>HUMBERTO COSTA (PT)</P></FONT><FONT size=2></p>
<p><P><FONT face=Verdana>Às 14h30</FONT></B><FONT face=Verdana>, participa de debate com estudantes e professores da Universidade Federal de Pernambuco (UFPE), no auditório do Centro de Filosofia e Ciências Humanas (14º andar).</FONT></P><B></p>
<p><P><FONT face=Verdana>Às</FONT></B><FONT face=Verdana> <B>18h</B>, inaugura do comitê da chapa majoritária <EM>Melhor pra Pernambuco,</EM> em Paulista,<EM>&nbsp;</EM>e participa do ato de filiação do vereador Jorge Carrero ao PT, na Rua Floriano Peixoto, 41, Centro. </FONT></P><B></p>
<p><P><FONT face=Verdana>Às 20h</FONT></B><FONT face=Verdana>, participa da inauguração do comitê de Jarbas Trindade, na Avenida Caxangá, 2105. </FONT></P><B></p>
<p><P><FONT face=Verdana>Às 20h30</FONT></B><FONT face=Verdana>, participa da inauguração do comitê do deputado federal e candidato à reeleição Paulo Rubem (PT), na Rua Visconde de Suassuna, 677, Boa Vista. </FONT></P><B></p>
<p><P><FONT face=Verdana>EDUARDO CAMPOS (PSB)</FONT></P></B></p>
<p><P><FONT face=Verdana><STRONG>Às 9h</STRONG>, promove caminhada na feira Santo Elias (Prazeres) e pelas ruas de Cajueiro Seco, em Jaboatão dos Guararapes. A concentração é em frente ao Bandepe da Avenida Barreto de Menezes.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Às 18h</STRONG>, participa da inauguração do comitê da candidata a deputada federal Ana Arraes, na Rua Dianópolis, 93, Cordeiro.<BR><BR><STRONG>Às 19h</STRONG>, participa da inauguração do comitê do candidato a deputado estadual Waldemar Borges.<BR><BR><STRONG>Às 20h</STRONG>, participa da inauguração do comitê do candidato a deputado federal Fernando Bezerra Filho, na Estrada do Encanamento, Casa Forte.</FONT></P></FONT><A href=\"https://www.jc.com.br/\" target=_blank><STRONG><EM></EM></STRONG></A> </p>
