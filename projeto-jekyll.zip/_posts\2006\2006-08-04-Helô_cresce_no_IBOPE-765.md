---
id: 12371938
data_publicacao: "2006-08-04 11:37:00"
data_alteracao: "None"
materia_tags: "Ibope"
categoria: "Notícias"
titulo: "Helô cresce no IBOPE"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG><EM><A href=\"https://noblat1.estadao.com.br/noblat/index.html\" target=_blank>blog</A></EM></STRONG> de Noblat</FONT></P></p>
<p><P><FONT face=Verdana>Pesquisa IBOPE aplicada entre os últimos dias 29 e 31 de julho e que acaba de ser divulgada em Bras?lia pela Confederação Nacional da Industria:</FONT></P></p>
<p><P><FONT face=Verdana>Lula - 44%</FONT></P></p>
<p><P><FONT face=Verdana>Alckmin - 25%</FONT></P></p>
<p><P><FONT face=Verdana>Helô - 11%</FONT></P></p>
<p><P><FONT face=Verdana>Cristovam - 1%</FONT></P></p>
<p><P><FONT face=Verdana>Luciano Bivar - 1%</FONT></P></p>
<p><P><FONT face=Verdana>Eymael e Rui Costa Pimenta - 0%</FONT></P></p>
<p><P><FONT face=Verdana>Brancos e nulos - 9&amp;</FONT></P></p>
<p><P><FONT face=Verdana>Não soube responder - 9%</FONT></P></p>
<p><P><FONT face=Verdana>Amostra: 2002 pessoas em 142 munic?pios.</FONT></P></p>
<p><P><FONT face=Verdana>Na pesquisa IBOPE/TV Globo aplicada entre 22 e 24 de julho último, Lula tinha 44%, Alckmin 27%, Helo?sa 8%, Cristovam, Eymael e Rui Costa 1% cada. Bivar, 0%.</FONT></P><FONT face=Verdana></p>
<p><P>Leia <STRONG><EM><A href=\"https://noblat1.estadao.com.br/noblat/index.html\" target=_blank>aqui</A></EM></STRONG> os números completos.</P></FONT> </p>
