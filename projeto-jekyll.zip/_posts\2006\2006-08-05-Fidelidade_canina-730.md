---
id: 12371903
data_publicacao: "2006-08-05 20:42:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Fidelidade canina"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>O presidenciável Cristovam Buarque (PDT) não pode ver um cachorrinho que se derrete. Foi o que ele mesmo revelou na sua rápida passagem pelo Mercado da Madalena, hoje. </FONT></P></p>
<p><P><FONT face=Verdana>E, por pouco,&nbsp;Cristovam não esbarrou com Mendonça Filho (PFL) e Jarbas Vasconcelos (PMDB), que deixavam o mercado por volta das 11h30, momento em que Cristovam chegava. </FONT></P></p>
<p><P><FONT face=Verdana>No mercado, o pedetista gravou cenas para o seu guia eleitoral. Teve até brinde com eleitores e prova de caldinho de feijão. </FONT></P></p>
<p><P><FONT face=Verdana>Mas foi em uma churrascaria chique do Recife que&nbsp;o pedetista almoçou, junto a aliados. \"Não vai entrar um centavo desse almoço em minha campanha\", garantiu Cristovam, ex-companheiro e ex-ministro do presidente Lula (PT). Saiu a R$ 35 por pessoa.&nbsp;&nbsp;</FONT></P></p>
<p><P><FONT face=Verdana>Lá, chamou a atenção o entusiasmo de João Braga, ex-secretário de Defesa Social (Governo Jarbas) e agora candidato a deputado estadual pelo PV, pela candidatura do pedetista. \"Na minha fam?lia todo mundo vota em você, Cristovam\", disse Braga. </FONT></P></p>
<p><P><FONT face=Verdana>\"Apóio Mendonça e Jarbas, mas meu partido liberou todos para as alianças estaduais\", explicou o ex-secretário aliancista, à Cláudia Vasconcelos, repórter de Pol?tica do JC.</FONT>&nbsp; </P> </p>
