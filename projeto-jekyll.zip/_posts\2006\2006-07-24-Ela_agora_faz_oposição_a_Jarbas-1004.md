---
id: 12372177
data_publicacao: "2006-07-24 13:15:00"
data_alteracao: "None"
materia_tags: "jarbas vasconcelos,Oposição"
categoria: "Notícias"
titulo: "Ela agora faz oposição a Jarbas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Cec?lia Ramos<BR></STRONG>Repórter do Blog</FONT></P></p>
<p><P><FONT face=Verdana>Ela é linda, jovem, solteira e candidata a uma vaga na Assembléia Legislativa de Pernambuco. Aos 21 anos, Débora Daggy resolveu que quer seguir carreira pol?tica. Trocou os antigos trajes m?nimos por tailleur e agora freqüenta as reuniões de partido. </FONT></P></p>
<p><P><FONT face=Verdana>Nesta entrevista exclusiva ao <B>Blog do JC</B>, ela confessa que foi miss Pernambuco aos 16 anos, quando a idade m?nima permitida era 18. Para todos dizia ser mais velha.</FONT></P></p>
<p><P><FONT face=Verdana>Na época, namorava o ex-governador Jarbas Vasconcelos (PMDB), com quem ficou por dois anos e quatro meses. </FONT></P></p>
<p><P><FONT face=Verdana>Jarbas era também uma das razões para esconder a idade. \"Não ficava bem, né? Naquela época eu também era a primeira-dama\", confessou, explodindo numa crise de riso. </FONT></P></p>
<p><P><FONT face=Verdana>Aqui no <B>Blog</B>, Débora fala sobre seu projeto eleitoral, diz que quer \"mexer com leis\". Seu único problema é ter entrado na pol?tica por meio do PSB de Eduardo Campos, candidato ao governo de Pernambuco e inimigo figadal de Jarbas.</FONT></P></p>
<p><P><B><FONT size=2><FONT face=Verdana>Por que você decidiu se filiar ao PSB?</FONT></P></B></p>
<p><P><FONT face=Verdana>Escolhi um partido da oposição mais por conta da história do PSB. Também tenho uma grande admiração por Miguel Arraes. Ele tem uma história legal, era honesto. Ele foi um homem muito bom, que ajudou quem mais precisava. Fui sozinha até a sede do partido, em setembro do ano passado. Estava tendo uma festa. Entrei e fui falando com as pessoas, dizendo que queria me filiar. Lá, me apresentaram a Eduardo Campos e ele reconheceu que eu era miss e pediu para eu me apresentar ao partido. Disseram que eu fui para o PSB para me vingar de Jarbas.</FONT></P><B></p>
<p><P><FONT face=Verdana>E foi vingança?</FONT></P></B></p>
<p><P><FONT face=Verdana>Na época que eu me filiei, em setembro do ano passado, algumas pessoas entenderam como se fosse uma vingança contra Jarbas. Até liguei para ele. Disse a Jarbas que não tinha nada a ver com vingança e ele falou que eu podia ficar tranquila, porque ele me conhecia e sabia que não era aquilo. Eu já era filiada ao PSC, desde a época que eu disputei o Miss Pernambuco, em 2001. E desde essa época falavam que eu tinha jeito para ser pol?tica e surgiu até a idéia de me lançarem para vereadora, mas eu só tinha 16 anos.</FONT></P><B></p>
<p><P><FONT face=Verdana>Então você foi Miss Pernambuco antes da idade permitida?</FONT></P></B></p>
<p><P><FONT face=Verdana>(Risos)... É... Na verdade eu tinha 16 anos. (Pausa longa)... Mas a produção do concurso me apoiou, minha familia também. Eu falava que eu tinha 18 anos. Era uma confusão danada, porque às vezes eu esquecia a idade que eu tinha falado nas entrevistas e terminava mudando e falava 17, 18, 19 anos. (Sorrisos marotos)... Não ficava bem, né? Naquela época eu também era a primeira-dama...(mais risos).</FONT></P><B></p>
<p><P><FONT face=Verdana>O que não ficava bem?</FONT></P></B></p>
<p><P><FONT face=Verdana>(Faz outra pausa)... Acho que era ruim para imagem de Jarbas. Mas ninguém nunca me falou nada sobre a idade, para mentir ou qualquer coisa assim. Eu é que dizia que era maior de idade por causa do concurso (ri mais um pouco). Eu não me incomodava com diferença de idade. Eu me sentia bem ao lado de Jarbas, que sempre foi um homem muito educado. Nosso relacionamento foi assunto nacional e é lógico que isso abriu portas. Até quando eu fui me filiar no PSB foi uma repercussão grande. Eu sei que é porque eu namorei com ele. Foram dois anos e quatro meses. A gente começou quando eu terminei o segundo grau, eu ia f</FONT><FONT face=Verdana>azer 17 anos (volta a gargalhar, tentando se conter)...</FONT></P><B></p>
<p><P><FONT face=Verdana>Como está sua campanha?</FONT></P></B></p>
<p><P><FONT face=Verdana>Ainda estou me organizando, começando aos pouquinhos. Vou investir na Região Metropolitana do Recife, porque é onde eu conheço mais as pessoas. Ainda não defini com quem vou fazer dobradinha (que candidato a deputado federal apoiará). Vou analisar quem tem mais chances de ganhar, quem tem mais voto.</FONT></P><B></p>
<p><P><FONT face=Verdana>E você acompanha os assuntos pol?ticos?</FONT></P></B></p>
<p><P><FONT face=Verdana>Leio os jornais todos os dias, especialmente sobre os temas de pol?tica. Ainda mais agora que decidi ser deputada. </FONT></P><B></p>
<p><P><FONT face=Verdana>O que você pretende fazer, caso eleita?</FONT></P></B></p>
<p><P><FONT face=Verdana>Quero criar leis. Penso em atuar nas áreas de educação e cultura, porque os jovens de hoje precisam disso. Eu ainda estou discutindo esses assuntos com as pessoas próximas a mim, alguns amigos, deputados e minha fam?lia. Só não quero citar nomes. Eu não tenho uma equipe. Sigo tudo da minha cabeça e da minha vontade.</FONT></P><B></p>
<p><P><FONT face=Verdana>Onde você quer chegar na pol?tica?</FONT></P></B></p>
<p><P><FONT face=Verdana>Eu quero ser deputada federal porque estadual é uma função muito restrita. Não pode mexer com lei. Quero melhorar o ensino estadual e igualar com o particular. Da 5ª à 8ª série estudei em escola pública, então eu sei bem o que é não ter professor na sala de aula, falta de estrutura e desorganização.</FONT></P><B></p>
<p><P><FONT face=Verdana>Quem são suas referências na pol?tica?</FONT></P></B></p>
<p><P><FONT face=Verdana>Miguel Arraes e Jarbas Vasconcelos.</FONT></P><B></p>
<p><P><FONT face=Verdana>Qual é o seu contato com Eduardo Campos?</FONT></P></B></p>
<p><P><FONT face=Verdana>A gente nunca sentou para conversar. Só nos falamos socialmente. Vou trabalhar para ele ser eleito. Eu acompanho a trajetória dele pelos jornais. Quando fui me filiar no PSB foi ele quem deu o aval. </FONT></P><B></p>
<p><P><FONT face=Verdana>Você tem acompanhado os eventos de campanha de Eduardo?</FONT></P></B></p>
<p><P><FONT face=Verdana>Desde que me filiei, em setembro do ano passado, só fui a um evento. Participei de um movimento para festejar o Dia da Mulher e exigir os direitos das mulheres. Foi em</p>
<p> frente ao Palácio das Princesas. Mas eu não entrei lá, não (não contém o riso)... Agora me deram a agenda de Eduardo e vou começar a acompanhar alguns eventos.</FONT></P><B></p>
<p><P><FONT face=Verdana>Você tem freqüentado a Assembléia Legislativa de Pernambuco?</FONT></P></B></p>
<p><P><FONT face=Verdana>Eu já, algumas vezes. Por exemplo, fiz questão de acompanhar a votação da Lei Seca, porque é um assunto muito polêmico.</FONT></P><B></p>
<p><P><FONT face=Verdana>Depois que você decidiu entrar para a pol?tica, o assédio aumentou?</FONT></P></B></p>
<p><P><FONT face=Verdana>Nada fora do normal. Os pol?ticos se aproximam como os homens comuns, como qualquer um chega. E eu também não dou cabimento.</FONT></P><B></p>
<p><P><FONT face=Verdana>Você já fez cirurgia plástica?</FONT></P></B></p>
<p><P><FONT face=Verdana>Com 18 anos, coloquei 180 ml de silicone e fiz lipoaspiração. Fiz o pacote completo!</FONT></P><B></p>
<p><P><FONT face=Verdana>Como é sua rotina?</FONT></P></B></p>
<p><P><FONT face=Verdana>De manhã vou para a academia. Preciso perder oito quilos. Descuidei um pouquinho e preciso emagrecer porque preciso estar preparada para o Recife Fashion. De tarde faço os trabalhos como modelo. Meus horários são complicados, porque não tem uma coisa fixa. De noite faço faculdade de Direito. Eu não estou namorando e não tenho sa?do muito. Não sou de balada. Prefiro ir para os eventos, aniversários, praia, barzinho...</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P></FONT><B></p>
<p><P><FONT face=Verdana>O QUE DÉBORA DAGGY PENSA SOBRE:</FONT></P></p>
<p><P><FONT face=Verdana>LULA</FONT></P></B></p>
<p><P><FONT face=Verdana>Ele é um vencedor. Um pernambucano que nao é intelectual e conseguiu chegar onde chegou. Ele conseguiu muita coisa para Pernambuco. Agora eu sei que Lula ficou em cima do muro, tentando ajudar os empresarios e o povo pobre.</FONT></P><B></p>
<p><P><FONT face=Verdana>JARBAS VASCONCELOS </FONT></P></B></p>
<p><P><FONT face=Verdana>É uma pessoa honesta, boa, muito dedicada ao trabalho. Ele foi fundamental para o desenvolvimento de Pernambuco. </FONT></P><B></p>
<p><P><FONT face=Verdana>EDUARDO CAMPOS </FONT></P></B></p>
<p><P><FONT face=Verdana>É o meu candidato a governador. É o mais preparado para governar o Estado. Ele tem futuro. Eduardo é um homem educado, inteligente e eu também acho ele bonito (risos). </FONT></P><B></p>
<p><P><FONT face=Verdana>POL??TICA </FONT></P></B></p>
<p><P><FONT face=Verdana>É um meio de transformar uma realidade. O pol?tico pode interferir na vida das pessoas, ajudar a mudar o que está errado. </FONT></P><B></p>
<p><P><FONT face=Verdana>POSAR NUA </FONT></P></B></p>
<p><P><FONT face=Verdana>Não sei. Pelo meu trabalho de modelo, seria uma coisa normal, mas agora que quero ser deputada, não acho um bom momento.</FONT></P><B></p>
<p><P><FONT face=Verdana>DIFERENÇA DE IDADE </FONT></P></B></p>
<p><P><FONT face=Verdana>Normal. Hoje em dia não vejo nada demais. Acho que as pessoas se acostumam.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>FICHA TÉCNICA</STRONG></FONT></P><FONT size=2></p>
<p><P><FONT face=Verdana><STRONG>Nome completo</STRONG>: Débora Michelle Araújo Daggy</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Idade</STRONG>: 21 anos</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Peso</STRONG>: 64 kg</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Tempo de profissão</STRONG>: 7 anos</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Estado civil</STRONG>: solteira. O último namorado foi um colega de faculdade</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Sonho de consumo</STRONG>: uma casa em Fernando de Noronha</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Profissão</STRONG>: modelo e aluna do 4º per?odo de Direito</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Homem bonito</STRONG>: Tom Cruise</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Homem ideal</STRONG>: carinhoso, leal, companheiro e educado</FONT></P></FONT> </p>
