---
id: 12372033
data_publicacao: "2006-07-31 18:20:00"
data_alteracao: "None"
materia_tags: "governo,Presidente"
categoria: "Notícias"
titulo: "Presidente da OAB comemora derrota do governo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Júlio Oliveira, presidente da OAB em Pernambuco, comemora a derrota do governo na eleição da lista tr?plice para nomeação do novo desembargador do Tribunal de Justiça. (Leia mais, abaixo,&nbsp;na nota <EM><STRONG>Os três poderes de Jarbas e Mendonça</STRONG></EM>).</FONT></P></p>
<p><P><FONT face=Verdana>Ele trabalhou desde o primeiro momento para excluir Pedro Henrique Alves, candidato de Jarbas e Mendonça, das listas sêxtupla e tr?plice.</FONT></P></p>
<p><P><FONT face=Verdana>Chegou até a montar uma chapinha, com seis nomes, e por pouco não deixou PH fora. Ele ficou em 6º, a poucos votos do sétimo, Carlos Gil Rodrigues (leia <STRONG><EM><A href=\"https://jc3.uol.com.br/blogs/jc/2006/07/28/index.php#316\" target=_blank>aqui</A></EM></STRONG> sobre a eleição na OAB).</FONT></P></p>
<p><P><FONT face=Verdana>Nesta entrevista ao Blog, Júlio ressaltou a independência do Tribunal de Justiça:</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>O que significa a escolha de Jorge Neves, Francisco Bandeira e Edgar Moury?</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Representa o respeito a uma lista que foi enviada pela Ordem. Na eleição que realizamos, Neves ficou em primeiro, como agora, Bandeira também, em segundo. Só Edgard que agora ficou em terceiro, mas na Ordem estava em 4º.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>O governo saiu derrotado?</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>O Tribunal foi sábio e mostrou que não aceita imposição do governo, mostrou independência. O governo fez dessa eleição um cabo de guerra, sem necessidade. A lição que tiramos disso é que não vivemos mais num mundo de imposições. </FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Quem é o seu preferido agora, Francisco Bandeira, que é seu sócio?</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Bandeira é meu sócio há 16 anos -&nbsp;é uma sociedade formal, devidamente constitu?da. Ele é uma pessoa que tem qualificações, mas minha ligação com Jorge Neves também é muito importante. Me sinto representado com quem for</p>
<p> nomeado. Todos três representam nosso grupo pol?tico.</FONT></P> </p>
