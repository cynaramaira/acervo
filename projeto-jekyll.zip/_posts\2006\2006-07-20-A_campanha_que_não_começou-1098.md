---
id: 12372271
data_publicacao: "2006-07-20 02:50:00"
data_alteracao: "None"
materia_tags: "campanha,Naomi Campbell"
categoria: "Notícias"
titulo: "A campanha que não começou"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Os pernambucanos não estão muito interessados em eleição. A pesquisa JC/Vox Populi, que vem sendo publicada ao longo desta semana no JC, mostra hoje que 54% da população revela pouco ou nenhum interesse pela disputa. A divisão é a seguinte: 32% têm pouco interesse; 22%, nenhum.</FONT></P></p>
<p><P><FONT face=Verdana>Esses dados, analisados por Sérgio Montenegro Filho, repórter especial do JC, traduzem muito bem como essa é uma campanha esquisita, marcada pelo medo de errar e sofrer sanções do Tribunal Eleitoral. </FONT></P></p>
<p><P><FONT face=Verdana>Engessada por regras de última hora, sem luz e festa, visto que estão proibidos outdoors, camisetas e diversos outros tipos de propaganda, a disputa simplesmente ficou sem empolgação.</FONT></P></p>
<p><P><FONT face=Verdana>Veja <B><A href=\"https://jc3.uol.com.br/especiais/eleicoes2006/\" target=_blank>aqui</A></B> os números completos.</FONT></P></FONT> </p>
