---
id: 12371930
data_publicacao: "2006-08-04 17:15:00"
data_alteracao: "None"
materia_tags: "jarbas vasconcelos,natação,proposta,Sinovac"
categoria: "Notícias"
titulo: "Jarbas ataca proposta de nova Constituinte"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Jarbas atacou duramente agora há pouco a idéia do presidente Lula de realizar, no próximo ano, caso seja reeleito,&nbsp;uma nova Assembléia Constituinte para promover a reforma pol?tica:</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>“Isso é uma invenção, tem alguma coisa por trás disso, porque é um processo paralisante, é querer desvirtuar as coisas, é uma ducha fria na reforma pol?tica???.</FONT></P> </p>
