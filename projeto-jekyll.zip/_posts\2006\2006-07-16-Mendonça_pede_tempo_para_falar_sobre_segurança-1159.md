---
id: 12372332
data_publicacao: "2006-07-16 17:29:00"
data_alteracao: "None"
materia_tags: "mendonça,Segurança,tempo"
categoria: "Notícias"
titulo: "Mendonça pede tempo para falar sobre segurança"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>O governador e candidato à reeleição Mendonça Filho pediu um tempo para analisar e comentar a pesquisa sobre Segurança Pública, divulgada hoje no jornal O Globo. A pesquisa mostra que Pernambuco é o 18º colocado no ranking de gasto público em segurança por habitante/ano, apesar de estar entre os três mais violentos do Pa?s - foram mais de 31 mil homic?dios nos sete anos e meio de gestão da União por Pernambuco. De Garanhuns, por meio da assessoria de imprensa, Mendonça comprometeu-se a falar com o blog sobre o tema, mas amanhã. Quanto às suas propostas de governo para a área, o pefelista disse que o assunto ainda está sendo \"cuidadosamente\" tratado pelos técnicos que elaboram o seu programa de governo. </P></FONT> </p>
