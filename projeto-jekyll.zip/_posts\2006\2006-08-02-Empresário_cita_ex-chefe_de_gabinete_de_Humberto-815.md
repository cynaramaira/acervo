---
id: 12371988
data_publicacao: "2006-08-02 09:07:00"
data_alteracao: "None"
materia_tags: "empresário,Humberto Costa"
categoria: "Notícias"
titulo: "Empresário cita ex-chefe de gabinete de Humberto"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><B></p>
<p><P><FONT face=Verdana>Por Marta Salomon e Adriano Ceolin</FONT></B><BR><FONT face=Verdana>Da Folha de S.Paulo</FONT></P></p>
<p><P><FONT face=Verdana>Em depoimento à Justiça Federal, o empresário Ronildo Pereira Medeiros, integrante da máfia dos sanguessugas, complicou a situação do atual secretário de gestão estratégica e participativa do Ministério da Saúde, Antonio Alves de Souza.</FONT></P></p>
<p><P><FONT face=Verdana>Segundo Medeiros, Souza seria \"a pessoa de contato\" do esquema no Ministério da Saúde quando ocupava a chefia de gabinete do então ministro Humberto Costa, hoje candidato do PT ao governo de Pernambuco.</FONT></P></p>
<p><P><FONT face=Verdana>Medeiros reiterou o que o empresário Luiz Antonio Vedoin, um dos l?deres do esquema, disse sobre a suposta participação de Souza na liberação de quase R$ 8 milhões de pagamentos bloqueados no in?cio do governo Lula para a compra de ambulâncias autorizada na gestão Fernando Henrique. </FONT></P></p>
<p><P><FONT face=Verdana>No primeiro momento, Humberto Costa teria recusado o pagamento e encaminhado o assunto ao chefe-de-gabinete.</FONT></P><FONT face=Verdana></p>
<p><P>(...)</P></FONT></p>
<p><P><FONT face=Verdana>Ontem, Souza reafirmou desconhecer os empresários que chefiavam a máfia: \"Não conheço os acusados Darci Vedoin, Luiz Antonio Vedoin e Ronildo Medeiros. Nunca os vi nem os recebi no Ministério da Saúde. Não tratei de liberação de emendas. Não estive em Fortaleza em julho de 2003 e nunca recebi qualquer vantagem ou pagamento de viagem por parte dos acusados\".</FONT></P></p>
<p><P><FONT face=Verdana>Até ontem à noite, o ministro da Saúde, Agenor ??lvares, dizia que não há motivos para afastar Souza: \"Ele não tem nada a ver com isso, está até muito revoltado e deprimido. As denúncias não têm a menor procedência\".</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.uol.com.br/fsp\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinantes).</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://jc3.uol.com.br/blogs/jc/2006/07/21/index.php#180\">aqui</A></EM></STRONG> o que o <STRONG>Blog</STRONG> publicou sobre o assunto, em 21 de julho.</FONT></P> </p>
