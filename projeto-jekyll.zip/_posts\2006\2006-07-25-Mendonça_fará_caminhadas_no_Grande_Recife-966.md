---
id: 12372139
data_publicacao: "2006-07-25 10:54:00"
data_alteracao: "None"
materia_tags: "grande recife,mendonça"
categoria: "Notícias"
titulo: "Mendonça fará caminhadas no Grande Recife"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do Jornal do Commercio</FONT></P></p>
<p><P><FONT face=Verdana>Uma nova estratégia de campanha de rua deve ser adotada pelo governador e candidato à reeleição, Mendonça Filho, a partir da segunda semana de agosto. Os coordenadores da coligação União por Pernambuco, que se reuniram ontem para definir a agenda de campanha das próximas semanas, decidiram propor a Mendonça Filho que passe a fazer caminhadas, à noite, de segunda a sexta-feira, no Recife e demais munic?pios da Região Metropolitana. Nos finais de semana, a agenda de viagens pelo interior do estado será mantida. </FONT></P></p>
<p><P><FONT face=Verdana>O governador-candidato, que não esteve na reunião de ontem, recomendou que quer manter o mesmo ritmo de trabalho, ou seja, dedicar o dia à administração do governo de Pernambuco, e fazer campanha somente após o expediente e nos finais de semana.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></STRONG> matéria completa (assinantes JC e Uol).</FONT></P> </p>
