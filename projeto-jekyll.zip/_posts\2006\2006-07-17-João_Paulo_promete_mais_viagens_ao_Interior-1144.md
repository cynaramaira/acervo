---
id: 12372317
data_publicacao: "2006-07-17 10:46:00"
data_alteracao: "None"
materia_tags: "interior,joão d,Paulo,Viagens"
categoria: "Notícias"
titulo: "João Paulo promete mais viagens ao Interior"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Coordenador das campanhas de Humberto e de Lula em Pernambuco, o prefeito do Recife diz que fará o poss?vel para acompanhar seus candidatos na Região Metropolitana e no Interior, como fez ontem no Agreste e no Sertão. João Paulo explicou ainda que o local onde será realizado o primeiro grande com?cio de Lula no Recife ainda não foi definido. Será no próximo sábado, às 17h.</P></p>
<p><P>Ouça o que ele disse a Geraldo Freire, logo cedo, na Rádio Jornal.</P></FONT> </p>
