---
id: 12371925
data_publicacao: "2006-08-04 19:43:00"
data_alteracao: "None"
materia_tags: "campanha,jarbas vasconcelos"
categoria: "Notícias"
titulo: "Jarbas promete engajamento na campanha"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Jarbas procurou ser enfático hoje, durante a apresentação do programa de Alckmin para o Nordeste, ao garantir que haverá engajamento na campanha do tucano.</FONT></P></p>
<p><P><FONT face=Verdana>\"Mesmo quem não queira, quem não chegou por aqui hoje, vai chegar. Não tenho a menor dúvida disso\", afirmou.</FONT></P></p>
<p><P><FONT face=Verdana>Para Jarbas, a falta de empenho dos aliados de Alckmin em Pernambuco e no Nordeste não existe, é coisa de imprensa.</FONT></P></p>
<p><P><FONT face=Verdana>A verdade é que Alckmin recebeu 16% de intenção de voto na última pesquisa JC/Vox Populi (veja <STRONG><EM><A href=\"https://jc3.uol.com.br/especiais/eleicoes2006/2006/07/18/not_266.php\" target=_blank>aqui</A></EM></STRONG> os números).</FONT></P></p>
<p><P><FONT face=Verdana>Jarbas na mesma pesquisa tem 66% para o Senado, percentual igual ao&nbsp;de Lula. Mendonça Filho, governador e&nbsp;candidato à reeleição, recebeu 35%.</FONT></P></p>
<p><P><FONT face=Verdana>Resumo dos números: a maioria dos eleitores de Jarbas e Mendonça&nbsp;está hoje disposta a votar&nbsp;em Lula, não em Alckmin.</FONT></P></p>
<p><P><FONT face=Verdana>E ninguém quer contrariar eleitores que não se interessam pelo tucano. Eles são muito numerosos.</FONT></P> </p>
