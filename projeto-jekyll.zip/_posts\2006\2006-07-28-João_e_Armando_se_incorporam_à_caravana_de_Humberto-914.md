---
id: 12372087
data_publicacao: "2006-07-28 19:59:00"
data_alteracao: "None"
materia_tags: "Armando Monteiro,Humberto Costa,joão d"
categoria: "Notícias"
titulo: "João e Armando se incorporam à caravana de Humberto"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>O prefeito do Recife, João Paulo Lima e Silva (PT), está chegando a Garanhuns com o deputado federal Armando Monteiro Neto (PTB) para dar um reforço na campanha de Humberto Costa (PT). </FONT></P></p>
<p><P><FONT face=Verdana>Os três acompanham o festival de inverno do camarote do deputado estadual Iza?as Régis (PTB). </FONT></P></p>
<p><P><FONT face=Verdana>A cinco reais por cabeça, Iza?as organizou uma barulhenta torcida para animar Humberto na visita às feiras de gado e livre de Capoeiras, cidade vizinha a Garanhuns.</FONT></P></p>
<p><P><FONT face=Verdana>Também nas redondezas, em São Bento do Una, foi organizado um encontro de lideranças pol?ticas com o cadidato petista. </FONT></P></p>
<p><P><FONT face=Verdana>As lideranças couberam em um único ônibus.</FONT></P> </p>
