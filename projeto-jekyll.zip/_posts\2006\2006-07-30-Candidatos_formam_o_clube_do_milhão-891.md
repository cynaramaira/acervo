---
id: 12372064
data_publicacao: "2006-07-30 09:40:00"
data_alteracao: "None"
materia_tags: "candidatos,JC Clube"
categoria: "Notícias"
titulo: "Candidatos formam o clube do milhão"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=Verdana></p>
<p><P>Por <STRONG>Jamildo Melo</STRONG><BR>Repórter especial do JC</P></p>
<p><P>A divulgação eletrônica da declaração de bens dos candidatos a cargos majoritários e proporcionais nestas eleições - realizada pela Tribunal Superior Eleitoral (TSE) pela primeira vez este ano, após o escândalo do mensalão - revelou a existência de um \"Clube do Milhão\" entre os 713 candidatos a deputado federal e estadual em Pernambuco. </P></p>
<p><P>O seleto grupo é formado por 28 nomes e representa 4% do total dos pretendentes à Câmara Federal e Assembléia Legislativa. Juntos, seu patrimônio declarado supera os R$ 120 milhões, de acordo com os registros do Tribunal Regional Eleitoral (TRE), pesquisados pela reportagem do JC.</P></p>
<p><P>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinantes JC e UOL).</P></FONT> </p>
