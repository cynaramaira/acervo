---
id: 12372172
data_publicacao: "2006-07-24 13:35:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Piauhylino desistiu prevendo a derrota"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Pois bem, desde o in?cio do mês o deputado federal Luiz Piauhylino e os parlamentares mais ligados a ele já sabiam que teria dificuldades para se reeleger e que desistiria da disputa.</FONT></P></p>
<p><P><FONT face=Verdana>O grupo fez e refez as contas sobre as chances de cada um. Tudo calculado a partir de dados concrestos, como apoios de prefeitos, ex-prefeitos, vereadores e l?deres pol?ticos locais, além de pesquisas de intenção de voto regionalizadas - exatamente para medir até que ponto esses apoios renderiam votos.</FONT></P></p>
<p><P><FONT face=Verdana>Com os dados nas mãos, Piauhylino decidiu abandonar a carreira pol?tica, após quatro mandatos de deputado federal e um curto per?odo no Senado (ele foi suplente de Mansueto de Lavor, nos anos 80).</FONT></P></p>
<p><P><FONT face=Verdana>Para sair de cena por cima, construiu-se essa desculpa de que a verticalização complica a situação dos candidatos. <STRONG><U><A href=\"https://jc3.uol.com.br/blogs/jc/2006/07/23/index.php#249\" target=_blank>Leia aqui</A></U></STRONG> nota postada ontem à noite.</FONT></P></FONT> </p>
