---
id: 12372351
data_publicacao: "2006-07-15 16:36:00"
data_alteracao: "None"
materia_tags: "eduardo,Humberto Costa,interior"
categoria: "Notícias"
titulo: "Eduardo perde para Humberto no Interior"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><TABLE cellSpacing=1 cellPadding=3 width=500 bgColor=#6ca7a6 border=0></p>
<p><TBODY></p>
<p><TR bgColor=#e0e4e5></p>
<p><TD><IMG height=20 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_titulo.gif\" width=144></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#000000 size=1><STRONG>CRUZAMENTO POR REGIÃO</STRONG></FONT><BR></p>
<p><TABLE cellSpacing=4 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR bgColor=#006666></p>
<p><TD>&nbsp;</TD></p>
<p><TD width=60></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>Capital/RM</FONT></STRONG></DIV></TD></p>
<p><TD width=60></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>Agreste</FONT></STRONG></DIV></TD></p>
<p><TD</p>
<p> width=60></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>Mata</FONT></STRONG></DIV></TD></p>
<p><TD width=60></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>Sertão/ São Francisco</FONT></STRONG></DIV></TD></p>
<p><TD width=50></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>Total</FONT></STRONG></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>Mendonça Filho (PFL) </STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>33%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>34%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>37%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>40%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>35%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>Humberto Costa(PT) </STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>26%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>24%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>17%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>17%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>22%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>Eduardo campos(PSB) </STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>20%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>22%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>26%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>16%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>21%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>Outros</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>4%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>4%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>2%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>-</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>3%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>Branco/ Nulo</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>10%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>7%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>8%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>2%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>7%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>NS / NR</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>8%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>10%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>12%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>26%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>12%</FONT></STRONG></FONT></DIV></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE> </p>
