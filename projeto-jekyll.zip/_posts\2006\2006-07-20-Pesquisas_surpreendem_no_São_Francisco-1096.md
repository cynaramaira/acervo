---
id: 12372269
data_publicacao: "2006-07-20 09:00:00"
data_alteracao: "None"
materia_tags: "Papa Francisco,pesquisas,são"
categoria: "Notícias"
titulo: "Pesquisas surpreendem no São Francisco"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Com 115 mil votos, Petrolina está entre os dez maiores colégios eleitorais do Estado e sempre foi um munic?pio complicado para a aliança União por Pernambuco. Jarbas perdeu ali as eleições de 1998 e 2002.</P></p>
<p><P>Há quatro anos perdeu de cabo a rabo. Deu Lula, Humberto, Carlos Wilson e Dilson Peixoto.</P></p>
<p><P>Pois neste ano as coisas podem mudar. </P></p>
<p><P>A pesquisa JC/Vox Populi, cujos resultados estão sendo divulgados ao longo desta semana pelo Jornal do Commercio, mostra que Mendonça Filho e Jarbas Vasconcelos têm seus melhores indicadores de intenção de voto e de aprovação justamente no Sertão do São Francisco, cuja principal cidade é Petrolina.</P></p>
<p><P>Mendonça tem 40% de intenções de voto na região. Mais do que sua média geral no Estado (35%). O São Francisco é melhor até mesmo que o Agreste, onde nasceu e tem bases. Veja <B><A href=\"https://jc3.uol.com.br/especiais/eleicoes2006/2006/07/15/not_249.php\">aqui</A></B> os números.</P><FONT size=2></p>
<p><P>Quanto à avaliação popular do governo dele, a região também se destaca. Ele conseguiu 41% de ótimo e bom, resultado que só não é melhor que o do Agreste, onde tem 48%. Mas supera a média no Estado, de 39%. Veja <B><A href=\"https://jc3.uol.com.br/especiais/eleicoes2006/2006/07/19/not_280.php\">aqui</A></B> os números.</P><FONT size=2></p>
<p><P>Com Jarbas a situação é ainda mais confortável. O São Francisco dá a ele 72% de intenções de votos. É disparado seu melhor ?ndice. Inclusive, supera o da Região Metropolitana do Recife em seis pontos percentuais. Veja <B><A href=\"https://jc3.uol.com.br/especiais/eleicoes2006/2006/07/17/not_261.php\">aqui</A></B> os números.</P></FONT></FONT></FONT> </p>
