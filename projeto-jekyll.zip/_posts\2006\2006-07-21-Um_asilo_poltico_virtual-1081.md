---
id: 12372254
data_publicacao: "2006-07-21 06:31:00"
data_alteracao: "None"
materia_tags: "galeria virtual"
categoria: "Notícias"
titulo: "Um asilo pol?tico virtual"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><H3 class=post-title><FONT face=Verdana>O mundo vai rolar de rir de nós</FONT></H3></p>
<p><DIV class=post-body></p>
<p><DIV><FONT face=Verdana>Por Alon Feuerwerker</FONT></DIV></p>
<p><DIV><FONT face=Verdana>(<STRONG><A href=\"https://blogdoalon.blogspot.com/\" target=_blank>Blog do Alon</A></STRONG>)</FONT></DIV></p>
<p><DIV><FONT face=Verdana></FONT>&nbsp;</DIV></p>
<p><DIV><FONT face=Verdana>Do site do TSE, na última terça-feira:<BR><BR><SPAN style=\"FONT-STYLE: italic\">\"Bras?lia, 18/07/2006 - O secretário-geral da executiva nacional do Partido Social Liberal (PSL), Ronaldo Nóbrega, protocolou Consulta junto ao Tribunal Superior Eleitoral (TSE) na qual questiona se os blogs podem opinar sobre os candidatos.<BR></SPAN><BR></FONT><FONT face=Verdana><SPAN style=\"FONT-STYLE: italic\">O secretário-geral do PSL quer saber se podem ser criados blogs, ou comunidades online em páginas de provedores de serviços de acesso à internet, que venham opinar sobre candidatos.<BR></SPAN><BR><SPAN style=\"FONT-STYLE: italic\">Ele também pergunta se os sites mantidos pelos partidos pol?ticos e os sites pessoais de candidatos na internet podem redirecionar o internauta para a página de dom?nio do candidato do partido para as eleições (<A href=\"https://www.nomedocandidato.can.br/\">www.nomedocandidato.can.br</A>).<BR></SPAN><BR><SPAN style=\"FONT-STYLE: italic\">O artigo 71 da Resolução 22.261 do TSE dispõe que os candidatos poderão manter página na internet com a terminação can.br, ou com outras terminações, como mecanismo de propaganda eleitoral.\"</SPAN><BR><BR>Essa questão não me atinge. Meu blog está hospedado nos Estados Unidos (blogger.com), onde não pode ser alcançado por consultas como a do senhor Nóbrega. Se o TSE responder que os blogs estão proibidos de opinar sobre as eleições, minha sugestão é que todos façam como eu: busquem asilo pol?tico virtual em outros pa?ses, onde o processo civilizatório tenha caminhado mais do que aqui. Vamos instalar os blogs no </FONT><A href=\"https://www.google.com/\"><FONT face=Verdana color=#5588aa>Google</FONT></A><FONT face=Verdana>, no </FONT><A href=\"https://www.wordpress.com/\"><FONT face=Verdana color=#5588aa>Wordpress</FONT></A><FONT face=Verdana> e outros. À luta, meus camaradas!</FONT><BR></DIV></DIV> </p>
