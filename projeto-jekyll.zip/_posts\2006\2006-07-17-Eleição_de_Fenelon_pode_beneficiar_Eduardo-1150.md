---
id: 12372323
data_publicacao: "2006-07-17 08:06:00"
data_alteracao: "None"
materia_tags: "beneficiários,eduardo,eleição"
categoria: "Notícias"
titulo: "Eleição de Fenelon pode beneficiar Eduardo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Goiana tem 51,5 mil eleitores. É um razoável colégio eleitoral - do tamanho, por exemplo, de Serra Talhada, terra do deputado estadual Augusto César (PTB), vice de Humberto Costa. Mas Eduardo apoiou Henrique Fenelon, que é do PCdoB, partido responsável pela indicação de Luciano Siqueira ao Senado na chapa de Humberto. Apesar de os comunistas serem disciplinados, a disputa no munic?pio afasta o prefeito eleito do PT. Os petistas não aceitaram apoiá-lo. Preferiram lançar candidato próprio, Paulo Veloso, que teve apenas 1,8 mil votos.</P></p>
<p><P>Confirmada a vitória do comunista, no in?cio da noite, Eduardo correu para a festa em Goiana. Já havia estado lá na sexta-feira, no com?cio final da campanha. Com mais esse apoio, Eduardo passa a contar com o voto de seis prefeitos da Região Metropolitana do Recife (Goiana, Igarassu, Itapissuma, Paulista, Jaboatão e Vitória).</P></p>
<p><P>Mas nem tudo é automático nessa questão de atrair os eleitores. É em Goiana que o governo federal vai instalar a Hemobras, fábrica para produção de hemoderivados que deve transformar a economia local. Isso pode beneficiar Humberto. Foi ele quem viabilizou o empreendimento quando era ministro da Saúde.</P></FONT> </p>
