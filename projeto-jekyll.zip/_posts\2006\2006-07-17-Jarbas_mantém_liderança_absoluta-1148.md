---
id: 12372321
data_publicacao: "2006-07-17 08:09:00"
data_alteracao: "None"
materia_tags: "jarbas vasconcelos,liderança indígena"
categoria: "Notícias"
titulo: "Jarbas mantém liderança absoluta"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>O ex-governador continua com 59 pontos percentuais acima dos concorrentes Jorge Gomes (PSB) e Luciano Siqueira (PCdoB), juntos, conforme números que o Jornal do Commercio publica nesta segunda-feira.</P></p>
<p><P>Clique <A href=\"https://jc3.uol.com.br/especiais/eleicoes2006/\">aqui</A> para ver os números completos&nbsp;no&nbsp;site JC&nbsp;nas Eleições 2006.</P></FONT> </p>
