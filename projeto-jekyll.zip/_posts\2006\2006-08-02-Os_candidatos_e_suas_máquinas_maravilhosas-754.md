---
id: 12371927
data_publicacao: "2006-08-02 10:00:00"
data_alteracao: "None"
materia_tags: "Ariano Suassuna,candidatos"
categoria: "Notícias"
titulo: "Os candidatos e suas máquinas maravilhosas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P></p>
<p><P><FONT face=Verdana>Por </FONT><FONT face=Arial><FONT face=Verdana><STRONG>S?lvio Menezes</STRONG><BR>Repórter de Economia/Ve?culos do JC</FONT></P></p>
<p><P></P></p>
<p><P><FONT face=Verdana>Para enfrentar a maratona da campanha eleitoral, as grandes coligações de Pernambuco não travam apenas uma disputa em busca de bons assessores e cabos eleitorais eficientes. </FONT></P></p>
<p><P><FONT face=Verdana>Partidos endinheirados investem alto em carrões importados para garantir mais conforto, menor desgaste f?sico e maior segurança para o pol?tico nas viagens pelo Estado. Os ve?culos preferidos são picapes e utilitários da Toyota, Hyundai, Chevrolet, Kia e Mercedes-Benz. </FONT></P></p>
<p><P><FONT face=Verdana>Só no campo majoritário, dos nove postulantes ao governo de Pernambuco, pelo menos quatro deles estão prontos para pegar a estrada a bordo de máquinas de mais de R$ 100 mil. </FONT></P></p>
<p><P><FONT face=Verdana>Os partidos têm argumentos semelhantes para justificar a aquisição de carrões no trabalho. São unânimes em dizer que não basta ter um automóvel bonito. Ele precisa ser prático, potente, veloz, luxuoso, eficiente e útil, já que alguns dos candidatos chegam a ficar até dez horas por dia recluso num ve?culo em viagens da capital a cidades do interior. </FONT></P></p>
<p><P><FONT face=Verdana>Grande parte dessas qualidades está na Toyota Hilux SW4, a diesel, motor de 163 cavalos, banco de couro, câmbio automático, ano 2006, usada pelo candidato da União por Pernambuco Mendonça Filho(PFL).</FONT></P></p>
<p><P><FONT face=Verdana>Com gasto máximo de campanha estimado em R$ 15 milhões, o governador-candidato destinou R$ 7 mil mensais para pagamento do aluguel da caminhonete, avaliada em R$ 150 mil. </FONT></P></p>
<p><P><FONT face=Verdana>(...)</FONT></P></p>
<p><P><FONT face=Verdana>O candidato da frente Melhor pra Pernambuco, Humberto Costa (PT) é dono de um Uno Mille 2004 conforme a declaração dele ao Tribunal Regional Eleitoral (TRE), mas tem a disposição de sua campanha uma Hyundai Terracan, de R$ 120 mil. </FONT></P></p>
<p><P><FONT face=Verdana>Melhor: não custou um centavo à coligação. O carro foi emprestado por um militante e usado em 90% dos deslocamentos. Foram mais de 25 mil quilômetros percorridos da pré-campanha até hoje.</FONT></P></p>
<p><P><FONT face=Verdana>(...)</FONT></P></p>
<p><P><FONT face=Verdana>Se houvesse uma eleição para o quesito praticidade, o carro do candidato da Frente Popular de Pernambuco, Eduardo Campos (PSB), estaria eleito hoje. A Mercedes Sprinter de 12 lugares custou R$ 103 mil e foi comprada exclusivamente para ser usada na disputa. </FONT></P></p>
<p><P><FONT face=Verdana>Batizada de \"Dudu móvel\", a van, por fora, não difere muito das lotações do transporte alternativo nas grandes cidades. O espaço interno, no entando, sofreu pequenas adaptações para atender às necessidades do candidato. Ganhou bancos em couro com braços, aparelho de DVD e até um guardar roupas. </FONT></P></p>
<p><P><FONT face=Verdana>É usado ainda como escritório de reuniões com assessores e convidados durante as viagens.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Nanicos vão até de ônibus</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>A disputa dos l?deres das pesquisas pelo melhor carro está bem longe da travada pelos candidatos integrantes do chamado \"baixo clero\". Carro de luxo para essa turma nem em sonho. Diz que nem combina com a proposta deles. </FONT></P></p>
<p><P><FONT face=Verdana>E com orçamento apertado e previsão de gasto máximo na campanha estimado em R$ 15 mil (cada um deles), o Partido Socialista dos Trabalhadores Unificado (PSTU) improvisam nesta eleição para cumprir a agenda. </FONT></P></p>
<p><P><FONT face=Verdana>Vão a compromissos de carona no carro de amigos, em ve?culos bastante usados e até de ônibus.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://jc3.uol.com.br/jornal/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinantes JC e UOL).</FONT></P></FONT> </p>
