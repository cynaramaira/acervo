---
id: 12372073
data_publicacao: "2006-07-29 09:40:00"
data_alteracao: "None"
materia_tags: "cerveja,Contran,Humberto Costa"
categoria: "Notícias"
titulo: "Humberto perde no TRE contra a Veja"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG><BR><BR></FONT><FONT face=Verdana>O candidato da coligação Melhor pra Pernambuco</p>
<p> ao governo do Estado, Humberto Costa, sofreu ontem sua primeira derrota na batalha judicial que trava no TRE contra a revista Veja. </FONT></P></p>
<p><P><FONT face=Verdana>Alegando resguardo à liberdade de expressão do ve?culo, o desembargador Marco Maggi negou ao petista o pedido de liminar em que solicitava que fosse retirada do site da revista a matéria em que é acusado de envolvimento com o esquema dos sanguessugas, enquanto esteve à frente do Ministério da Saúde, e a apreensão dos exemplares impressos que ainda estivessem à venda.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></EM></STRONG> texto completo (assinantes JC e UOL).</FONT></P> </p>
