---
id: 12372143
data_publicacao: "2006-07-25 15:05:00"
data_alteracao: "None"
materia_tags: "Contestação,Desinformação,Humberto Costa"
categoria: "Notícias"
titulo: "Humberto contesta informação de Noblat"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>A assessoria do ex-ministro da Saúde Humberto Costa liga para comentar nota do blog de Noblat, reproduzida abaixo.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Nega que Humberto tenha sido citado por Luiz Vedoin, conforme entrevista do advogado do empresário (<STRONG><U><A href=\"https://jc3.uol.com.br/blogs/jc/2006/07/25/index.php#272\">leia aqui nota postada mais cedo</A></U></STRONG>).</FONT></P> </p>
