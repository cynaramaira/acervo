---
id: 12372355
data_publicacao: "2006-07-17 10:53:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Participe, vote"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Você acha que haverá caixa 2 nestas eleições?<BR><BR>198 disseram que sim, 14, não. Dê sua opinião na coluna ao lado.</P> </p>
