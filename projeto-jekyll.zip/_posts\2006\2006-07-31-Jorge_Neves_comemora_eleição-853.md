---
id: 12372026
data_publicacao: "2006-07-31 18:58:00"
data_alteracao: "None"
materia_tags: "eleição,jorge jesus,Mozart Neves"
categoria: "Notícias"
titulo: "Jorge Neves comemora eleição"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Do ex-presidente da Ordem dos Advogados do Brasil em Pernambuco, Jorge Neves, mais votado nas duas eleições para escolha do novo desembargador do Tribunal de Justiça:</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>“Sou advogado há 30 anos e tenho um curr?culo que o Tribunal reconheceu. Fui o mais votado também na OAB. Mas todos os candidatos têm condições de ser desembargador. Qualquer um dos três representaria bem a advocacia.???</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana></FONT>&nbsp;</P> </p>
