---
id: 12372044
data_publicacao: "2006-07-31 08:00:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "O império da militância paga"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Cec?lia Ramos</STRONG> e <STRONG>Mônica Crisóstomo</STRONG><BR>Repórteres do Blog e do Jornal do Commercio</FONT></P></p>
<p><P><FONT face=Verdana>A passagem dos candidatos ao governo do Estado Eduardo Campos (PSB) e Humberto Costa (PT) pelo Agreste Setentrional, neste final de semana, foi marcada pela forte presença de militância paga. </FONT></P></p>
<p><P><FONT face=Verdana>Na última sexta-feira, o deputado Iza?as Régis (PTB) \"patrocinou\" cerca de 30 pessoas, que formavam uma animada torcida organizada (com direito a mamãe-sacode, além de coreografia ensaiada e gingles na ponta da l?ngua) durante a visita de Humberto ao munic?pio de Capoeiras. </FONT></P></p>
<p><P><FONT face=Verdana>A maior parte do grupo era formada por moradores de Garanhus e foi transportada em um ônibus de campanha do petebista. Depois de negar que houvesse pagamento, rapazes e moças confirmaram ter recebido R$ 5,00 para \"cumprir a tarefa\". </FONT></P></p>
<p><P><FONT face=Verdana>No sábado, em Bom Conselho – onde petista e socialista caminharam na feira livre da cidade – novamente a militância paga esteve presente. Eduardo Campos levou vantagem no quesito estrutura. </FONT></P></p>
<p><P><FONT face=Verdana>Por R$ 200 ele contratou dois barulhentos mini-trios para acompanhá-lo no percurso da feira, tocando jingles da campanha socialista e repetindo os nomes e os números majoritários da coligação da Frente Popular. </FONT></P></p>
<p><P><FONT face=Verdana>\"Não ganho mais do que R$ 100,00 por semana vendendo CD’s genéricos. Esse negócio de alugar meu equipamento traz muito mais vantagens. Já tenho trabalho por pelo menos mais duas semanas nas cidades vizinhas\", destacou o ambulante Luciano Cavalcanti, proprietário dos mini-trios. </FONT></P> </p>
