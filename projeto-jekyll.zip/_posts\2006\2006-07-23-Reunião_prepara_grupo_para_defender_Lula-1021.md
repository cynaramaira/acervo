---
id: 12372194
data_publicacao: "2006-07-23 12:01:00"
data_alteracao: "None"
materia_tags: "GrupoA,Lula,preparação,reunião"
categoria: "Notícias"
titulo: "Reunião prepara grupo para defender Lula"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>A reunião de Lula com personalidades, em Olinda, faz parte de uma estratégia para a reconquista da classe média e daqueles segmentos formadores de opinião.</FONT></P></p>
<p><P><FONT face=Verdana>Debruçado sobre pesquisas qualitativas e quantitavas, o presidente nacional do PT e coordenador da campanha, deputado Ricardo Berzoini (SP), tem dito que Lula mantém ?ndices elevados de intenção de votos em quase todos os setores da sociedade brasileira. Mas naqueles dois em particular a situação não é boa. </FONT></P></p>
<p><P><FONT face=Verdana>Na opinião de Berzoini, é preciso reconquistá-los com explicações claras sobre tudo o que ocorreu desde o ano passado, após a crise do mensalão, e o que realmente vem sendo realizado pelo governo.</FONT></P></p>
<p><P><FONT face=Verdana>Pois bem, esse tipo de encontro de hoje deverá se repetir sistematicamente ao longo da campanha, onde for poss?vel. Em Olinda, estão cerca de 280 pessoas. Praticamente todas já eram eleitoras de Lula.</FONT></P></p>
<p><P><FONT face=Verdana>A idéia de reuni-las não é conquistar seus votos. É prepará-las para defender Lula e o governo, propagando uma onda de argumentos positivos entre outros professores universitários, artistas, empresários, l?deres sindicais e pol?ticos.</FONT></P></p>
<p><P><FONT face=Verdana>De Pernambuco, estão lá agora, por exemplo, o produtor cultural Alfredo Bertini; o presidente da Federação das Indústrias, Jorge Corte Real; o advogado José Paulo Cavalcanti Filho; Edmir Nunes Filho, presidente da colônica de pescadores Z1, do Pina; e o pintor Giuseppe Baccaro.</FONT></P></p>
<p><P><FONT face=Verdana>O roteiro do encontro mostra bem esse interesse em deixar todo mundo com um discurso afinado. Já falaram Ciro Gomes, que apresentou as realizações de Lula no Nordeste; Armando Neto, como empresário; Tânia Bacelar, como economista; Messias Melo, da CUT nacional; e Ariano Suassuna, como animador cultural. Lula fechará com os argumentos pol?ticos.</FONT></P></FONT> </p>
