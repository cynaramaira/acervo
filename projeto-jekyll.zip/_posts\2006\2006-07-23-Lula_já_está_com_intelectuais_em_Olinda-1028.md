---
id: 12372201
data_publicacao: "2006-07-23 10:24:00"
data_alteracao: "None"
materia_tags: "esta,Lula,olinda"
categoria: "Notícias"
titulo: "Lula já está com intelectuais em Olinda"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><SPAN class=txt_13_cinza><SPAN class=arial_13_azul2><SPAN class=arial_13_azul2><FONT color=#666666><FONT face=Verdana><STRONG>Do JC OnLine</STRONG><BR><EM>Com informações da Rádio Jornal</EM></FONT></P></p>
<p><P><FONT face=Verdana>O presidente Luiz Inácio Lula da Silva já chegou ao Convento Santa Gertrudes, no Alto da Sé de Olinda, onde se encontrará, na manhã deste domingo,&nbsp;com cerca de 120 intelectuais, pol?ticos e candidatos ao governo de Estados do Nordeste que apóiam sua reeleição. </FONT></P></p>
<p><P><FONT face=Verdana>Integram a comitiva do presidente Humberto Costa, Eduardo Campos, Ciro Gomes, dona Marisa (esposa de Lula) e o prefeito do Recife, João Paulo, entre outros.</FONT></P></p>
<p><P><FONT face=Verdana>Antes de chegar a Olinda, quando deixava o hotel em que está hospedado, no bairro de Boa Viagem, Recife, Lula foi abordado por agentes da Pol?cia Ferroviária Federal. Os trabalhadores estavam com faixas e pediam para agendar uma audiência com o presidente.</FONT></P></p>
<p><P><FONT face=Verdana>De acordo com o inspetor Augusto Lima, presidente da Associação dos Policiais Ferroviários Federais, a categoria quer abertura de concurso para aumentar o efetivo e também pede para deixar o Ministério das Cidades e dos Transportes e passar para o da Justiça. </FONT></FONT></SPAN></SPAN></SPAN></P> </p>
