---
id: 12372189
data_publicacao: "2006-07-23 15:00:00"
data_alteracao: "None"
materia_tags: "jarbas vasconcelos,patrimônio"
categoria: "Notícias"
titulo: "Patrimônio de Jarbas cresceu R$ 291,9 mil"
sutia: "None"
chapeu: "None"
autor: "jamildo"
imagem: "None"
---
<p>&nbsp;</p>
<p>Por Sheila Borges<br />Rep&oacute;rter de Pol&iacute;tica do JC</p>
<p>Depois de quatro anos exercendo o segundo mandato como governador do Estado, Jarbas Vasconcelos (PMDB) deixou o governo registrando um crescimento patrimonial de R$ 291,9 mil.</p>
<p>De acordo com a declara&ccedil;&atilde;o de bens apresentada ao Tribunal Regional Eleitoral de Pernambuco (TRE-PE), o candidato a senador tem um patrim&ocirc;nio avaliado em R$ 878,6 mil. Em 2002, este valor era de R$ 586,6 mil.</p>
<p>Jarbas preferiu investir seu dinheiro na compra de im&oacute;veis e obras de arte, que juntos chegam a R$ 638,1 mil. Neste per?odo, o ex-governador vendeu um apartamento, mas comprou outros dois - o primeiro no Cais de Santa Rita e o segundo no Rosarinho -, al&eacute;m de uma casa, tamb&eacute;m no Rosarinho, e um lote em Bezerros.</p>
<p>O peemedebista, no entanto, n&atilde;o &eacute; o candidato ao Senado que tem o maior patrim&ocirc;nio. O campe&atilde;o &eacute; um estreante na pol?tica: o m&eacute;dico e empres&aacute;rio Pedro Corr&ecirc;a Gondim, que disputa o cargo pelo Prona. Segundo a declara&ccedil;&atilde;o de renda protocolada por Gondim, o patrim&ocirc;nio dele est&aacute; avaliado em pouco mais de R$ 1 milh&atilde;o.</p>
<p>Veja o patrim&ocirc;nio dos candidatos ao Senado</p>
<p>Jorge Gomes (PSB)</p>
<p>Total: R$ 241.663,84</p>
<p>* Apartamento em Boa Viagem - R$ 116.539,24</p>
<p>* Casa em Caruaru - R$ 26.135,98</p>
<p>* A&ccedil;&otilde;es Telemar - R$ 4,00</p>
<p>* Casa - R$ 60.194,81</p>
<p>* Conta corrente Banco do Brasil - R$ 2.734,93</p>
<p>* Conta corrente Banco do Brasil - R$ 34.822,77</p>
<p>* Poupan&ccedil;a Bandepe - R$ 1.183,11</p>
<p>Jarbas Vasconcelos (PMDB)</p>
<p>Total: R$ 878.658,10</p>
<p>* Apartamento em constru&ccedil;&atilde;o no Cais de Santa Rita - R$ 130 mil</p>
<p>* Apartamento em Boa Viagem - R$ 94.055,29</p>
<p>* Autom&oacute;vel Gol - R$ 23 mil</p>
<p>* Camarote est&aacute;dio Sport Clube - R$ 11.289,37</p>
<p>* Casa no Rosarinho - R$ 100 mil</p>
<p>* Casa em Paulista - R$ 25 mil</p>
<p>* Lote em condom?nio em Bezerros - R$ 44.632,02</p>
<p>* Obras de arte - R$ 198.217,20</p>
<p>* Pr&ecirc;mio acumulado Unibanco - R$ 142.974,44</p>
<p>* Cota cons&oacute;rcio de carro - R$ 58.260,66</p>
<p>* Saldo conta corrente nos bancos Real, Brasil, Ita&uacute; e Unibanco - R$ 2.276,42</p>
<p>* Aplica&ccedil;&otilde;es Ita&uacute; e Unibanco - R$ 2.688,56</p>
<p>* Apartamento em constru&ccedil;&atilde;o no Rosarinho - R$ 46.264,14</p>
<p>Luciano Siqueira (PCdoB)</p>
<p>Total: R$ 67.800,00</p>
<p>* Apartamento no Centro do Recife - R$ 17 mil</p>
<p>* Apartamento em Campo Grande - R$ 20 mil</p>
<p>* Lote em Vit&oacute;ria de Santo Ant&atilde;o - R$ 800,00</p>
<p>* Ve?culo Siena - R$ 30 mil</p>
<p>Pedro Corr&ecirc;a Gondim (Prona)</p>
<p>Total: R$ 1.049.872,00</p>
<p>* 1/3 da propriedade de uma fazenda em Gravat&aacute; - R$ 86.188,93</p>
<p>* 1/3 de um s?tio em Sair&eacute; - R$ 23.030,20</p>
<p>* 1/7 da propriedade de uma fazenda em Sair&eacute; recebida por doa&ccedil;&atilde;o - R$ 18.699,76</p>
<p>* A&ccedil;&otilde;es da Telpe para uso de tr&ecirc;s linhas - R$ 1.655,52 (cada uma)</p>
<p>* Aplica&ccedil;&atilde;o Unibanco - R$ 10.539,00</p>
<p>* Apartamento em Parnamirim - R$ 241 mil</p>
<p>* Toyotta Corolla 2003 - R$ 45 mil</p>
<p>* Celta 2005 - R$ 25.500,00</p>
<p>* Poupan&ccedil;a Unibanco - R$ 165,73</p>
<p>* Capital empresa Agreste Mineradora - R$ 91 mil</p>
<p>* Capital firma comercial Loyon - R$ 10 mil</p>
<p>* Capital firma imobili&aacute;ria Rosa do Janga - R$ 4.051,82</p>
<p>* Capital Seope - R$ 200 mil</p>
<p>* Cotas cooperativa oftalmolaser - R$ 33.700,00</p>
<p>* Dinheiro em esp&eacute;cie - R$ 51 mil</p>
<p>* Empr&eacute;stimo a Alexandre Godim - R$ 2 mil</p>
<p>* Empr&eacute;stimo compuls&oacute;rio s/ve?culo - R$ 470,13</p>
<p>* Investimento Banco Real - R$ 92.428,14</p>
<p>* Aplica&ccedil;&atilde;o Unibanco - R$ 60.892.30</p>
<p>* Linha telef&ocirc;nica - R$ 1.600,00</p>
<p>* Linha telef&ocirc;nica - R$ 500,00</p>
<p>* Linha telef&ocirc;nica - R$ 646,58</p>
<p>* M&oacute;veis e equipamentos de consult&oacute;rio - R$ 45.819,17</p>
<p>* Poupan&ccedil;a Banco Real - R$ 240,15</p>
<p>* Investimento Unibanco - R$ 435,35</p>
<p>Delta Marim Moraes de Farias (PRTB)</p>
<p>Total: R$ 109 mil</p>
<p>* Apartamento em Boa Viagem - R$ 100 mil</p>
<p>* Autom&oacute;vel Fiat Uno/98 - R$ 9 mil</p>
<p>Aluisio de Ara&uacute;jo Figueir&ocirc;a (PCB), Severino Jos&eacute; Belarmino Silva (PTdoB), H&eacute;lio Cabral Lima (PSTU) e Breno Rocha Soares (PCO) dizem n&atilde;o ter bens a declarar.</p>
