---
id: 12372054
data_publicacao: "2006-07-29 13:29:00"
data_alteracao: "None"
materia_tags: "jorge jesus,Marcos Pontes"
categoria: "Notícias"
titulo: "Situação complicada a de Marcos de Jesus"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Painel da Folha</STRONG><BR>(Folha de S.Paulo)</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Sem o reino de Deus</STRONG> </FONT></P></p>
<p><P><FONT face=Verdana>A Igreja Universal, que conseguiu emplacar na lista dos sanguessugas nada menos que 14 dos 16 deputados federais que elegeu em 2002, decidiu retirar o suporte financeiro necessário à reeleição dessa turma.</FONT></P></p>
<p><P><FONT face=Verdana>Na tentativa de reduzir o estrago de imagem para a organização que comanda, o bispo Edir Macedo conclamou os envolvidos no escândalo a não concorrer este ano, mas até o momento não foi ouvido nem dentro da própria fam?lia. </FONT></P></p>
<p><P><FONT face=Verdana>O dono da Universal subiu pelas paredes com a irmã, Edna Macedo (PTB-SP), citada no depoimento dos donos da Planam como participante da quadrilha das ambulâncias. Ela, porém, insiste em disputar novamente vaga na Câmara.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Comentário meu:</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>O deputado federal pernambucano Marcos de Jesus está na lista e pode ser atingido pela decisão de Edir Macedo.</FONT></P> </p>
