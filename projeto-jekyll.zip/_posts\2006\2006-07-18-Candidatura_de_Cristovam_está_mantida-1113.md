---
id: 12372286
data_publicacao: "2006-07-18 18:17:00"
data_alteracao: "None"
materia_tags: "Candidatura,esta"
categoria: "Notícias"
titulo: "Candidatura de Cristovam está mantida"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>O Ministério Público Federal, na verdade, pediu a impugnação e não impugnou as candidaturas de Cristovam Buarque (PDT), Ana Maria Rangel (PRP) e de Rui Pimenta (PCO), conforme texto da Agência Estado reproduzido abaixo.</P></p>
<p><P>O Tribunal Superior Eleitoral, em Bras?lia, tem até 23 de agosto para julgar todos os pedidos de impugnação.</P> </p>
