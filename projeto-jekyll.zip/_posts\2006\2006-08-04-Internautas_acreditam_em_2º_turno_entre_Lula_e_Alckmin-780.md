---
id: 12371953
data_publicacao: "2006-08-04 08:30:00"
data_alteracao: "None"
materia_tags: "entrega,geraldo Alckmin,Lula,Saturno"
categoria: "Notícias"
titulo: "Internautas acreditam em 2º turno entre Lula e Alckmin"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Este é o resultado parcial da enquete que o <STRONG>Blog</STRONG> realiza. Veja os números:</FONT></P></p>
<p><P><FONT face=Verdana>Você acha que haverá segundo turno na eleição para presidente da República?</FONT></P></p>
<p><P><FONT face=Verdana>Sim, entre Lula e Alckmin&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 197 (47%)</FONT></P></p>
<p><P><FONT</p>
<p> face=Verdana>Sim, entre Lula e Helo?sa Helena&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 65 (15%)</FONT></P></p>
<p><P><FONT face=Verdana>Não&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 159 (38%)</FONT></P></p>
<p><P><FONT face=Verdana><BR>Participe, dê sua opinião na coluna ao lado.</FONT></P> </p>
