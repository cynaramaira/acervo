---
id: 12372137
data_publicacao: "2006-07-26 11:00:00"
data_alteracao: "None"
materia_tags: "Humberto Costa,José Serra"
categoria: "Notícias"
titulo: "Biscaia descarta convocação de Humberto e José Serra"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana size=2>Por <STRONG>Ayrton Maciel</STRONG><BR>Repórter de Pol?tica do JC </P></p>
<p><P>O presidente da CPI das Sanguessugas, Antônio Carlos Biscaia (PT-RJ), afirmou ontem que as investigações não encontraram, até o momento, nenhum ind?cio que ligue os ex-ministros da Saúde, Humberto Costa (PT) e José Serra (PSDB) - respectivamente, nos governos Lula e FHC - ao esquema de desvio de recursos via emendas parlamentares para compra de ambulâncias superfaturadas. </P></p>
<p><P>Biscaia descartou, em entrevista por telefone, a convocação de ambos para depor e disse que se for necessário, ocorrerá em um segundo momento, como desdobramento das investigações atuais. </P></p>
<p><P>Biscaia afirmou que o foco da CPI, hoje, é a conclusão das apurações sobre os parlamentares citados pelos donos da Planam, Darcy e Luiz Antônio Vedoin, mentores da máfia das sanguessugas. </P></p>
<p><P>O presidente da CPI revelou que recebeu, ontem, três requerimentos de convocação para depor dos ex-ministros Serra, Humberto e Saraiva Felipe (PMDB), este último, porém, foi citado na condição deputado. </P></p>
<p><P>\"Nem chegamos a votá-los. Agora, não haverá convocação. Não há nada que indique que o esquema tinha a responsabilidade dos ex-ministros Humberto e Serra\", afirmou. </P></p>
<p><P>Com mais de 90 parlamentares a ser ouvidos, Biscaia disse que não tem como abrir outra linha de apuração. </P></p>
<p><P>\"Há uma acervo imenso de provas. Não vamos parar o trabalho para ouvir ex-ministro. Não é preciso a solicitação de ninguém para cumprimos nosso papel. Estamos investigando tudo\", revelou Biscaia.</P></FONT> </p>
