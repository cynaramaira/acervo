---
id: 12371979
data_publicacao: "2006-08-02 17:17:00"
data_alteracao: "None"
materia_tags: "ação,cerveja,Contran,Humberto Costa"
categoria: "Notícias"
titulo: "Humberto perde ação contra a Veja"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=\"Times New Roman\"></p>
<p><P><FONT face=Verdana>O ex-ministro da Saúde havia pedido ao Tribunal Regional Eleitoral que garantisse um espaço na revista Veja para que pudesse rebater a acusação de envolvimento com o escândalo das sanguessugas.</FONT></P></p>
<p><P><FONT face=Verdana>O pedido de Humberto Costa (PT) foi recusado com o voto de minerva do presidente do TRE, Eloy d’Almeida Lins, segundo Cláudia Vasconcelos, repórter do Jornal do Commercio.</FONT></P></p>
<p><P><FONT face=Verdana>Houve três votos favoráveis a Humberto: de Geraldo Apoliano, João Campos e Márcio Alves. E três contrários: Marco Maggi, Eduardo Guillio e Carlos Moraes.</FONT></P></p>
<p><P><FONT face=Verdana>Leia mais <A href=\"https://jc3.uol.com.br/blogs/jc/2006/07/22/index.php#194\" target=_blank><STRONG><EM>aqui</EM></STRONG></A> e <STRONG><EM><A href=\"https://jc3.uol.com.br/blogs/jc/2006/07/24/index.php#257\" target=_blank>aqui</A></EM></STRONG> para entender o caso.</FONT></P></FONT> </p>
