---
id: 12371783
data_publicacao: "2006-05-01 15:44:00"
data_alteracao: "None"
materia_tags: "None"
categoria: "Notícias"
titulo: ""
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><TABLE cellSpacing=10 cellPadding=0 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD vAlign=top><A name=660></p>
<p><P><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>SANGUESSUGAS</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;11/08/2006 <IMG height=13 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/ico_hora.gif\" width=13 align=absMiddle> 14:44<BR></FONT><FONT face=\"Arial, Helvetica, sans-serif\" size=4><STRONG>Até Jungmann apresentou emenda para inclusão digital</STRONG></FONT></P></p>
<p><P></p>
<p><P><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2></p>
<p><P><FONT</p>
<p> face=Verdana>Pois o vice-presidente da CPI das Sanguessugas incluiu no Orçamento Geral da União do ano passado duas emendas destinadas ao programa de inclusão digital, do Ministério da Ciência e Tecnologia.</FONT></P></p>
<p><P><FONT face=Verdana>Uma emenda tem valor total de R$ 800 mil, dos quais R$ 438 mil foram empenhados e liquidados pelo Governo Federal, segundo dados da Comissão de Orçamento do Congresso Nacional, obtidos pelo <STRONG>Blog</STRONG>.</FONT></P></p>
<p><P><FONT face=Verdana>Pesam contra o programa de inclusão digital as suspeitas de ser o foco de um novo esquema de superfaturamento, semelhante ao das ambulâncias envolvendo o Ministério da Saúde.</FONT></P></p>
<p><P><FONT face=Verdana>No caso da Ciência e Tecnologia, a CPI suspeita de superfaturamento de ônibus adaptados com computadores para promover a inclusão digital em comunidades carentes.</FONT></P></p>
<p><P><FONT face=Verdana size=3><STRONG><EM>BANCADA&nbsp;DESTINOU&nbsp;R$ 12,9 MILHÕES</EM></STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Nos orçamentos da União de 2005 e 2006, dez parlamentares apresentaram emendas individuais para o programa.</FONT></P></p>
<p><P><FONT face=Verdana>A maior emenda, no entanto, é de bancada. </FONT></P></p>
<p><P><FONT face=Verdana>No OGU 2006, há uma emenda coletiva da bancada no valor de R$ 7,9 milhões, dos quais R$ 4,1 milhões já foram empenhados. Nada foi pago ainda.</FONT></P></p>
<p><P><FONT face=Verdana>Veja a relação das emendas:</FONT></P></p>
<p><P><FONT face=Verdana></FONT><FONT face=Verdana><STRONG>OGU 2006</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Quatro deputados pernambucanos e 1 emenda de bancada</FONT></P></p>
<p><P><FONT face=Verdana>VALOR APRESENTADO: R$ 8,949 milhões</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: R$ 5,08 milhões</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: -</FONT></P></p>
<p><P><FONT face=Verdana>------------------------------------------</FONT></P><B></p>
<p><P><FONT face=Verdana>OGU 2005</FONT></P></B></p>
<p><P><FONT face=Verdana>Oito deputados pernambucanos</FONT></P></p>
<p><P><FONT face=Verdana>VALOR APRESENTADO: R$ 3,960 milhões</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: R$ 2,486 milhões</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: R$ 2,486 milhões</FONT></P><FONT face=Verdana></p>
<p><P>&nbsp;</P></FONT><FONT face=Verdana></p>
<p><P>------------------------------------------</P></FONT><FONT face=Verdana></p>
<p><P>&nbsp;</P></FONT><B></p>
<p><P><FONT face=Verdana>OGU&nbsp;2006</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P><FONT face=Verdana>1) EMENDA DE BANCADA </FONT></P></B></p>
<p><P><FONT face=Verdana>VALOR APRESENTADO:<B> </B>R$ 7,9 milhões</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: R$ 4,1 milhões</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: -</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P><B></p>
<p><P><FONT face=Verdana>2) FERNADO FERRO (PT)</FONT></P></B></p>
<p><P><FONT face=Verdana>Emenda 1 - VALOR APRESENTADO: R$ 120 mil</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: R$ 60 mil</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: -</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P><B></p>
<p><P><FONT face=Verdana>3) PAULO RUBEM SANTIAGO (PT)</FONT></P></B></p>
<p><P><FONT face=Verdana>Emenda 1 - VALOR APRESENTADO: R$ 160 mil</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: R$ 160 mil</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: -</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P><FONT face=Verdana>Emenda 2 - VALOR APRESENTADO: R$ 200 mil</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: R$ 200 mil</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: -</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P><FONT face=Verdana>Emenda 3 - VALOR APRESENTADO: R$ 175 mil</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: R$ 175 mil</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: -</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P><FONT face=Verdana></FONT></P><B></p>
<p><P><FONT face=Verdana>4) PEDRO CORRÊA (PP)</FONT></P></B></p>
<p><P><FONT face=Verdana>Emenda 1 - VALOR APRESENTADO: R$ 300 mil</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: -</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: - </FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P><B></p>
<p><P><FONT face=Verdana>5) SALATIEL CARVALHO (PMDB)</FONT></P></B></p>
<p><P><FONT face=Verdana>Emenda 2 - VALOR APRESENTADO: R$ 90 mil</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: R$ 90 mil</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: - </FONT></P><FONT face=Verdana></p>
<p><P>------------------------------------------</P></FONT><B><FONT face=\"Times New Roman\"></p>
<p><P><FONT face=Verdana>OGU 2005</FONT></P></p>
<p><P><FONT face=Verdana>1) FERNANDO FERRO (PT)</FONT></P></B></p>
<p><P><FONT face=Verdana>Emenda 1 - VALOR APRESENTADO: R$ 100 mil </FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: R$ 100 mil</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: R$ 100 mil</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P><FONT face=Verdana>Emenda 2 - VALOR APRESENTADO: R$ 100 mil</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: R$ 100 mil</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: R$ 100 mil</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P><FONT face=Verdana>Emenda 3 – VALOR APRESENTADO: R$ 100 mil</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: R$ 100 mil</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: R$ 100 mil</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P><FONT face=Verdana>Emenda 4 - VALOR APRESENTADO: R$ 250 mil</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: R$ 250 mil</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: R$ 250 mil</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P><B></p>
<p><P><FONT face=Verdana>2) JOSÉ CHAVES (PTB)</FONT></P></B></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P><FONT face=Verdana>Emenda 1 - VALOR APRESENTADO: R$ 150 mil</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: R$ 30 mil</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: R$ 30 mil</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P><B></p>
<p><P><FONT face=Verdana>3) MAUR??CIO RANDS (PT)</FONT></P></B></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P><FONT face=Verdana>Emenda 1 - VALOR APRESENTADO: R$ 450 mil</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: R$ 438 mil</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: R$ 438 mil</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P><B></p>
<p><P><FONT face=Verdana>4) PEDRO CORRÊA (PP)</FONT></P></B></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P><FONT face=Verdana>Emenda 1 - VALOR APRESENTADO: R$ 400 mil</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: R$ 330 mil</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: R$ 330 mil</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P><FONT face=Verdana>Emenda 2 - VALOR APRESENTADO: R$ 400 mil</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: R$ 400 mil</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: R$ 400 mil</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P><B></p>
<p><P><FONT face=Verdana>5) RAUL JUNGMANN (PPS)</FONT></P></B></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P><FONT face=Verdana>Emenda 1 - VALOR APRESENTADO: R$ 800 mil</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: R$ 438 mil</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: R$ 438 mil</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P><FONT face=Verdana>Emenda 2 - VALOR APRESENTADO: R$ 100 mil</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: -</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: -</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P><FONT face=Verdana></FONT></P><B></p>
<p><P><FONT face=Verdana>6) RICARDO FIÚZA (PP)</FONT></P></B></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P><FONT face=Verdana>Emenda 1 - VALOR APRESENTADO: R$ 300 mil</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: R$ 300 mil </FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: R$ 300 mil</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P><B></p>
<p><P><FONT face=Verdana>7) ROBERTO FREIRE (PPS)</FONT></P></B></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P><FONT face=Verdana>Emenda 1 - VALOR APRESENTADO: R$ 80 mil</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: -</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: -</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P><FONT face=Verdana>Emenda 2 - VALOR APRESENTADO: R$ 80 mil</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: -</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: -</FONT></P></p>
<p><P><FONT face=Verdana></FONT></P></p>
<p><P><FONT face=Verdana>Emenda 3 - VALOR APRESENTADO: R$ 500 mil</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: -</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: -</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P><B></p>
<p><P><FONT face=Verdana>8) ROBERTO MAGALHÃES (PFL)</FONT></P></B></p>
<p><P><FONT face=Verdana>VALOR APRESENTADO: R$ 150 mil</FONT></P></p>
<p><P><FONT face=Verdana>EMPENHADO: -</FONT></P></p>
<p><P><FONT face=Verdana>LIQUIDADO: -</FONT> </P></FONT></FONT></p>
<p><P></P></A></TD></TR></p>
<p><TR></p>
<p><TD vAlign=top>&nbsp;</TD></p>
<p><TD vAlign=top></p>
<p><TABLE cellSpacing=0 cellPadding=0 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD width=\"80%\" height=20><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#006633 size=1><STRONG>Por César Rocha</STRONG> | <STRONG><A href=\"https://jc3.uol.com.br/blogs/jc/comentarios.php?codigo=660&amp;canal=0\">Nenhum comentário</A></STRONG> | <A href=\"https://jc3.uol.com.br/blogs/jc/comentar.php?codigo=660&amp;canal=0\">Comente</A> </FONT></TD></p>
<p><TD width=\"11%\"><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#006633 size=1><A href=\"https://jc3.uol.com.br/blogs/jc/enviar.php?codigo=660&amp;canal=0\"><IMG height=13 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/ic_mail.gif\" width=13 align=absMiddle border=0></A>&nbsp;<A href=\"https://jc3.uol.com.br/blogs/jc/enviar.php?codigo=660&amp;canal=0\"><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#006633 size=1>Enviar</FONT></FONT></FONT></A></TD></p>
<p><TD</p>
<p> width=\"9%\"></p>
<p><DIV align=center><A href=\"https://jc3.uol.com.br/blogs/jc/#\"><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#006633 size=1>Topo</FONT></A></DIV></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#006600 height=1></TD></p>
<p><TD bgColor=#006600></TD></p>
<p><TD bgColor=#006600></TD></TR></TBODY></TABLE></TD></TR></p>
<p><TR></p>
<p><TD vAlign=top>&nbsp;</TD></p>
<p><TD vAlign=top>&nbsp;</TD></TR></p>
<p><TR></p>
<p><TD vAlign=top width=5>&nbsp;</TD></p>
<p><TD vAlign=top><A name=659></p>
<p><P><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>SUCESSÃO ESTADUAL</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;11/08/2006 <IMG height=13 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/ico_hora.gif\" width=13 align=absMiddle> 14:41<BR></FONT><FONT face=\"Arial, Helvetica, sans-serif\" size=4><STRONG>Assessoria de Humberto nega greve no guia</STRONG></FONT></P></p>
<p><P></p>
<p><P><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-pagination: none; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana>A assessoria de imprensa do candidato ao governo de Pernambuco pelo PT diz que a equipe de produção da propaganda eleitoral está parada por problemas técnicos.<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-pagination: none; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-pagination: none; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana>Segundo a assessoria, os equipamentos da produção estão sendo transferidos da Videoteipe, produtora responsável pelo guia, para um outro imóvel, no bairro de Casa Forte, no Recife.<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-pagination: none; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-pagination: none; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana>Só por isso, garante a assessoria, os técnicos contratados estão parados. Hoje à tarde mesmo, acrescenta, eles voltam ao trabalho.<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-pagination: none; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-pagination: none; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana><o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-pagination: none; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana><STRONG>COMENT??RIO MEU:<o:p></o:p></STRONG></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt; mso-pagination: none; mso-layout-grid-align: none\"><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></SPAN></P><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Arial; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana>Gente dentro da Videoteipe garante que faltou mesmo foi dinheiro. E continua faltando.</FONT></SPAN></FONT><FONT face=\"Times New Roman\"> </FONT></p>
<p><P></P></A></TD></TR></TBODY></TABLE> </p>
