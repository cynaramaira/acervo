---
id: 12372179
data_publicacao: "2006-07-24 09:58:00"
data_alteracao: "None"
materia_tags: "blogs jc,LotoFácil"
categoria: "Notícias"
titulo: "Ficou mais fácil comentar no Blog"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=Verdana size=2></p>
<p><P>Fizemos mudanças no cadastro para simplificar o acesso àqueles que quiserem comentar not?cias postadas aqui. </P></p>
<p><P>Deixe seu comentário.</P></FONT> </p>
