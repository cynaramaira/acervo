---
id: 12372107
data_publicacao: "2006-07-28 11:18:00"
data_alteracao: "None"
materia_tags: "eleição"
categoria: "Notícias"
titulo: "O que vem por a? depois da eleição presidencial"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Da coluna <STRONG>Toda M?dia</STRONG><BR>na Folha de S.Paulo</FONT></P></p>
<p><P><FONT face=Verdana>\"Com o Oriente Médio em chamas, os preços recordes do petróleo, a economia americana esfriando e o clima esquentando, é dif?cil se excitar com encalhe nas conversas comerciais.\" É o in?cio do editorial de capa da \"Economist\", semelhante ao do \"New York Times\".<BR><BR></FONT><FONT face=Verdana>Duas das mais importantes publicações do mundo, elas partem da? para afirmar que \"este desastre nascido de complacência e negligência\" precisa da atenção, sim. Na revista, anuncia-se para logo logo o apocalipse mundial, ou melhor, \"a debacle constitui a maior ameaça até o momento ao sistema comercial pós-guerra\" etc. O jornal vai além:<BR><BR>- O dano aos pa?ses mais pobres do mundo será enorme. Assim como será (e deve ser mesmo) enorme o ressentimento contra os pa?ses mais ricos. Muito da culpa deve ser direcionada à Europa e aos EUA, que outra vez decidiram que a influência pol?tica de seus lobbies de fazendeiros pesa mais do que as promessas de fazer mais para acabar com a pobreza global.</FONT></P></p>
<p><P><FONT face=Verdana>Lei <STRONG><EM><A href=\"https://www.uol.com.br/fsp\" target=_blank>aqui</A></EM></STRONG> coluna completa (Assinate da Folha e UOL).</FONT></P> </p>
