---
id: 12372299
data_publicacao: "2006-07-18 10:29:00"
data_alteracao: "None"
materia_tags: "esta,mendonça,site"
categoria: "Notícias"
titulo: "Site de Mendonça já está na rede"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Veja <A href=\"https://www.mendonca25.can.br/\" target=_blank><STRONG>aqui </STRONG></A>o site.</P> </p>
