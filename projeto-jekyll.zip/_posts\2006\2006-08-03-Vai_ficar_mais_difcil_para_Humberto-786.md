---
id: 12371959
data_publicacao: "2006-08-03 18:32:00"
data_alteracao: "None"
materia_tags: "Humberto Costa"
categoria: "Notícias"
titulo: "Vai ficar mais dif?cil para Humberto"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG><EM><A href=\"https://www.noblat.com.br/\" target=_blank>blog</A></EM></STRONG> de Noblat</FONT></P></p>
<p><P><FONT face=Verdana>Sob o t?tulo \"Carne Nova\", publiquei às 15h47 de hoje nota que começava assim:</FONT></P></p>
<p><P><FONT face=Verdana>\"Tem nome novo no escândalo da venda superfaturada de ambulâncias para prefeituras: Duncan Sample, ex-funcionário da Casa Civil quando ali pontificava o ministro José Dirceu.</FONT></P></p>
<p><P><FONT face=Verdana>Foi o empresário Luiz Antonio Vedoin, um dos donos da Planam, quem pôs o nome de Sample na roda ao depor diante da CPI dos Sanguessugas em uma sala da Pol?cia Federal em Bras?lia.</FONT></P></p>
<p><P><FONT face=Verdana>Era Sample, segundo contou Vedoin,&nbsp; quem cuidava na Casa Civil da liberação de dinheiro das emendas ao Orçamento da União apresentadas por parlamentares.</FONT></P></p>
<p><P><FONT face=Verdana>(...) Disse Vedoin que no ano passado Sample teve a ver com a liberação de R$ 18 milhões de recursos extra-orçamento para a prefeitura de Nova Iguaçu, no Rio.\"</FONT></P></p>
<p><P><FONT face=Verdana>Bem, Sample me telefonou há pouco. Disse que jamais trabalhou com o ministro José Dirceu. </FONT></P></p>
<p><P><FONT face=Verdana>Foi assessor parlamentar do Ministério da Saúde do in?cio do governo Lula até março de 2004. </FONT></P></p>
<p><P><FONT face=Verdana>Da? até fevereiro de 2005 foi Subchefe-adjunto da Secretaria de Articulação Pol?tica do ministro Aldo Rebelo.</FONT></P></p>
<p><P><FONT face=Verdana>Com a sa?da de Aldo do governo em fevereiro de 2005, assumiu a chefia do gabinete do ministro da Saúde Humberto Costa. </FONT></P></p>
<p><P><FONT face=Verdana>Deixou o cargo pouco antes de Humberto deixar o dele em julho de 2005. Então virou assessor especial do ministro das Relações Institucionais Jacques Wagner.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.noblat.com.br/\" target=_blank>aqui</A></EM></STRONG> o texto completo.</FONT></P> </p>
