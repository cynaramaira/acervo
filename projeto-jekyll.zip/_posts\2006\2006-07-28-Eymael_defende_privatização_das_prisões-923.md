---
id: 12372096
data_publicacao: "2006-07-28 14:47:00"
data_alteracao: "None"
materia_tags: "prisões,privatização"
categoria: "Notícias"
titulo: "Eymael defende privatização das prisões"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Candidato do PSDC faz campanha no Recife e diz que irá, caso eleito, terceirizar o sistema prisional brasileiro, considerado por ele como medieval.</FONT></P></p>
<p><P><FONT face=Verdana>Eymael encontrou-se com policiais civis e prometeu desenvolver um programa de construção de casas populares para a categoria.</FONT></P></p>
<p><P><FONT face=Verdana>Ouça o que ele disse a Wagner Gomes, no programa de Geraldo Freire, na Rádio Jornal.</FONT></P> </p>
