---
id: 12372020
data_publicacao: "2006-08-01 10:00:00"
data_alteracao: "None"
materia_tags: "cartilha,Lançamento,Lula,PSDB"
categoria: "Notícias"
titulo: "PSDB lança cartilha comparando os governos FHC e Lula"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Jamildo Melo</STRONG><BR>Repórter especial do JC</FONT></P></p>
<p><P><FONT face=Verdana>Os tucanos vão partir para o ataque contra o governo Lula, às vésperas da visita que o candidato à Presidência Geraldo Alckmin (PSDB-SP) fará ao Recife para lançar seu programa de governo para o Nordeste, na sexta-feira. </FONT></P></p>
<p><P><FONT face=Verdana>A partir de hoje, os correligionários do tucano divulgarão na internet e em edição impressa uma cartilha comparando o governo Fernando Henrique Cardoso (FHC) com a gestão do petista. </FONT></P></p>
<p><P><FONT face=Verdana>A obra terá prefácio do ex-presidente FHC e traz sua primeira provocação aos petistas já no t?tulo: \"FHC X Lula, a verdade dos números contra o governo da mentira\". O PSDB fará a distribuição de 10 mil exemplares, em todo Pa?s.</FONT></P></p>
<p><P><FONT face=Verdana>A primeira leva das cartilhas começou a ser impressa ontem, em Bras?lia, onde fica a coordenação da campanha. No entanto, a obra já será publicada hoje, na rede, com a ajuda do Instituto Teotônio Vilela.</FONT></P></p>
<p><P><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Verdana; mso-bidi-font-family: Arial\">Leia <EM><B><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></B></EM> o texto completo (assinantes JC e UOL).<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></SPAN></P> </p>
