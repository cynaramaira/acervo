---
id: 12372122
data_publicacao: "2006-07-27 07:33:00"
data_alteracao: "None"
materia_tags: "reagendamentos"
categoria: "Notícias"
titulo: "A complicada agenda de Helo?sa Helena"
sutia: "None"
chapeu: "None"
autor: "jc"
imagem: "None"
---
<p>Por <strong>Cl&aacute;udia Vasconcelos<br /></strong>Rep&oacute;rter do JC</p>
<p>A passagem de Helo?sa Helena pelo Recife, amanh&atilde;, j&aacute; come&ccedil;a tumultuada pela defini&ccedil;&atilde;o da agenda.</p>
<p>A caminhada pela ocupa&ccedil;&atilde;o de sem-teto Dorothy Stang, na Imbiribeira, confirmada no in?cio da semana, foi confirmada e cancelada pelo P-SOL num intervalo de tr&ecirc;s dias.</p>
<p>Isso antes mesmo que as lideran&ccedil;as local e nacional do Movimento Terra Trabalho e Liberdade (MTL), que coordena a ocupa&ccedil;&atilde;o, fossem oficialmente informadas da caminhada pela comunidade.</p>
<p>A mudan&ccedil;a na agenda foi ordem da coordena&ccedil;&atilde;o nacional da campanha. Depois da indisposi&ccedil;&atilde;o de Helo?sa Helena em Natal, a recomenda&ccedil;&atilde;o expressa &eacute; que ela participe de apenas dois eventos por dia, para evitar desgaste.</p>
<p>Privilegiaram, ent&atilde;o, a visita &agrave; comunidade da Ilha de Deus, tamb&eacute;m na Imbiribeira, e a passeata pela Avenida Conde da Boa Vista, no Centro. Se j&aacute; sabiam da determina&ccedil;&atilde;o nacional desde o fim de semana, por que ent&atilde;o anunciaram uma caminhada na ocupa&ccedil;&atilde;o de sem-teto antes mesmo de ser confirmada?</p>
<p>O fato &eacute; que quase ningu&eacute;m conhece a alagoana na Dorothy Stang, reduto do PT. E o P-SOL estava esperando para come&ccedil;ar a articular a visita somente hoje, quando a agenda da candidata foi definida pela coordena&ccedil;&atilde;o nacional da campanha.</p>
