---
id: 12372057
data_publicacao: "2006-07-29 15:00:00"
data_alteracao: "None"
materia_tags: "Altas Horas,candidatos"
categoria: "Notícias"
titulo: "Candidatos sem pudor na hora de fechar alianças"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Curioso&nbsp;o comitê da coligação de Humberto Costa (PT), em Bom Conselho, no Agreste,&nbsp;inaugurado no começo da tarde. O espaço é comandado por Armando Monteiro Neto (PTB) e Romário Dias (PFL). O pefelista não compareceu, mas o prefeito do munic?pio, Audálio Ferreira (PTB), pediu voto para Romário.</FONT></P></p>
<p><P><FONT face=Verdana>Eles fazem campanha casada, a chamada dobradinha. Armando para federal, Romário, que é presidente da Assembléia Legislativa, para estadual.</FONT></P></p>
<p><P><FONT face=Verdana>E no tal comitê de Humberto o que mais tem, segundo Cec?lia Ramos, repórter do <STRONG>Blog</STRONG>, é foto de Romário, correligionário e peça-chave do governador Mendonça Filho (PFL).</FONT></P> </p>
