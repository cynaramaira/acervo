---
id: 12371885
data_publicacao: "2006-08-07 09:46:00"
data_alteracao: "None"
materia_tags: "interior"
categoria: "Notícias"
titulo: "Com?cio e carreata no interior"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Candidato do PT a governador de Pernambuco, Humberto Costa participou de com?cio organizado pelo prefeito Clóvis Paiva (PTB), em Ribeirão, Zona da Mata Sul.</FONT></P></p>
<p><P><FONT face=Verdana>Esteve ao lado de aliados, como o deputado federal Armando Monteiro Neto (PTB), e de adversários, a exemplo do estadual João Fernando Coutinho (PSB).</FONT></P></p>
<p><P><FONT face=Verdana>Coutinho</p>
<p> disputa a reeleição com apoio do prefeito Clóvis. Ele também é aliado de primeira hora de Eduardo Campos, candidato a governador pelo PSB.</FONT></P></p>
<p><P><FONT face=Verdana>Eduardo realizou carreata nas ruas de Aliança, Zona da Mata Norte.</FONT><FONT face=Arial></P></FONT> </p>
