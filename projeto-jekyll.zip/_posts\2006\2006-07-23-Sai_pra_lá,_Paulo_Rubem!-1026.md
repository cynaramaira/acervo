---
id: 12372199
data_publicacao: "2006-07-23 08:35:00"
data_alteracao: "None"
materia_tags: "Paulo,Rubem Fonseca,Secretaria de Cultura"
categoria: "Notícias"
titulo: "Sai pra lá, Paulo Rubem!"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>O deputado Paulo Rubem Santiago (de camisa azul, atrás ou à esquerda do presidente) é um dos mais duros cr?ticos do governo Lula dentro do PT. </FONT></P></p>
<p><P><FONT face=Verdana>Por pouco não deixou o partido em outubro do ano passado para engrossar as fileiras do P-SOL da senadora Helo?sa Helena.</FONT></P></p>
<p><P><FONT face=Verdana>Pois não é que Santiago passou a maior parte do tempo colado ao presidente no com?cio de ontem à noite, em Bras?lia Teimosa.</FONT></P></FONT> </p>
