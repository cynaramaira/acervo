---
id: 12372022
data_publicacao: "2006-08-01 08:50:00"
data_alteracao: "None"
materia_tags: "Falta"
categoria: "Notícias"
titulo: "Na falta de militância, vai a gurizada mesmo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Humberto Costa, candidato do PT a governador, decidiu de última hora fazer, ontem,&nbsp;uma caminhada pelo mercado da Encruzilhada, no Recife. Só não tinha multidão para pedir votos. </FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Mas guris e bandeiras não faltaram. A meninada fez uma farra.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>E o deputado Paulo Rubem Santiago (PT) disse que a caminhada tinha tanta bandeira que parecia desfile das Casas José Araújo: “Nunca vi tanto pano junto???.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Não foi diferente em torno do caixote 40, a tribuna de Eduardo Campos, candidato do PSB a governador. Ele deu uma passada ontem por Roda de Fogo, enorme favela do Recife.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>A gurizada observava tudo atentamente – mas de costas para o candidato.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2>Suando a camisa, só mesmo Milton Coelho, presidente estadual do PSB e candidato a uma vaga na Assembléia Legislativa. </FONT></SPAN></P></p>
<p><P><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2>Ao lado dele, a mãe de Eduardo, Ana Arraes, vibrou como pôde. E a gurizada soube aplaudir quando deveria.</FONT></SPAN></P> </p>
