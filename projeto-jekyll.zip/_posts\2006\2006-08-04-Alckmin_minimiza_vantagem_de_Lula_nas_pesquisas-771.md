---
id: 12371944
data_publicacao: "2006-08-04 11:02:00"
data_alteracao: "None"
materia_tags: "geraldo Alckmin,Lula,pesquisas"
categoria: "Notícias"
titulo: "Alckmin minimiza vantagem de Lula nas pesquisas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>O presidenciável tucano está na Rádio Jornal, participando de debate com Geraldo Freire. </FONT></P></p>
<p><P><FONT face=Verdana>Diz que as pesquisas ainda refletem o&nbsp;n?vel de lembrança e conhecimento dos candidatos.</FONT></P></p>
<p><P><FONT face=Verdana>O que vai valer mesmo, acabou de dizer, é o guia eleitoral, a partir do dia 15. Por meio dele poderá ser mais conhecido.</FONT></P></p>
<p><P><FONT face=Verdana>Alckmin também disse que \"o governo Lula poderia ir muito melhor\" por três razões fundamentais:</FONT></P></p>
<p><P><FONT face=Verdana>\"Do ponto de vista ético, é um descalabro. Quanto à gestão, há um governo muito grande. No crescimento econômico, crescemos muito pouco, 3, 4%, enquanto nossos vizinhos chegaram a 5, 6%. O Brasil pode mais.\"</FONT></P></p>
<p><P><FONT face=Verdana>Acompanhe ao vivo <STRONG><EM><A href=\"https://jc3.uol.com.br/radiojornal/\" target=_blank>aqui</A></EM></STRONG>.</FONT></P> </p>
