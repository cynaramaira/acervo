---
id: 12372007
data_publicacao: "2006-08-01 16:30:00"
data_alteracao: "None"
materia_tags: "brasil"
categoria: "Notícias"
titulo: "Sem modéstia, FHC diz que transformou o Brasil"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Os tucanos começaram a distribuir uma cartilha para mostrar as diferenças entre os governos FHC e Lula. O documento é munição na guerra das comparações, iniciada pelos petistas.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>No prefácio, assinado&nbsp; pelo próprio Fernando Henrique, ele esquece qualquer sinal de modéstia: “Não é tarefa simples mostrar que existe um Brasil radicalmente diferente do passado e, conseqüentemente, avaliar minha própria ação.???</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>O texto também ataca as taxas de juros praticadas na gestão Lula e aponta aquilo que, segundo os tucanos, FHC implementou<SPAN style=\"mso-spacerun: yes\">&nbsp; </SPAN>para combater a corrupção.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2>Veja acima trechos do documento, obtidos por Jamildo Melo, repórter especial do Jornal do Commercio.</FONT></SPAN> </p>
