---
id: 12372250
data_publicacao: "2006-07-21 08:00:00"
data_alteracao: "None"
materia_tags: "geraldo Alckmin,Lançamento,nordeste"
categoria: "Notícias"
titulo: "Alckmin lança pacote de promessas para o Nordeste"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>(Agência Folha)</FONT></P></p>
<p><P><FONT face=Verdana>Alckmin prometeu em Fortaleza, onde esteve nesta quinta, que irá anunciar, no dia 4 de agosto, em Pernambuco, um pacote de medidas para o Nordeste. O tucano negou que o fato esteja relacionado aos seus baixos ?ndices de intenção de voto na região.<BR><BR>\"É um projeto estruturante. Envolve questões do desenvolvimento de todo o Nordeste. Aborda as questões de infra-estrutura necessárias para o desenvolvimento. Aborda questões estratégicas. Questões de natureza fiscal, credit?cia. É bastante abrangente.\"<BR><BR>Ao ser questionado se o anúncio do plano ocorrerá em razão da dianteira de Lula nas pesquisas de intenção de voto na região, o tucano negou. \"Desde Celso Furtado (economista fundador da Sudene, morto em 2004), você não tem um projeto global de desenvolvimento para a região\", disse Alckmin.<BR><BR>\"Nos preocupa porque o Nordeste vem tendo um crescimento menor do que a média brasileira, quando é o contrário, para diminuir desigualdades, você tem de ter um crescimento maior que a média brasileira.\"<BR><BR>O pacote deve conter medidas relacionadas ao turismo, ao transporte público metropolitano e à agricultura, entre outras áreas.</FONT></P></FONT> </p>
