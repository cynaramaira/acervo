---
id: 12372335
data_publicacao: "2006-07-17 08:00:00"
data_alteracao: "None"
materia_tags: "declaração,Humberto Costa"
categoria: "Notícias"
titulo: "Internauta rebate declaração de Humberto"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Um leitor do blog, identificado por Rodrigues, diz que Humberto Costa mente quando critica o desempenho do governo Jarbas/Mendonça na área de Segurança Pública. Segundo Rodrigues, o governo Lula repassou para Pernambuco apenas R$ 0,16 por habitante/ano para serem aplicados em Segurança. Foi o menor percentual do Pa?s, de acordo com o internauta.</P></p>
<p><P>\"Os pernambucanos também foram punidos pelo Governo do PT com uma redução de 96,6% nos repasses entre 2001 (penúltimo ano do Governo FHC) e 2005 (penúltimo ano do Governo Lula). Além disso, Humberto fez parte do terceiro Governo Arraes, no qual Pernambuco atingiu o maior percentual de homic?dios por 100 mil habitantes. O leitor deve se lembrar que, em 1998, Humberto foi candidato ao Senado na chapa de Arraes. O povo tem memória. Se não tiver, a propaganda da União por Pernambuco vai acabar com qualquer amnésia\", disparou Rodrigues.</P></FONT> </p>
