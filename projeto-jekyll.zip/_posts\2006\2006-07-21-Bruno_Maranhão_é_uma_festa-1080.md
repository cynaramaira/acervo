---
id: 12372253
data_publicacao: "2006-07-21 06:32:00"
data_alteracao: "None"
materia_tags: "Bruno Covas,festa,maranhão"
categoria: "Notícias"
titulo: "Bruno Maranhão é uma festa"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Chique, filho de usineiros, falante e com o cabelo acaju, Bruno Maranhão, 66,&nbsp;desembarcou no Recife, depois de 38 dias presos sob a acusação de liderar o quebra-quebra promovido pelos sem-terra do MLST na Câmara dos Deputados, no in?cio de junho.</P></p>
<p><P>Ele deu um espetáculo particular. Concedeu entrevistas, cumprimentou a fam?lia e, principalmente, a mãe, dona Gisella, 87 anos, que, mesmo presa a uma cadeira de rodas, não é de entregar os pontos. Há dias, esteve em Bras?lia para visitar o filho na penitenciária da Papuda.</P> </p>
