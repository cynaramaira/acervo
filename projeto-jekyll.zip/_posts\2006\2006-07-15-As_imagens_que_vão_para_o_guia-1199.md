---
id: 12372372
data_publicacao: "2006-07-15 08:02:00"
data_alteracao: "None"
materia_tags: "Galvão Bueno"
categoria: "Notícias"
titulo: "As imagens que vão para o guia"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p>Veja a reportagem da TV Jornal com as imagens da megaoperação realizada pela Secretaria de Defesa Social e que servirão ao guia eleitoral do governador Mendonça Filho. </p>
