---
id: 12372030
data_publicacao: "2006-07-31 18:38:00"
data_alteracao: "None"
materia_tags: "henrique albino,pedro manta,Voto"
categoria: "Notícias"
titulo: "Pedro Henrique reclama do voto secreto"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Abatido, o procurador Pedro Henrique Alves, candidato de Jarbas e Mendonça a desembargador, falou há pouco com Cec?lia Ramos, repórter do <STRONG>Blog</STRONG>. </FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Tentou demonstrar otimismo, enquanto era cumprimentado e ouvia palavras de incentivo cochichadas por alguns.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Derrotado com o apoio de apenas dez desembargadores, <SPAN style=\"mso-spacerun: yes\">&nbsp;</SPAN>PH reclamou do sistema de votação secreta.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><STRONG>Como o sr. se sente com esse resultado?</STRONG></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Me sinto prestigiado pelo Tribunal. Foi uma boa votação. O voto secreto não permite analisar a motivação de cada magistrado. É louvável a postura de Fernando Cerqueira (desembargador que defendeu o voto aberto), isso é o que a sociedade almeja.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><STRONG>Mas o governo saiu derrotado?</STRONG></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2>Não existe isso. Isso tudo é pretexto.</FONT></SPAN> </p>
