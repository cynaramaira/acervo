---
id: 12372168
data_publicacao: "2006-07-24 18:56:00"
data_alteracao: "None"
materia_tags: "cerveja,Humberto Costa,revista"
categoria: "Notícias"
titulo: "Humberto decide processar a revista Veja"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>O ex-ministro da Saúde Humberto Costa contratou o advogado Bráulio Lacerda para processar a revista Veja e o repórter Marcelo Carneiro por acusá-lo, sem provas, de envolvimento com a máfia das ambulâncias. Ele apresentará na Justiça uma queixa-crime contra ambos.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Hoje, o advogado Otto Medeiros, que defende o empresário Luiz Antônio Vedoin, dono da Planam, isentou Humberto de relações com o escândalo. Disse no Jornal Hoje, da TV Globo, que em momento algum o empresário envolveu o ex-ministro nem ofereceu vantagens a ele para facilitar a liberação de recursos destinados à compra de ambulâncias.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Vedoin é acusado de chefiar a quadrilha que desviava recursos públicos de emendas parlamentares para a compra de ambulâncias.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Para a assessoria de Humberto, a declaração de Medeiros é prova “cabal??? de que ele não está envolvido com o escândalo.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Humberto também conversou hoje, por telefone, com o presidente e o vice-presidente da CPI das Sanguessugas, deputados Antônio Carlos Biscaia (PT-RJ) e Raul Jungmann (PPS-PE). A ambos pediu pressa nas investigações “porque não tem nada a temer???.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2>O ex-ministro não concorda com o relator da CPI, senador Amir Lando (PMDB-RO), que pretende deixar a conclusão dos trabalhos para depois das eleições.</FONT></SPAN> </p>
