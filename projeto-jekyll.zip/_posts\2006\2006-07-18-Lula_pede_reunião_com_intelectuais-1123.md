---
id: 12372296
data_publicacao: "2006-07-18 16:43:00"
data_alteracao: "None"
materia_tags: "Lula,reunião"
categoria: "Notícias"
titulo: "Lula pede reunião com intelectuais"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>O presidente Lula não vai mais a Caetés, no Agreste de Pernambuco, onde nasceu. Ele virá ao Estado, no sábado, para marcar, nas ruas, o in?cio de sua campanha à reeleição. Fará um com?cio, no final da tarde (17), em Bras?lia Teimosa, no Recife.</P></p>
<p><P>Segundo informações obtidas agora por Cec?lia Ramos, repórter do blog, no domingo, ao invés de Caetés, Lula vai a Olinda para um encontro, em ambiente fechado, com cerca de 150 personalidades nordestinas, entre intelectuais, empresários e l?deres de áreas como cultura, saúde e educação. A idéia é atrair formadores de opinião, gente de peso. Também serão convidados governadores aliados. De Pernambuco, vão ser chamadas figuras como Alceu Valença, Ariano Suassuna e Tânia Bacelar.</P></p>
<p><P>Lula faz um esforço enorme para reconquistar a classe média, da qual se distanciou ao longo dos últimos três anos e meio, principalmente depois do escândalo do mensalão. A coordenação da campanha de Humberto Costa (PT), que cuida da agenda de Lula em Pernambuco, está finalizando neste momento os detalhes dos eventos.</P></FONT> </p>
