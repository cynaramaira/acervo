---
id: 12371916
data_publicacao: "2006-08-06 08:30:00"
data_alteracao: "None"
materia_tags: "Causas,conflitos,fundo eleitoral"
categoria: "Notícias"
titulo: "TRE espera mais conflitos por causa do guia eleitoral"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Se a intensidade da batalha jur?dica entre os candidatos tem aumentado, isso ainda não é nada, se comparado ao que o TRE espera para depois do in?cio do guia eleitoral, no próximo dia 15. </FONT></P></p>
<p><P><FONT face=Verdana>E a julgar pelo que aconteceu em 2002, os desembargadores deverão ter muito trabalho até o final do pleito. Há quatro anos, se até o in?cio de agosto só haviam sido protocoladas 11 representações, o número subiu para impressionantes 335 no per?odo entre meados do mês e a eleição, em outubro.</FONT></P></p>
<p><P><FONT face=Verdana>Tomando esses dados como referência, o desembargador Marco Maggi, membro da comissão do TRE responsável pelo julgamento das representações, prevê uma quantidade de reclamações ainda maior este ano, com o começo da propaganda gratuita. </FONT></P></p>
<p><P><FONT face=Verdana>Ele leva em conta, principalmente, o acirramento da disputa. \"A tendência é só aumentar, já que este ano existem três candidatos fortes concorrendo ao governo\" comenta. </FONT></P></p>
<p><P><FONT face=Verdana>Leia o <STRONG><EM><A href=\"https://jc3.uol.com.br/jornal/\" target=_blank>texto</A></EM></STRONG> completo em Pol?tica, no JC (assinantes JC e UOL).</FONT><FONT face=Verdana></P></FONT> </p>
