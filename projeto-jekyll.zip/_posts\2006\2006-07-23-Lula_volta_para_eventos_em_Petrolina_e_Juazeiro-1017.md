---
id: 12372190
data_publicacao: "2006-07-23 16:59:00"
data_alteracao: "None"
materia_tags: "eventos,juazeiro,Lula,Petrolina"
categoria: "Notícias"
titulo: "Lula volta para eventos em Petrolina e Juazeiro"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=Verdana size=2></p>
<p><P>Segundo o prefeito João Paulo, coordenador da campanha do presidente em Pernambuco, Lula estará em Petrolina (PE) e Juazeiro (BA) no dia 14 de agosto. Cumprirá uma agenda de campanha nas duas cidades vizinhas, que juntas têm quase meio milhão de habitantes e influência sobre todo o submédio São Francisco.</P></FONT> </p>
