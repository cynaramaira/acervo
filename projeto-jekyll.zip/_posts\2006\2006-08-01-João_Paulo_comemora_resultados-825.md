---
id: 12371998
data_publicacao: "2006-08-01 20:23:00"
data_alteracao: "None"
materia_tags: "joão d,Paulo,resultados"
categoria: "Notícias"
titulo: "João Paulo comemora resultados"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Coordenador da campanha de Humberto Costa (PT), o prefeito João Paulo (PT) afirmou estar \"animad?ssimo\" com o resultado da pequisa Ibope/TV Globo, divulgada agora há pouco no NETV 2ª Edição. </FONT></P></p>
<p><P><FONT face=Verdana>Em entrevista para Cec?lia Ramos, repórter do Blog, ele falou da satisfação de ter dado a \"boa nova\" ao companheiro. \"Eu liguei para Humberto para comunicar os números, porque ele está no Rio de Janeiro. Ele soube por mim\", afirmou o prefeito. </FONT></P></p>
<p><P><FONT face=Verdana>João Paulo atribuiu o resultado de Humberto a três fatores: o engajamento da militância, a adesão do PTB do deputado federal Armando Monteiro Neto e a passagem do presidente Lula (PT) por Recife e Olinda, nos dias 22 e 23 de julho. </FONT></P></p>
<p><P><FONT face=Verdana>Para ele, a máfia das sanguessugas não atingiu Humberto Costa porque \"a população pernambucana entendeu que isso ocorreu no Governo Fernando Henrique Cardoso, quando o ministro da Saúde era José Serra\". \"A população está bastante escaldada dessa onda de denuncismo e isso não vai funcionar aqui\", garante o prefeito.</FONT></P> </p>
