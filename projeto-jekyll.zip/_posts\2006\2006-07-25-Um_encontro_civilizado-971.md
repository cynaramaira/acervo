---
id: 12372144
data_publicacao: "2006-07-25 15:58:00"
data_alteracao: "None"
materia_tags: "encontro"
categoria: "Notícias"
titulo: "Um encontro civilizado"
sutia: "None"
chapeu: "None"
autor: "jamildo"
imagem: "None"
---
<p>Jarbas Vasconcelos (PMDB), Humberto Costa (PT) e Eduardo Campos (PSB) deixaram hoje de lado os improp&eacute;rios trocados mutuamente, em p&uacute;blico ou privado, para participar do lan&ccedil;amento do Projeto Orquestra Crian&ccedil;a Cidad&atilde;, da Associa&ccedil;&atilde;o Beneficente Crian&ccedil;a Cidad&atilde; (ABCC), no Coque, bairro miser&aacute;vel do Recife.</p>
<p>&nbsp;</p>
<p>Ficaram pouco &agrave; vontade, mas foram educados. Mendon&ccedil;a Filho (PFL) n&atilde;o p&ocirc;de ir. Mandou a primeira-dama, Taciana, representa-lo.</p>
