---
id: 12371895
data_publicacao: "2006-08-06 16:15:00"
data_alteracao: "None"
materia_tags: "divulgação,pesquisas"
categoria: "Notícias"
titulo: "A divulgação contaminada das pesquisas eleitorais"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Ven?cio A. de Lima</STRONG><BR>No Observatório da Imprensa</FONT></P></p>
<p><P><FONT face=Verdana>A divulgação dos resultados da última pesquisa eleitoral do Ibope encomendada pela TV Globo, nos dias 25 e 26 de julho, é um bom exemplo das diferenças que o <I>enquadramento</I> de uma not?cia pode representar (ver \"</FONT><A href=\"https://observatorio.ultimosegundo.ig.com.br/artigos.asp?cod=391IMQ001\" target=_blank><U><FONT color=#0000ff><FONT face=Verdana>Cobertura das eleições: O significado de `tempos rigorosamente iguais´</FONT></U></FONT></A><FONT face=Verdana>\"). Mais ainda. É também um exemplo de como, sobretudo em per?odos eleitorais, a corrida pelo \"furo\" e/ou a irresponsabilidade jornal?stica fazem com que sejam veiculadas informações não confirmadas e/ou falsas.</FONT></P></p>
<p><P><FONT face=Verdana>Durante a terça-feira (25/7), o </FONT><A href=\"https://www.noblat.com.br/\" target=_blank><U><FONT color=#0000ff><FONT face=Verdana>Blog do Noblat</FONT></U></FONT></A><FONT face=Verdana> começou a divulgar os resultados da pesquisa Ibope com números favoráveis ao candidato do PSDB e a indicação de que haveria um segundo turno. Esses números foram imediatamente repercutidos em apressados comentários de outros blogs, por analistas pol?ticos e emissoras de rádio. Só à noite, quando a Rede Globo divulgou os verdadeiros resultados da pesquisa em seu <I>Jornal Nacional</I>, soube-se que aqueles números, tidos como corretos durante quase todo o dia, eram, na verdade, falsos.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://observatorio.ultimosegundo.ig.com.br/artigos.asp?cod=392IMQ002\" target=_blank>aqui</A></EM></STRONG> o texto completo.</FONT></P> </p>
