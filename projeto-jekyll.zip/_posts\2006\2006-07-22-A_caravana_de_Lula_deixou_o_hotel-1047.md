---
id: 12372220
data_publicacao: "2006-07-22 17:47:00"
data_alteracao: "None"
materia_tags: "hotel,Lula"
categoria: "Notícias"
titulo: "A caravana de Lula deixou o hotel"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=Verdana size=2></p>
<p><P>Saiu todo mundo do Recife Praia. Não houve muito papo com o presidente, nem entrevista. Ficou todo mundo esperando numa sala. E ele desceu já pronto para ir para Bras?lia Formosa.</P></p>
<p><P>No palco, toca Vermelho, com Fafá de Belém.</P></FONT> </p>
