---
id: 12372324
data_publicacao: "2006-07-17 08:07:00"
data_alteracao: "None"
materia_tags: "eduardo,entrega,Humberto Costa"
categoria: "Notícias"
titulo: "O embate entre Eduardo e Humberto"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>O presidente Lula poderá ser o principal fator de desempate entre Eduardo Campos e Humberto Costa. Eles dividem o segundo lugar nas pesquisas de intenção de voto JC/Vox Populi. Eduardo tem 21%. Humberto 22%. </P></p>
<p><P>Mudaram pouco de lugar em relação ao levantamento anterior, publicado em 7 de maio. Na época, Eduardo tinha 23%, Humberto, 21%. </P></p>
<p><P>Mendonça é o l?der desde maio. Nesses dois meses e meio, o governador cresceu seis pontos e agora tem 35%.</P></p>
<p><P>Mas por que Lula seria um fator de desempate? Porque Eduardo poderá ficar impedido de usar as imagens do presidente na propaganda eleitoral de TV, a partir de 15 de agosto. O Ministério Público eleitoral já mandou avisar que não pode, o PSB não se aliou a Lula nacionalmente.</P></p>
<p><P>Nesse caso, Humberto teria direitos exclusivos por ser do PT e iria faturar com a vinculação ao presidente, cuja popularidade no Estado está no mesmo n?vel da de Jarbas.</P></p>
<p><P>A briga pelo segundo lugar e por uma das vagas num provável segundo turno com Mendonça&nbsp;deve ser influenciada ainda por outros fatores:</P></p>
<p><P><STRONG>1) Os dois estão equilibrados no interior</STRONG></P></p>
<p><P>- Eduardo vence na Mata, 26% a 17%</P></p>
<p><P>- Empatam no Agreste, estão dentro da margem de erro da pesquisa (3,5%): Humberto tem 24% e Eduardo, 22%</P></p>
<p><P>- Empatam&nbsp;no Sertão, 17% (Humberto) e 16% (Eduardo)</P></p>
<p><P><STRONG>2) Humberto vence na Região Metropolitana do Recife</STRONG></P></p>
<p><P>- O petista tem 26%, o socialista, 20%</P></p>
<p><P>- Mas Eduardo conseguiu apoios importantes: Jaboatão (372,8 mil eleitores); Paulista (174,6 mil); Vitória&nbsp;(87,5 mil); Igarassu (58,2 mil); e Itapissuma (15,7 mil)</P></p>
<p><P>- Humberto tem o Recife (1,07 milhão); Olinda (283,8 mil); Cabo (125,8 mil); e Camaragibe (99,6 mil)</P></p>
<p><P><STRONG>3) A soma das cidades importantes favorece Humberto</STRONG></P></p>
<p><P>- Recife, Olinda, Cabo e Camaragibe somam um eleitorado de 1,58 milhão de votos</P></p>
<p><P>- As cidades maiores onde Eduardo conta com o apoio de l?deres importantes somam 1,08 milhão (Jaboatão, Paulista, Caruaru, Petrolina, Vitória, Igarassu, Serra Talhada, Itapissuma e Salgueiro)</P></p>
<p><P><STRONG>A chegada do PTB</STRONG></P></p>
<p><P>Humberto diz que a adesão de Armando&nbsp;Neto&nbsp;não chegou ao eleitorado. Ela&nbsp;é tema apenas das lideranças pol?ticas. Só a partir de gora, com a campanha nas ruas, começará a alcançar o eleitor. O petista também espera o in?cio do programa eleitoral na TV e no rádio para explorar melhor a vinculação com Lula. </P></p>
<p><P>O ex-ministro aposta em um crescimento maior na Região Metropolitana, onde é bastante conhecido - foi o vereador mais votado da história do Recife (27 mil votos), em 2000. </P></p>
<p><P>Ele também não crê que a estrutura&nbsp;montada pelo PSB&nbsp;no interior possa gerar mais frutos para Eduardo que os já&nbsp;produzidos.</P></p>
<p><P><STRONG>??ndice menor de rejeição</STRONG></P></p>
<p><P>Eduardo aposta na baixa rejeição que&nbsp;apresenta nas pesquisas JC/Vox Populi. Ele tem o menor ?ndice, de 4%, contra 10% de Mendonça e 11% de Humberto. Espera poder usar Lula na TV, como já vem fazendo no material gráfico que mandou imprimir.</P></p>
<p><P>O socialista espera um retorno elevado da estrutura que sua equipe diz ter&nbsp;no interior. O PSB contabiliza o apoio de 58 prefeitos, 75 vices, 130 ex-prefeitos e 800 vereadores. </P></p>
<p><P>Outros indicadors importantes&nbsp;são os de desempenho&nbsp;num segundo turno. Eduardo vence Humberto e perde melhor&nbsp;contra Mendonça.</P></FONT> </p>
