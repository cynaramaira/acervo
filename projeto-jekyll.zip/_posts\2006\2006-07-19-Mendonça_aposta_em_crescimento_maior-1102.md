---
id: 12372275
data_publicacao: "2006-07-19 19:17:00"
data_alteracao: "None"
materia_tags: "apostas,crescimento,Maioria,mendonça"
categoria: "Notícias"
titulo: "Mendonça aposta em crescimento maior"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>O comando da campanha da União por Pernambuco vê com otimismo o ritmo de crescimento da candidatura de Mendonça Filho. Ele tem 35% das intenções de voto no Estado, mas o governo alcança 39% de avaliação positiva. Ou seja, o candidato é hoje menor do que o governo (veja <B><A href=\"https://jc3.uol.com.br/especiais/eleicoes2006/\">números</A></B> da pesquisa JC/Vox Populi e texto postado <B><A href=\"https://jc3.uol.com.br/blogs/jc/2006/07/19/index.php#137\">abaixo</A></B>).</P></p>
<p><P>Eles rejeitam a avaliação de que Mendonça poderia ter conseguido percentuais melhores, mais próximos dos de Jarbas. O ex-governador deixou o mandato, em abril, com 61% de aprovação. Hoje, candidato ao Senado, tem 66%. Ou seja, é maior do que o próprio governo.</P></p>
<p><P>Essa avaliação, para eles, é pessimista. O comando de Mendonça diz o seguinte. Primeiro, ele está numa ótima trajetória de crescimento. Duplicou seus números nos últimos meses e logo estará num n?vel ainda melhor - faltam dois meses e meio para a eleição.</P></p>
<p><P>Dizem também que é \"extraordinário\" atingir cerca de 40% de avaliação positiva. Nenhum outro governador, ressaltam, chegou a tal ?ndice em tão pouco tempo, cerca de 90 dias. E lembram que há outros dados que colocam a gestão e o candidato em situação confortável. Pesquisas mostram que o governo supera os 50% quando se questiona o cidadão sobre se o aprova ou o&nbsp;desaprova.</P></p>
<p><P>Enfim, na visão deles e ao contrário do que sonha a oposição, Mendonça está num bom ritmo de apropriação da boa popularidade do governo Jarbas e deve chegar à eleição num patamar ainda melhor. Ninguém se arrisca, porém, a fazer apostas públicas sobre qual seria este número.</P></FONT> </p>
