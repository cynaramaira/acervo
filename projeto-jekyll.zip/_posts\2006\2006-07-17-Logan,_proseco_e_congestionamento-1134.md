---
id: 12372307
data_publicacao: "2006-07-17 19:57:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Logan, proseco e congestionamento"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Se você pretende ir ao Paço Alfândega, shopping chique no centro do Recife, desista. A não ser que tenha R$ 1 mil para gastar e queira participar do jantar de arrecadação de fundos para as campanhas de Jarbas e Mendonça. Mesmo assim será preciso paciência. O jantar congestionou estacionamentos e vias em torno do shopping.</P></p>
<p><P>Até lá dentro há um congestionamentode vips nas escadas. Todos aqueles nomes de 400 anos foram, de Brennand a Petribu.</P></p>
<p><P>Para quem já cumprimentou o governador e entrou, a situação está melhor. O lugar é espaçoso, pode receber até 1,2 mil pessoas. E deve lotar. </P></p>
<p><P>As bandejas circulam fartas, por enquanto, com canapés, u?sque Logan, vinho Monte Lindo e proseco. Tudo a R$ 1 mil por cabeça, incluindo o jantar - aquele pato ao cravo e canela com medalhões de filé.</P></FONT> </p>
