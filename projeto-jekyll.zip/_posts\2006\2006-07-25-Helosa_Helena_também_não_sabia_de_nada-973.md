---
id: 12372146
data_publicacao: "2006-07-25 18:13:00"
data_alteracao: "None"
materia_tags: "Naomi Campbell"
categoria: "Notícias"
titulo: "Helo?sa Helena também não sabia de nada"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Da Folha Online, em Bras?lia</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT>&nbsp;</P><SPAN style=\"FONT-SIZE: 9pt; COLOR: black; FONT-FAMILY: Verdana; mso-fareast-font-family: \Times New Roman\; mso-bidi-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT size=2>A senadora Helo?sa Helena (AL), candidata do PSOL à Presidência da República, demitiu hoje seu assessor de imprensa após descobrir que ele usava os e-mails do Senado para divulgar a agenda dela como candidata para ve?culos de comunicação. Helo?sa disse que \"não sabia de nada\" e que sua atitude não poderia ser diferente.<BR><BR>\"Não sabia, senão seria burra ou vigarista\", disse Helo?sa.<BR><BR>Helo?sa disse que não tinha outra opção senão demitir o funcionário. \"Se não tivesse sido r?gida, implacável todos iriam dizer que era um erro porque falo de todo mundo. Para que eu tenha autoridade de condenar a canalhice pol?tica não posso aceitar esse tipo de coisa\", disse.</FONT></SPAN> </p>
