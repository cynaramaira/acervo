---
id: 12371992
data_publicacao: "2006-08-02 08:12:00"
data_alteracao: "None"
materia_tags: "governo,mendonça,Votos Nulos"
categoria: "Notícias"
titulo: "Professora pede votos para Mendonça em ato do governo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Mônica Crisóstomo</STRONG><BR>Repórter de Pol?tica do JC</FONT></P></p>
<p><P><FONT face=Verdana>O ato era administrativo, mas isso não prejudicou a empolgação da diretora da Escola Estadual José Maria, Josefa Siqueira Alves, conhecida como </FONT><FONT face=Verdana>Zezinha.</FONT></P></p>
<p><P><FONT face=Verdana>Animada com a presença do governador-candidato Mendonça Filho (PFL) - que foi até a unidade educacional, localizada no bairro de Santo </FONT><FONT face=Verdana>Amaro, ontem pela manhã - para assinar a ordem de serviço que autoriza a construção de uma quadra poliesportiva - a educadora ignorou as </FONT><FONT face=Verdana>orientações repassadas para todo o serviço público estadual, através de decreto publicado no Diário Oficial - e caprichou no discurso eleitoral.</FONT></P></p>
<p><P><FONT face=Verdana>\"Temos muito a agradecer, mas também temos algumas melhorias para pedir. Mas se não for poss?vel agora, pode ser no ano que vem, porque com certeza ele (Mendonça) será reeleito na próxima eleição\", disparou, sob os aplausos de alunos e professores.</FONT></P></p>
<p><P><FONT face=Verdana>Durante os sete minutos em que esteve com o microfone mas mãos, Zezinha fez elogios rasgados a atuação do pefelista, a quem agradeceu reiteradas vezes pelo \"maravilhoso trabalho na educação\".</FONT></P></p>
<p><P><FONT face=Verdana>Visivelmente eufórica com a visita ilustre chegou pedir para as crianças trocarem os gritos de \"esso, esso, esso, Zezinha é um sucesso\" por \"Mendonça, Mendonça\". Foi parcialmente atendida.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinantes JC e UOL).</FONT></P> </p>
