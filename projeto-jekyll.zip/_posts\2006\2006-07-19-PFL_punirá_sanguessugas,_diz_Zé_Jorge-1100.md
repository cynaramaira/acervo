---
id: 12372273
data_publicacao: "2006-07-19 20:20:00"
data_alteracao: "None"
materia_tags: "jorge jesus"
categoria: "Notícias"
titulo: "PFL punirá sanguessugas, diz Zé Jorge"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Vice-presidente nacional do PFL, o senador José Jorge disse a Jamildo Melo, repórter especial do JC, que todos os deputados do partido envolvidos na CPI das Sanguessugas serão punidos. \"Se ficar comprovada qualquer irregularidade, eles serão expulsos e punidos\", garantiu.</FONT></P></p>
<p><P><FONT face=Verdana>Os pefelistas acusados de relação com o escândalo na compra de ambulâncias são Laura Carneiro e Almir Moura, do Rio de Janeiro, Zelinda Novaes e Coriolano Sales, da Bahia.</FONT></P> </p>
