---
id: 12372237
data_publicacao: "2006-07-21 22:47:00"
data_alteracao: "None"
materia_tags: "jarbas vasconcelos,Oposição,tempo,terapia"
categoria: "Notícias"
titulo: "Oposição terá mais tempo do que Jarbas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Os adversários do ex-governador Jarbas Vasconcelos (PMDB) contarão com um tempo mais do que suficiente no rádio e na TV para tentar reduzir a liderança dele na disputa pelo Senado.</FONT></P></p>
<p><P><FONT face=Verdana>Luciano Siqueira, candidato do PCdoB na chapa de Humberto Costa (PT), terá dois minutos e oito segundos nos programas das segundas, quartas e sextas. Terá ainda 115 inserções de 30 segundos no mês e meio de propaganda gratuita. Joge Gomes, do PSB de Eduardo Campos, ficará com um minuto e 59 segundos mais 107 inserções.</FONT></P></p>
<p><P><FONT face=Verdana>Juntos, terão 222 inserções e quatro minutos e sete segundos. Jarbas, sozinho, disporá de três minutos e 34 segundos nos programas, além de 193 inserções.</FONT></P></FONT> </p>
