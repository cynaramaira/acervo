---
id: 12372236
data_publicacao: "2006-07-21 18:37:00"
data_alteracao: "None"
materia_tags: "damares alves,primeira etapa"
categoria: "Notícias"
titulo: "A tromba da primeira-dama"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=Verdana size=2></p>
<p><P>Esqueceram de avisar a Taciana Mendonça, mulher do governador Mendonça Filho, de que haveria hoje o anúncio da equipe de coordenação da campanha. </P></p>
<p><P>Ela é da ala feminina. Acabou chegando no final e passou um bom tempo com uma baita tromba. Ao sentar, durante entrevista organizada pelo vice Evandro Avelar, foi logo perguntando a um dos colegas: \"Por que não me avisaram?\"</P></FONT> </p>
