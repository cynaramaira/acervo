---
id: 12372368
data_publicacao: "2006-07-15 09:01:00"
data_alteracao: "None"
materia_tags: "Ciro Gomes,Humberto Costa,Miguel Coelho"
categoria: "Notícias"
titulo: "Humberto e Ciro Coelho"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>O petista tomou café da manhã há pouco, no Hotel Plaza, em Salgueiro, na companhia do deputado estadual Ciro Coelho, do PFL de Petrolina, aliado de Mendonça. Segundo Ayrton Maciel, da equipe de Pol?tica do JC, o pefelista explicou aos repórteres surpresos: \"É só coincidência. Por enquanto.\"</P> </p>
