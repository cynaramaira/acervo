---
id: 12372016
data_publicacao: "2006-08-01 08:54:00"
data_alteracao: "None"
materia_tags: "eduardo,esquema criminoso"
categoria: "Notícias"
titulo: "Eduardo: Colocam nosso nome neste esquema só para confundir"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Aparentando tranqüilidade, o candidato a governador pelo PSB, Eduardo Campos, afirmou ontem que estão tentando \"confundir\" a opinião pública ao envolver o Ministério da Ciência e Tecnologia na máfia das sanguessugas. </FONT></P></p>
<p><P><FONT face=Verdana>Após caminhar pelas ruas da comunidade de Bola na Rede, ontem, o ex-ministro assegurou que, durante sua gestão, não foi firmado nenhum convênio ou liberado recursos para a empresa Planam, acusada de comandar a máfia. O socialista comandou o ministério de janeiro de 2004 a abril de 2005.</FONT></P></p>
<p><P><FONT face=Verdana>\"Não estou nem um pouco preocupado com esta citação porque enquanto eu estive no ministério não fizemos nenhum acordo com a empresa (Planam). Colocam o nosso nome neste esquema só para confundir. Não negociamos nenhum tipo de ambulância\", explicou o candidato. </FONT></P></p>
<p><P><FONT face=Verdana>A informação do suposto envolvimento do Ministério da Ciência e Tecnologia partiu de membros da CPI que investiga o esquema de corrupção, mas não foi divulgada nenhuma prova que comprovasse a participação. </FONT></P></p>
<p><P><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Verdana; mso-bidi-font-family: Arial\">Leia <EM><B><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></B></EM> o texto completo (assinantes JC e UOL).<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></SPAN></P> </p>
