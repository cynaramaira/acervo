---
id: 12372055
data_publicacao: "2006-07-29 14:08:00"
data_alteracao: "None"
materia_tags: "esquema criminoso,José Dirceu"
categoria: "Notícias"
titulo: "Darci Vedoin cita José Dirceu como parte do esquema"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Correio Braziliense</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Em depoimento secreto dado na CPI dos Sanguessugas no último dia 13, o empresário Darci Vedoin, dono da Planam, afirmou cinco vezes que, a partir da posse do presidente Luiz Inácio Lula da Silva, o dinheiro que abasteceu o caixa da quadrilha passou a ser liberado diretamente pela Casa Civil, a época chefiada por José Dirceu (PT-SP). </FONT></P></p>
<p><P><FONT face=Verdana>Segundo Vedoin, a liberação dos recursos era usada de forma a forçar os deputados, inclusive alguns da oposição, a votarem conforme o mando do Palácio do Planalto. <BR><BR>“O ministro da área tem uma cota. Mas quem aprova e quem paga chama-se Casa Civil. Só paga quem votar junto com ele???, informou Vedoin. Questionado pela senadora Helo?sa Helena (PSol-AL) sobre a existência de um contato dos sanguessugas dentro da Casa Civil incumbido de acelerar a liberação de verbas orçamentárias, ele primeiro negou. </FONT></P></p>
<p><P><FONT face=Verdana>Depois, refugou — “eu não tenho provas, senadora???. E por fim, confirmou, quando perguntado se alguém de dentro do esquema já mencionara o nome dessa pessoa: “Sim???. Darci Vedoin, porém, não disse de quem se tratava. <BR></FONT></P></p>
<p><P><FONT face=Verdana>(...)</FONT></P></p>
<p><P><FONT face=Verdana>De acordo com Darci Vedoin, a Planam preparava o pré-projeto e o projeto apresentados ao Ministério da Saúde, acertava a realização da licitação nas prefeituras e acionava os parlamentares com base na previsão de gastos no Orçamento da União. </FONT></P></p>
<p><P><FONT face=Verdana>Ele não diz com todas as letras, mas sugere que os ministros da cada área tinham autonomia para executar apenas as chamadas despesas “extra-orçamentárias???, como são chamados os gastos orçados pelo Ministério do Planejamento na Lei Orçamentária. Mas emendas parlamentares, não.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.correioweb.com.br/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinantes).</FONT></P> </p>
