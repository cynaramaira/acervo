---
id: 12372333
data_publicacao: "2006-07-16 17:32:00"
data_alteracao: "None"
materia_tags: "Humberto Costa,natação,prioridade,Segurança"
categoria: "Notícias"
titulo: "Segurança nunca foi prioridade, ataca Humberto"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Humberto Costa criticou há pouco, ao desembarcar no aeroporto do Recife, o desempenho do governo Jarbas/Mendonça Filho na área de Segurança Pública. Pesquisa divulgada hoje pelo jornal O Globo mostra que Pernambuco é o 18º colocado no ranking de gastos por habitante/ano para conter a violência, apesar de estar entre os três mais violentos do Pa?s. \"(A pesquisa) É prova cabal de que a segurança nunca foi uma prioridade. Isso explica parte dos problemas que temos. O desaparalhamento do Estado para enfrentar os problemas de violência é evidente\". </P></p>
<p><P>Se eleito, Humberto disse que vai priorizar a área, mas evitou se comprometer com aumentos salariais para a pol?cia. \"A nossa ideia é ampliar o efetivo da policia civil e militar, desenvolver um serviço de tecnologia e de inteligência policial. Outro tema é o da autonomia da pol?cia, a despartidarização. As promoções devem ocorrer por merecimento e não por conveniências pol?ticas. Também vamos investir uma maior qualificação de pessoal. Havendo crescimento da receita, uma das minhas preocupações será tentar melhorar os padrões salarias da pol?cia.\"</P></p>
<p><P>O blog continua tentando falar com Eduardo Campos sobre o assunto.</P></FONT> </p>
