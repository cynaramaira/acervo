---
id: 12372261
data_publicacao: "2006-07-20 16:02:00"
data_alteracao: "None"
materia_tags: "Bruno Covas,maranhão"
categoria: "Notícias"
titulo: "Disciplinado, Bruno Maranhão acata ordem do PT"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>O l?der sem-terra&nbsp;ficou indignado com o veto à participação dele no com?cio de Lula, sábado, no Recife. Mas vai acatar a decisão&nbsp;para não prejudicar o presidente. </FONT></P></p>
<p><P><FONT face=Verdana>\"Entrei em contato com a direção para saber como será minha participação. Não sou menino para criar contradição com a coordenação da campanha. Seria um erro da minha parte chegar aqui reivindicando participar do com?cio\", acaba de dizer o l?der do MLST, em entrevista coletiva&nbsp;no aeroporto.</FONT></P></p>
<p><P><FONT face=Verdana>Maranhão pretende provar que o Movimento de Libertação dos Sem Terra é inocente em relação ao quebra-quebra ocorrido na Câmara dos Deputados, em Bras?lia, no in?cio de junho. E quer mostrar que não há incoveniente na participação dele no com?cio. \"Vou conversar com várias pessoas. Se acharem que&nbsp;é inconveniente minha participação, tudo bem. Mas tenho que pensar numa estratégia para reeleger meu companheiro Lula, de quem sou amigo há mais de 25 anos. Esta é minha prioridade.\"</FONT></P></p>
<p><P><FONT face=Verdana>Após a coletiva, e depois de 38 dias preso na Papuda, em Bras?lia, ele segue para casa, o velho e bom um-por-andar-com-200-metros-quadrados, onde comemorará o aniversário da filha, Alessandra, 27 anos amanhã, que mora nos Estados Unidos.</FONT></P></FONT> </p>
