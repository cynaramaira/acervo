---
id: 12372174
data_publicacao: "2006-07-23 22:54:00"
data_alteracao: "None"
materia_tags: "Naomi Campbell"
categoria: "Notícias"
titulo: "Não perca!!!! Ela agora é socialista"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Ex-namorada de Jarbas Vasconcelos revela porque vai disputar um mandato de deputada estadual pelo PSB do arquiinimigo dele, Eduardo Campos.</P></p>
<p><P>A entrevista vem acompanhada de um belo ensaio com a modelo e Miss Pernambuco 2001.</P></p>
<p><P>Na rede, a partir das 6h desta segunda-feira.</P> </p>
