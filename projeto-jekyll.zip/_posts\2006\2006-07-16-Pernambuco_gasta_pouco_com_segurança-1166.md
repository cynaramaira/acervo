---
id: 12372339
data_publicacao: "2006-07-16 11:23:00"
data_alteracao: "None"
materia_tags: "pernambuco,Segurança"
categoria: "Notícias"
titulo: "Pernambuco gasta pouco com segurança"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 5pt 0cm; mso-pagination: none; mso-layout-grid-align: none\"></P><FONT size=2></p>
<p><P>Estudo mostra que o governo de Pernambuco ficou em 18º lugar no ranking de gastos por habitante/ano com Segurança Pública, apesar de o Estado estar entre os três mais violentos do Brasil. No ano passado, gastou apenas R$ 96,18, contra R$ 236,98 do Rio de Janeiro, R$ 153,81 de São Paulo e R$ 126,47 do Esp?rito Santo. No Nordeste, ficou atrás de Alagoas (R$ 108,10) e Sergipe (R$ 106,66). O levantamento foi feito pelo economista José Roberto Afonso e publicado na edição de hoje de O Globo.</P></p>
<p><P>Em sete anos e meio de gestão da União por Pernambuco (Jarbas/Mendonça Filho), mais de 31 mil pessoas foram assassinadas no Estado.</P></p>
<p><P>Leia mais em <A href=\"https://oglobo.globo.com/jornal/pais/284880956.asp\">O Globo</A>.</P></FONT> </p>
