---
id: 12372304
data_publicacao: "2006-07-18 09:13:00"
data_alteracao: "None"
materia_tags: "Aliança pelo Brasil,balanço,festa"
categoria: "Notícias"
titulo: "Balanço da festa da aliança"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>O empresário Eduardo Monteiro, dono do Grupo Folha (Folha de Pernambuco) e irmão do deputado federal Armando Monteiro Neto (PTB), foi o maior contribuinte individual na festa de arrecadação de fundos para as campanhas de Jarbas e Mendonça Filho.</P></p>
<p><P>Ele comprou 50 ingressos para ir ao jantar promovido ontem, no Recife, no chique Paço Alfândega. Pagou R$ 50 mil e ocupou um bom número de mesas.</P></p>
<p><P>A responsável pela festa, Lúcia Pontes, ex-chefe da Casa Civil de Jarbas, deu mais alguns dados interessantes. </P></p>
<p><P>O também empresário Ricardo Brennand&nbsp;colaborou com R$ 27 mil como pessoa f?sica.</P></p>
<p><P>Entre as empresas, um pool de Caruaru repassou R$ 85 mil. Outro, composto por seguradoras, mais R$ 15 mil. </P></p>
<p><P>\"Tivemos que fazer mais 100 convites. Se a gente tivesse colocado mais à venda, teria vendido\", disse no jantar, numa roda de amigos, o deputado&nbsp;José Mendonça Bezerra, pai do governador.</P></p>
<p><P>Daqui a pouco, Lúcia Pontes fará o balanço final da festa. Sabe-se que ao todo foram vendidos 1.132 ingressos. Nada menos que R$ 1,132 milhão.</P></p>
<p><P>&nbsp;</P></FONT> </p>
