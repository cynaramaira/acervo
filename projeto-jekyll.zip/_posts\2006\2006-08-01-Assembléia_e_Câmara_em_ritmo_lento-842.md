---
id: 12372015
data_publicacao: "2006-08-01 10:30:00"
data_alteracao: "None"
materia_tags: "Assembleia Geral,Câmara"
categoria: "Notícias"
titulo: "Assembléia e Câmara em ritmo lento"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>A Assembléia Legislativa do Estado e a Câmara Municipal do Recife voltam hoje aos trabalhos em clima de campanha, haja vista a quantidade de deputados estaduais e vereadores que vão concorrer nas eleições de outubro. </FONT></P></p>
<p><P><FONT face=Verdana>Mesmo com as suas campanhas nas ruas, os legisladores ouvidos pelo JC garantiram que a prioridade é votar os projetos de interesse da população.</FONT></P></p>
<p><P><FONT face=Verdana>Devido ao pleito que se aproxima haverá uma mudança no horário de funcionamento da Assembléia. Nos meses de agosto e setembro a sessão plenária das quintas-feiras será às 10h. Nas Segundas, terças e quartas continuará às 14h30. Não há votação nas sextas. </FONT></P></p>
<p><P><FONT face=Verdana>Já na Câmara do Recife o expediente é completo: de segunda à sexta, sempre às 15h. Nas duas casas as votações das matérias mais importantes devem se concentrar nas terças e quartas. </FONT></P></p>
<p><P><FONT face=Verdana>O objetivo é liberar o resto dias para os candidatos cairem em campo na busca do voto.</FONT></P></p>
<p><P><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Verdana; mso-bidi-font-family: Arial\">Leia <EM><B><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></B></EM> o texto completo (assinantes JC e UOL).<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></SPAN></P> </p>
