---
id: 12371952
data_publicacao: "2006-08-03 21:48:00"
data_alteracao: "None"
materia_tags: "Cirilo Mota,Humberto Costa"
categoria: "Notícias"
titulo: "Cirilo nega relação com Humberto Costa"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>blog</A></EM></STRONG> de Noblat</FONT></P></p>
<p><P><FONT face=Verdana>(Trecho de entrevista exclusiva de José Airton Cirilo, ex-candidato ao governo do Ceará pelo PT, acusado de facilitar a liberação de recursos do Ministério da Saúde para a máfia das ambulâncias)</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Qual a relação do senhor com o ex-ministro da saúde Humberto Costa?</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Nem amigo eu sou do ex-ministro. Conheci ele em 2002 no fim da campanha eleitoral daquele ano. Nunca fomos próximos. </FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Luiz Antônio Vedoin, dono da Planam, acusa o senhor de participar do esquema dos sanguessugas. Ele disse que tudo que era combinado com o senhor, o Ministério da Saúde cumpria. E que o senhor exercia influência sobre o ministro Humberto Costa.</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Esse canalha nunca tratou nada comigo que não fosse a instalação da fábrica. Isso é a maior heresia do mundo. No per?odo em que Humberto Costa foi ministro só me reun? com ele uma única vez. E para tratar da campanha de poliomelite. Como eu era vereador na época, participei da reunião. Nunca tive proximidade com o ex-ministro. </FONT></P></p>
<p><P><FONT face=Verdana><STRONG>O senhor intermediou junto ao Ministério da Saúde o pagamento de uma d?vida de R$ 8 milhões da Planam como contou Luiz Antônio Vedoin em depoimento à Justiça?</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Nunca ouvi falar desses R$ 8 milhões que a Planam tinha a receber. Isso é mentira, é mentira.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Leia a entrevista completa no blog de Noblat.</STRONG></FONT></P> </p>
