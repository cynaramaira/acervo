---
id: 12372247
data_publicacao: "2006-07-21 10:42:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Petistas sanguessugas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>De Cláudio Humberto, JC de hoje.</FONT></P></p>
<p><P><FONT size=2><FONT size=1><FONT size=2><FONT face=Verdana>O <I>petista cearense José Airton, ex-Agência Nacional de Transportes Terrestres, envolvido no caso das sanguessugas, quer uma acareação com Darci Vedoin, dono da empresa Planam, e o ex-ministro da Saúde Humberto Costa, também do PT. Luiz, o filho de Darci, revelou à Justiça que um sobrinho de Airton, Raimundo Lacerda Filho, teria pedido “pedágio??? para liberar recursos no ministério, após uma audiência de Costa a Darci.</I> </FONT></P></p>
<p><DIV id=corpo style=\"FONT-SIZE: 90%\"></p>
<p><P></p>
<p><P><B><FONT face=Verdana>Sanguessugas </FONT></p>
<p><P><FONT face=Verdana></FONT></B></p>
<p><P><FONT face=Verdana>Ney Suassuna acusa o deputado Raul Jungmann (PPS-PE, foto) de divulgar uma lista fajuta de parlamentares suspeitos, ainda não confirmada. </FONT></p>
<p><P><FONT face=Verdana></FONT></p>
<p><P><B><FONT face=Verdana>Sem medo </FONT></p>
<p><P></B><FONT face=Verdana>O senador Ney Suassuna (PMDB-PB) entregou sua defesa à CPI das Sanguessugas e pediu que as investigações sejam aprofundadas.</FONT></P></DIV></FONT></FONT></FONT> </p>
