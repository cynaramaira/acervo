---
id: 12372264
data_publicacao: "2006-07-20 17:41:00"
data_alteracao: "None"
materia_tags: "guerra,Humberto Costa"
categoria: "Notícias"
titulo: "Na guerra dos muros, Humberto já perdeu"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Até sábado, o pintor&nbsp;não pára com tanto muro na avenida Bras?lia Formosa. Mais à frente, a moradora do bairro mostra como é que os petistas vão passar no lugar, quando virem o tanto de Eduardo que tem por lá.</FONT></P></p>
<p><P><FONT face=Verdana>Pois bem. Está uma guerra em Bras?lia Teimosa, no Recife, onde haverá no sábado o primeiro com?cio da campanha de Lula à reeleição. Os candidatos a deputado e a governador disputam palmo a palmo cada pedaço de muro - um dos últimos lugares do Brasil onde se pode fazer propaganda eleitoral.</FONT></P></p>
<p><P><FONT face=Verdana>Eduardo, mais uma vez, partiu&nbsp;á frente na disputa com Humberto para estar associado a Lula. Pegou os melhores espaços entre a entrada da avenida e o palco do com?cio (fotos). Tem dois gigantescos só com o nome e a marca dele.</FONT></P></p>
<p><P><FONT face=Verdana>Humberto está na rabeira dos muros dos proporcionais. Uma coisa incr?vel.</FONT></P></p>
<p><P><FONT face=Verdana>João da Costa, o ex-secretário petista e candidato a deputado estadual do prefeito João Paulo, tem quase o mesmo espaço que Eduardo. </FONT></P></p>
<p><P><FONT face=Verdana>Mas no muro dele a área para Lula+Humberto+Luciano é tão pequena que poderia ter colocado Lula-Humberto-Luciano, ninguém notaria.</FONT></P></p>
<p><P><FONT face=Verdana>Tem muros com importantes inscrições de Maur?cio Rands, Isaltino Nascimento, Dilson Peixoto (todos do PT), Milton Coelho e Ana Arraes (do PSB).</FONT></P></p>
<p><P><FONT face=Verdana>Como ninguém é maluco, os moradores evitam falar em preços cobrados pelas propagandas. Pagar por isso é crime eleitoral. Pode levar o candidato a perder o mandato, caso eleito.</FONT></P></p>
<p><P><FONT face=Verdana>Mesmo assim, Cec?lia Ramos, repórter do <STRONG>Blog</STRONG>, apurou que há uma tabela informal. Cada muro, segundo os pintores e moradores, teria custado cerca de R$ 250, mais R$ 3 por metro pelo trabalho da pintura. Isso não inclui despesas eventuais com, por exemplo, um bom letrista, para riscar as letras mais complicadas.</FONT></P></FONT> </p>
