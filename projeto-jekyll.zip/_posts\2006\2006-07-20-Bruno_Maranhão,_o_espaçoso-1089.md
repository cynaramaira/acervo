---
id: 12372262
data_publicacao: "2006-07-20 16:23:00"
data_alteracao: "None"
materia_tags: "Bruno Covas,maranhão"
categoria: "Notícias"
titulo: "Bruno Maranhão, o espaçoso"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><A name=post23430><FONT face=Verdana>O transgressor</FONT></A></P></p>
<p><P class=fontPadrao><FONT face=Verdana></FONT></p>
<p><P><FONT face=Verdana>(do blog de Noblat - </FONT><A href=\"https://www.noblat.com.br\"><FONT face=Verdana>www.noblat.com.br</FONT></A><FONT face=Verdana>)</FONT></P></p>
<p><P><FONT face=Verdana>Sabe o que é um sujeito folgado, espaçoso e que não está&nbsp;nem a? para nada que não lhe seja conveniente? Esse é o Bruno Maranhão, l?der do MLST.<BR><BR>Ainda no aeroporto de Bras?lia, ele furou a fila de passageiros para embarcar no vôo 1810 da GOL com destino ao Recife. </FONT></P></p>
<p><P><FONT face=Verdana>Na hora de mostrar o bilhete de embarque à funcionária da GOL, pediu para não fazê-lo. Alegou que estava com as mãos ocupadas. Cedeu diante da insistência da funcionária. </FONT></P></p>
<p><P><FONT face=Verdana>A bordo do avião, atrapalhou mais de uma vez o trabalho das comissárias por se levantar com freqüência para conversar com amigos durante o vôo. </FONT></P></p>
<p><P><FONT face=Verdana>Nos últimos 20 minutos de viagem, plantou-se com um amigo perto da cabine do comandante de vôo e, só de meias, jogou conversa fora até a hora de voltar ao seu assento.</FONT></P> </p>
