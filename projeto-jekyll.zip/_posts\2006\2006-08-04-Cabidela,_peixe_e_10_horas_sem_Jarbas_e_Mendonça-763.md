---
id: 12371936
data_publicacao: "2006-08-04 13:31:00"
data_alteracao: "None"
materia_tags: "Altas Horas,jarbas vasconcelos,mendonça,peixe"
categoria: "Notícias"
titulo: "Cabidela, peixe e 10 horas sem Jarbas e Mendonça"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>O presidenciável tucano completará daqui a pouco dez horas de permanência em Pernambuco.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Ele desembarcou no Recife às 4h20, foi recebido por Bruno Araújo (PSDB), deputado estadual e candidato&nbsp;a federal. </FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Tomou café no quarto mesmo, um menu burocrático: café com leite, pão e geléia. Depois esteve aqui na Rádio Jornal, dando entrevista a Geraldo Freire.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Geraldo Alckmin está neste momento comendo uma galinha ao molho pardo, como&nbsp;chama a nossa velha e boa galinha à cabidela, que ele&nbsp;adora.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>O tucano almoça com jornalistas no Mourisco, em Olinda, cujo dono, Zinho Correia, é amigo-irmão de Jarbas Vasconcelos.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Zinho preparou um menu sintonizado com os sabores apreciados por Alckmin. Tem peixe ao forno, pernil de porco, camarão ao molho de tomate,<SPAN style=\"mso-spacerun: yes\">&nbsp; </SPAN>sururu, siri, filé ao molho de madeira e, claro, a cabidela.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Só não tem Jarbas nem Mendonça Filho. Devem estar com agendas cheias. </FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Ambos&nbsp;se integram ao roteiro do tucano às 14h30, no Centro de Convenções de Pernambuco, em Olinda.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Ele vai apresentar suas propostas para o desenvolvimento do Nordeste. </FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Por sinal, estava neste instante dando uma revisada no documento que sua assessoria preparou. O texto fala de Novo Nordeste.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana></FONT>&nbsp;</P> </p>
