---
id: 12372097
data_publicacao: "2006-07-28 15:20:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Eu nunca conversei com Garotinho, diz Helo?sa Helena"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Candidata do P-SOL diz no Recife que não sabia que o ex-governador Anthony Garotinho havia decidido apoiá-la, que não conversou com ele e prefere não comentar a adesão.</FONT></P></p>
<p><P><FONT face=Verdana>\"Claro, humildemente, todas as pessoas que querem votar em mim eu tenho que agradecer\", ressaltou.</FONT></P></p>
<p><P><FONT face=Verdana>HH falou também das dificuldades para enfrentar os adversários, principalmente Lula e Alckmin, que têm estruturas maiores para viajar e fazer campanha no pa?s inteiro.</FONT></P></p>
<p><P><FONT face=Verdana>\"Há uma luta desigual\", diz Helo?sa Helena</FONT></P><FONT face=Verdana></p>
<p><P>Ouça o que ela disse a Wagner Gomes, no programa de Geraldo Freire, na Rádio Jornal.</P></FONT> </p>
