---
id: 12371941
data_publicacao: "2006-08-04 11:32:00"
data_alteracao: "None"
materia_tags: "geraldo Alckmin,pesquisas,skate"
categoria: "Notícias"
titulo: "Alckmin quer crescer até sete pontos nas pesquisas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>O senador José Jorge (PFL-PE), vice de Alckmin, disse há pouco ao <STRONG>Blog</STRONG> que a coordenação da campanha trabalha com a meta de reduzir para 10 pontos percentuais, em 15 dias, a diferença entre o tucano e o presidente Lula.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>A meta é ousada. Lula obteve nas últimas pesquisas Ibope e Datafolha&nbsp;vantagens de 17 e 16 pontos, respectivamente.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>A campanha de Alckmin avalia que a redução é poss?vel com o in?cio da propaganda eleitoral no próximo dia 15. </FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>“O outro (Lula) já foi candidato sete vezes, é mais conhecido. O que vai contar mesmo é a propaganda???, acrescentou Jorge.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Com a exposição no horário eleitoral, diz o senador, é poss?vel alcançar essa diferença de 10 pontos</p>
<p> até 30 de agosto. Nesse n?vel, seria assegurado o segundo turno da eleição:</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>“Lula trabalha para ganhar no primeiro turno. Nós queremos provocar o segundo. Se conseguirmos esse patamar em 30 de agosto, teremos consolidado o segundo turno e ficaremos com mais um mês de propaganda para conquistar um n?vel ainda melhor nas pesquisas???.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>José Jorge acompanha Alckmin aqui no programa de Geraldo Freire, na <EM>Rádio Jornal</EM>.</FONT></P> </p>
