---
id: 12371999
data_publicacao: "2006-08-01 20:18:00"
data_alteracao: "None"
materia_tags: "Ibope,Miguel Coelho,milton,natação"
categoria: "Notícias"
titulo: "“O Ibope vai ter que se explicar???, ataca Milton Coelho"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>De Milton Coelho,&nbsp;presidente do PSB de Eduardo Campos, indignado com a diferença de 10 pontos percentuais em relação a Humberto:</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>“A gente, até aqui, tem o comportamento de não questionar as pesquisas, até porque fazemos sondagens constantes. Sai pesquisa e entra pesquisa, e a gente mantém a tranqüilidade. Os números são tão absurdos que eu, pessoalmente, renego. Acho que é uma forma de, através de pesquisa, tirar Eduardo da disputa.???</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Em entrevista a Jorge Cavalcanti, repórter do JC,&nbsp;Milton Coelho diz mais:</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>“Não é novidade falha do Ibope em pesquisas. Institutos diferentes, (contratados pelo) JC e Folha de Pernambuco, deram o mesmo resultado, dentro da margem de erro, que conferiam com os nossos. Não existe nenhum elemento que provoque essa disparidade em poucos dias???.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>“Nós vamos questionar os resultados pelas vias judiciais. O Ibope vai ter que se explicar. Vamos conversar amanhã com o candidato e o jur?dico para definir a medida (judicial). Não é poss?vel que no século 21, numa disputa tão acirrada, o processo passe a sofrer influências como essas???.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2>Milton Coelho disse ainda que o PSB realizou pesquisa no mesmo per?odo, exatamente para comparar os números com os do Ibope. “Temos resultados concomitantes com o Ibope. Não temos com o que nos preocupar, a não ser com os números, que são absurdos???.</FONT></SPAN> </p>
