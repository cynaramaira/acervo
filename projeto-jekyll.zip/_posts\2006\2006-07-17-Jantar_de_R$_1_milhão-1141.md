---
id: 12372314
data_publicacao: "2006-07-17 15:32:00"
data_alteracao: "None"
materia_tags: "jantar"
categoria: "Notícias"
titulo: "Jantar de R$ 1 milhão"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Mais de&nbsp;mil pessoas confirmaram presença no jantar que a União por Pernambuco promove hoje à noite, no Paço Alfândega, no Recife, para arrecadar fundos destinados às campanhas de Jarbas e Mendonça. Cada participante está pagando R$ 1 mil, em cheque nominal. A aliança registrou no Tribunal Regional Eleitoral uma previsão total de gastos de R$ 19 milhões (Governo e Senado).</P></p>
<p><P>O balanço da arrecadação será feito amanhã por Lúcia Pontes, assessora e ex-chefe da Casa Civil de Jarbas.</P></FONT> </p>
