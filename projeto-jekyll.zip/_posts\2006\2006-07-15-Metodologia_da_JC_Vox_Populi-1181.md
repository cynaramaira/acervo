---
id: 12372354
data_publicacao: "2006-07-15 15:45:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Metodologia da JC/Vox Populi"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>A pesquisa JC/Vox Populi foi feita nos dias 7 e 8 de julho de 2006. É um levantamento quantitativo para investigar as opiniões e expectativas da população do Estado sobre as eleições e o desempenho dos governantes, feito de acordo com a técnica de survey, que consiste na aplicação de questionários padronizados a uma amostra representativa do universo de investigação. Foram feitas 800 entrevistas domiciliares com moradores e eleitores de 38 munic?pios, de idade superior a 16 anos, e adotada uma amostra estratificada por cotas, calculadas de acordo com dados do IBGE, Censo de 2000 e TSE. O intervalo de confiança é de 95% e a margem de erro média de 3,5 pontos percentuais, para mais ou para menos. A pesquisa foi registrada no TRE-PE no dia 07 de julho de 2006, sob o número 8898/2006.</P> </p>
