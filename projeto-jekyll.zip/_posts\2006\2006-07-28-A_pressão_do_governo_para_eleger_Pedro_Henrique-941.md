---
id: 12372114
data_publicacao: "2006-07-28 09:52:00"
data_alteracao: "None"
materia_tags: "depressão,governo,henrique albino,pedro manta"
categoria: "Notícias"
titulo: "A pressão do governo para eleger Pedro Henrique"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Não será fácil o final de semana para os 36 desembargadores do Tribunal de Justiça de Pernambuco. </FONT></P></p>
<p><P><FONT face=Verdana>Eles escolherão na segunda-feira os advogados que comporão lista tr?plice a ser encaminhada ao governador Mendonça Filho (PFL) para nomeação do 37º desembargador - cargo vago hoje em função da aposentadoria de Dário Rocha.</FONT></P></p>
<p><P><FONT face=Verdana>A pressão sobre eles já começou e deve se intensificar. Todo o governo, com Jarbas Vasconcelos e Mendonça Filho à frente, faz o poss?vel e o imposs?vel para assegurar a entrada de Pedro Henrique Reinaldo Alves na lista tr?plice. </FONT></P></p>
<p><P><FONT face=Verdana>Por pouco, ele não era derrotado na eleição direta promovida ontem pela Ordem dos Advogados do Brasil em Pernambuco. A OAB elegeu uma lista sêxtupla para encaminhar ao TJ, que chegará à tr?plice.</FONT></P></p>
<p><P><FONT face=Verdana>Apesar de Pedro Henrique ter ficado em sexto, o governo saiu vitorioso da disputa. Enfrentou e venceu o presidente da OAB, Júlio Oliveira, que usou toda a máquina da entidade para eleger uma chapa fechada que exclu?sse o candidato de Jarbas e Mendonça.</FONT></P></p>
<p><P><FONT face=Verdana>Não fosse a força do governo, Henrique teria ficado fora. Veja os números:</FONT></P></p>
<p><P><FONT face=Verdana>1º Jorge Neves Batista&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1.381 </FONT></P></p>
<p><P><FONT face=Verdana>2º Francisco Bandeira&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1.264</FONT></P></p>
<p><P><FONT face=Verdana>3º Braga Sá&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1.102</FONT></P></p>
<p><P><FONT face=Verdana>4º Edgar Moury Fernandes&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1.085</FONT></P></p>
<p><P><FONT face=Verdana>5º Reinaldo Gueiros&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1.049</FONT></P><B></p>
<p><P><FONT face=Verdana>6º Pedro Henrique Alves&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 999</FONT></P></B></p>
<p><P><FONT face=Verdana>------------</FONT></P></p>
<p><P><FONT face=Verdana>7º Carlos Gil Rodrigues&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;948</FONT></P></p>
<p><P><FONT face=Verdana>------------</FONT></P></p>
<p><P><FONT face=Verdana>Carlos Gil deveria estar no lugar de Pedro Henrique. Ele era o último da chapa fechada de Júlio Oliveira. Tanto que, d</FONT><FONT face=Verdana>epois dele, o 7º e o 8º colocados aparecem com votações muito menos expressivas. Dayse Maya teve 560 votos. José Carlos Cavalcanti, o 8º, recebeu 416.</FONT></P></p>
<p><P><FONT face=Verdana>A entrada de Pedro Henrique, ex-procurador geral adjunto do Estado, foi uma vitória do governo, que agora faz as contas para conseguir alçá-lo, pelo menos, à terceira colocação entre os eleitos pelos desembargadores.</FONT></P></p>
<p><P><FONT face=Verdana>O governo aposta que ele terá cerca de 18 votos. Os dois primeiros colocados devem receber entre 20 e 25.</FONT></P></p>
<p><P><FONT face=Verdana>A disputa pelas duas primeiras colocações, imaginam os governistas, ficará entre Jorge Neves, Francisco Bandeira e Edgar Moury Neto.</FONT></P></p>
<p><P><FONT face=Verdana>Neves foi presidente da OAB por três mandatos e tem tradição familiar no meio jur?dico estadual.</FONT></P></p>
<p><P><FONT face=Verdana>Bandeira é ligad?ssimo ao senador Marco Maciel, homem de fortes relações com o Judiciário. Moury Neto também conta com boas relações, mas principalmente por méritos próprios.</FONT></P></p>
<p><P><FONT face=Verdana>Se entrar na lista tr?plice, não há dúvidas, Pedro Henrique será o próximo desembargador, apesar de 6º colocado na sêxtupla.</FONT></P> </p>
