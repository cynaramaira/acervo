---
id: 12372216
data_publicacao: "2006-07-22 18:54:00"
data_alteracao: "None"
materia_tags: "festa,pernambuco,União"
categoria: "Notícias"
titulo: "A festa da União por Pernambuco"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Sem lei seca, mas com muito afeto. Depois de uma boa rodada de Bohemia, na casa de Jarbas, Sérgio Guerra, Mendonça Filho, Evandro Avelar e Roberto Freire seguiram para a inauguração do comitê, no Recife.</FONT></P></p>
<p><P><FONT face=Verdana>No comitê, Marco Maciel botou pra funcionar o velho e bom gogó que o mantém firme e forte na pol?tica há quatro décadas. Depois dos discursos, Mendonça mostrou até que ponto a aliança dá sustentação à candidatura dele.</FONT></P></p>
<p><P><FONT face=Verdana>E Jarbas, bem, Jarbas é um caso à parte. Popular, bem posicionado nas pesquisas, tranqüilo com as obras que realizou nas sucessivas gestões na Prefeitura do Recife e no Governo de Pernambuco, mostrou que está de bem com vida. Depois de um papo franco com Medonça, foi generoso com os amigos, celebrando tudo com uma boa branquinha.</FONT></P></FONT> </p>
