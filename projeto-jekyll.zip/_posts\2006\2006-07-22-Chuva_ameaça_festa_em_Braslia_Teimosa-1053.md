---
id: 12372226
data_publicacao: "2006-07-22 17:32:00"
data_alteracao: "None"
materia_tags: "Brasília Teimosa,chuva,festa"
categoria: "Notícias"
titulo: "Chuva ameaça festa em Bras?lia Teimosa"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>O tempo está fechando. Já se sente um pingo ou outro. Até agora, chegaram muitos candidatos proporcionais. Armando Monteiro Neto, acompanhado do pai, Armando Filho, Dilson Peixoto, Maur?cio Rands, João da Costa, Tereza Leitão e o vice-prefeito Luciano Siqueira, candidato de Humberto Costa ao Senado.</FONT></P></p>
<p><P><FONT face=Verdana>As estrelas estão com Lula no Recife Praia Hotel, a poucos metros dali. João Paulo, Humberto, Eduardo Campos e a comitiva do presidente batem um papo antes de ir para o palanque na avenida Bras?lia Formosa.</FONT></P></p>
<p><P><FONT face=Verdana>No hotel, João Paulo tenta combinar com Lula um jantar no apartamento dele, nas Graças. Lula pernoita aqui para participar amanhã de um encontro com intelectuais do Nordeste. Será em Olinda, na Academia Santa Gertrudes.</FONT></P></FONT> </p>
