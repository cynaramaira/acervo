---
id: 12371922
data_publicacao: "2006-08-05 07:41:00"
data_alteracao: "None"
materia_tags: "Desigualdades,nordeste"
categoria: "Notícias"
titulo: "Nordeste quase igual"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Fernando Castilho</STRONG><BR></FONT><FONT face=Verdana>Colunista de Economia do JC</FONT></P></p>
<p><P><FONT face=Verdana>Quando, nos próximos dias, o presidente Lula divulgar os documentos sobre as pol?ticas para um eventual segundo per?odo de governo para o Nordeste, qualquer pessoa que comparar o programa do PT com o do PSDB vai ver que os economistas que assessoram os dois candidatos trabalharam sobre as mesmas propostas. Trabalharam, também, sobre as mesmas interpretações acadêmicas, diferenciando-se apenas em função do viés pol?tico.</FONT></P></p>
<p><P><FONT face=Verdana>É compreens?vel. Sem o banco de dados da Sudene, os estudiosos trabalham em cima de dados do IBGE, das planilhas de aplicação de crédito para baixa-renda do Banco do Nordeste e dos trabalhos feitos pela Fundação Getúlio Vargas para o Ministério da Integração. Na verdade, está aberto um grande mercado para consultores escreverem dezenas de estudos sobre propostas para o Nordeste, exatamente porque, com o desmanche do sistema de planejamento regional, não existe mas uma base de dados num único lugar.<BR></FONT><BR><FONT face=Verdana>Isso fez com que os economistas que escreveram o texto do candidato Geraldo Alckmin trabalhassem não só sobre os mesmos dados, mas sobre as mesmas propostas que estão sendo escritas no Ministério da Integração. Algumas delas de discussão sobre temas antigos: como o Novo Semi-??rido, criação de redes de cidades-pólo, implantação de novos fundos constitucionais, fortalecimento da educação básica e superior e ampliação da rede de proteção social. Sim, tiveram que incluir o tema revitalização da Sudene.</FONT></P> </p>
