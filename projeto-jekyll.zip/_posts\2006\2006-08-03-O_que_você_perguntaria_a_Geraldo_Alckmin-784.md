---
id: 12371957
data_publicacao: "2006-08-03 17:34:00"
data_alteracao: "None"
materia_tags: "geraldo Alckmin"
categoria: "Notícias"
titulo: "O que você perguntaria a Geraldo Alckmin?"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Pois é, Alckmin, o presidenciável tucano, vai estar aqui, amanhã, para uma visita ao <EM>Jornal do Commercio</EM>, à <EM>TV Jornal</EM> e para uma entrevista no programa de Geraldo Freire, na <EM>Rádio Jornal</EM>.</FONT></P></p>
<p><P><FONT face=Verdana>O que vocês gostariam de perguntar a ele? </FONT></P></p>
<p><P><FONT face=Verdana>Apresentem suas questões aqui embaixo, na seção comentários.</FONT></P></p>
<p><P><FONT face=Verdana>O <STRONG>Blog</STRONG> vai pedir a ele para respondê-las.</FONT></P> </p>
