---
id: 12372043
data_publicacao: "2006-07-31 10:45:00"
data_alteracao: "None"
materia_tags: "paulo freire,Votos Nulos"
categoria: "Notícias"
titulo: "Os pol?ticos de-votos de Frei Damião"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>O <STRONG>Blog do JC</STRONG> passa a publicar a partir de hoje, sempre às segundas,&nbsp;uma série de histórias relacionadas às eleições e à pol?tica do Estado, que vêm sendo produzidas pelo site <STRONG>Pernambuco de A/Z</STRONG> (<A href=\"https://www.pe-az.com.br/\">www.pe-az.com.br</A>). Boa leitura.</FONT></P></p>
<p><P><FONT face=Verdana>----------------------------</FONT></P></p>
<p><P><FONT face=Verdana>Do <STRONG>Pernambuco de A/Z</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Falecido em 1997, Frei Damião de Bozzano era um religioso carismático, um missionário tido como <EM>santo</EM> pelos sertanejos nordestinos – só comparado ao lendário Padre C?cero Romão, o <EM>santo</EM> do Juazeiro do Norte.</FONT></P></p>
<p><P><FONT face=Verdana>Por essas razões, o frade capuchinho sempre despertou a cobiça de pol?ticos que o agraciavam com medalhas, t?tulos e honrarias ou que simplesmente posavam ao seu lado e, depois, faziam de tudo isso material de propaganda eleitoral.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.pe-az.com.br/politica/memoria_politica.htm\" target=_blank>aqui</A></EM></STRONG> o texto completo.</FONT></P> </p>
