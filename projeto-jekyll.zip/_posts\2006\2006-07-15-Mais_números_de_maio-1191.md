---
id: 12372364
data_publicacao: "2006-07-15 10:29:00"
data_alteracao: "None"
materia_tags: "animais"
categoria: "Notícias"
titulo: "Mais números de maio"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Na pesquisa feita em 7 de maio, quando as candidaturas ainda não estavam homologadas, o JC publicou o seguinte:</P></p>
<p><P><BR><STRONG>Intenção de voto espontânea<BR></STRONG>(quando o eleitor indica o candidato sem a apresentação de listas)</P></p>
<p><P>Mendonça&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 8%</P></p>
<p><P>Eduardo&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 8%</P></p>
<p><P>Jarbas&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;7%</P></p>
<p><P>Humberto&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; 4%</P></p>
<p><P>Roberto Magalhães&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;1%</P></p>
<p><P>Armando Neto&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1%</P></p>
<p><P><BR>--------------------------------------</P></p>
<p><P><STRONG>Qual destes candidatos têm mais chances de vitória?</STRONG></P></p>
<p><P><BR>Mendonça&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
<p> 36%</P></p>
<p><P>Eduardo&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;23%</P></p>
<p><P>Humberto&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 18%</P></p>
<p><P>Armando&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5%</P></p>
<p><P>Clóvis Corrêa&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1%<BR></P> </p>
