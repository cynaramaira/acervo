---
id: 12372090
data_publicacao: "2006-07-28 19:04:00"
data_alteracao: "None"
materia_tags: "Contas Externas,Fechamento,Naomi Campbell"
categoria: "Notícias"
titulo: "As contas da CPI não fecham. Vai dar pizza"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <B>Fernando Castilho<BR></B></FONT><FONT face=Verdana>Colunista de Economia do JC</FONT></P><FONT face=\"Courier New\"></p>
<p><P><FONT face=Verdana>Basta uma conta de padaria para saber que, apesar do barulho, a CPI das Sanguessugas não vai dar em muita coisa em termos de punição no plenário da Câmara Federal. </FONT></P></p>
<p><P><FONT face=Verdana>Segundo o marqueteiro Marcelo Teixeira, da Makplan, se, dos 513 deputados da casa, os 109 suspeitos votarem, a sessão já começa com 109 votos contra qulquer cassação.</FONT></P></p>
<p><P><FONT face=Verdana>Se eles não estiverem no plenário, o desafio é conseguir, primeiro, que os 404 restantes compareçam. Segundo, que, destes, 257 votem a favor, cumprindo o quórum m?nimo exigido.</FONT></P></FONT> </p>
