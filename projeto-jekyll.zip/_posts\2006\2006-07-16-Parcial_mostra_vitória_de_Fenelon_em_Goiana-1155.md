---
id: 12372328
data_publicacao: "2006-07-16 19:17:00"
data_alteracao: "None"
materia_tags: "Anavitória,Goiana,Mostra"
categoria: "Notícias"
titulo: "Parcial mostra vitória de Fenelon em Goiana"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Apurados os votos em&nbsp;94% das sessões eleitorais de Goiana, 142 das 151 existentes, os resultados são os seguintes:</P></p>
<p><P>Henrique Fenelon (PCdoB)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 40,98% (15.488 votos)</P></p>
<p><P>Edval Soares (PTB)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
<p> 32,96% (12.459 votos)</P></p>
<p><P>Ana Silveira (PDT)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;21,12% (7.983 votos)</P></p>
<p><P>Paulo Veloso (PT)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4,52% (1.708 votos)</P></p>
<p><P>Ezildo Gadelha (PPS)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 0,42%&nbsp;&nbsp;&nbsp;(160 votos)</P></p>
<p><P>&nbsp;</P> </p>
