---
id: 12371977
data_publicacao: "2006-08-02 17:55:00"
data_alteracao: "None"
materia_tags: "Lula"
categoria: "Notícias"
titulo: "Lula admite propor uma Constituinte"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><DIV id=credito-texto><FONT face=Verdana>Por <STRONG>Ricardo Amaral</STRONG><BR>Da Reuters</FONT></DIV></p>
<p><P><FONT face=Verdana>O presidente Luiz Inácio Lula da Silva disse nesta quarta-feira (2/8) que pode enviar ao Congresso, depois das eleições, proposta de emenda constitucional (PEC) propondo a convocação de uma Assembléia Constituinte exclusiva, com a finalidade espec?fica de votar a reforma pol?tica.<BR><BR>Lula admitiu a convocação da Constituinte exclusiva, que seria uma assembléia paralela e independente do Congresso, durante encontro com uma comissão de juristas e ex-presidentes da Ordem dos Advogados do Brasil (OAB), no final da manhã, no Palácio do Planalto.<BR></FONT></P> </p>
