---
id: 12372206
data_publicacao: "2006-07-22 21:07:00"
data_alteracao: "None"
materia_tags: "bipolaridade,jantar,peixe"
categoria: "Notícias"
titulo: "Bode, peixe e macaxeira no jantar"
sutia: "None"
chapeu: "None"
autor: "jamildo"
imagem: "None"
---
<p>&nbsp;</p>
<p>J&aacute; come&ccedil;ou o jantar para Lula no apartamento de Jo&atilde;o Paulo, nas Gra&ccedil;as. Tudo estava programado para 15 pessoas. Agora v&atilde;o umas 30.</p>
<p>"Vou ter que comprar mais comida", disse o prefeito a Cec?lia Ramos, rep&oacute;rter do Blog. Jo&atilde;o Paulo n&atilde;o cabe em si por causa desse jantar.</p>
<p>A lista de convidados, al&eacute;m de Lula, inclui o ministro Luiz Dulci, o presidente da C&acirc;mara, Aldo Rebelo, o presidente do PT e coordenador da campanha, Ricardo Berzoini, Ariano Suassuna, Armando Neto e Armando Filho.</p>
<p>V&atilde;o tamb&eacute;m as chapas completas de Humberto e Eduardo: Augusto C&eacute;sar de Carvalho e Jo&atilde;o Lyra Neto (os vices), Luciano Siqueira e Jorge Gomes (candidatos ao Senado) e as respectivas esposas.</p>
<p>Jo&atilde;o Paulo est&aacute; oferecendo tudo o que o presidente gosta: bode, peixe, macaxeira e outras iguarias regionais.</p>
