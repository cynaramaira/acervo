---
id: 12372281
data_publicacao: "2006-07-19 17:06:00"
data_alteracao: "None"
materia_tags: "amigos,Bruno Covas,maranhão"
categoria: "Notícias"
titulo: "Amigos preparam recepção para Bruno Maranhão"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Vai ser uma festa a chegada amanhã, no Recife, de Bruno Maranhão, l?der do MLST (Movimento de Libertação dos Sem Terra). Ele desembarca às 15h, vindo de Bras?lia, onde ficou preso por 38 dias, incomunicável, em cela comum, na Papuda, principal complexo penitenciário do Distrito Federal.</P></p>
<p><P>Maranhão é herdeiro de usineiros, mas militante de esquerda, ligado historicamente a Lula e ao PT. Ele era membro da executiva nacional até ser afastado depois do quebra-quebra ocorrido na Câmara dos Deputados, no in?cio de junho, durante manifestação do MLST.</P></p>
<p><P>Em conversa com o blog, um dos irmãos de Bruno, Carlos Henrique Maranhão, confirmou que está organizando a festa. \"Estou chamando amigos para recepcioná-lo no Aeroporto\".</P></p>
<p><P>Do aeroporto,&nbsp;segue direto para casa, aquele belo apartamento de 200 metros quadrados, um por andar,&nbsp;em bairro nobre do Recife.</P></p>
<p><P>Leia <STRONG><A href=\"https://jc3.uol.com.br/blogs/jc/2006/07/18/index.php#117\" target=_blank>aqui</A></STRONG> a entrevista exclusiva concedida ao blog por Bruno Maranhão, anteontem à noite.</P></FONT> </p>
