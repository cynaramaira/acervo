---
id: 12371975
data_publicacao: "2006-08-02 19:57:00"
data_alteracao: "None"
materia_tags: "confronto"
categoria: "Notícias"
titulo: "O confronto dos guias eleitorais"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>O fotógrafo é do Palácio das Princesas, mandado pela equipe do governador Mendonça Filho (PFL).</P></p>
<p><P>O cinegrafista (sentado e circulando) é de Eduardo Campos (PSB).</P></p>
<p><P>Os PMs e os sem-terra foram apenas figurantes no confronto iminente da desapropriação do Engenho São João, em São Lourenço da Mata, Região Metropolitana do Recife.</P></p>
<p><P>Fotógrafo e cinegrafista estiveram lá para registrar tudo, principalmente se houvesse conflito entre PMs e sem-terra.</P></p>
<p><P>A Justiça mandou desapropriar o Engenho. O governo enviou 325 PMs para cumprir a ordem. De última,&nbsp;a disputa eleitoral assumiu o palco central da batalha e a operação foi suspensa.</P></p>
<p><P>Leia mais sobre o assunto em notas abaixo.</P> </p>
