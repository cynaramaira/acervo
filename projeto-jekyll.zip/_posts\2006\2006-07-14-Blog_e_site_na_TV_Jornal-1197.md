---
id: 12372370
data_publicacao: "2006-07-14 20:06:00"
data_alteracao: "None"
materia_tags: "blogs jc,site,TV Jornal"
categoria: "Notícias"
titulo: "Blog e site na TV Jornal"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p> </p>
