---
id: 12372182
data_publicacao: "2006-07-23 14:50:00"
data_alteracao: "None"
materia_tags: "Naomi Campbell"
categoria: "Notícias"
titulo: "Já fui dominado e não quero dominar ninguém"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Lula falou quase 50 minutos para os cerca de 280 intelectuais, empresários e l?deres pol?ticos e sindicais reunidos na Academia Santa Gertrudes, em Olinda. Prometeu defender a reforma pol?tica no Congresso no próximo governo, caso reeleito. Defendeu a Transposição do São Francisco e condenou os que são contra a obra. Disse que não será agressivo com os adversários. E que vai se dedicar à campanha nos finais de semana. Algumas frases ditas por ele: </FONT></P></p>
<p><P><FONT face=Verdana>\"Não vou falar mal de nenhum candidato, mas também não vou falar bem.\"</FONT></P></p>
<p><P><FONT face=Verdana>\"Não aceitem provocação de ninguém. Eu disse ontem a Eduardo e Humberto: \Não briguem. Ariano vai ser o árbitro.\ Vamos fazer uma linha direta, Ariano. Se eles brigarem, você me liga. Vamos fazer eles sentarem em caroço de milho.\"</FONT></P></p>
<p><P><FONT face=Verdana>\"Quero tratar o Brasil assim como uma mãe que dá mais dengo ao filho mais fraco. E eu vou fazer isso.\"</FONT></P></p>
<p><P><FONT face=Verdana>\"Olhem para o Aldo (Rebelo, presidente da Câmara), ele está bem, não precisa de ajuda,&nbsp;ao contrário de mulheres e crianças pobres que estão sendo beneficiadas com o Bolsa Fam?lia.\"</FONT></P></p>
<p><P><FONT face=Verdana>\"Eu já fui dominado e não quero dominar ninguém. Eu quero parceria. Quero que esta palavra hegemonia passe longe de mim.\"</FONT></P></FONT> </p>
