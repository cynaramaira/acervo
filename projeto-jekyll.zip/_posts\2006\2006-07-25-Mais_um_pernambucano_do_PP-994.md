---
id: 12372167
data_publicacao: "2006-07-25 08:50:00"
data_alteracao: "None"
materia_tags: "animais,pernambucano"
categoria: "Notícias"
titulo: "Mais um pernambucano do PP"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>O Partido Progressista (PP) está muito mal de pernambucanos em seus quadros. </FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>O l?der na Câmara, Mário Negromonte, acusado de envolvimento no escândalo das sanguessugas, nasceu aqui. É recifense.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Anos atrás, foi morar em Paulo Afonso, na Bahia, e lá acabou construindo sua carreira pol?tica. Advogado, está no terceiro mandato de deputado federal.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Antes dele, porém, houve Severino Cavalcanti, obrigado a renunciar ao mandato, no ano passado, acusado de&nbsp;cobrar mensalinho de Augusto Buani, dono de restaurantes instalados no Congresso.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2>Depois veio Pedro Corrêa, presidente nacional do PP, cassado sob a acusação de ter recebido R$ 700 mil do esquema do mensalão, do publicitário Marcos Valério.</FONT></SPAN> </p>
