---
id: 12372350
data_publicacao: "2006-07-16 07:00:00"
data_alteracao: "None"
materia_tags: "cerveja,resultados"
categoria: "Notícias"
titulo: "Veja os resultados"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Esta é a pesquisa completa publicada na edição de hoje do Jornal do Commercio.</P></p>
<p><P></P></p>
<p><TABLE cellSpacing=1 cellPadding=3 width=500 bgColor=#6ca7a6 border=0></p>
<p><TBODY></p>
<p><TR bgColor=#e0e4e5></p>
<p><TD><IMG height=20 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_titulo.gif\" width=144></TD></TR></p>
<p><TR bgColor=#e0e4e5></p>
<p><TD><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1>INTENÇÃO DE VOTO ESTIMULADA<BR></FONT></STRONG></p>
<p><TABLE cellSpacing=0 cellPadding=5 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD bgColor=#6ca7a6><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=2><EM>Se a eleição de governador de Pernamuco fosse hoje, e os candidatos fossem esses, em qual deles o sr(a). votaria?</EM></FONT></STRONG></TD></TR></TBODY></TABLE></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee></p>
<p><TABLE cellSpacing=2 cellPadding=0 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR vAlign=bottom align=middle bgColor=#c1d2cd></p>
<p><TD><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>35%</FONT></STRONG><BR><IMG height=100 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_bg_barra.gif\" width=30></FONT></TD></p>
<p><TD><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>22%</FONT></STRONG><BR><IMG height=60 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_bg_barra.gif\" width=30></FONT></TD></p>
<p><TD><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>21%</FONT></STRONG><BR><IMG height=50 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_bg_barra.gif\" width=30></FONT></TD></p>
<p><TD><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>2%</FONT></STRONG><BR><IMG height=7 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_bg_barra.gif\" width=30></FONT></TD></p>
<p><TD><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>1%</FONT></STRONG><BR><IMG height=5 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_bg_barra.gif\" width=30></FONT></TD></p>
<p><TD><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>0%</FONT></STRONG></FONT></TD></p>
<p><TD><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>0%</FONT></STRONG></FONT></TD></p>
<p><TD><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>0%</FONT></STRONG></FONT></TD></p>
<p><TD><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>0%</FONT></STRONG></FONT></TD></TR></p>
<p><TR></p>
<p><TD><IMG height=50 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_mendonca_p.gif\" width=51></TD></p>
<p><TD><IMG height=50 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_humberto.gif\" width=47></TD></p>
<p><TD><IMG height=50 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_eduardo.gif\" width=48></TD></p>
<p><TD><IMG height=50 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_clovis.gif\" width=46></TD></p>
<p><TD><IMG height=50 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_rivaldo.gif\" width=46></TD></p>
<p><TD><IMG height=50 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_osvaldo.gif\" width=48></TD></p>
<p><TD><IMG height=50 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_edilson.gif\" width=46></TD></p>
<p><TD><IMG height=50 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_katia.gif\" width=47></TD></p>
<p><TD><IMG height=50 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_vidal.gif\" width=46></TD></TR></p>
<p><TR></p>
<p><TD><FONT face=\"Arial, Helvetica, sans-serif\" size=1>Mendonça Filho<BR>(PFL) <BR></FONT></TD></p>
<p><TD><FONT face=\"Arial, Helvetica, sans-serif\" size=1>Humberto Costa<BR>(PT) </FONT></TD></p>
<p><TD><FONT face=\"Arial, Helvetica, sans-serif\" size=1>Eduardo Campos<BR>(PSB) </FONT></TD></p>
<p><TD><FONT face=\"Arial, Helvetica, sans-serif\" size=1>Clovis Corrêa<BR>(Prona) </FONT></TD></p>
<p><TD><FONT face=\"Arial, Helvetica, sans-serif\" size=1>Rivaldo Soares<BR>(PSL) </FONT></TD></p>
<p><TD><FONT face=\"Arial, Helvetica, sans-serif\" size=1>Osvaldo Alves<BR>(PCO) </FONT></TD></p>
<p><TD><FONT face=\"Arial, Helvetica, sans-serif\" size=1>Edilson Silva}<BR>(PSOL) </FONT></TD></p>
<p><TD><FONT face=\"Arial, Helvetica, sans-serif\" size=1>Kátai Teles<BR>(PSTU) </FONT></TD></p>
<p><TD><FONT face=\"Arial, Helvetica, sans-serif\" size=1>Luiz Vidal<BR>(PSDC) </FONT></TD></TR></TBODY></TABLE></p>
<p><TABLE cellSpacing=5 cellPadding=0 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD width=\"50%\"></p>
<p><TABLE borderColor=#6ca7a6 cellSpacing=1 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD bgColor=#ffffff></p>
<p><TABLE cellSpacing=0 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>Branco/Nulo</STRONG></FONT></TD></p>
<p><TD align=right><IMG height=20 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_bg_barra2.gif\" width=50 align=absMiddle><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>7%</FONT></STRONG></FONT></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></p>
<p><TD width=\"50%\"></p>
<p><TABLE borderColor=#6ca7a6 cellSpacing=1 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD bgColor=#ffffff></p>
<p><TABLE cellSpacing=0 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>Não sabe/<BR>Não respondeu</STRONG></FONT></TD></p>
<p><TD align=right><IMG height=20 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_bg_barra2.gif\" width=60 align=absMiddle><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>12%</FONT></STRONG></FONT></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#000000 size=1><STRONG>CRUZAMENTO POR REGIÃO</STRONG></FONT><BR></p>
<p><TABLE cellSpacing=4 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR bgColor=#006666></p>
<p><TD>&nbsp;</TD></p>
<p><TD width=60></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>Capital/RM</FONT></STRONG></DIV></TD></p>
<p><TD width=60></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>Agreste</FONT></STRONG></DIV></TD></p>
<p><TD width=60></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>Mata</FONT></STRONG></DIV></TD></p>
<p><TD width=60></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>Sertão/ São Francisco</FONT></STRONG></DIV></TD></p>
<p><TD width=50></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>Total</FONT></STRONG></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>Mendonça Filho (PFL) </STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>33%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>34%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>37%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>40%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>35%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\"</p>
<p> size=1><STRONG>Humberto Costa(PT) </STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>26%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>24%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>17%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>17%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>22%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>Eduardo campos(PSB) </STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>20%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>22%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>26%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>16%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>21%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>Outros</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>4%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>4%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>2%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>-</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>3%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>Branco/ Nulo</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>10%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>7%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>8%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>2%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>7%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>NS / NR</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>8%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>10%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>12%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>26%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>12%</FONT></STRONG></FONT></DIV></TD></TR></TBODY></TABLE></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#000000 size=1><STRONG>INTENÇÃO DE VOTO ESPONTÂNEA</STRONG></FONT> </p>
<p><TABLE cellSpacing=4 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR bgColor=#006666></p>
<p><TD colSpan=2></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=2><EM>Se a eleição de governador de Pernamuco fosse hoje, em quem o sr(a). votaria?</EM></FONT></STRONG></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2><STRONG>Mendonça Filho</STRONG></FONT></TD></p>
<p><TD align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>12%</FONT></STRONG></FONT></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2><STRONG>Humberto Costa</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>7%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2><STRONG>Eduardo campos</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>6%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2><STRONG>Jarbas Vasconcelos</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>4%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2><STRONG>Roberto Magalhães</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>-</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2><STRONG>Armando Monteiro</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>-</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2><STRONG>Outros com menos de 0,5% de citação</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>1%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2><STRONG>Branco/ Nulo</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>12%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2><STRONG>NS / NR</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>58%</FONT></STRONG></FONT></DIV></TD></TR></TBODY></TABLE></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#000000 size=1><STRONG>REJEIÇÃO</STRONG></FONT> </p>
<p><TABLE cellSpacing=4 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR bgColor=#006666></p>
<p><TD colSpan=2></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=2><EM>Pensando em todos os candidatos que falamos até agora, existe algum em quem o sr(a). não votaria de jeito nenhum? Qual?</EM></FONT></STRONG></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD bgColor=#c1d2cd></p>
<p><P><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Clóvis Corrêa (Prona) </FONT></STRONG></P></TD></p>
<p><TD align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>13%</FONT></STRONG></FONT></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD bgColor=#c1d2cd></p>
<p><P><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Humberto Costa (PT)</FONT></STRONG></P></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>11%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD bgColor=#c1d2cd></p>
<p><P><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Mendonça Filho (PFL) </FONT></STRONG></P></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>10%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR</p>
<p> bgColor=#c1d2cd></p>
<p><TD bgColor=#c1d2cd></p>
<p><P><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Kátia Teles (PSTU) </FONT></STRONG></P></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>8%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD bgColor=#c1d2cd></p>
<p><P><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Luiz Vidal (PSDC) </FONT></STRONG></P></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>7%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD bgColor=#c1d2cd></p>
<p><P><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Edilson Silva (P-SOL) </FONT></STRONG></P></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>7%</FONT></STRONG></FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD bgColor=#c1d2cd></p>
<p><P><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Oswaldo Alves (PCO) </FONT></STRONG></P></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>5%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD bgColor=#c1d2cd></p>
<p><P><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Eduardo Campos (PSB) </FONT></STRONG></P></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>4%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD bgColor=#c1d2cd><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Rivaldo Soares (PSL) </FONT></STRONG></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>3%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD bgColor=#c1d2cd><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Não votaria em nenhum deles</FONT></STRONG></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>4%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD bgColor=#c1d2cd><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Não existe um em quem não votaria</FONT></STRONG></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>14%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD bgColor=#c1d2cd><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Não sabe / Não respondeu</FONT></STRONG></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>14%</FONT></STRONG></FONT></DIV></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE><BR></p>
<p><TABLE cellSpacing=1 cellPadding=3 width=500 bgColor=#6ca7a6 border=0></p>
<p><TBODY></p>
<p><TR bgColor=#e0e4e5></p>
<p><TD><IMG height=20 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_titulo.gif\" width=144></TD></TR></p>
<p><TR bgColor=#e0e4e5></p>
<p><TD></p>
<p><P><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1>AVALIAÇÃO DE APOIOS</FONT></STRONG></P></p>
<p><TABLE cellSpacing=0 cellPadding=5 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD bgColor=#6ca7a6><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=2><EM>Para o sr(a), o apoio de um desses pol?ticos a um candidato a governador de Pernambuco aumenta, não aumenta nem diminui ou diminui a sua vontade de votar neste candidato?</EM></FONT></STRONG></TD></TR></TBODY></TABLE></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee></p>
<p><TABLE cellSpacing=10 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR bgColor=#006666></p>
<p><TD><IMG height=120 hspace=5 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_lula.gif\" width=120 vspace=5></TD></p>
<p><TD><IMG height=120 hspace=5 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_jarbas.gif\" width=120 vspace=5></TD></p>
<p><TD><IMG height=120 hspace=5 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_joao_paulo.gif\" width=120 vspace=5></TD></TR></TBODY></TABLE></p>
<p><TABLE cellSpacing=2 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR bgColor=#006666></p>
<p><TD bgColor=#eaf0ee>&nbsp;</TD></p>
<p><TD colSpan=2></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>Aumenta</FONT></STRONG></DIV></TD></p>
<p><TD colSpan=2></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>Não aumenta nem diminui</FONT></STRONG></DIV></TD></p>
<p><TD colSpan=2></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>Dimunui</FONT></STRONG></DIV></TD></p>
<p><TD colSpan=2></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>Não sabe / Não respondeu</FONT></STRONG></DIV></TD></TR></p>
<p><TR bgColor=#006666></p>
<p><TD>&nbsp;</TD></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1><STRONG>Abr/06</STRONG></FONT></TD></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1><STRONG>Jul/06</STRONG></FONT></TD></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1><STRONG>Abr/06</STRONG></FONT></TD></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1><STRONG>Jul/06</STRONG></FONT></TD></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1><STRONG>Abr/06</STRONG></FONT></TD></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1><STRONG>Jul/06</STRONG></FONT></TD></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1><STRONG>Abr/06</STRONG></FONT></TD></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1><STRONG>Jul/06</STRONG></FONT></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1>Presidente Lula</FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>47%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>50%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>40%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>36%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>11%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>13%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>2%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>1%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1>Ex-Governador ,Jarbas Vasconcelos</FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>50%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>50%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>39%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>37%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>37%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>10%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>1%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>2%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1>Prefeito do Recife, João Paulo</FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>30%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>27%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV</p>
<p> align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>55%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>52%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>52%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>10%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>5%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>8%</FONT></STRONG></FONT></DIV></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE><BR></p>
<p><TABLE cellSpacing=1 cellPadding=3 width=500 bgColor=#6ca7a6 border=0></p>
<p><TBODY></p>
<p><TR bgColor=#e0e4e5></p>
<p><TD><IMG height=20 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_titulo.gif\" width=144></TD></TR></p>
<p><TR bgColor=#e0e4e5></p>
<p><TD></p>
<p><P><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1>SEGUNDO TURNO</FONT></STRONG></P></p>
<p><TABLE cellSpacing=0 cellPadding=5 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD bgColor=#6ca7a6><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=2><EM>Caso haja segundo turno na eleição para governador, e os candidatos sejam estes, em quem o sr(a). votaria?</EM></FONT></STRONG></TD></TR></TBODY></TABLE></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1>CEN??RIO 1 </FONT></STRONG></p>
<p><TABLE cellSpacing=5 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD width=\"30%\" rowSpan=2></p>
<p><TABLE cellSpacing=2 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD><IMG height=60 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/foto_mendonca_p.gif\" width=60 align=middle border=1></TD></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1>Mendonça <BR>Filho (PFL)<BR><FONT face=\"Arial, Helvetica, sans-serif\" color=#cc0000 size=3><STRONG>46%</STRONG></FONT> </FONT></TD></TR></TBODY></TABLE></TD></p>
<p><TD width=\"30%\" rowSpan=2></p>
<p><TABLE cellSpacing=2 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD><IMG height=60 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/foto_eduardo_p.gif\" width=60 align=middle border=1></TD></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1>Eduardo Campos<BR>(PSB)<BR><FONT face=\"Arial, Helvetica, sans-serif\" color=#cc0000 size=3><STRONG>32%</STRONG></FONT> </FONT></TD></TR></TBODY></TABLE></TD></p>
<p><TD width=\"35%\"><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><FONT face=\"Arial, Helvetica, sans-serif\" color=#cc0000 size=3><STRONG>10% </STRONG></FONT><STRONG>Branco/ Nulo</STRONG></FONT></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#c1d2cd><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><FONT face=\"Arial, Helvetica, sans-serif\" color=#cc0000 size=3><STRONG>10%</STRONG></FONT> <STRONG>Não sabe/ Não respondeu </STRONG><FONT face=\"Arial, Helvetica, sans-serif\" color=#cc0000 size=3></FONT></FONT></TD></TR></TBODY></TABLE><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1>CEN??RIO 2 </FONT></STRONG></p>
<p><TABLE cellSpacing=5 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD width=\"30%\" rowSpan=2></p>
<p><TABLE cellSpacing=2 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD><IMG height=60 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/foto_mendonca_p.gif\" width=60 align=middle border=1></TD></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1>Mendonça <BR>Filho (PFL)<BR><FONT face=\"Arial, Helvetica, sans-serif\" color=#cc0000 size=3><STRONG>48%</STRONG></FONT> </FONT></TD></TR></TBODY></TABLE></TD></p>
<p><TD width=\"30%\" rowSpan=2></p>
<p><TABLE cellSpacing=2 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD><IMG height=60 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/foto_humberto_p.gif\" width=60 align=middle border=1></TD></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1>Humberto Costa (PT)<BR><FONT face=\"Arial, Helvetica, sans-serif\" color=#cc0000 size=3><STRONG>32%</STRONG></FONT> </FONT></TD></TR></TBODY></TABLE></TD></p>
<p><TD width=\"35%\"><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><FONT face=\"Arial, Helvetica, sans-serif\" color=#cc0000 size=3><STRONG>10% </STRONG></FONT><STRONG>Branco/ Nulo</STRONG></FONT></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#c1d2cd><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><FONT face=\"Arial, Helvetica, sans-serif\" color=#cc0000 size=3><STRONG>10%</STRONG></FONT> <STRONG>Não sabe/ Não respondeu </STRONG><FONT face=\"Arial, Helvetica, sans-serif\" color=#cc0000 size=3></FONT></FONT></TD></TR></TBODY></TABLE><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>CEN??RIO 3</STRONG></FONT><STRONG> </STRONG></p>
<p><TABLE cellSpacing=5 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD width=\"30%\" rowSpan=2></p>
<p><TABLE cellSpacing=2 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD><IMG height=60 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/foto_eduardo_p.gif\" width=60 align=middle border=1></TD></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1>Eduardo Campos<BR>(PSB)<BR><FONT face=\"Arial, Helvetica, sans-serif\" color=#cc0000 size=3><STRONG>39%</STRONG></FONT> </FONT></TD></TR></TBODY></TABLE></TD></p>
<p><TD width=\"30%\" rowSpan=2></p>
<p><TABLE cellSpacing=2 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD><IMG height=60 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/foto_humberto_p.gif\" width=60 align=middle border=1></TD></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1>Humberto Costa (PT)<BR><FONT face=\"Arial, Helvetica, sans-serif\" color=#cc0000 size=3><STRONG>32%</STRONG></FONT> </FONT></TD></TR></TBODY></TABLE></TD></p>
<p><TD width=\"35%\"><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><FONT face=\"Arial, Helvetica, sans-serif\" color=#cc0000 size=3><STRONG>10% </STRONG></FONT><STRONG>Branco/ Nulo</STRONG></FONT></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#c1d2cd><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><FONT face=\"Arial, Helvetica, sans-serif\" color=#cc0000 size=3><STRONG>10%</STRONG></FONT> <STRONG>Não sabe/ Não respondeu </STRONG><FONT face=\"Arial, Helvetica, sans-serif\" color=#cc0000 size=3></FONT></FONT></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE> </p>
