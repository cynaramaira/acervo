---
id: 12371966
data_publicacao: "2006-08-03 11:54:00"
data_alteracao: "None"
materia_tags: "fotos,Serrana"
categoria: "Notícias"
titulo: "Fotos de Serra com sanguessugas circulam na CPI"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>blog de Fernando Rodrigues</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Circulam no Congresso fotos de José Serra participando de uma cerimônia de entrega de ambulâncias em Mato Grosso, em maio 2001, ao lado de deputados hoje acusados de participarem do esquema dos sanguessugas. </FONT></P></p>
<p><P><FONT face=Verdana>Nas fotos, lá estão eles: Serra e os deputados Lino Rossi (PL-MT), Pedro Henry (PP-MT) e Ricarte de Freitas (PTB-MT). Como se observa, os 3 deputados pertencem aos partidos mais fortemente identificados com o escândalo do mensalão, além do PT. Henry foi citado nos dois casos. Na </FONT><A href=\"https://download.uol.com.br/fernandorodrigues/sanguessugas/Darci_Vedoin-lista_de_congressistas-02jun2006-8pag.doc\"><U><FONT color=#0000ff><FONT face=Verdana>lista fornecida por Darci Vedoin</FONT></U></FONT></A><FONT face=Verdana> sobre os sanguessugas à Pol?cia Federal estão citados Lino, Henry e Freitas.</FONT></P></p>
<p><P><FONT face=Verdana>Veja <STRONG><EM><A href=\"https://uolpolitica.blog.uol.com.br/\" target=_blank>aqui</A></EM></STRONG> o texto completo e as fotos.</FONT></P> </p>
