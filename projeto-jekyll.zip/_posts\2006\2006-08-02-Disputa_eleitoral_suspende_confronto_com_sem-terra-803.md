---
id: 12371976
data_publicacao: "2006-08-02 19:30:00"
data_alteracao: "None"
materia_tags: "confronto,fundo eleitoral,Terra"
categoria: "Notícias"
titulo: "Disputa eleitoral suspende confronto com sem-terra"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>O governo decidiu suspender a ordem de desocupação do Engenho São João. </FONT></P></p>
<p><P><FONT face=Verdana>Durante todo o dia, 325 PMs estiveram prestes a entrar em confronto direto e violento com os sem-terra que ocupam os 270 hectares do Engenho, em São Lourenço da Mata, Região Metropolitana do Recife.</FONT></P></p>
<p><P><FONT face=Verdana>Às vésperas do in?cio da propaganda eleitoral no rádio e na TV (dia 15), Mendonça Filho (PFL) decidiu evitar o confronto, que pode prejudicar a candidatura dele à reeleição.</FONT></P></p>
<p><P><FONT face=Verdana>Os adversários, Eduardo Campos (PSB) e Humberto Costa (PT), estavam atentos. Mandaram suas equipes de TV registrar tudo. </FONT></P></p>
<p><P><FONT face=Verdana>Mendonça também manteve no local uma equipe de fotógrafo e repórter do Palácio das Princesas.</FONT></P></p>
<p><P><FONT face=Verdana>A disputa eleitoral, por enquanto, salvou os sem-terra. Mas a PM continua lá. E a ordem judicial permanece em vigor. Até amanhã tem mais novidades nessa batalha.</FONT></P></p>
<p><P><FONT face=Verdana>Daqui a pouco vamos publicar as fotos do embate de guias eleitorais (fotógrafo do Palácio e cinegrafista de Eduardo).</FONT></P></p>
<p><P><FONT face=Verdana>Entenda o caso em notas postadas abaixo.</FONT></P> </p>
