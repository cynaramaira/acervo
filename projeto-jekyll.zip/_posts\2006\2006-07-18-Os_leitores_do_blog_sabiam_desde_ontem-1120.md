---
id: 12372293
data_publicacao: "2006-07-18 17:40:00"
data_alteracao: "None"
materia_tags: "blogs jc,Eleitores"
categoria: "Notícias"
titulo: "Os leitores do blog sabiam desde ontem"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=Verdana size=2></p>
<p><P>da <B>Folha Online</B>, em Bras?lia<BR><BR>Na primeira entrevista depois que deixou a prisão, o l?der do MLST (Movimento de Libertação dos Sem Terra), Bruno Maranhão, negou que o movimento tenha invadido e depredado a Câmara Federal em junho. Maranhão acusou a \"direita\" de deturpar a ocupação na Câmara e responsabilizou o que chamou de \"quarteto golpista\" por politizar o ato.<BR><BR>Maranhão acusou os senadores Antonio Carlos Magalhães (PFL-BA), Arthur Virg?lio (PSDB-AM), ??lvaro Dias (PSDB-PR) e Jorge Bornhausen (PFL-SC) de formar o \"quarteto golpista\".<BR><BR>\"Não acho que o Congresso foi quebrado, se isso fosse verdade o preju?zo teria sido de R$ 10 milhões e não de R$ 84 mil como noticiou a imprensa. O problema é pol?tico. Me colocaram no programa [pol?tico] do PFL. É uma baixaria para tentar desmontar a vantagem que o Lula tem nas pesquisas\", disse.<BR><BR>Leia <STRONG><A href=\"https://jc3.uol.com.br/blogs/jc/2006/07/18/index.php#117\">aqui</A></STRONG> a entrevista que Bruno Maranhão deu ao blog, ontem à noite.</P></FONT> </p>
