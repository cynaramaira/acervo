---
id: 12371926
data_publicacao: "2006-08-04 20:05:00"
data_alteracao: "None"
materia_tags: "esta,geraldo Alckmin,métodos contraceptivos"
categoria: "Notícias"
titulo: "Todos sabem onde está o malandro, diz Alckmin"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Ana Paula Scinocca</STRONG> e <STRONG>Angela Lacerda</STRONG><BR>Da Agência Estado</FONT></P></p>
<p><P><FONT face=Verdana>O candidato do PSDB à Presidência, Geraldo Alckmin, prometeu hoje, em Pernambuco, um trabalho \"duro\" no combate à corrupção e partiu para uma ousada provocação ao presidente Luiz Inácio Lula da Silva, ao dizer - sem citar nomes - que \"todo mundo sabe onde está o malandro\".</FONT></P> </p>
