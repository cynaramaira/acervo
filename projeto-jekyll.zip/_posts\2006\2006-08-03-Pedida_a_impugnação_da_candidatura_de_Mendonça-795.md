---
id: 12371968
data_publicacao: "2006-08-03 07:00:00"
data_alteracao: "None"
materia_tags: "Candidatura,despedida,impugnação,mendonça"
categoria: "Notícias"
titulo: "Pedida a impugnação da candidatura de Mendonça"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Por <STRONG>Cláudia Vasconcelos<BR></STRONG></FONT><FONT face=Verdana>Repórter de Pol?tica do JC<BR></FONT><FONT face=Verdana></FONT></P></p>
<p><P><FONT face=Verdana>O procurador regional do Ministério Público Eleitoral (MPE), Fernando Araújo, acatou a ação de investigação impetrada pelo PT contra o PFL e o governador Mendonça Filho, pedindo a inelegibilidade do pefelista. </FONT><FONT face=Verdana>Os petistas acusam o governador de Pernambuco de uso da máquina pública na inserção partidária do PFL no último dia 19 de junho. A matéria está desde segunda-feira com o juiz corregedor do Tribunal Regional Eleitoral, Carlos Moraes, que decidirá se a ação irá ou não a julgamento no plenário do TRE.<BR></FONT></P></p>
<p><P><FONT face=Verdana>O PT invocou o artigo 22 da lei complementar número 64/1990, que versa sobre a inelegibilidade por três anos e a cassação do registro de candidatura </FONT><FONT face=Verdana>de quem utilizar o poder público e econômico em campanha. \"Para o PT, houve um claro programa que misturou propaganda do governo com a do partido\", disse o presidente estadual do PT, Dilson Peixoto.</FONT><BR></P><FONT face=Verdana></FONT></p>
<p><P><FONT face=Verdana>Leia <A href=\"https://www.jc.com.br/\" target=_blank><STRONG><EM>aqui</EM></STRONG></A> o texto completo (assinantes JC e UOL).</FONT></P></FONT> </p>
