---
id: 12371954
data_publicacao: "2006-08-04 06:48:00"
data_alteracao: "None"
materia_tags: "geraldo Alckmin,reagendamentos,Recife"
categoria: "Notícias"
titulo: "A agenda de Alckmin no Recife"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><B></p>
<p><P><FONT face=Verdana>Às 8h</FONT></B><FONT face=Verdana>, café da manhã no Hotel Atlante Plaza, em Boa Viagem,&nbsp;com o senador Sérgio Guerra (PSDB), coordenador nacional da campanha do presidenciável tucano</FONT></P><B></p>
<p><P><FONT face=Verdana>Às 10h30</FONT></B><FONT face=Verdana>, visita as instalações do Sistema Jornal do Commercio</FONT></P><B></p>
<p><P><FONT face=Verdana>Às 11h</FONT></B><FONT face=Verdana>, entrevista ao programa de Geraldo Freire, na Rádio Jornal</FONT></P><B></p>
<p><P><FONT face=Verdana>Às 12h30</FONT></B><FONT face=Verdana>, almoça com jornalistas no restaurante Mourisco, em Olinda</FONT></P><B></p>
<p><P><FONT face=Verdana>Às 14h</FONT></B><FONT face=Verdana>, apresenta propostas para o desenvolvimento do Nordeste, no Teatro Beberibe do Centro de Convenções de Pernambuco, em Olinda</FONT></P><B></p>
<p><P><FONT face=Verdana>Às 18h</FONT></B><FONT face=Verdana>, inaugura comitê na Rua Barão de Itamaracá, no Espinheiro</FONT></P> </p>
