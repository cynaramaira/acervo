---
id: 12371928
data_publicacao: "2006-08-04 18:31:00"
data_alteracao: "None"
materia_tags: "animais,geraldo Alckmin"
categoria: "Notícias"
titulo: "Mais resposta de Alckmin aos internautas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Esta foi a última resposta que conseguimos do presidenciável tucano Geraldo Alckmin, em sua passagem pelo Recife.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Pergunta de Fernando Arruda</STRONG>: \"Se a ética e a honestidade são temas tão importantes na sua campanha, o sr. poderia nos explicar porque barrou, na Assembléia Legislativa de São Paulo, a instalação</p>
<p> de 69 (sessenta e nove) CPIs que visavam apurar casos de corrupção no seu governo? Obrigado.\"</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Alckmin -</STRONG> Primeiro, governador não barra CPI. A Assembléia Legislativa é um outro poder, não é? Depois, como fala 69? A maioria das CPIs nem se refere a governo. Pedidos de CPIs: CPI do Apito. Tem lá várias. Ou seja, um juiz de futebol roubou lá, ele vendia resultado do jogo de futebol. Tem pedido de CPI. CPI da Contaminação do solo, tem quatro. A maioria das coisas nem se refere ao governo.</FONT></P></p>
<p><P><FONT face=Verdana>Leia&nbsp;<STRONG><EM><A href=\"https://jc3.uol.com.br/blogs/jc/2006/08/04/index.php#501\">aqui</A></EM></STRONG> as outras&nbsp;respostas de Alckmin.</FONT></P> </p>
