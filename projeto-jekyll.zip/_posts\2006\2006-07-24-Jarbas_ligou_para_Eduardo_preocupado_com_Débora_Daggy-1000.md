---
id: 12372173
data_publicacao: "2006-07-24 13:46:00"
data_alteracao: "None"
materia_tags: "Débora Dantas,eduardo,jarbas vasconcelos"
categoria: "Notícias"
titulo: "Jarbas ligou para Eduardo preocupado com Débora Daggy"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Era setembro do ano passado. A ex-modelo e ex-namorada de Jarbas Vasconcelos (PMDB) acabava de decidir disputar um mandato de deputada estadual justo pelo PSB do deputado federal Eduardo Campos, seu arquiinimigo.</P></p>
<p><P>Jarbas ficou preocupado. Imaginou logo que aquilo tudo não passava de uma armação, de uma sacanagem que os socialistas estariam preparando para ele nas eleições deste ano, quando disputaria o Senado.</P></p>
<p><P>O governador não teve dúvidas. Ligou imediatamente para Eduardo Campos, com quem foi franco e direto, como costuma ser. </P></p>
<p><P>Jarbas só se tranqüilizou quando Eduardo garantiu que nada havia sido planejado. Ninguém tinha procurado Débora Daggy e a candidatura dela não seria explorada contra Jarbas,&nbsp;nem em favor da candidatura de Eduardo a governador.</P></p>
<p><P>Veja abaixo o ensaio exclusivo que a modelo fez para o <B>Blog</B>.</P></FONT> </p>
