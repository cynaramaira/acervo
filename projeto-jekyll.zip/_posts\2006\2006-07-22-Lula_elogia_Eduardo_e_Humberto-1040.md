---
id: 12372213
data_publicacao: "2006-07-22 19:32:00"
data_alteracao: "None"
materia_tags: "eduardo,Humberto Costa,Lula"
categoria: "Notícias"
titulo: "Lula elogia Eduardo e Humberto"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Trechos do discurso que Lula faz neste momento:</FONT></P></p>
<p><P><FONT face=Verdana>\"</FONT><FONT size=2><FONT face=Verdana>Quero fazer alguns registros especiais. Re</FONT><FONT face=Verdana>gistrar minha alegria de estar aqui com esse intelectual que é Ariano Suassuna.</FONT></P></p>
<p><P><FONT face=Verdana>\"E registrar a presença da nossa querida Madalena, que esteve ao longo de tantos anos ao lado de um homem como Miguel Arraes.</FONT></P></p>
<p><P><FONT face=Verdana>\"Quero registrar a presença de Armando Monteiro Filho, homem muito rico, que já foi um dos mais ricos, mas não deixou que o dinheiro fizesse dele um homem perverso. O dinheiro nunca o fez mudar de lado, ele sempre esteve do nosso lado.\"</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Em seguida, passou a ressaltar o clima de conciliação entre Eduardo e Humberto:</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>\"E agora um registro muito especial que foi a aula de democracia para mim e para toda a imprensa do Brasil.&nbsp;Pernambuco é considerado um estado rebelde, mais rebelde, liderou vários movimentos. Eu duvido que a imprensa de Pernambuco e a nacional já tenha registrado o que você Armando, Ariano, registrado uma atitude tão civilizada, já tenha registrado a democracia no seu alto n?vel, domostrada por vocês, Eduardo e Humberto.</FONT></P></p>
<p><P><FONT face=Verdana>\"Aqui tem militante de todo tipo, mas as pessoas sabem que entre você (Eduardo)&nbsp;e Humberto tem apenas uma disputa circunstancial, mas que o adversário de vocês não está aqui, no meio do povo, nem nesse palanque.</FONT></P></p>
<p><P><FONT face=Verdana>\"Por isso, estou confortavelmente. Nunca tinha visto isso em 30 anos de pol?tica.</FONT></P></p>
<p><P><FONT face=Verdana>\"Se não tivesse mais que falar já teria ganho a noite.\"</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Em outro ponto, mandou recado para a oposição:</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>\"Quanto mais eles me acusam, me agridem, mais&nbsp;eu tenho que me aquietar.\"</FONT></P></FONT> </p>
