---
id: 12371986
data_publicacao: "2006-08-02 08:32:00"
data_alteracao: "None"
materia_tags: "campanha,esta,geraldo Alckmin,Naomi Campbell,Pará"
categoria: "Notícias"
titulo: "Alckmin não está só. Apareceu um para fazer campanha"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Ana Lúcia Andrade</STRONG><BR>Repórter de Pol?tica do JC</FONT> </p>
<p><P><FONT face=Verdana>Os tucanos finalmente “acordaram??? para a campanha de seu candidato a presidente Geraldo Alckmin (PSDB). Mas só depois de serem despertados pela reportagem do <B>JC</B> e a três dias do desembarque do tucano no Recife, previsto para sexta-feira. </FONT></p>
<p><P><FONT face=Verdana>O deputado estadual Pedro Eurico (PSDB) encabeçou o primeiro adesivaço pró-Alckmin, ontem à tarde, num dos principais cruzamentos da cidade. </FONT></p>
<p><P><FONT face=Verdana>Coincidência ou não, no dia seguinte à reportagem em que o <B>JC</B> denunciou o “esquecimento??? dos candidatos proporcionais em citar Alckmin na sua publicidade. </FONT></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinantes JC e UOL).</FONT></P> </p>
