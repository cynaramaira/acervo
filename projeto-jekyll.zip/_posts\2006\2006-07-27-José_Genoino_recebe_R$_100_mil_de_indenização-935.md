---
id: 12372108
data_publicacao: "2006-07-27 20:20:00"
data_alteracao: "None"
materia_tags: "indenização,Louro José"
categoria: "Notícias"
titulo: "José Genoino recebe R$ 100 mil de indenização"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P></p>
<p><DIV id=corpo></p>
<p><P><FONT face=Verdana>O candidato a deputado federal e ex-presidente do PT José Genoino Neto foi considerado anistiado pol?tico, de acordo com portaria do ministro da Justiça, Márcio Thomaz Bastos, publicada no Diário Oficial de hoje.<BR><BR>Conforme a portaria, Genoino receberá uma reparação econômica de caráter indenizatório de R$ 100 mil. A portaria do ministro tem como base o julgamento da Comissão de anistia ocorrido em abril passado.</FONT></P></p>
<p><P><FONT face=Verdana>Leia texto completo no site do <STRONG><EM><A href=\"https://jc3.uol.com.br/especiais/eleicoes2006/2006/07/26/not_375.php\">JC nas Eleições 2006</A></EM></STRONG>.<BR></P></FONT></DIV> </p>
