---
id: 12372263
data_publicacao: "2006-07-20 16:51:00"
data_alteracao: "None"
materia_tags: "deputado,Paulo,Ricardo Salles"
categoria: "Notícias"
titulo: "Deputado Paulo Ricardo?"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=Verdana size=2></p>
<p><P>Por Sérgio Montenegro Filho<BR>(blog <A href=\"https://polisetcircensis.zip.net\">https://polisetcircensis.zip.net</A>)</P></FONT><FONT face=Verdana size=1></p>
<p><P>Para Estênio Brasilino</P></FONT><FONT size=2></p>
<p><P><FONT face=Verdana>A gente cresce, amadurece e pensa logo que já viu de tudo. Viu nada! Pois não é que o cantor e compositor (?) Paulo Ricardo - sim, aquele do olhar 43 - arranjou outra maneira de voltar à cena, de onde saiu desde a falência múltipla de órgãos do meloso RPM? O cara decidiu, simplesmente, ser candidato a deputado federal, surfando na onda da renovação do Congresso Nacional. Mas calma, minha senhora. Ele desistiu da idéia ontem...</FONT></P></p>
<p><P><FONT face=Verdana>Olha? o bilhete de desistência, publicado no blog do cara: \"Como vocês sabem, fui honrado com um convite do prefeito de São Paulo, sr. Gilberto Kassab, para me candidatar a deputado federal pelo PFL-SP, já nas próximas eleições. Animado com a perspectiva de influir no processo pol?tico, aceitei. Minha candidatura foi muit?ssimo bem recebida por todos.Tive excelentes espaços na m?dia e apoio incondicional</p>
<p> de fãs, amigos, e principalmente do partido. Contudo, em função do pequeno espaço de tempo em que foi articulada minha candidatura, não consegui transferir importantes compromissos profissionais, que entrariam em choque com a nova legislação eleitoral. Abro mão, portanto, de concorrer às eleições de 2006. Agradeço pela confiança em mim depositada, e desejo boa sorte a todos e ao Brasil. Até breve\"</FONT></P></p>
<p><P><FONT face=Verdana>Ufa! Menos um!</FONT></P></FONT> </p>
