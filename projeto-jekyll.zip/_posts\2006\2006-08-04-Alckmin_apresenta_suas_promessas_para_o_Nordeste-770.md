---
id: 12371943
data_publicacao: "2006-08-04 08:45:00"
data_alteracao: "None"
materia_tags: "APRESENTADORA,geraldo Alckmin,nordeste"
categoria: "Notícias"
titulo: "Alckmin apresenta suas promessas para o Nordeste"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Jamildo Melo</STRONG><BR></FONT><FONT face=Verdana>Repórter especial do JC</FONT></P></p>
<p><P><FONT face=Verdana>O plano de desenvolvimento para o Nordeste que o candidato a presidente Geraldo Alckmin (PSDB/SP) apresenta hoje, no Centro de Convenções, soma 11 pontos e tem como principal objetivo o fim dos desequil?brios regionais no Nordeste. </FONT></P></p>
<p><P><FONT face=Verdana>Além da recriação da Sudene, a principal promessa do programa é a aplicação de mais verbas federais no Nordeste, com o objetivo de melhorar os indicadores sociais e econômicos da região.</FONT></P></p>
<p><P><FONT face=Verdana>O plano batizado de Novo Nordeste prevê a criação de um plus no Orçamento Geral da União especialmente para a região, sem alterar os atuais n?veis de investimentos que hoje são executados nas demais regiões do pa?s. </FONT></P></p>
<p><P><FONT face=Verdana>Pela regra, já a partir de 2007, de todo o adicional de investimentos do governo Federal, pelo menos 32% serão alocados no Nordeste. Na medida em que o desequil?brio regional for sendo reduzido, o plus também iria diminuindo, até desaparecer automaticamente.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://jc3.uol.com.br/jornal/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinates JC e UOL).</FONT></P> </p>
