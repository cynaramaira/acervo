---
id: 12372276
data_publicacao: "2006-07-19 18:21:00"
data_alteracao: "None"
materia_tags: "varejo"
categoria: "Notícias"
titulo: "PT no atacado, PFL no varejo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2><FONT size=2></p>
<p><P>O senador José Jorge (PFL), vice de Geraldo Alckmin (PSDB), disse no Recife que o PT pratica a corrupção por atacado. Foi uma resposta curiosa à indagação de Jamildo Melo, repórter especial do JC, sobre o fato de haver quatro parlamentares do PFL e três do PSDB envolvidos com a CPI das Sanguessugas e nenhum do PT.</P></FONT></FONT><FONT face=Verdana size=3></FONT> </p>
