---
id: 12372200
data_publicacao: "2006-07-22 22:25:00"
data_alteracao: "None"
materia_tags: "josé teles"
categoria: "Notícias"
titulo: "E lá foram eles, aliados desde criancinha"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p> </p>
