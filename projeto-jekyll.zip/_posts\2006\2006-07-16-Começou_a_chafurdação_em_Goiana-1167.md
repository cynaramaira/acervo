---
id: 12372340
data_publicacao: "2006-07-16 12:21:00"
data_alteracao: "None"
materia_tags: "Goiana"
categoria: "Notícias"
titulo: "Começou a chafurdação em Goiana"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>O munic?pio tem hoje eleição suplementar para prefeito porque o eleito em 2004, Beto Gadelha (PSDB), foi cassado por abuso de poder econômico e propaganda irregular. Há cinco candidatos na disputa (veja o perfil deles em nota postada abaixo). Alguns&nbsp;estão cometendo os mesmos delitos.&nbsp;Cinco donos de bares já foram detidos. A juiza eleitoral do munic?pio, Mariza Silva Borges, não está conseguindo conter as infrações, como informa Cec?lia Ramos, repórter do blog. </P></p>
<p><P>Os postos de gasolina Ello, Albuquerque Pneus e Master Gás, na PE 408, foram interditados por estarem abastecendo, gratuitamente, carros de campanha.&nbsp;Até às 17h, as bombas de gasolina desses estabelecimentos ficam lacradas e com policiais no local.</P></p>
<p><P>Segundo a juiza, os candidatos estão fazendo carreata e publicidade ilegal, com panfletagem dentro dos locais de votação. A lei eleitoral só permite a uma distância de 100 metros dos locais</p>
<p> de votação. </P></p>
<p><P>\"Aqui teve candidato que foi votar carregado nos braços de eleitores. Isso é uma verdadeira afronta à Justiça, mas não conseguimos coibir porque o número de policiais é insufiiciente\", queixou-se a ju?za, referindo-se ao presidente da Câmara dos Vereadores e prefeito interino, Henrique Fenelon (PCdoB). De acordo com a juiza, o efetivo policial é de 350 homens.</P></FONT> </p>
