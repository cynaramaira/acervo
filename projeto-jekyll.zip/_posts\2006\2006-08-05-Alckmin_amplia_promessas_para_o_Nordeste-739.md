---
id: 12371912
data_publicacao: "2006-08-05 08:30:00"
data_alteracao: "None"
materia_tags: "Ampliação,geraldo Alckmin,nordeste"
categoria: "Notícias"
titulo: "Alckmin amplia promessas para o Nordeste"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Ayrton Maciel</STRONG> e <STRONG>Jamildo Melo</STRONG><BR>Repórteres do Jornal do Commercio</FONT></P></p>
<p><P><FONT face=Verdana>O candidato Geraldo Alckmin (PSDB) ampliou ontem as promessas de redenção do Nordeste, em uma eventual gestão tucana. Em almoço com jornalistas no restaurante Mourisco, em Olinda, o ex-governador de São Paulo prometeu que, se eleito presidente, promoverá a unificação em cinco al?quotas do ICMS e adotará o princ?pio de destino do imposto, com a reforma tributária. </FONT></P></p>
<p><P><FONT face=Verdana>A proposta beneficia os Estados do Nordeste, que produzem poucas mercadorias e são maiores consumidores de produtos acabados. Com o princ?pio de destino, os Estados da região teriam ampliação da arrecadação, que no sistema atual privilegia o destino de origem, justamente os Estados do Sul e do Sudeste, mais industrializados e produtores dos bens de consumo. \"Isto vai ser o pulo do gato da minha reforma tributária. Posso garantir que São Paulo concorda, pois vamos sair da guerra fiscal. Isto não será feito de uma vez, mas com uma transição, de cinco, seis, sete ou 11 anos, quando tempo for preciso\".</FONT></P></p>
<p><P><FONT face=Verdana>Leia o </FONT><A href=\"https://jc3.uol.com.br/jornal/\" target=_blank><B><I><U><FONT color=#0000ff><FONT face=Verdana>texto</FONT></B></I></U></FONT></A><FONT face=Verdana> completo em Pol?tica, no JC (assinantes JC e UOL).</FONT></P> </p>
