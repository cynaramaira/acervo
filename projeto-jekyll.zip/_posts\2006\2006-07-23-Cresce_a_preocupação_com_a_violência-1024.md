---
id: 12372197
data_publicacao: "2006-07-23 08:30:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Cresce a preocupação com a violência"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Por Sérgio Montenegro Filho<BR>Repórter especial do JC</P></p>
<p><P>O desemprego é o principal fantasma que assombra o cotidiano dos pernambucanos, segundo dados colhidos pelo Instituto Vox Populi na pesquisa feita sob encomenda para o <B>Jornal do Commercio</B>. De acordo com o levantamento, 37% dos entrevistados apontaram a falta de empregos como o principal problema enfrentado hoje pela população do Estado, três pontos percentuais a mais que na pesquisa anterior, realizada em maio.</P></p>
<p><P>Ainda segundo a sondagem deste mês, o primeiro da campanha eleitoral, a preocupação com a violência também aumentou em Pernambuco. Em maio, 21% dos entrevistados pelo instituto de pesquisas apontaram a falta de segurança pública como o principal problema a ser resolvido pelos governantes. Em julho, esse ?ndice subiu para 25%, um aumento de quatro pontos percentuais.</P></p>
<p><P>Em compensação, a situação da saúde pública melhorou no Estado. Na pesquisa anterior, 24% dos pernambucanos elegeram essa área como a mais problemática. Já este mês, a saúde recebeu 20% das citações, quatro pontos a menos, portanto.</P></p>
<p><P>Outros ?ndices se mantiveram praticamente estáveis da pesquisa anterior para a atual. A educação foi citada novamente por 7% dos entrevistados como o principal problema de Pernambuco, seguido das queixas sobre a situação das estradas e rodovias do Estado – 4% no levantamento anterior e 3% no atual – e da falta de apoio ao agricultor rural, citado antes por 5% e agora por 3% dos entrevistados.</P></p>
<p><P>Veja <B><U><A href=\"https://jc3.uol.com.br/especiais/eleicoes2006/\" target=_blank>aqui</A></B></U> os números completos.</P></FONT> </p>
