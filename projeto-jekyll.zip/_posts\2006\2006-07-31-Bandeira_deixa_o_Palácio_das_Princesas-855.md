---
id: 12372028
data_publicacao: "2006-07-31 20:00:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Bandeira deixa o Palácio das Princesas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Acabou agora a reunião entre o governador Mendonça Filho e o advogado Francisco Bandeira, novo desembargador do Tribunal de Justiça.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Após a conversa, na qual Bandeira foi comunicado da nomeação dele, Mendonça telefonou para o presidente do TJ, Fausto Freitas, com quem esteve no in?cio da noite, para reconfirmar a escolha.</FONT></P> </p>
