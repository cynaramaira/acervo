---
id: 12372268
data_publicacao: "2006-07-20 02:45:00"
data_alteracao: "None"
materia_tags: "Pnad contínua"
categoria: "Notícias"
titulo: "PT continua sendo o preferido"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Destroçado pelos escândalos de corrupção, o PT continua sendo a legenda preferida dos pernambucanos.&nbsp;Mais uma rodada da&nbsp;pesquisa JC/Vox Populi, publicada hoje no JC, mostra que 20% dos entrevistados preferem o partido de Lula aos demais.</FONT></P></p>
<p><P><FONT face=Verdana>Os outros vêm muito distantes na avaliação. Empatados em segundo lugar, com apenas 4%, estão o PMDB de Jarbas e o PFL de Mendonça.</FONT></P></p>
<p><P><FONT face=Verdana>Mas o PT é também o mais rejeitado, com 9%, seguido&nbsp;do PFL, com 6%, e do PMDB, com 3%.</FONT></P></p>
<p><P><FONT face=Verdana>Veja <B><A href=\"https://jc3.uol.com.br/especiais/eleicoes2006/\" target=_blank>aqui</A></B> os números completos.</FONT></P></FONT> </p>
