---
id: 12372266
data_publicacao: "2006-07-20 10:23:00"
data_alteracao: "None"
materia_tags: "Caixa,eleições"
categoria: "Notícias"
titulo: "Internautas esperam mais caixa 2 nas eleições"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>É o que mostram os resultados da enquete que realizamos aqui no blog desde sábado e que encerramos agora. </P></p>
<p><P>Foram 391 votos no total. Veja os números:</P></p>
<p><P>Você acha que haverá caixa 2 nestas eleições?</P></p>
<p><P>Sim&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 94% (367)</P></p>
<p><P>Não&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 6%&nbsp;&nbsp; (24)</P></p>
<p><P>Iniciamos agora uma nova enquete.&nbsp;Queremos saber se você acha que haverá segundo turno na eleição para governador de Pernambuco e,&nbsp;caso diga sim,&nbsp;quais seriam os candidatos.&nbsp;</P></p>
<p><P>Participe, dê sua opinião no menu, ao lado.</P> </p>
