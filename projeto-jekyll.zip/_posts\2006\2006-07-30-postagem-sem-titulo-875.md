---
id: 12372048
data_publicacao: "2006-07-30 13:00:00"
data_alteracao: "None"
materia_tags: "None"
categoria: "Notícias"
titulo: ""
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><STRONG><FONT face=Verdana>“O&nbsp; presidente tem um único candidato em Pernambuco. É um homem que sempre caminhou ao lado dele e este homem se chama Humberto Costa.???</FONT></STRONG></P></p>
<p><P><FONT face=Verdana>Deputado federal Armando Monteiro Neto (PTB),&nbsp;no Agreste, provocando Eduardo Campos (PSB), que luta para vincular a campanha dele a governador à imagem do presidente</FONT></P> </p>
