---
id: 12372272
data_publicacao: "2006-07-20 08:00:00"
data_alteracao: "None"
materia_tags: "Lula,Naomi Campbell"
categoria: "Notícias"
titulo: "Não vou responder aos empregadinhos de Lula"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>A senadora Helo?sa Helena (P-SOL) esnobou os ataques que recebeu do ministro Tarso Genro, das Relações Institucionais. Após ver a ex-petista crescer nas pesquisas de intenção de voto de 6% para 10% (Datafolha), Genro questionou se a candidatura de Helo?sa era mesmo \"de esquerda\". \"Que candidatura de esquerda é essa que é contra pobre entrar na universidade? Que candidatura se apresenta como popular e é contra o Bolsa Fam?lia?\", questionou o ministro.</FONT></P></p>
<p><P><FONT face=Verdana>\"Eu não vou responder aos empregadinhos-ministros do presidente Lula. Eu quero é ir para o debate com o patrão deles\", disparou a senadora, por telefone, de Fortaleza, em entrevista exclusiva a Cec?lia Ramos, repórter do Blog do JC.</FONT></P></p>
<p><P><FONT face=Verdana>A senadora estará no Recife no próximo dia 28 para caminhadas nas comunidades Dorothy Stang e Chico Xavier, ambas na Imbiribeira, e Ilha de Deus, no Ipsep, além de panfletagem no centro do Recife.</FONT></P><B></p>
<p><P><FONT face=Verdana>Como a senhora recebe as cr?ticas do ministro Tarso Genro? </FONT></P></B></p>
<p><P><FONT face=Verdana>Eu não vou responder aos empregadinhos-ministros do presidente Lula. Eu quero é ir para o debate com o patrão deles. Quero responder é a Lula. Achei rid?culo e leviano um emissário do Lula dizendo que eu vou acabar com o Bolsa Fam?lia. Sou contra a utilização demagógica e eleitoreira, da apropriação de um pai e uma mãe de fam?lia para fazer pol?tica. O programa precisa ser reformulado. </FONT></P><B></p>
<p><P><FONT face=Verdana>A sua candidatura começa a incomodar o Palácio do Planalto? </FONT></P></B></p>
<p><P><FONT face=Verdana>Para eles eu virei candidata agora, com o resultado das pesquisas. Mas eu, humildemente, estou agradecida pelo resultado da pesquisa. Agradeço de coração a generosidade e o carinho de mulheres e homens do Brasil. Mas eu, humildimente, reconheço que pesquisa é um retrato do momento.</FONT></P><B></p>
<p><P><FONT face=Verdana>Aqui no Recife, o senador José Jorge (PFL, vice de Geraldo Alckmin) afirmou que vê a senhora como aliada, uma vez que tem o objetivo de, segundo ele, derrotar Lula. A senhora pensa o mesmo? </FONT></P></B></p>
<p><P><FONT face=Verdana>De forma alguma. O meu objetivo é derrotar Lula e Alckmin. Eles representam o parasitismo dos agressores dos cofres públicos. Esse racioc?nio dele não tem lógica. </FONT></P><B></p>
<p><P><FONT face=Verdana>Qual a sua estratégia para levar a disputa para o segundo turno? </FONT></P></B></p>
<p><P><FONT face=Verdana>Estou fazendo um esforço muito grande para ir para o segundo turno. E não tem segredo. É trabalhar, trabalhar, trabalhar. Ao contrário de um que tem o aerolula, o outro, jatinhos e helicópteros à disposição, a gente tem avião de carreira. Nós não conseguimos estar em muitos lugares ao mesmo tempo, mas vamos a todos os Estados. Não me interessa o número de votos que cada lugar tem, eu quero falar para as pessoas o nosso projeto. Não tenho medo de luta. Fui uma menina pobre do sertão do Alagoas e cheguei até aqui. </FONT></P><B></p>
<p><P><FONT face=Verdana>Qual é a sua avaliação do governo Lula? </FONT></P></B></p>
<p><P><FONT face=Verdana>O governo é a propaganda triunfalista do neoliberalismo. Lula é uma continuação piorada do governo anterior. E ainda copiou e aperfeiçoou o banditismo da elite pol?tica brasileira.</FONT></P></FONT> </p>
