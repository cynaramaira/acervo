---
id: 12372032
data_publicacao: "2006-07-31 17:41:00"
data_alteracao: "None"
materia_tags: "Desembargadores,governo,novos"
categoria: "Notícias"
titulo: "Governo é derrotado na escolha do novo desembargador"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Não adiantou todo o esforço do governo.</FONT></P></p>
<p><P><FONT face=Verdana>Deu Jorge Neves (27 votos), Francisco Bandeira (26 votos) e Edgar Moury Neto (22 votos). </FONT></P></p>
<p><P><FONT face=Verdana>Pedro Henrique Alves (10), candidato de Jarbas Vasconcelos e Mendonça Filho, ficou fora da lista tr?plice.</FONT></P></p>
<p><P><FONT face=Verdana>Os demais candidatos tiveram: </FONT><FONT face=Verdana>Reinaldo Gueiros (6), </FONT><FONT face=Verdana>Braga Sá (3) e b</FONT><FONT face=Verdana>rancos (5)</FONT></P> </p>
