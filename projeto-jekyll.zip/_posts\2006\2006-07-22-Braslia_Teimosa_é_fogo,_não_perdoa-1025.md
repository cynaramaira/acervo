---
id: 12372198
data_publicacao: "2006-07-22 21:54:00"
data_alteracao: "None"
materia_tags: "Brasília Teimosa,fogo,Naomi Campbell"
categoria: "Notícias"
titulo: "Bras?lia Teimosa é fogo, não perdoa"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p> </p>
