---
id: 12372063
data_publicacao: "2006-07-30 09:30:00"
data_alteracao: "None"
materia_tags: "Blocos Líricos,deputados"
categoria: "Notícias"
titulo: "Nossos deputados estão mais ricos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Jorge Cavalcanti<BR></STRONG></FONT><FONT face=Verdana>Repórter do Jornal do Commercio</FONT></P></p>
<p><P><FONT face=Verdana>A soma do patrimônio declarado dos deputados estaduais cresceu 89,6% em quatro anos. </FONT></P></p>
<p><P><FONT face=Verdana>Em 2002, os bens dos parlamentares estavam avaliados em cerca de R$ 16,8 milhões, segundo as declarações apresentadas ao Tribunal Regional Eleitoral (TRE) de Pernambuco. </FONT></P></p>
<p><P><FONT face=Verdana>Este ano, o valor aumentou para cerca de R$ 32,07 milhões. O subs?dio bruto de um deputado estadual é R$ 9.525. </FONT></P></p>
<p><P><FONT face=Verdana>Cada gabinete dispõe ainda de R$ 34 mil para o pagamento de assessores, e de até R$ 19.154 de verba idenizatória – a quantia é repassada mediante a comprovação de nota fiscal dos gastos.</FONT></P></p>
<p><P><FONT face=Verdana>De todos os 49 estaduais, o levantamento do JC deixou de fora apenas Adelmo Duarte (PFL), pois o processo de registro de candidatura de 2002 do pefelista não constava na biblioteca do TRE. </FONT></P></p>
<p><P><FONT face=Verdana>Este ano, o deputado declarou cerca de R$ 279,5 mil, e garantiu que não houve acréscimo em quatro anos, embora não tenha apresentado cópia da declaração de 2002.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinantes JC e UOL).</FONT></P> </p>
