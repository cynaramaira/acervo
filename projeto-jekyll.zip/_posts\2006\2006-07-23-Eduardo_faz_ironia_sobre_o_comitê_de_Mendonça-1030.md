---
id: 12372203
data_publicacao: "2006-07-23 10:55:00"
data_alteracao: "None"
materia_tags: "eduardo,mendonça"
categoria: "Notícias"
titulo: "Eduardo faz ironia sobre o comitê de Mendonça"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Aline Moura, repórter do Diario de Pernambuco, perguntou a Eduardo Campos, agora há pouco: \"O evento de ontem (o com?cio de Lula) foi frio? A militância estava fria?\"</FONT></P></p>
<p><P><FONT face=Verdana>Campos não teve dúvidas:\"Você quer dizer que quente mesmo foi a inauguração do comitê de Mendoncinha?\" </FONT></P></p>
<p><P><FONT face=Verdana>Todo mundo caiu na gargalhada, lembrando do evento da União por Pernambuco, ontem pela manhã, com aquela militância minguada e sem povo.</FONT></P></FONT> </p>
