---
id: 12371951
data_publicacao: "2006-08-04 06:52:00"
data_alteracao: "None"
materia_tags: "Humberto Costa"
categoria: "Notícias"
titulo: "Vedoin volta a citar ex-assessor de Humberto"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Num depoimento de mais de sete horas a integrantes da CPI das Sanguessugas, o empresário Luiz Antônio Trevisan Vedoin reforçou ontem as acusações contra o l?der do PMDB no Senado, Ney Suassuna (PB), e também complicou a situação de petistas. </FONT></P></p>
<p><P><FONT face=Verdana>Um dos principais alvos das revelações foi José Airton Cirilo, integrante do Diretório Nacional do PT e candidato a deputado federal pelo Ceará. As acusações contra Cirilo levaram parlamentares a defender que seja aprofundada a investigação sobre as relações da Planam, empresa da fam?lia Vedoin, com o Ministério da Saúde na gestão do ex-ministro Humberto Costa (PT), candidato a governador de Pernambuco.</FONT></P></p>
<p><P><FONT face=Verdana>Vedoin negou ter tido contatos com o ex-ministro, mas citou Francisco Rocha, Rochinha, ex-braço direito de Humberto e que seria o homem responsável pelo pagamento de emendas no ministério. Vedoin disse, segundo os deputados, que Rochinha seria o interlocutor de Cirilo no governo.</FONT></P><FONT face=Verdana></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://jc3.uol.com.br/jornal/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinates JC e UOL).</FONT></P></FONT> </p>
