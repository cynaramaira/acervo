---
id: 12372210
data_publicacao: "2006-07-22 20:05:00"
data_alteracao: "None"
materia_tags: "aviso prévio,Oposição"
categoria: "Notícias"
titulo: "Aviso à oposição: Meçam suas l?nguas!"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>De Lula, pouco antes de encerrar o discurso:</FONT></P></p>
<p><P><FONT face=Verdana>\"Não baixarei o n?vel como presidente, meçam suas l?nguas, nós também temos l?ngua. Respeito é bom e se eles não agem com respeito, podem ter certeza que não ficaremos mais quietos.\"</FONT></P></FONT> </p>
