---
id: 12372128
data_publicacao: "2006-07-26 16:32:00"
data_alteracao: "None"
materia_tags: "dinheiro, pedro manta, salvaguardas"
categoria: "Notícias"
titulo: "Pedro Eugênio não guarda dinheiro no BNB"
sutia: "None"
chapeu: "None"
autor: "jamildo"
imagem: "None"
---
<p>Pedro Eug&ecirc;nio Cabral deixou a diretoria do Banco do Nordeste, no in?cio do ano, para disputar uma vaga na C&acirc;mara Federal pelo PT de Pernambuco.</p>
<p>Na declara&ccedil;&atilde;o de bens que entregou ao Tribunal Eleitoral, por&eacute;m, n&atilde;o h&aacute; nada das economias que fez guardado no BN.</p>
<p>Segundo levantamento feito por Jamildo Melo, rep&oacute;rter especial do JC, est&aacute; tudo, quase R$ 25 mil, no Banco do Brasil, Caixa, Itau e BankBoston.</p>
<p>Tem mais R$ 17.000 na m&atilde;o.</p>
