---
id: 12371894
data_publicacao: "2006-08-06 16:00:00"
data_alteracao: "None"
materia_tags: "Fidel Castro"
categoria: "Notícias"
titulo: "Cerco a jornalistas aperta com Fidel doente"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Observatório da Imprensa</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Em um dos mais importantes momentos na história de Cuba, com o longevo e forte Fidel Castro transferindo o poder a seu irmão, jornalistas estrangeiros estão sendo proibidos de entrar na ilha. </FONT></P></p>
<p><P><FONT face=Verdana>A agência de not?cias alemã Deutsche Presse-Agentur afirmou que mais de 150 jornalistas estrangeiros tentando entrar em Cuba com visto de turista foram barrados no aeroporto de Havana desde que o governo anunciou que Fidel estava com hemorragia interna e teria de passar por uma cirurgia delicada. </FONT></P></p>
<p><P><FONT face=Verdana>Em Cuba, jornalistas precisam ter visto de trabalho para exercerem a profissão legalmente.</FONT></P></p>
<p><P>Leia <STRONG><EM><A href=\"https://observatorio.ultimosegundo.ig.com.br/artigos.asp?cod=392MON023\" target=_blank>aqui</A></EM></STRONG> o texto completo.</P> </p>
