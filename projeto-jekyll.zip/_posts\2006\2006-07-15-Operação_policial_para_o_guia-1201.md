---
id: 12372374
data_publicacao: "2006-07-15 08:05:00"
data_alteracao: "None"
materia_tags: "operação policial"
categoria: "Notícias"
titulo: "Operação policial para o guia"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Por pouco não passa despercebida a megaoperação montada pela Secretaria de Defesa Social, na quinta-feira, para prender seis pessoas, um cachimbo de crack, uma trouxinha de maconha e um facão. Foi tudo feito sob medida para a&nbsp;equipe do guia eleitoral do governador Mendonça Filho. </P></p>
<p><P>Para quem não sabe, a segurança pública é, não um calo, mas um grav?ssimo problema do Estado. Mais de 31 mil pessoas foram assassinadas em Pernambuco nos últimos sete anos e meio. Toda a sociedade vive um permanente estado de insegurança por falta de medidas eficazes para conter a banalização do crime. Imagens da pol?cia em ação ajudam no esforço para esvaziar a agenda da oposição contra Mendonça.</P></p>
<p><P>Para quem deseja conhecer melhor essa história, segue aqui a coluna JC nas Ruas, escrita por Ciara Carvalho, repórter especial de Cidades do Jornal do Commercio e publicada nesta sexta-feira: </P></p>
<p><P>-----------</P></p>
<p><P>Hora do espetáculo </P></p>
<p><P><BR>Quem viu ontem a megaoperação que a Secretaria de Defesa Social montou, no ar e na terra, para prender seis pessoas deve estar achando que é conversa de trancoso essa história de que falta efetivo na PM para garantir a segurança do cidadão. Afinal foram deslocados 102 policiais militares, de nove unidades especializadas, para recolher um cachimbo de crack, uma trouxinha de maconha e um facão. </P></p>
<p><P>Tinha PM de tudo o que é canto. Radiopatrulha, Rocam, Cioe, Cipmotos, Cipoma e até Patrulha Aérea. Todas as siglas que a população queria ver atuando nos sinais de trânsito estavam lá. Tudo isso para uma hora e vinte minutos de operação. Mas espetacular mesmo foi o desfecho. Os moradores não entenderam muito bem o porquê daquilo tudo, mas, quando viram, eis que, lá no alto, surge o helicóptero da SDS e, pouso feito, salta dele o secretário de Defesa Social, Rodney Miranda. </P></p>
<p><P><BR>O secretário foi lá ver se a operação tinha sido um sucesso. Olhou a trouxinha de maconha, conversou com a imprensa e foi embora. Chegou a 20 minutos do final da história. Como era uma ação arriscada, desceu de colete à prova de balas. Mas ele não era o único que estava devidamente paramentado. Sobrou colete também para o pessoal do guia eleitoral do governador. A equipe não perdeu uma cena. Desde a sa?da do comboio da Secretaria de Defesa Social, o cinegrafista acompanhou, imagem a imagem, cada passo dos 102 policiais militares. Realmente foi coisa de cinema. Ou de televisão. </P></p>
<p><P><BR>No passo do guia </P></p>
<p><P>A equipe do guia eleitoral do governador suou o colete ontem. Na megaoperação montada pela SDS, passou por Peixinhos, S?tio Novo, Campo Grande e Campina do Barreto. O cinegrafista estava em todos os lances, mas a repórter chegou e saiu sem gravar nenhuma entrevista. </P></p>
<p><P><BR>Assunto amargo </P></p>
<p><P>Ontem o secretário Rodney Miranda, começou a conversa com a imprensa avisando: “Falo sobre tudo. Menos o pres?dio, certo????. Não adiantou. O que os repórteres queriam saber mesmo eram os detalhes da queda do diretor do An?bal Bruno e o que será feito das confortáveis su?tes, disfarçadas de celas, que existem por lá. </P></p>
<p><P><BR>Santo nome em vão </P></p>
<p><P>O ex-secretário da SDS, João Braga, nega que tenha bancado um ônibus para levar ao cemitério parentes de um rapaz morto, no Ibura. “Ninguém me procurou, não paguei e desconheço esse fato???, garantiu. Braga disse que, se usaram o nome dele, foi sem o seu conhecimento e aprovação. </P></p>
<p><P><BR>&nbsp;</P> </p>
