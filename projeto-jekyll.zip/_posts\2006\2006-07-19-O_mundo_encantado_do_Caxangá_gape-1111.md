---
id: 12372284
data_publicacao: "2006-07-19 08:40:00"
data_alteracao: "None"
materia_tags: "mundo"
categoria: "Notícias"
titulo: "O mundo encantado do Caxangá ??gape"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Pois hoje é dia de o senador José Jorge (PFL), vice de Geraldo Alckmin (PSDB), ser homenageado no ??gape, uma confraria que, desde 1945, reúne todas as quartas uma turma animada, sempre com um bom e farto u?sque, para homenagear todo mundo, de gregos a troianos. Os últimos foram Humberto Costa e Maur?cio Rands, do PT. Antes, havia passado por lá Jarbas Vasconcelos, do PMDB.</FONT></P></p>
<p><P><FONT face=Verdana>É assim mesmo. Todo mundo tem espaço por lá. Todo mundo mesmo. É uma farra, no Boi Preto, churrascaria com aquele clima emergente, no Pina, zona sul do Recife.</FONT></P></p>
<p><P><FONT face=Verdana>Em conversa com Jamildo Melo, repórter especial do JC, José Jorge deixou claro que vai para o ??gape animado com a sucessão presidencial. Ele acredita que Alckmin conseguirá reverter a distância&nbsp;de Lula nas pesquisa de intenção de voto.</FONT></P></p>
<p><P><FONT face=Verdana>O levantamento JC/Vox Populi divulgado ontem no Jornal do Commercio mostra o presidente com 66%, contra 16% de Alckmin. No interior do Estado, a diferença é ainda maior: 74% a, no máximo, 16%.</FONT></P></p>
<p><P><FONT face=Verdana>\"No Interior, tem muita gente que acredita que só tem um candidato (Lula). É que a informação chega mais lentamente no Interior do que na capital, numa região em que o governo está explorando tudo que for poss?vel, como o Bolsa Fam?lia, para se reeleger\", avaliou Jorge. </FONT></P></p>
<p><P><FONT face=Verdana>Para ele, no entanto, o dado mais significativo é que, com o crescimento de Alckmin na região Sul e com o aumento das intenções de voto de outros candidatos, como Helo?sa Helena (P-SOL), haverá segundo turno. \"Era esse o nosso objetivo (levar a disputa para o segundo turno). Aqui em Pernambuco, desde a última pesquisa JC/Vox Populi, já crescemos de 10% para 16%\", observou.</FONT></P></p>
<p><P><FONT face=Verdana>O clima do ??gape fará bem ao senador.</FONT></P></FONT> </p>
