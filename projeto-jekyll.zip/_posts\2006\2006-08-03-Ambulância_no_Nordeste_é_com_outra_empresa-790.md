---
id: 12371963
data_publicacao: "2006-08-03 15:30:00"
data_alteracao: "None"
materia_tags: "empresa,nordeste,Outra Vez"
categoria: "Notícias"
titulo: "Ambulância no Nordeste é com outra empresa"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG><EM><A href=\"https://www.noblat.com.br/\" target=_blank>blog</A></EM></STRONG> de Noblat</FONT></P></p>
<p><P><FONT face=Verdana>A empresa KM, do munic?pio de Jaboatão dos Guararapes, na Grande Recife, é quem domina o esquema de venda superfaturada de ambulâncias às prefeituras do Nordeste.</FONT></P></p>
<p><P><FONT face=Verdana>Por isso a Planam, de Luiz Antonio Vedoim e do seu pai Darci, nunca se deu bem por lá. Foi o que disse Vedoin à CPI dos Sanguessugas e reproduziu o deputado Raul Jungmann (PPS-PE).</FONT></P></p>
<p><P><FONT face=Verdana>No plano federal, o Ministério da Saúde era nicho de mercado da Planam. O nicho da KM era o Ministério da Ciência e Tecnologia.</FONT></P></p>
<p><P><FONT face=Verdana>Vedoin contou à CPI que a Planam pretendia diversificar sua carteira de negócios investindo mais na área da inclusão digital via compra e repasse superfaturado de equipamentos.</FONT></P></p>
<p><P><FONT face=Verdana>Não deu tempo. A pol?cia descobriu tudo.</FONT></P> </p>
