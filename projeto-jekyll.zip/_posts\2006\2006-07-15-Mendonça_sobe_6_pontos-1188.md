---
id: 12372361
data_publicacao: "2006-07-15 10:39:00"
data_alteracao: "None"
materia_tags: "mendonça"
categoria: "Notícias"
titulo: "Mendonça sobe 6 pontos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Pesquisa do Vox Populi, cujos resultados estarão publicados daqui a pouco, com exclusividade, na edição de domingo do Jornaldo Commercio, mostra que o governador Mendonça Filho (PFL) conseguiu ampliar a vantagem sobre seus dois principais concorrentes, Humberto Costa (PT) e Eduardo Campos (PSB).</P></p>
<p><P>A pesquisa ouviu 800 pessoas entre os dias 7 e 8 e tem 3,5% de margem de erro para mais ou para menos. Estimulados a apontar numa lista com os nove candidatos a governador de Pernambuco quais seriam seus escolhidos, os eleitores se dividiram da seguinte forma:</P></p>
<p><TABLE cellSpacing=1 cellPadding=3 width=400 bgColor=#6ca7a6 border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD><FONT color=#ffffff>&nbsp;</FONT></TD></p>
<p><TD><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=2>Dados de hoje</FONT></STRONG></TD></p>
<p><TD><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=2>em maio passado</FONT></STRONG></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Mendonça</FONT></STRONG></TD></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=4>35%</FONT></STRONG></TD></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=4>29%</FONT></STRONG></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Eduardo</FONT></STRONG></TD></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=4>21%</FONT></STRONG></TD></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=4>23%</FONT></STRONG></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Humberto</FONT></STRONG></TD></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=4>22%</FONT></STRONG></TD></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=4>21%</FONT></STRONG></TD></TR></TBODY></TABLE><BR></p>
<p><TABLE cellSpacing=1 cellPadding=3 width=400 bgColor=#6ca7a6 border=0></p>
<p><TBODY></p>
<p><TR bgColor=#006666></p>
<p><TD colSpan=3><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>SEGUNDO TURNO</FONT></STRONG></TD></TR></p>
<p><TR bgColor=#eaf0ee></p>
<p><TD colSpan=3><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Mendonça cresce e vence em todos os cenários</FONT></TD></TR></p>
<p><TR></p>
<p><TD width=94><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=2><STRONG>&nbsp;Cenário 1 </STRONG></FONT></TD></p>
<p><TD width=129><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=2>Hoje</FONT></STRONG></TD></p>
<p><TD width=155><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=2>Maio</FONT></STRONG></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Mendonça</FONT></STRONG></TD></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>46%</FONT></STRONG></TD></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>40%</FONT></STRONG></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Eduardo</FONT></STRONG></TD></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>32%</FONT></STRONG></TD></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>39%</FONT></STRONG></TD></TR></p>
<p><TR bgColor=#6ca7a6></p>
<p><TD><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=2>Cenário 2</FONT></STRONG></TD></p>
<p><TD><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=2>Hoje</FONT></STRONG></TD></p>
<p><TD><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=2>Maio</FONT></STRONG></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Mendonça</FONT></STRONG></TD></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>48%</FONT></STRONG></TD></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>44%</FONT></STRONG></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Humberto</FONT></STRONG></TD></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>32%</FONT></STRONG></TD></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>35%</FONT></STRONG></TD></TR></p>
<p><TR bgColor=#6ca7a6></p>
<p><TD><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=2>Cenário 3</FONT></STRONG></TD></p>
<p><TD><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=2>Hoje</FONT></STRONG></TD></p>
<p><TD><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=2>Maio</FONT></STRONG></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Eduardo</FONT></STRONG></TD></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>39% </FONT></STRONG></TD></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>39%</FONT></STRONG></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Humberto</FONT></STRONG></TD></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>32% </FONT></STRONG></TD></p>
<p><TD bgColor=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>33%</FONT></STRONG></TD></TR></TBODY></TABLE><BR></p>
<p><TABLE cellSpacing=1 cellPadding=3 width=400 bgColor=#6ca7a6 border=0></p>
<p><TBODY></p>
<p><TR bgColor=#006666></p>
<p><TD colSpan=2><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>REJEIÇÃO</FONT></STRONG></TD></TR></p>
<p><TR bgColor=#eaf0ee></p>
<p><TD colSpan=2><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Eduardo continua com ?ndice mais baixo:</FONT></TD></TR></p>
<p><TR></p>
<p><TD width=298><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=2><STRONG>&nbsp;</STRONG></FONT></TD></p>
<p><TD</p>
<p> width=87></p>
<p><DIV align=right><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=2>Julho</FONT></STRONG></DIV></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee></p>
<p><P><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Clóvis Corrêa (Prona) </FONT></P></TD></p>
<p><TD vAlign=top bgColor=#eaf0ee></p>
<p><DIV align=right><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=4>13%</FONT></STRONG></DIV></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee></p>
<p><P><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Humberto Costa (PT) </FONT></P></TD></p>
<p><TD vAlign=top bgColor=#eaf0ee></p>
<p><DIV align=right><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=4>11%</FONT></STRONG></DIV></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee></p>
<p><P><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Mendonça Filho (PFL) </FONT></P></TD></p>
<p><TD vAlign=top bgColor=#eaf0ee></p>
<p><DIV align=right><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=4>10%</FONT></STRONG></DIV></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee></p>
<p><P><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Kátia Teles (PSTU) </FONT></P></TD></p>
<p><TD vAlign=top bgColor=#eaf0ee></p>
<p><DIV align=right><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=4>8%</FONT></STRONG></DIV></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee></p>
<p><P><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Luiz Vidal (PSDC) </FONT></P></TD></p>
<p><TD vAlign=top bgColor=#eaf0ee></p>
<p><DIV align=right><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=4>7%</FONT></STRONG></DIV></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee></p>
<p><P><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Edilson Silva (P-SOL) </FONT></P></TD></p>
<p><TD vAlign=top bgColor=#eaf0ee></p>
<p><DIV align=right><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=4>7%</FONT></STRONG></DIV></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee></p>
<p><P><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Oswaldo Alves (PCO) </FONT></P></TD></p>
<p><TD vAlign=top bgColor=#eaf0ee></p>
<p><DIV align=right><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=4>5%</FONT></STRONG></DIV></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee></p>
<p><P><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Eduardo Campos (PSB) </FONT></P></TD></p>
<p><TD vAlign=top bgColor=#eaf0ee></p>
<p><DIV align=right><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=4>4%</FONT></STRONG></DIV></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2>Rivaldo Soares (PSL) </FONT></TD></p>
<p><TD vAlign=top bgColor=#eaf0ee></p>
<p><DIV align=right><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=4>3%</FONT></STRONG></DIV></TD></TR></TBODY></TABLE> </p>
