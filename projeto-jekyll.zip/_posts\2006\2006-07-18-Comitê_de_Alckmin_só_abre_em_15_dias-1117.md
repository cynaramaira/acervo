---
id: 12372290
data_publicacao: "2006-07-18 17:55:00"
data_alteracao: "None"
materia_tags: "geraldo Alckmin"
categoria: "Notícias"
titulo: "Comitê de Alckmin só abre em 15 dias"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>O senador José Jorge (PFL) está no Recife e afirmou há pouco a Cec?lia Ramos, repórter do blog, que a inauguração do comitê do presidenciável Geraldo Alckmin (PSDB), de quem é vice, será inaugurado dentro de 15 dias. \"Precisamos fazer uma pequena reforma ainda\", referindo-se a um casarão na rua Barão de Itamaracá, no Espinheiro, Recife.</P></p>
<p><P>José Jorge está animado, embora, em Pernambuco, o cenário para a chapa tucana não seja favorável. A pesquisa JC/Vox Populi divulgada hoje no Jornal do Commercio mostra Lula com 66% e Alckmin com apenas 16%. \"Aqui e no Nordeste todo vamos reverter esses números com o guia eleitoral\", avalia o senador. </P></FONT> </p>
