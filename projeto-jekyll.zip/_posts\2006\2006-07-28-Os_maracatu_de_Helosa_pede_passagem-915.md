---
id: 12372088
data_publicacao: "2006-07-28 19:30:00"
data_alteracao: "None"
materia_tags: "maracatu,passagem aérea"
categoria: "Notícias"
titulo: "Os maracatu de Helo?sa pede passagem"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>A senadora do P-SOL esbanjou simpatia e frases de efeito na passagem pelo Recife.</P></p>
<p><P>Também&nbsp;lançou ao vento tudo o que defende contra o capital e seus asseclas. </P></p>
<p><P>Retomou, com intensidade,&nbsp;toda a pol?tica defendida por Lula (cinco eleições atrás).</P> </p>
