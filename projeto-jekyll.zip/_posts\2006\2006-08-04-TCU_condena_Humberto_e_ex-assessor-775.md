---
id: 12371948
data_publicacao: "2006-08-04 06:54:00"
data_alteracao: "None"
materia_tags: "Condenação,Humberto Costa"
categoria: "Notícias"
titulo: "TCU condena Humberto e ex-assessor"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=Arial></p>
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG><BR>(com Agência Estado)</FONT></P></p>
<p><P><FONT face=Verdana>O plenário do Tribunal de Contas da União (TCU) determinou, em sessão sigilosa, que o jornalista Laércio Portela Delgado, assessor-adjunto de Imprensa do governo, e o candidato a governador de Pernambuco Humberto Costa (PT), da Coligação Melhor pra Pernambuco (PT-PRB-PT-PTB-PAN-PMN-PC do B), paguem multa de R$ 5 mil e R$ 13 mil, respectivamente, por fazer uso pessoal do programa \"Rádio Saúde\", do Ministério da Saúde.</FONT></P></p>
<p><P><FONT face=Verdana>Delgado, o segundo da hierarquia da comunicação do presidente Luiz Inácio Lula da Silva, candidato da Coligação A Força do Povo (PT-PRB-PC do B) à reeleição, pode recorrer num prazo de 15 dias da decisão. Técnicos do TCU propuseram que Delgado fique inabilitado por cinco anos para exercer cargo de confiança na administração federal. O acórdão só determina a multa.</FONT></P></p>
<p><P><FONT face=Verdana></FONT></P></p>
<p><P><FONT face=Verdana>Relatório do ministro Benjamim Zymler destaca que Costa, à época em que dirigiu o ministério, e Delgado, assessor dele na pasta, produziram programas voltados, exclusivamente, para Pernambuco, base eleitoral do petista. </FONT></P></p>
<p><P><FONT face=Verdana>Zymler afirma que Delgado demonstrou \"ausência de controle\" no ministério e produziu programas sem a devida \"motivação\". Foi gasto um total de R$ 1,4 milhão só na veiculação</p>
<p> do programa, de dois minutos de duração, de outubro de 2004 a abril de 2005, em dias úteis. </FONT></P></p>
<p><P><FONT face=Verdana>Delgado disse que recorrerá. \"Discordo desta decisão do TCU, que carece de qualquer fundamento, e vou recorrer, administrativamente e judicialmente\", afirmou.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://jc3.uol.com.br/jornal/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinates JC e UOL).</FONT></P></FONT> </p>
