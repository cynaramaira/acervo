---
id: 12372218
data_publicacao: "2006-07-22 19:14:00"
data_alteracao: "None"
materia_tags: "Ana Arraes,eduardo"
categoria: "Notícias"
titulo: "Eduardo fala no companheiro Arraes"
sutia: "None"
chapeu: "None"
autor: "jamildo"
imagem: "None"
---
<p>&nbsp;</p>
<p>Eduardo n&atilde;o foi t&atilde;o amistoso com Humberto. Disse agora: "Lula, a luta primeira, agora, &eacute; reeleger voc&ecirc;. Os palanques precisam se unificar". Muitos fogos nesta hora. Eduardo continua: "As elei&ccedil;&otilde;es passam, mas nossa luta tem que seguir. N&atilde;o somos inimigos nem advers&aacute;rios, nossos advers&aacute;rios s&atilde;o os mesmos. Aqui estamos, Lula, para dizer que estou no mesmo palanque de seu companheiro". E fez uma pausa ainda maior.</p>
<p>Todo mundo esperava que ele dissesse: "Seu companheiro Humberto". N&atilde;o foi o que aconteceu: "Seu companheiro Miguel Arraes, que esteve no seu palanque em 1989. N&oacute;s, eu e Humberto, estaremos nas ruas unidos para garantir sua vit&oacute;ria, para derrotar o &oacute;dio, a intransig&ecirc;ncia e o atraso".</p>
<p>Quem est&aacute; falando agora &eacute; Jo&atilde;o Paulo, o prefeito.</p>
<p>Jo&atilde;o Lyra Neto, vice de Eduardo, &eacute; do PDT e achou conveniente n&atilde;o discursar. O partido dele tem candidato a presidente, o senador Cristovam Buarque (DF).</p>
