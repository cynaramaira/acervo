---
id: 12371967
data_publicacao: "2006-08-03 07:30:00"
data_alteracao: "None"
materia_tags: "Ciro Gomes,geraldo Alckmin,Lula,papelão,projeto,refinarias"
categoria: "Notícias"
titulo: "Alckmin promete acelerar refinaria. Ciro Gomes diz que projeto só sairá do papel com Lula"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Jamildo Melo <BR></STRONG>Repórter&nbsp;especial do JC</FONT></P></p>
<p><P><FONT face=Verdana>Na visita que fará amanhã ao Estado, com o<BR>objetivo de anunciar seu plano de governo para a região Nordeste, o candidato tucano Geraldo Alckmin (PSDB/SP) dirá aos pernambucanos e a sociedade regional que planeja acelerar a construção da refinaria da Petrobras em Pernambuco, numa clara oposição<BR>ao discurso petista. </FONT></P></p>
<p><P><FONT face=Verdana>No mês passado, em um evento da campanha de Lula em Olinda, o ex-ministro da Integração Nacional, Ciro Gomes (PSB-CE), afirmou que o empreendimento só sairia do papel se o presidente fosse reeleito.</FONT></P></p>
<p><P><FONT face=Verdana>\"Alckmin vai entrar e sair de Pernambuco comprometido com a refinaria\", confirmou ontem o senador Sérgio Guerra (PSDB/PE), coordenador nacional da campanha da coligação PSDB-PFL. A promessa só não vai constar do programa para o Nordeste, embora seja uma obra<BR>estruturadora para a região, porque o candidato quer evitar a necessidade de elencar outros projetos estaduais, como o projeto de uma siderúrgica para o Ceará, também objeto de compromisso eleitoral.<BR></FONT><FONT face=Verdana><FONT size=2></FONT></FONT></P></p>
<p><P><FONT face=Verdana><FONT size=2>Leia <A href=\"https://www.jc.com.br/\" target=_blank><STRONG><EM>aqui</EM></STRONG></A>&nbsp;o texto completo (assinantes JC e UOL).</P></p>
<p><P><STRONG></STRONG>&nbsp;</P></p>
<p><P><STRONG></STRONG>&nbsp;</P></FONT></FONT> </p>
