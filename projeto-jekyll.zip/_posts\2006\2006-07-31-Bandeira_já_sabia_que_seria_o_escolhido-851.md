---
id: 12372024
data_publicacao: "2006-07-31 20:16:00"
data_alteracao: "None"
materia_tags: "Serial Killer"
categoria: "Notícias"
titulo: "Bandeira já sabia que seria o escolhido"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Assim que deixou o plenário do Tribunal de Justiça, no final da tarde, Francisco Bandeira já sabia que seria o novo desembargador.</FONT></P></p>
<p><P><FONT face=Verdana>Pouco antes de se desequilibrar e quase cair das escadarias do TJ, deixou escapar uma frase reveladora: \"Agora só falta o governador assinar.\"</FONT></P></p>
<p><P><FONT face=Verdana>Disse isso a um dos muitos amigos que foram cumprimentá-lo.</FONT></P></p>
<p><P><FONT face=Verdana>Bandeira temia apenas que o procurador Pedro Henrique Alves, o candidato do governo, fosse eleito para a lista tr?plice que seguiria ao Palácio das Princesas.</FONT></P></p>
<p><P><FONT face=Verdana>O acordo entre Mendonça Filho e Jarbas Vasconcelos era o de nomear PH, caso entrasse na lista. Se não entrasse, o caminho estaria aberto.</FONT></P></p>
<p><P><FONT face=Verdana>Muita gente no PFL torcia por Bandeira, um quase afilhado do senador Marco Maciel.</FONT></P> </p>
