---
id: 12372164
data_publicacao: "2006-07-24 20:10:00"
data_alteracao: "None"
materia_tags: "eduardo"
categoria: "Notícias"
titulo: "Eduardo festejado na Soledade"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Eduardo chegou e está sendo superfestejado pelo público.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Disse que o encontro de agora, no Centro Social da Soledade, é de responsabilidade de João Fernando Coutinho. Fez questão de deixar isso claro. E que cabia ao deputado manter o público informado sobre o que ocorreria.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2>De qualquer maneira, disse Eduardo em conversa com Cec?lia Ramos, repórter do Blog, “(o encontro) não deixa de ser uma boa oportunidade. Quem veio sabendo ou não vai ouvir (o que ele tem a dizer). É uma coisa positiva???, afirmou.</FONT></SPAN> </p>
