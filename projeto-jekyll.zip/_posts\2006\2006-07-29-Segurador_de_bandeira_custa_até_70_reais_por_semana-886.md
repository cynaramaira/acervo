---
id: 12372059
data_publicacao: "2006-07-29 14:00:00"
data_alteracao: "None"
materia_tags: "confere.aí,Seguradora Líder,Semana Santa,skate"
categoria: "Notícias"
titulo: "Segurador de bandeira custa até 70 reais por semana"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Este é o preço revelado por militantes contratados para segurar bandeiras e distribuir panfletos de Armando Monteiro Neto (PTB), deputado que disputa a reeleição.</FONT></P></p>
<p><P><FONT face=Verdana>Hoje cedo, os militantes disseram a Cec?lia Ramos, repórter do <STRONG>Blog</STRONG>, que os 70 reais correspondem ao trabalho&nbsp;da semana inteira (seis dias).</FONT></P></p>
<p><P><FONT face=Verdana>Ela apurou também que a campanha de Eduardo Campos (PSB), candidato a governador, paga quase metade pelo mesmo serviço: 40 reais.</FONT></P></p>
<p><P><FONT face=Verdana>Os valores pagos pelo pessoal de Humberto Costa (PT), outro candidato a governador, não foram revelados simplesmente porque não havia quem segurasse bandeiras para ele no Agreste, em Bom Conselho, hoje pela manhã.</FONT></P> </p>
