---
id: 12371990
data_publicacao: "2006-08-02 09:29:00"
data_alteracao: "None"
materia_tags: "geraldo Alckmin,nordeste,projeto"
categoria: "Notícias"
titulo: "Alckmin: projeto genérico para o Nordeste"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do</FONT><FONT face=Verdana><STRONG> Painel <BR></STRONG>(Folha de S.Paulo)</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Genérico</STRONG>. Quem espera propostas objetivas, com destinação de recursos e prazo de execução, vai se decepcionar com o programa \"O Novo Nordeste\", que Geraldo Alckmin apresenta sexta em Recife. O documento tucano elenca grandes temas regionais, sem mencionar obras nem Estados espec?ficos. <BR></FONT></P> </p>
