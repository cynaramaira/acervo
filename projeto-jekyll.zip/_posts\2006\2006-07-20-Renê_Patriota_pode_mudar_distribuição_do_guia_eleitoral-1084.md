---
id: 12372257
data_publicacao: "2006-07-20 11:54:00"
data_alteracao: "None"
materia_tags: "Distribuição,fundo eleitoral,Gonzaga Patriota"
categoria: "Notícias"
titulo: "Renê Patriota pode mudar distribuição do guia eleitoral"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>As brigas da advogada Renê Patriota com os companheiros do PV podem complicar toda a propaganda eleitoral gratuita no rádio e na TV em Pernambuco. </FONT></P></p>
<p><P><FONT face=Verdana>O TRE fará amanhã a divisão dos tempos, horários e seqüências de entrada no ar dos programas dos partidos e coligações. Mas a divisão poderá ser modificada mais adiante, quando o Tribunal decidir se anula ou não a convenção do PV.</FONT></P></p>
<p><P><FONT face=Verdana>Patriota não aceita o resultado da convenção, que aprovou a aliança com Mendonça Filho. Ela deseja ser candidata a governadora.</FONT></P></p>
<p><P><FONT face=Verdana>A divisão dos tempos do guia eleitoral ocorrerá amanhã, às 14h, no TRE, no Recife.</FONT></P></FONT> </p>
