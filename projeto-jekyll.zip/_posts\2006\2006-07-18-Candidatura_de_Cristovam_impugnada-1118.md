---
id: 12372291
data_publicacao: "2006-07-18 17:22:00"
data_alteracao: "None"
materia_tags: "Candidatura"
categoria: "Notícias"
titulo: "Candidatura de Cristovam impugnada"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Da Agência Estado</FONT></P></p>
<p><P><FONT face=Verdana>O Ministério Público Federal (MPF) impugnou três chapas registradas no Tribunal Superior Eleitoral (TSE) para disputar a sucessão presidencial nas próximas eleições de outubro. Foram impugnadas as chapas de Cristovam Buarque, candidato a presidente, e de seu vice, Jefferson Peres, ambos pelo PDT; Ana Maria Rangel, candidata a presidente, e sua vice, Delma Gama e Narici, pelo PRP, e também de Rui Pimenta e seu candidato a vice-presidente, Pedro Paulo Pinheiro, ambos pelo PCO. </FONT></P></p>
<p><P><FONT face=Verdana>Sobre a chapa formada pelos senadores Cristovam Buarque (DF) e Jefferson Peres (AM), o Ministério Público afirma que o pedido de registro de candidatura da chapa não veio instru?do com a documentação necessária, de acordo com informações do site do TSE. A chapa formada por Rui Pimenta e Pedro Paulo Pinheiro, também tinha falha na documentação necessária à candidatura. </FONT></P></p>
<p><P><FONT face=Verdana>No pedido de impugnação de candidatura de Ana Maria Rangel, o Ministério Público argumenta que, apesar de filiada ao PRP desde o dia 12 de agosto de 2005, a candidata não foi indicada pelo partido em convenção. Para pedir a impugnação de Delma Gama, suposta candidata a vice de Ana Maria, o Ministério Público afirma que \"nem mesmo existe a not?cia de que seja filiada a partido pol?tico, não sendo admitida a candidatura avulsa\" </FONT></P></FONT> </p>
