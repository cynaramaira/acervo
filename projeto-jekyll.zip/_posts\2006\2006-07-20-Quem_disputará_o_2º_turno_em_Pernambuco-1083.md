---
id: 12372256
data_publicacao: "2006-07-20 19:07:00"
data_alteracao: "None"
materia_tags: "esquema criminoso,pernambuco,Saturno"
categoria: "Notícias"
titulo: "Quem disputará o 2º turno em Pernambuco?"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>A maioria dos que votaram até agora aposta numa disputa Mendonça X Eduardo. Veja os números (arredondados)&nbsp;da enquete postada no menu, ao lado:</P></p>
<p><P>Você acha que haverá segundo turno na eleição para governador de Pernambuco?</P></p>
<p><P>Sim, entre Mendonça e Eduardo&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 82%&nbsp; (411 votos)</P></p>
<p><P>Sim, entre Mendonça e Humberto&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;6%&nbsp;&nbsp; (28 votos)</P></p>
<p><P>Sim, entre Eduardo e Humberto&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1%&nbsp;&nbsp;&nbsp; (6 votos)</P></p>
<p><P>Não&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;12%&nbsp; (58 votos)</P></p>
<p><P>&nbsp;</P></p>
<p><P>Total de votos&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;503</P></p>
<p><P>&nbsp;</P> </p>
