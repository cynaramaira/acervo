---
id: 12371984
data_publicacao: "2006-08-02 13:58:00"
data_alteracao: "None"
materia_tags: "PSDB"
categoria: "Notícias"
titulo: "PSDB e PPS começam a punir sanguessugas"
sutia: "None"
chapeu: "None"
autor: "jamildo"
imagem: "None"
---
<p>Do <strong>JC OnLine</strong><br />(<a href="http://fivenews.sjcc.com.br/&quot;https:/www.jc.com.br&quot;">www.jc.com.br</a>)</p>
<p>Dois partidos deram in?cio nessa ter&ccedil;a-feira (1&ordm;) &agrave; puni&ccedil;&atilde;o de parlamentares de seus quadros que se envolveram com a m&aacute;fia dos sanguessugas.</p>
<p>O PSDB abriu processo de expuls&atilde;o contra o deputado Paulo Feij&oacute; (RJ). "N&atilde;o h&aacute; d&uacute;vidas da culpa dele nesse processo", disse o presidente do PSDB, senador Tasso Jereissati (CE).</p>
<p>O relator do caso no PSDB, deputado Gustavo Fruet (PR), disse que h&aacute; provas da participa&ccedil;&atilde;o de Feij&oacute; na m&aacute;fia. "S&atilde;o dep&oacute;sitos banc&aacute;rios", disse ele.</p>
<p>Tamb&eacute;m nessa ter&ccedil;a (1&ordm;) o PPS suspendeu as atividades partid&aacute;rias do deputado Fernando Estima (SP), suspeito de envolvimento com o esquema de desvio de dinheiro do Or&ccedil;amento da Uni&atilde;o.</p>
<p>Estima poder&aacute; ainda ficar sem a legenda, o que o impedir&aacute; de se candidatar. Por enquanto, o parlamentar fica proibido de representar o partido na C&acirc;mara, seja nas comiss&otilde;es ou no plen&aacute;rio, mas ainda pode disputar a reelei&ccedil;&atilde;o.</p>
<p>Coment&aacute;rio meu:</p>
<p>O PPS &eacute; aquele partido que na propaganda na TV e no r&aacute;dio, no primeiro semestre, apresentava um locutor com voz empostada, dizendo que estava limpo, n&atilde;o tinha envolvimento com o esc&acirc;ndalo do mensal&atilde;o.</p>
<p>&nbsp;</p>
