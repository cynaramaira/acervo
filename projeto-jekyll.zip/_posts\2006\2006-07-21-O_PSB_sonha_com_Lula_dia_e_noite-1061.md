---
id: 12372234
data_publicacao: "2006-07-21 22:59:00"
data_alteracao: "None"
materia_tags: "Lula,noite"
categoria: "Notícias"
titulo: "O PSB sonha com Lula dia e noite"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Tiradas em Natal, 20 dias atrás, as fotos vêm sendo distribu?das pelo partido para mostrar o quanto Lula prefere Arraes e seus descendentes a Humberto Costa (PT).</P></p>
<p><P>&nbsp;</P> </p>
