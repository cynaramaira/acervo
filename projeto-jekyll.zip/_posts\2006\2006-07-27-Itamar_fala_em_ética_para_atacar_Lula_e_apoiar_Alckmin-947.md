---
id: 12372120
data_publicacao: "2006-07-27 17:12:00"
data_alteracao: "None"
materia_tags: "ética,geraldo Alckmin,Itamaraty,Lula"
categoria: "Notícias"
titulo: "Itamar fala em ética para atacar Lula e apoiar Alckmin"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><DIV class=ad1><FONT face=Verdana>Da <B>Folha Online</B><BR><BR>O ex-presidente Itamar Franco disse hoje que o governo do presidente Luiz Inácio Lula da Silva não escolheu o caminho da ética e que por isso iria apoiar a candidatura do tucano Geraldo Alckmin à Presidência.<BR><BR>\"Quando o presidente Lula escolheu o seu caminho e a suas companhias, nós escolhemos um outro caminho e uma companhia ética e é nessa companhia ética que nós vamos caminhar aqui (Minas)\", afirmou o ex-presidente.<BR><BR>Itamar comparou o governo Lula com um feixe de palha. \"O governo Lula virou um feixe de palha. Feixe de palha, qualquer vento leva esta palha. Então, a partir de um certo momento, ele se esgarçou. Esgarçou o tecido governamental\", disse Itamar.</FONT></DIV></p>
<p><DIV class=ad1><FONT face=Verdana></FONT>&nbsp;</DIV></p>
<p><DIV class=ad1><FONT face=Verdana><STRONG>Comentário meu:</STRONG></FONT></DIV></p>
<p><DIV class=ad1><FONT face=Verdana></FONT>&nbsp;</DIV></p>
<p><DIV class=ad1><FONT face=Verdana>O governo Lula foi bom para Itamar enquanto ele viveu seu ex?lio dourado como embaixador na Europa e tinha esperança de ser o candidato do presidente a senador, por Minas Gerais. A ética é balela.</FONT></DIV> </p>
