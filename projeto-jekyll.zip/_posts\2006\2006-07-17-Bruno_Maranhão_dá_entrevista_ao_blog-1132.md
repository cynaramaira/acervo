---
id: 12372305
data_publicacao: "2006-07-17 21:46:00"
data_alteracao: "None"
materia_tags: "Bruno Covas,entrevista,maranhão"
categoria: "Notícias"
titulo: "Bruno Maranhão dá entrevista ao blog"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>O l?der do Movimento&nbsp;de Libertação dos Trabalhadores Sem-Terra (MLST) foi libertado no sábado, após 38 dias preso em Bras?lia, e falou ao blog há pouco por telefone.</P></p>
<p><P>Criticou duramente Aldo Rebelo (PCdoB), presidente da Câmara, a quem chamou de inseguro e fraco por não ter resistido às pressões da \"direita do Congresso\", que está tentando causar a criminalização dos movimentos sociais.</P></p>
<p><P>Daqui a pouco postarei a entrevista completa. Ela antecipa os principais pontos que Bruno Maranhão vai abordar amanhã, durante coletiva que&nbsp;concederá em Bras?lia.</P> </p>
