---
id: 12372319
data_publicacao: "2006-07-17 11:54:00"
data_alteracao: "None"
materia_tags: "regras"
categoria: "Notícias"
titulo: "Regras para os comentários"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Decidimos estabelecer limites aos comentários postados no blog. Muitos deles já extrapolaram qualquer padrão m?nimo de civilidade. A interação com vocês não pode servir à publicação de calúnias e difamação, que são crimes. Cada comentário é de total responsabilidade do internauta que o inseriu. E o blog reserva-se o direito de não publicar mensagens contendo palavras de baixo calão, publicidade, calúnia, injúria, difamação ou qualquer conduta que possa ser considerada criminosa.</P></p>
<p><P>Voltaremos a falar sobre isso.</FONT></P> </p>
