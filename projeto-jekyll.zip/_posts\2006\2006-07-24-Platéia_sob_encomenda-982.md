---
id: 12372155
data_publicacao: "2006-07-24 22:29:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Platéia sob encomenda"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Eduardo Campos, candidato socialista ao governo de Pernambuco, acabou de falar para uma platéia de cerca de 500 pessoas, no Centro Social da Soledade, no Recife. Todas&nbsp;foram levadas ao local pelo deputado estadual João Fernando Coutinho, candidato à reeleição. Nenhuma das 20 entrevistadas pelo <STRONG>Blog</STRONG> sabia dizer exatamente o que fazia no local.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2>Trecho do discurso de Eduardo para&nbsp;elas: \"A pol?tica tem mostrado tantas cenas que têm afastado as pessoas da pol?tica. Mas nós precisamos continuar com a nossa luta. Não podemos nos afastar dos nossos compromissos com o povo\".</FONT></SPAN> </p>
