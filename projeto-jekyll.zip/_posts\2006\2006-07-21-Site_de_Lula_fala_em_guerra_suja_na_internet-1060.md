---
id: 12372233
data_publicacao: "2006-07-21 20:14:00"
data_alteracao: "None"
materia_tags: "guerra,internet,Lula,site"
categoria: "Notícias"
titulo: "Site de Lula fala em guerra suja na internet"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do&nbsp;site <A href=\"https://www.lulapresidente.org.br/noticia.php?codigo=99\" target=_blank><STRONG>Lula Presidente</STRONG></A>:</FONT></P></p>
<p><P><FONT face=Verdana>A internet é um meio de comunicação muito importante. Atualmente, 36 milhões de brasileiros têm acesso à rede diariamente. Este número representa aproximadamente 30% do eleitorado. A utilização desta ferramenta pode fazer a diferença junto a alguns setores sociais. Por isso, o Partido dos Trabalhadores está orientando militantes, simpatizantes e todos os eleitores do presidente Luiz Inácio da Silva a utilizarem o potencial da Internet para dinamizar a campanha pela reeleição. </FONT></P></p>
<p><P><FONT face=Verdana>Texto divulgado nesta quarta-feira (19) pelo secretário de Relações Internacionais do PT, Valter Pomar, discorre sobre importância da internet no processo eleitoral e convoca os internautas a se manifestarem através de todas as ferramentas dispon?veis (blogs, chats, sites, e-mails) em favor da candidatura Lula.</FONT></P></p>
<p><P><FONT face=Verdana>O secretário alerta para as informações falsas e as difamações difundidas contra o presidente Lula e outros candidatos do PT. Por isso, é preciso ocupar o espaço virtual para defender os projetos da administração federal, debater o programa de governo do próximo mandato e combater a \"guerra suja\" das acusações infundadas, caluniosas e criminosas que circulam com facilidade por esse meio. A participação de todos os apoiadores da candidatura Lula é fundamental para que seja poss?vel um contra-ataque imediato e eficiente, não deixando nenhuma acusação sem resposta\".</FONT></P></p>
<p><P><FONT face=Verdana>O PT e a coordenação de campanha do presidente Lula pedem aos eleitores que repassem todas as mensagens ofensivas para a área <B><I>Entre em Contato</B></FONT></I><FONT face=Verdana> no site www.lulapresidente.org.br e para o e-mail </FONT><A href=\"mailto:internet@pt.org.br\"><U><FONT color=#0000ff><FONT face=Verdana>internet@pt.org.br</FONT></U></FONT></A><FONT face=Verdana>.</FONT></P> </p>
