---
id: 12372357
data_publicacao: "2006-07-15 13:10:00"
data_alteracao: "None"
materia_tags: "candidatos"
categoria: "Notícias"
titulo: "O que dizem os candidatos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Por meio de sua assessoria de imprensa, Mendonça disse que não vai comentar a pesquisa JC/Vox Populi. O blog está tentando conversar com Humberto e Eduardo, ambos em campanha no interior. Oswaldo Alves (PCO) está em Goiás e não foi localizado.</P></p>
<p><P>Veja o que os outros candidatos disseram a Cec?lia Ramos, repórter do blog:</P></p>
<p><P><STRONG>CLOVIS CORRÊA (Prona)</STRONG></P></p>
<p><P>Ele subiu de 1% para 2%. Entre os candidatos de pequenos partidos, foi o único citado pelos eleitores na pesquisa.</P></p>
<p><P>“Que bom que os outros não foram citados. Eu dobrei a minha intenção de voto sem aparecer na TV. Isso é uma prova eloqüente de que quando for para o guia eu passo para o segundo turno. Mendonça, Humberto e Eduardo usaram de forma imoral os programas partidários de TV, fazendo campanha aberta e descumprindo a Justiça Eleitoral. Não vou me juntar a nenhum deles. Agora a população precisa saber que o eleitor é vendido como um garrote, como um gado e os pol?ticos são os fazendeiros.??? </P></p>
<p><P><STRONG>K??TIA TELES (PSTU)</STRONG></P></p>
<p><P>“A disputa é desigual. As campanhas deles são milionárias, bancadas por empresários. O crescimento de Mendonça Filho, por exemplo, mostra que ele tem vantagem por ter o poder econômico. Vou continuar lutando contra o sistema liderado por Jarbas Vasconcelos e João Paulo, aqui no Estado. Vamos aproveitar nosso guia eleitoral para tentar reverter esse resultado. Não tem chance alguma de nós apoiarmos um dos<BR>três majoritários. São tudo farinha do mesmo saco.???</P></p>
<p><P><STRONG>&nbsp;LUIS VIDAL (PSDC)</STRONG></P></p>
<p><P>“Acho normais esses dados. Lancei minha candidatura só há 45 dias. Nós, minoritários, não temos acesso à m?dia. Quando o guia for ao ar, teremos a chance de divulgar nossas propostas e a?, sim, acredito que eu vou crescer. É quando a população vai tomar conhecimento de que existem outras opções. Vamos mostrar a fragilidade do Congresso, em Bras?lia. E mostrar também que Mendonça Filho cresceu nas pesquisas graças à m?dia, desde que ficou à frente do Governo.???<BR><STRONG></STRONG></P></p>
<p><P><STRONG>RIVALDO SOARES (PSL)</STRONG></P></p>
<p><P>\"Isso é normal. Até porque começamos a nossa campanha a partir do dia 5. Eu não tenho m?dia, então é normal que eu não apareça na pesquisa do JC, mas a partir da próxima semana, já estaremos com a campanha nas ruas, distribuindo panfletos, adesivos e bandeiras. O guia também vai ajudar. Nao tem nenhum mito disputando estas eleições. Somos iguais. A maioria da população não sabe da nossa candidatura, quando souber&nbsp; esse quadro vai mudar.\"<BR><STRONG></STRONG></P></p>
<p><P><STRONG>EDILSON SILVA (P-SOL)</STRONG></P></p>
<p><P>\"Isso é fruto da grande exposição das candidaturas majoritárias. Clóvis está aparecendo porque tem criado alguns canais. Mas nossa campanha ainda não começou por conta de ajustes exigidos pela legislação eleitoral. Esse resultado não nos preoculpa.\"</P> </p>
