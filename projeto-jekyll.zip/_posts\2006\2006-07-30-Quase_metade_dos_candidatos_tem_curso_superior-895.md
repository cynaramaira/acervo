---
id: 12372068
data_publicacao: "2006-07-30 08:10:00"
data_alteracao: "None"
materia_tags: "candidatos,cursos,superiorrecife"
categoria: "Notícias"
titulo: "Quase metade dos candidatos tem curso superior"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=Verdana></p>
<p><P>Por <STRONG>Jamildo Melo</STRONG><BR>Repórter especial do JC</P></p>
<p><P>O perfil dos candidatos a cargos proporcionais, revelado pelos registros do Tribunal Regional Eleitoral (TRE), surpreende pelo baixo n?vel dos postulantes no que toca ao grau de instrução dos candidatos. </P></p>
<p><P>No caso dos deputados federais, por exemplo, há 214 postulantes e apenas 90 pessoas deles declaram que contam com superior completo. Isto representa 42% do total. </P></p>
<p><P>No caso dos deputados estaduais, o número de candidatos oficiais soma 500 postulantes e, proporcionalmente, menos gente ainda tem o n?vel superior. </P></p>
<p><P>Segundo o TRE, 202 declararam que contam com curso superior completo ou 40,31% do total. Pelos registros do TRE, no caso dos deputados federais, cerca de 8% (ou 19 pessoas) teria o curso superior incompleto, contra 11% (ou 58 pessoas), no caso dos candidatos a deputado estadual.</P></p>
<p><P>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinantes JC ou UOL).</P></FONT> </p>
