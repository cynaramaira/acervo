---
id: 12372110
data_publicacao: "2006-07-28 07:55:00"
data_alteracao: "None"
materia_tags: "Ana Arraes,eduardo,Lula,Naomi Campbell"
categoria: "Notícias"
titulo: "Eduardo é associado a Arraes e não a Lula"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Por <STRONG>Sheila Borges</STRONG><BR>Repórter do JC</P></p>
<p><P>Em sua primeira caminhada pelo Centro do Recife, o candidato a governador da Frente Popular de Pernambuco, deputado federal Eduardo Campos (PSB), encontrou, ontem à tarde, dois tipos de eleitor: aquele que o vinculava, prontamente, à imagem do ex-governador</p>
<p> Miguel Arraes - avô do socialista que faleceu no ano passado - e aquele que, simplesmente, não o conhecia.</P></p>
<p><P>Por mais que a militância distribu?sse panfletos com a foto do ex-ministro da Ciência e Tecnologia ao lado do presidente Luiz Inácio Lula da Silva (PT), as pessoas não faziam uma associação voluntária. </P></p>
<p><P>Para consolidar o slogan de sua campanha \"Novo Pernambuco. Novo governador\", principalmente na Região Metropolitana do Recife, Eduardo vai ter que encontrar uma fórmula que o ajude a descolar da figura de Arraes, que já governou o Estado por três vezes (62/86/94), e a aproximar-se de Lula.</P></p>
<p><P>Surpresa com a presença de um pol?tico andando no camelódromo e conversando com os ambulantes, a vendedora Roseane Teles, de 21 anos, cumprimentou o candidato, mas depois revelou à reportagem do JC que não o conhecia, nem pela televisão. \"Nunca tinha visto antes\", falou enquanto guardava a propaganda do socialista.</P></p>
<p><P>O ex-ministro era cumprimentado com mais entusiasmo pelos ambulantes mais velhos, que faziam questão de lembrar do ex-governador. \"Sempre votei em doutor Arraes. Agora, voto nele. É uma questão de fam?lia\", recordou Reinaldo de Lima, que também está no camelódromo desde 92. </P></p>
<p><P>O cineasta camelô, Simião Martiniano, que tem um box no local, disse que estava \"feliz\" por ver Eduardo ali. Lembrou que, em campanhas passadas, dona Madalena Arraes, esposa do ex-governador, chegou a ir em sua casa, em Jaboatão dos Guararares.</P></p>
<p><P>Leia <STRONG><U><A href=\"https://www.jc.com.br/\" target=_blank><EM>aqui</EM></A></U></STRONG> o texto completo (assinantes JC e UOL).</P></FONT> </p>
