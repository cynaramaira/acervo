---
id: 12371983
data_publicacao: "2006-08-02 16:45:00"
data_alteracao: "None"
materia_tags: "eduardo campos,estudo,fundo eleitoral,Gravatá,Naomi Campbell,São João"
categoria: "Notícias"
titulo: "Não é “fantasma???, é de Eduardo Campos a equipe do     guia eleitoral que tudo grava no Engenho São João"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>A assessoria dele havia negado ao <STRONG>Blog</STRONG> que estivesse no local.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>O clima de confronto está sendo registrado desde cedo por um cinegrafista e repórter, acompanhados por um motorista. Todos contratados pelo guia de Eduardo Campos (PSB).</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Também acaba de chegar um fotógrafo do Palácio das Princesas, enviado pela assessoria do governador Mendonça Filho (PFL).</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>E uma equipe do guia de Humberto Costa (PT) está saindo neste momento do Recife para acompanhar também o confronto.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><STRONG>Entenda</p>
<p> o que está ocorrendo (trecho de nota publicada há pouco):</STRONG></FONT></P></p>
<p><P><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Verdana\">É&nbsp;tensa e extremamente politizada a situação no engenho, área de 270 hectares, em São Lourenço da Mata, Região Metropolitana do Recife, ocupada por cerca de 300 fam?lias sem-terra.<o:p></o:p></SPAN></P></p>
<p><P><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Verdana\">A Pol?cia Militar foi enviada ao local para cumprir ordem de desocupação. Há 325 homens cercando o acampamento Chico Mendes, segundo Eduardo Machado, repórter do Jornal do Commercio. Tem PMs do Batalhão de Choque, do 20º Batalhão, da Rádio Patrulha e da Companhia Independente de Operações Especiais.<o:p></o:p></SPAN></P><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Verdana; mso-fareast-font-family: \Times New Roman\; mso-bidi-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><STRONG>Leia mais abaixo</STRONG>.</SPAN> </p>
