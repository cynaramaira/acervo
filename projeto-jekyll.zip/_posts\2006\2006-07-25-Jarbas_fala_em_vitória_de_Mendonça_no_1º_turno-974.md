---
id: 12372147
data_publicacao: "2006-07-25 18:31:00"
data_alteracao: "None"
materia_tags: "Anavitória,jarbas vasconcelos,mendonça,Saturno"
categoria: "Notícias"
titulo: "Jarbas fala em vitória de Mendonça no 1º turno"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Declarações do ex-governador Jarbas Vasconcelos (PMDB)&nbsp;há pouco, no comitê central, no Recife, onde discursa para lideranças comunitárias, ao lado de Mendonça Filho (PFL):</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>“Acho que em toda eleição temos que estar preparados para os dois turnos. Mas quem comanda a estrutura de campanha tem que estar mais preparado ainda porque a eleição pode ser faturada no primeiro turno. É não errar. A gente não errou até agora. Tem dois meses e uma semana pela frente. É procurar não errar, fazer um guia eleitoral competente e propositivo.???</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>E o que é não errar, perguntou Ana Lúcia Andrade, repórter do JC, e Jarbas:</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>“É não fazer um guia capenga; uma fala não adequada. Ele (Mendonça) tem que continuar com um discurso propositivo e administrativo até onde ele puder.???</FONT></P> </p>
