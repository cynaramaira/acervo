---
id: 12371961
data_publicacao: "2006-08-03 16:00:00"
data_alteracao: "None"
materia_tags: "eduardo,Humberto Costa,interior,mendonça,Superávit"
categoria: "Notícias"
titulo: "Humberto supera Mendonça na RMR e Eduardo no interior"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>O <STRONG>Blog</STRONG> analisou os números detalhados da primeira pesquisa realizada pelo Ibope sobre a disputa pelo governo de Pernambuco. </FONT></P></p>
<p><P><FONT face=Verdana>Encomendada pela TV Globo, ela foi divulgada na terça à noite e mostrou Mendonça Filho (PFL) com 32% de intenções de votos, Humberto Costa (PT), 24%, e Eduardo Campos (PSB), 14%. </FONT></P></p>
<p><P><FONT face=Verdana>Os dados sobre aspectos espec?ficos da disputa mostram que Humberto tem seu melhor ?ndice de intenção de voto no Recife (32%), onde supera Mendonça (30%) e Eduardo (11%).</FONT></P></p>
<p><P><FONT face=Verdana>Veja abaixo os detalhes da pesquisa estimulada - aquela em que são apresentados ao eleitor os nomes dos candidatos: </FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Mendonça lidera no interior </STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Se Humberto tem o melhor ?ndice no Recife, Mendonça alcança 34% no interior do Estado, contra 21% do petista e 16% de Eduardo. </FONT></P></p>
<p><P><FONT face=Verdana>Ainda nos dados por região, Mendonça também tem melhor desempenho na periferia, com 31%, contra 26% de Humberto e 10% de Eduardo.</FONT></P></p>
<p><P><FONT face=Verdana>----------------------------------</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Por renda familiar</STRONG> </FONT></P></p>
<p><P><FONT face=Verdana>Humberto e Eduardo apresentam maior intenção de voto entre os eleitores com renda superior a cinco salários m?nimos (R$ 1.750). </FONT></P></p>
<p><P><FONT face=Verdana>Mendonça encontra seu maior ?ndice entre eleitores na faixa de dois a cinco salários m?nimos (de R$ 700 a R$ 1.750). </FONT></P></p>
<p><P><FONT face=Verdana>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <STRONG>Mais de 5</STRONG>&nbsp;/ Mais de 2 a 5&nbsp;/&nbsp;<STRONG>Mais de 1 a 2</STRONG>&nbsp;/ Até 1 </FONT></P></p>
<p><P><FONT face=Verdana>Mendonça&nbsp;&nbsp;&nbsp;34%&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; 37%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;34%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;29% <BR><BR></FONT><FONT face=Verdana>Humberto&nbsp;&nbsp;&nbsp; 26%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 24%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 25%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 23%<BR><BR></FONT><FONT face=Verdana>Eduardo&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 17%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 13%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 13%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 15% </FONT></P></p>
<p><P><FONT face=Verdana>----------------------------------</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Maior rejeição é de Humberto</STRONG> </FONT></P></p>
<p><P><FONT face=Verdana>Com 17%, o candidato do PT lidera o ?ndice de rejeição. Eduardo e Mendonça empatam com 15%. </FONT></P></p>
<p><P><FONT face=Verdana>A pergunta para os 1.806 entrevistados foi: \"Dentre estes poss?veis candidatos ao Governo de Pernambuco em quem o (a) sr. (a) não votaria de jeito nenhum?\" </FONT></P></p>
<p><P><FONT face=Verdana>A maior rejeição para Humberto está entre os eleitores com 50 anos e mais. Nessa faixa etária o petista alcança 21%, contra 19% de Eduardo e 16% de Mendonça. </FONT></P></p>
<p><P><FONT face=Verdana>----------------------------------</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Mendoça é o preferido pelo eleitorado masculino</STRONG> </FONT></P></p>
<p><P><FONT face=Verdana>Quando se observa os números por sexo, Humberto apresentou seu maior ?ndice entre o eleitorado feminino, enquanto Mendonça e Eduardo somam mais entre o eleitorado masculino. </FONT></P></p>
<p><P><FONT face=Verdana>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Masculino&nbsp;&nbsp;&nbsp;&nbsp; Feminino </FONT></P></p>
<p><P><FONT face=Verdana>Mendonça&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 37%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 29% </FONT></P></p>
<p><P><FONT face=Verdana>Humberto&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 23%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 25% </FONT></P></p>
<p><P><FONT face=Verdana>Eduardo&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 14%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 13% </FONT></P></p>
<p><P><FONT face=Verdana>----------------------------------</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Eduardo é está melhor entre os mais velhos</STRONG> </FONT></P></p>
<p><P><FONT face=Verdana>Os eleitorados de Mendonça e Humberto coincidem ao menos na classificação por idade. Ambos apresentam os melhores ?ndices entre os jovens de 16 a 24 anos. </FONT></P></p>
<p><P><FONT face=Verdana>E é justamente nessa faixa etária que Eduardo tem o seu menor ?ndice. Veja abaixo os resultados em cinco faixas (16 a 24 anos; 25 a 29 anos; 30 a 39; 40 a 49; e 50 anos ou mais):</FONT></P></p>
<p><P><FONT face=Verdana>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>16/24</STRONG>&nbsp;&nbsp; 25/29&nbsp;&nbsp;&nbsp; <STRONG>30/39</STRONG>&nbsp;&nbsp; 40/49&nbsp;&nbsp; <STRONG>50/mais</STRONG> </FONT></P></p>
<p><P><FONT face=Verdana>Mendonça&nbsp;&nbsp;&nbsp;&nbsp; 35%&nbsp;&nbsp;&nbsp;&nbsp; 33%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 31%&nbsp;&nbsp;&nbsp;&nbsp; 29%&nbsp;&nbsp;&nbsp;&nbsp; 33% </FONT></P></p>
<p><P><FONT face=Verdana>Humberto&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 30%&nbsp;&nbsp;&nbsp;&nbsp; 25%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 22%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;27%&nbsp;&nbsp;&nbsp;&nbsp; 17% </FONT></P></p>
<p><P><FONT face=Verdana>Eduardo&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 10%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;11%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 17%&nbsp;&nbsp;&nbsp;&nbsp; 15%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;15% </FONT></P></p>
<p><P><FONT face=Verdana>----------------------------------</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Por escolaridade</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Mendonça está melhor entre eleitores que cursaram da 5ª à 8ª série do ensino fundamental,</p>
<p> Humberto entre eleitores do ensino médio e Eduardo, do ensino superior. </FONT></P></p>
<p><P><FONT face=Verdana>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<STRONG>Até 4ª série</STRONG>&nbsp;&nbsp;5ª&nbsp;à 8ª&nbsp; <STRONG>Médio</STRONG>&nbsp;&nbsp;Superior</FONT></P></p>
<p><P><FONT face=Verdana>Mendonça&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 29%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 35%&nbsp;&nbsp;&nbsp;&nbsp; 34%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 34%</FONT></P></p>
<p><P><FONT face=Verdana>Humberto&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 19%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 26%&nbsp;&nbsp;&nbsp;&nbsp; 28%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;27% </FONT></P></p>
<p><P><FONT face=Verdana>Eduardo&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 16%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;11%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;12%&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 17%</FONT></P></p>
<p><P><FONT face=Verdana>Leia mais <STRONG><EM><A href=\"https://jc3.uol.com.br/blogs/jc/2006/08/01/index.php#430\" target=_blank>aqui</A></EM></STRONG> sobre a pesquisa</FONT></P> </p>
