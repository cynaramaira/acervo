---
id: 12372170
data_publicacao: "2006-07-24 16:39:00"
data_alteracao: "None"
materia_tags: "Oposição"
categoria: "Notícias"
titulo: "Nóbrega explica posição sobre disputa na OAB"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Izael Nóbrega, advogado do PSB, ficou preocupado com nota postada aqui na sexta-feira (<B><A href=\"https://jc3.uol.com.br/blogs/jc/2006/07/21/index.php#172\">leia a nota</A></B>), mostrando como os consultores jur?dicos dos principais candidatos a governador de Pernambuco se posicionam em relação à disputa pela presidência da Ordem dos Advogados do Brasil no Estado.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2>Nóbrega diz que não há posição fechada do Jur?dico do PSB. Há apenas decisões isoladas e individuais de seus advogados em relação a Júlio Oliveira, que disputa reeleição no comando da OAB, e Jaime Asfora, candidato de oposição.</FONT></SPAN> </p>
