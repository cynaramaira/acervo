---
id: 12372360
data_publicacao: "2006-07-15 11:45:00"
data_alteracao: "None"
materia_tags: "andré rio,Paula Braun,Saturno"
categoria: "Notícias"
titulo: "André de Paula fala em 1º turno"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Deputado federal, presidente estadual do PFL e um dos principais articuladores da candidatura de Mendonça, André de Paula considerou extremamente positivos os resultados da JC/Vox Populi. De Feira Nova, no Agreste, onde acompanha o governador em campanha, acaba de falar para o blog por telefone.</P></p>
<p><P>Cauteloso, diz que todo o comando da campanha trabalha para uma eleição em dois turnos. Porém, avalia que começaram a surgir os primeiros sinais de que a disputa “possa eventualmente se resolver no primeiro???.</P></p>
<p><P>Ele lembra que Jarbas, principal pilar da aliança, ainda não entrou na campanha. Isso só acontecerá efetivamente a partir do final de julho. Portanto, é importante que Mendonça tenha apresentado até agora um crescimento consistente e em bases sólidas.<BR></P> </p>
