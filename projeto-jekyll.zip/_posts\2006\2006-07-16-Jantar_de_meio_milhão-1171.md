---
id: 12372344
data_publicacao: "2006-07-16 09:44:00"
data_alteracao: "None"
materia_tags: "jantar,meio ambien"
categoria: "Notícias"
titulo: "Jantar de meio milhão"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Com R$ 19 milhões de gastos previstos, a União por Pernambuco já arrecadou mais de meio milhão de reais com o jantar de adesão que promove na segunda-feira à noite, no Recife, para cobrir as despesas das campanhas de Mendonça Filho, à reeleição, e de Jarbas Vasconcelos, ao Senado. Será um jantar com hora marcada, das 19h às 23h, pontualmente. Cada conviva está desenbolsando R$ 1 mil para ouvir os discursos dos dois - apenas dos dois - e se debruçar sobre um pato ao cravo e canela com medalhães de filé, pene com frutos do mar, arroz com castanha e salada de folhas e legumes. Tem direito também a cheese cake com calda de amora na sobremesa. Nada a ver com os R$ 200 que a elite mestiça gastou para comer frango com polenta no jantar de Lula, em São Bernardo do Campo (SP), na última quinta.</P> </p>
