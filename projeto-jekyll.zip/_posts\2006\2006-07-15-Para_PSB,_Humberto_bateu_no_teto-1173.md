---
id: 12372346
data_publicacao: "2006-07-15 19:24:00"
data_alteracao: "None"
materia_tags: "Humberto Costa,Pará"
categoria: "Notícias"
titulo: "Para PSB, Humberto bateu no teto"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>O PSB temia que a adesão de Armando Monteiro Neto desse impulso maior à candidatura de Humberto Costa, revelou agora o presidente estadual do partido, Milton Coelho, em conversa com Cec?lia Ramos, repórter do blog. Aliviado, Minton diz que os números da JC/Vox Populi são positivos para Eduardo Campos. \"Essa pesquisa já computa o apoio dos trabalhistas e a gente vê que alterou pouca coisa. A alavanca de Lula também está computada. Então Humberto não tem mais fatores para crescer, ao contrário de Eduardo\", avaliou Milton.</P> </p>
