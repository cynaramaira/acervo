---
id: 12372205
data_publicacao: "2006-07-22 20:53:00"
data_alteracao: "None"
materia_tags: "Humberto Costa,imprensa"
categoria: "Notícias"
titulo: "Humberto, indignado, promete processar a imprensa"
sutia: "None"
chapeu: "None"
autor: "jamildo"
imagem: "None"
---
<p>&nbsp;</p>
<p>Humberto est&aacute; indignado com o envolvimento do nome dele na CPI das Sanguessugas. Disse que vai processar a imprensa nacional e quem mais o apontar como respos&aacute;vel por desvios de recursos p&uacute;blicos na compra de ambul&acirc;ncias.</p>
<p>Logo ap&oacute;s a entrevista de Lula, disse aos jornalistas que n&atilde;o h&aacute; nada provado contra ele nem contra seu ex-chefe de gabinete, Ant&ocirc;nio Alves de Souza. Condenou o que chamou de "insinua&ccedil;&otilde;es maldosas com ares de verdade". "Processarei quem quer que me acuse."</p>
