---
id: 12372140
data_publicacao: "2006-07-25 10:56:00"
data_alteracao: "None"
materia_tags: "eduardo"
categoria: "Notícias"
titulo: "Eduardo reedita com?cio-relâmpago"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do Jornal do Commercio</FONT></P></p>
<p><P><FONT face=Verdana>O principal evento do candidato a governador pelo PSB, Eduardo Campos, hoje à tarde, a Tribuna 40, pode não atrair um número tão grande de pessoas, mas, certamente, chamará atenção de quem costuma passar pelo Centro do Recife. Diante das restrições impostas pela minirreforma eleitoral, que mudou as regras da propaganda pol?tica, os coordenadores da campanha da coligação Frente Popular de Pernambuco decidiram voltar no tempo, ressuscitando o antigo modelo do com?cio-relâmpago, realizado no meio da rua e sem a utilização de palanque. Com a ajuda de um banquinho e de um alto-falante, que será colocado em uma bicicleta, o ex-ministro da Ciência e Tecnologia discutirá os problemas enfrentados pela cidade e seus moradores.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></STRONG> matéria completa (assinantes JC e Uol).</FONT></P> </p>
