---
id: 12372212
data_publicacao: "2006-07-22 20:49:00"
data_alteracao: "None"
materia_tags: "Lula"
categoria: "Notícias"
titulo: "Lula defende petistas envolvidos com sanguessugas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Lula estava uma simpatia na entrevista coletiva, há pouco, revela Cec?lia Ramos, repórter do <B>Blog</B>. Berzoini foi quem o tirou para ir embora.</FONT></P></p>
<p><P><FONT face=Verdana>Lula condenou o envolvimento de petistas na CPI das Sanguessugas. Disse que não achava justo falarem sem provas, sem nada concreto. Garantiu que tudo o que está surgindo de denúncia na CPI é fruto de investigações iniciadas pelo próprio governo.</FONT></P></p>
<p><P><FONT face=Verdana>Ele não citou Humberto Costa diretamente. Mas ressaltou que durante a campanha há sempre um clima de denuncismo, que faz questão de condenar.</FONT></P></FONT> </p>
