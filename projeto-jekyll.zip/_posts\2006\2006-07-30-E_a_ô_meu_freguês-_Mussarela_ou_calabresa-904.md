---
id: 12372077
data_publicacao: "2006-07-30 11:06:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "E a? ô meu freguês:/Mussarela ou calabresa?"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por </FONT><STRONG><FONT face=Verdana>Allan Sales<BR></FONT></STRONG><A href=\"mailto:allancariri@ig.com.br\"><FONT face=Verdana>allancariri@ig.com.br</FONT></A></P></p>
<p><P><BR><FONT face=Verdana>(1)<BR><BR>Descobriram a mutreta<BR>Mas puseram vaselina<BR>Será esta nossa sina?<BR>Deputados de veneta<BR>Caixa dois e a mala preta<BR>E muita da safadeza<BR>Canalhice e esperteza<BR>Quando será nossa vez<BR>E a? ô meu freguês:<BR>Mussarela ou calabresa?</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Leia texto completo na coluna ao lado, na seção artigos.</STRONG></FONT></P> </p>
