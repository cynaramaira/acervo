---
id: 12372056
data_publicacao: "2006-07-29 18:05:00"
data_alteracao: "None"
materia_tags: "Lula"
categoria: "Notícias"
titulo: "Lula quer distância de petistas problemáticos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><SPAN class=texto><FONT face=Verdana><SPAN class=subtitulo>Do <STRONG>Radar</STRONG><BR>(revista Veja)</SPAN></FONT></SPAN></P></p>
<p><P><SPAN class=texto><FONT face=Verdana>Após passar por constrangimento em Pernambuco ao lado do ex-ministro Humberto Costa, acusado de envolvimento com os sanguessugas, Lula pretende livrar seu palanque de pol?ticos metidos em escândalos. </FONT></SPAN></P></p>
<p><P><SPAN class=texto><FONT face=Verdana>O presidente já avisou a Aloizio Mercadante, candidato do PT ao governo de São Paulo, que não quer a companhia dos mensaleiros João Paulo Cunha, Professor Luizinho e José Mentor. Até que enfim.</FONT></SPAN></P></p>
<p><P><SPAN class=texto><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.uol.com.br/veja\" target=_blank>aqui</A></EM></STRONG> a coluna completa (assinantes).</FONT></SPAN></P> </p>
