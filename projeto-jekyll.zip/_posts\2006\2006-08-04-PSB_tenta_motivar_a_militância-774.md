---
id: 12371947
data_publicacao: "2006-08-04 07:30:00"
data_alteracao: "None"
materia_tags: "atentado"
categoria: "Notícias"
titulo: "PSB tenta motivar a militância"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=Arial></p>
<p><P><FONT face=Verdana>Por <STRONG>Sheila Borges</STRONG><BR>Repórter de Pol?tica do JC</FONT></P></p>
<p><P><FONT face=Verdana>Para mostrar que a polêmica gerada em torno da pesquisa Ibope/Rede Globo não desmobilizou a militância, os coordenadores da campanha do candidato a governador pela Frente Popular, deputado federal Eduardo Campos (PSB), promoveram, ontem pela manhã, uma das caminhadas mais animadas desta eleição pelas ruas de Prazeres e Cajueiro Seco, em Jaboatão dos Guararapes. </FONT></P></p>
<p><P><FONT face=Verdana>O instituto registrou que Eduardo está na terceira posição com 14% das intenções de voto, atrás do governador-candidato Mendonça Filho (PFL) e do candidato do PT, Humberto Costa. </FONT></P></p>
<p><P><FONT face=Verdana>Durante duas horas, o socialista percorreu quatro quilômetros, metade deles ao lado do prefeito do munic?pio, Newton Carneiro (PSB). Para animar os correligionários, três carros de som tocavam os jingles das campanhas de Eduardo e da filha de Newton, Elina Carneiro (PSB), candidata a deputada estadual. Uma parte desta militância foi arregimentada dentro da própria prefeitura, especialmente no quadro funcional da Empresa de Desenvolvimento de Jaboatão (Emdeja), órgão dirigido por Terc?lia Vila Nova, que é filiada ao PSB.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://jc3.uol.com.br/jornal/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinates JC e UOL).</FONT></P></FONT> </p>
