---
id: 12372367
data_publicacao: "2006-07-15 08:58:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Nunca fui um esquerdista"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p>Luiz Inácio Lula da Silva, presidente </p>
