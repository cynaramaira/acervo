---
id: 12372154
data_publicacao: "2006-07-25 10:49:00"
data_alteracao: "None"
materia_tags: "Serrana"
categoria: "Notícias"
titulo: "Berzoini diz que Serra tem sido poupado"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do Jornal do Commercio</FONT></P></p>
<p><P><FONT face=Verdana>BRAS??LIA – O presidente do PT, deputado Ricardo Berzoini (SP), afirmou ontem que o candidato do PSDB ao governo paulista e ex-ministro da Saúde, José Serra, está sendo “poupado??? no caso da máfia dos sanguessugas, enquanto o também ex-ministro da Saúde Humberto Costa (PT) – candidato a governador em Pernambuco – recebe tratamento “extremamente duro???. </FONT></P></p>
<p><P><FONT face=Verdana>Berzoini disse que “tem candidato com nariz crescendo??? ao acusar petistas como Humberto de envolvimento na quadrilha que fraudou a compra das ambulâncias. Foi uma referência indireta ao presidenciável tucano Geraldo Alckmin, principal adversário de Lula. “Essa preparação começou no governo FHC, quando Serra era ministro da Saúde. É impressionante o tratamento diferenciado que a imprensa dá ao caso???, disse Berzoini.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><U><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></U></STRONG> matéria completa (assinantes JC e Uol).</FONT></P> </p>
