---
id: 12372187
data_publicacao: "2006-07-24 11:23:00"
data_alteracao: "None"
materia_tags: "Altas Horas,combate"
categoria: "Notícias"
titulo: "Hora de cobrar combate à violência"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>O eleitor pernambucano terá uma oportunidade importante para pressionar e exigir dos candidatos ao governo de Pernambuco um plano de combate à criminalidade no Estado, um dos mais violentos do pa?s.</FONT></P></p>
<p><P><FONT face=Verdana>&nbsp;A partir do próximo dia 14, o Instituto Antônio Carlos Escobar (IACE) promoverá uma série de debates sobre segurança pública com os candidatos.</FONT></P></p>
<p><P><FONT face=Verdana>Não serão debates entre eles. Mas individuais e com o público. O primeiro marcado é com Humberto Costa, ex-ministro da Saúde e candidato pelo PT. </FONT></P></p>
<p><P><FONT face=Verdana>Ele estará no auditório do bloco G da Universidade Católica, no Recife, à disposição dos interessados no tema. Os debates terão entrada franca, começam às 19h.</FONT></P></p>
<p><P><FONT face=Verdana>O segundo confirmado até agora é Eduardo Campos, ex-ministro da Ciência e Tecnologia e candidato pelo PSB. Será dia 18. Os outros sete candidatos já foram contactados pelo IACE e negociam uma data para participar.</FONT></P></p>
<p><P><FONT face=Verdana>O IACE surgiu há sete meses, depois que o psiquiatra Antônio Carlos Escobar foi brutalmente assassinado, às seis da tarde, em um semáforo, na Domingos Ferreira, zona sul do Recife. Tentava ajudar uma pessoa que era assaltada diante dele.</FONT></P></p>
<p><P><FONT</p>
<p> face=Verdana>O instituto tenta politizar um tema que deve cada dia mais ser politizado. O governo Jarbas Vasconcelos/Mendonça Filho fracassou no combate à violência e precisa urgentemente apresentar o plano convincente para um novo governo. </FONT></P></p>
<p><P><FONT face=Verdana>Os demais candidatos, principalmente Eduardo Campos e Humberto Costa, ainda não apresentaram nada consistente para essa área.</FONT></P></FONT> </p>
