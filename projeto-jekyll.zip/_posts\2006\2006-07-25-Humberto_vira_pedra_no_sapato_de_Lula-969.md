---
id: 12372142
data_publicacao: "2006-07-25 12:16:00"
data_alteracao: "None"
materia_tags: "Humberto Costa,Lula,pedra"
categoria: "Notícias"
titulo: "Humberto vira pedra no sapato de Lula"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do </FONT><A href=\"https://noblat1.estadao.com.br/noblat/index.html\"><STRONG><FONT face=Verdana>blog</FONT></STRONG></A><FONT face=Verdana> de Noblat</FONT></P></p>
<p><P><FONT face=Verdana>A essa altura do campeonato, tudo de que Lula não precisava era de mais uma história cabeluda protagonizada por um auxiliar ou ex-auxiliar dele - muito menos alguém do Nordeste, região que por ora sustenta a dianteira de Lula nas pesquisas eleitorais.</FONT></P></p>
<p><P><FONT face=Verdana>Ex-ministro da Saúde, Humberto Costa, candidato do PT ao governo de Pernambuco, virou sem querer uma pedra no sapato de Lula. E a ordem dada pelo alto comando da campanha de Alckmin é uma só: bater o máximo em Humberto.</FONT></P></p>
<p><P><FONT face=Verdana>O empresário Luiz Antonio Trevisan Vedoin, apontado pela Pol?cia Federal como chefe da máfia dos sanguessugas, disse que Humberto&nbsp;o ajudou liberando verbas do Ministério da Saúde via&nbsp;&nbsp;José Airton Cirilo, membro da Executiva Nacional do PT.</FONT></P></p>
<p><P><FONT face=Verdana>Humberto nega e promete processar quem repercutir a confissão de Vedoin. Cirilo confirma que se reuniu com Vedoin algumas vezes, mas também nega que o tenha ajudado a liberar verbas no ministério. E que tenha cobrado comissão em troca do serviço.</FONT></P></p>
<p><P><FONT face=Verdana>Lula confia na indoneidade de Humberto. Mas sabe que uma assessora dele no ministério sacou grana&nbsp;do mensalão de conta de Marcos Valério. E sabe que Vedoin citou mais quatro assessores de Humberto como envolvidos com os sanguessugas.&nbsp;</FONT></P></p>
<p><P><FONT face=Verdana>Se tudo isso é péssimo para a campanha de Humberto em Pernambuco,</p>
<p> é ruim para a de Lula no Nordeste ou fora dali. Mas ele tem pouco a fazer a essa altura - salvo evitar aparecer na companhia do seu ex-ministro.</FONT></P> </p>
