---
id: 12371958
data_publicacao: "2006-08-03 17:51:00"
data_alteracao: "None"
materia_tags: "Elcio Franco,geraldo Alckmin,Itamaraty"
categoria: "Notícias"
titulo: "Itamar Franco vem acompanhar Alckmin"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>O ex-presidente, ex-embaixador e, no momento, desafeto de Lula, estará integrado à comitiva de Geraldo Alckmin, na visita que o tucano faz nesta sexta&nbsp;ao Recife.</P> </p>
