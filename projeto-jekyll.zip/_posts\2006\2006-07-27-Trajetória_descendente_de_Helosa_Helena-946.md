---
id: 12372119
data_publicacao: "2006-07-27 15:57:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Trajetória descendente de Helo?sa Helena"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG><U><A href=\"https://uolpolitica.blog.uol.com.br/\">blog</A></U> de Fernando Rodrigues</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Ainda é cedo para afirmar, faltam mais de 2 meses para a eleição etc. Feitas as ressalvas, há um sinal detectado na pesquisa Ibope que não foi totalmente divulgado. No primeiro dia de entrevistas, 22 de julho (sábado), o instituto captava até 11% para a candidata do PSOL. Quando o trabalho de campo acabou, dia 24 de julho (segunda-feira), o percentual já estava em apenas 8%.</FONT></P></p>
<p><P><FONT face=Verdana>O que isso quer dizer? Por enquanto, que Helo?sa Helena não surfou na boa onda dos seus 10% anunciados pelo Datafolha, no dia 19 de julho. Em tese, um candidato embalado vai alavancando uma pesquisa na outra. Não foi o que ocorreu com a candidata do PSOL, terceira colocada na corrida presidencial.</FONT></P></p>
<p><P><FONT face=Verdana>Dá para dizer que existe uma tendência definida? Não, não dá. É necessário esperar novos levantamentos. Por enquanto, é só um fato a ser registrado.</FONT></P></p>
<p><P><FONT face=Verdana>Fato, aliás, de relevância extrema. Até o momento, Helo?sa Helena parece ser a única pessoa capaz de ter algum desempenho positivo fora do pelotão dos nanicos. Se ela realmente não acontecer –estacionando ou até caindo– o cenário eleitoral fica mais para 1º do que para 2º turno.</FONT></P></p>
<p><P><FONT face=Verdana>Não é à toa que o PT, Lula e cia. não querem hostilizar Helo?sa Helena. Acham que parte considerável dos votantes na senadora alagoana pode ser recomposta dentro do ninho petista.</FONT></P></p>
<p><P><FONT face=Verdana>Desnecessário dizer, essa poss?vel flopada de HH é uma péssima not?cia para Geraldo Alckmin (PSDB).</FONT></P> </p>
