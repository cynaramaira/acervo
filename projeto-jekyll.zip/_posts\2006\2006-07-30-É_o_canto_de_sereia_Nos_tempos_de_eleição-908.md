---
id: 12372081
data_publicacao: "2006-07-30 11:08:00"
data_alteracao: "None"
materia_tags: "cantor,eleição"
categoria: "Notícias"
titulo: "É o canto de sereia/Nos tempos de eleição"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Allan Sales</STRONG><BR></FONT><A href=\"mailto:allancariri@ig.com.br\"><FONT face=Verdana>allancariri@ig.com.br</FONT></A></P></p>
<p><P align=justify><FONT face=Verdana></FONT></P></p>
<p><P align=justify><FONT face=Verdana>(1)<BR><BR>Meu cidadão brasileiro<BR>Amigo e trabalhador<BR>Você que é eleitor<BR>Batalhador e ordeiro<BR>Querem fazê-lo cordeiro<BR>Turvar a sua visão<BR>Fazer manipulação<BR>Do voto que coisa feia<BR>É o canto de sereia<BR>Nos tempos de eleição</FONT></P></p>
<p><P align=justify><FONT face=Verdana><STRONG>Leia texto completo na coluna ao lado, na seção artigos.</STRONG></FONT></P> </p>
