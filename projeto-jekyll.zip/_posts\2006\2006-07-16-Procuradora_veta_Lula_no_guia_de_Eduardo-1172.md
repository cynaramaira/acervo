---
id: 12372345
data_publicacao: "2006-07-16 09:10:00"
data_alteracao: "None"
materia_tags: "eduardo,Lula"
categoria: "Notícias"
titulo: "Procuradora veta Lula no guia de Eduardo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Eduardo Campos terá um problemão com a procuradora eleitoral auxiliar Maria do Socorro Paiva. Ela diz que o socialista não pode, de maneira alguma, utilizar imagens do presidente Lula no guia. \"Contra a lei não há acordo\", avisou Paiva, em conversa com Clóvis Andrade, repórter de pol?tica do Jornal do Commercio. \"Está terminantemente proibida a aparição de Lula ao lado de um candidato que não é da sua coligação\", explicou, citando a Lei 9.504/97. </P></p>
<p><P>Estão proibidas até as imagens de Eduardo ao lado de Lula na época em que o socialista era ministro da Ciência e Tecnologia. \"Pode o PT ou o próprio presidente Lula concordar, não adianta\", garante a procuradora. O PSB discorda mesmo e os marqueteiros de Eduardo, Edson Barbosa e Raimundo Luedy, asseguram que Lula vai estar no guia.</P></p>
<p><P>Sem Lula na TV, a candidatura de Eduardo ao governo de Pernambuco perde ainda mais substância pol?tica. Ele já enfrenta hoje as dificuldades de um palanque fraco, caseiro, montado de última hora, com uma chapa composta</p>
<p> por l?deres apenas de Caruaru (Jorge Gomes no Senado e João Lyra na vice).</P> </p>
