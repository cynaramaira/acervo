---
id: 12371918
data_publicacao: "2006-08-06 08:50:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Improviso e criatividade nas campanhas dos nanicos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Arthur Cunha</STRONG><BR>Repórter de Pol?tica do JC</FONT></P></p>
<p><P><FONT face=Verdana>Com pouco dinheiro e muito improviso. Foi assim que os candidatos ao governo de Pernambuco pelas pequenas siglas conseguiram, com muito esforço, montar seus os seus comitês de campanha. </FONT></P></p>
<p><P><FONT face=Verdana>Ao contrário dos \"grandes\" - Mendonça Filho (PFL), Humberto Costa (PT) e Eduardo Campos (PSB), que montaram verdadeiros quartéis-generais para abrigar as suas campanhas, os pequenos tiveram que apelar para doação e arrecadação conjunta de fundos.</FONT></P></p>
<p><P><FONT face=Verdana>Teve candidato que montou comitê na garagem de um amigo. Já outro postulante, em vez de tinta, decorou seu \"quartel-general\" com grafitagem. Na falta de um comitê real, um candidato lançou mão de um \"virtual\". </FONT></P></p>
<p><P><FONT face=Verdana>Outro, não tão vanguardista e sem recursos, resolveu recorrer a um patroc?nio inédito: fazendo a linha \"filhinho de papai\", ligando para a mãe no intuito de pedir dinheiro para a sua campanha.</FONT></P></p>
<p><P><FONT face=Verdana>Leia o <STRONG><EM><A href=\"https://jc3.uol.com.br/jornal/\" target=_blank>texto</A></EM></STRONG> completo em Pol?tica, no JC (assinantes JC e UOL).</FONT></P> </p>
