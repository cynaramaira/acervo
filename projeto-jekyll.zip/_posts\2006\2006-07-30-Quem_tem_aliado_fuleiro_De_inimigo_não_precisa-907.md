---
id: 12372080
data_publicacao: "2006-07-30 11:07:00"
data_alteracao: "None"
materia_tags: "esquema criminoso,Naomi Campbell"
categoria: "Notícias"
titulo: "Quem tem aliado fuleiro/De inimigo não precisa"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Allan Sales</STRONG><BR></FONT><FONT face=Verdana><A href=\"mailto:allancariri@ig.com.br\"><FONT face=Verdana>allancariri@ig.com.br</FONT></A></FONT></P><FONT face=Verdana></p>
<p><P><BR>(1)<BR></FONT><FONT face=Verdana><BR>Coitado do presidente<BR></FONT><FONT face=Verdana>Com Dirceu e o mensalão<BR></FONT><FONT face=Verdana>Mas com Bruno Maranhão<BR></FONT><FONT face=Verdana>A coisa ficou mais quente<BR></FONT><FONT face=Verdana>Que coisa inconseqüente<BR></FONT><FONT face=Verdana>Que pra fazer não avisa<BR></FONT><FONT face=Verdana>Só mesmo dando um pisa<BR></FONT><FONT face=Verdana>No lombo do companheiro<BR></FONT><FONT face=Verdana>Quem tem aliado fuleiro<BR></FONT><FONT face=Verdana>De inimigo não precisa</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Leia texto completo na coluna ao lado, na seção artigos.</STRONG></FONT></P> </p>
