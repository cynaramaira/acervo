---
id: 12372060
data_publicacao: "2006-07-29 14:27:00"
data_alteracao: "None"
materia_tags: "mendonça,Naomi Campbell,Petrobras,Renovação"
categoria: "Notícias"
titulo: "Petrobras não renova contrado da Duda Mendonça"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=texto><FONT face=Verdana>Do&nbsp;<STRONG>Radar</STRONG><BR>(revista Veja)</FONT></P></p>
<p><P class=texto><FONT face=Verdana>A diretoria da Petrobras já decidiu abrir licitação para a volumosa conta de publicidade da estatal. Coisa de 190 milhões de reais por ano. </FONT></P></p>
<p><P class=texto><FONT face=Verdana>O edital deve sair na próxima semana. Os contratos atuais vencem em dezembro. Desde o in?cio da era Lula, a agência de Duda Mendonça é uma das três que dividem esse butim milionário. </FONT></P></p>
<p><P class=texto><FONT face=Verdana>Na última renovação, no ano passado, Duda, já flagrado com dinheiro ilegal no exterior pago pelo PT, sapateou, ameaçou e ficou na estatal. </FONT></P></p>
<p><P class=texto><FONT face=Verdana>Agora, voltou a conversar com o governo sobre o contrato. Será que seu silêncio ainda vale ouro?</FONT></P></p>
<p><P class=texto><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.uol.com.br/veja\">aqui</A></EM></STRONG> a coluna completa (assinantes).</FONT></P> </p>
