---
id: 12372311
data_publicacao: "2006-07-17 15:39:00"
data_alteracao: "None"
materia_tags: "voos suspensos"
categoria: "Notícias"
titulo: "Comentários suspensos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Como vocês já notaram, decidimos suspender&nbsp;o recebimento de comentários por conta dos exageros cometidos por alguns leitores. O blog não é&nbsp;terra de ninguém. Também somos obrigados a responder legalmente pelo conteúdo aqui postado.</P></p>
<p><P>Por isso, seguindo o exemplo de outros blogs, como o de Noblat, resolvemos implantar o cadastramento dos remetentes.</P></p>
<p><P>Breve voltaremos a disponibilizar o espaço para comentários.</P> </p>
