---
id: 12372089
data_publicacao: "2006-07-29 10:00:00"
data_alteracao: "None"
materia_tags: "geraldo Alckmin,nordeste"
categoria: "Notícias"
titulo: "Aliados de Alckmin estão inibidos no Nordeste"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do ex-blog de <STRONG>Cesar Maia<BR></STRONG>(prefeito do Rio, PFL)</FONT></P></p>
<p><P><FONT face=Verdana>A vantagem de Lula no nordeste tem muita, muita gordura. Só que ela inibe seus adversários e candidatos a governador e deputados a pedir voto para o Alckmin. Com isso a gordura cristaliza e se necessita de mais temperatura para derretê-la.</FONT></P></p>
<p><P><FONT face=Verdana>Se os candidatos da coligação de Alckmin perderem a inibição, esta gordura começa a derreter. Claro, se perderem a inibição. Ceará é a terra onde Tasso Jereissati -presidente do PSDB- é o pol?tico mais popular e mais importante. </FONT></P></p>
<p><P><FONT face=Verdana>Ninguém pede -necessariamente- que venha uma reversão total, mas a diferença cair de 56% para 20%, é meta facilmente ating?vel.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Comentário meu:</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>(Reproduzo aqui um texto que escrevi na coluna Cena Pol?tica, do JC, um mês atrás, para vocês terem um idéia do que está acontecendo com os aliados de Alckmin):</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Aparências, nada mais</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Wagner Peixoto é um garoto inteligente. Aos 20 anos, sabe melhor do que ninguém como explicar porque Jarbas e Mendonça Filho darão um apoio de conveniência e burocrático a Geraldo Alckmin. Nascido em Caruaru, passou infância e adolescência em Belo Jardim, terra de Mendonça. </FONT></P></p>
<p><P><FONT face=Verdana>O garoto milita no PFL e criou a primeira comunidade no Orkut em favor de um candidato ao governo de Pernambuco. Chama-se Eu voto Mendonça Filho 2006. Pois bem, Wagner diz que Jarbas e o governador \"irão pedir votos para Alckmin, mas respeitando nossos eleitores que votam em outro\". É a senha para a falta de empenho: \"Alckmin tem 10% das intenções de votos. Mendonça está na casa dos 35%. Há muitos eleitores de MF que não votam no nosso presidenciável. Por outro lado, há eleitores de Alckmin que não estão conosco, como seguidores de Sérgio Guerra\". Vincular campanhas, acrescenta, só as de Mendonça e Jarbas. </FONT></P></p>
<p><P><FONT face=Verdana>Os sinais de que Alckmin está frito em Pernambuco são abundantes. Ele foi esquecido no último programa do PFL na TV. Quinta-feira nem foi recebido no aeroporto. É certo que esteve com Jarbas no Recife e em Caruaru, mas porque forçou a barra. Jarbas não mudou um mil?metro a agenda dele. No Alto do Moura, ainda deu de presente a Alckmin uma fam?lia de retirantes do mestre Eudócio. Peça cara, R$ 500, para o paulista não esquecer mesmo de Lula, mais amigo que adversário de Jarbas.</FONT></P> </p>
