---
id: 12372289
data_publicacao: "2006-07-19 02:50:00"
data_alteracao: "None"
materia_tags: "governo,mendonça"
categoria: "Notícias"
titulo: "Mendonça é menor que o governo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Novos números da pesquisa JC/Vox Populi, publicados hoje no Jornal do Commercio, mostram que Mendonça Filho tem ?ndices de intenção de voto semelhantes, porém inferiores, aos de avaliação do desempenho de seu governo. </P></p>
<p><P>Como candidato, ele conta com 35% das intenções de voto dos pernambucanos. Como governo, 39% de aprovação.</P></p>
<p><P>Os números, apresentados por Sérgio Montenegro Filho, repórter especial do JC, mostram que o governo Mendonça é classificado como uma ótima gestão por 6% dos pernambucanos. Outros 33% o consideram bom. Da? os 39% de aprovação.</P></p>
<p><P>Para 46%, quase metade da população, no entanto, a gestão é apenas regular. </P></p>
<p><P>Veja os números completos no site do <B><A href=\"https://jc3.uol.com.br/especiais/eleicoes2006/\" target=_blank>JC&nbsp;Eleições 2006</A></B>.</P></p>
<p><P>Mas o importante a destacar na pesquisa é que o tempo entre a posse de Mendonça e a eleição é extremamente curto. Tem que ser muito bem aproveitado pela União por Pernambuco para que ele, como candidato, possa se apropriar da popularidade do governo, constru?da pela dupla Jarbas Vasconcelos/Antônio Lavareda.</P></p>
<p><P>O que Mendonça conseguiu até agora é positivo, mas muito aquém do que poderia ter.</P></p>
<p><P>Jarbas deixou o governo, em abril, com 61% de ótimo e bom. Mais ou menos o mesmo percentual que tem hoje como candidato, 66%. Com uma diferença impressionante em relação a Mendonça: Jarbas é 5 pontos percentuais maior que o governo dele. Mendonça candidato está 26 pontos abaixo do que a administração era antes dele.</P></FONT> </p>
