---
id: 12372083
data_publicacao: "2006-07-30 09:29:00"
data_alteracao: "None"
materia_tags: "cantor,Colégio Salesiano,eleição"
categoria: "Colunistas"
titulo: "É o canto de sereia/Nos tempos de eleição / Allan Sales"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Allan Sales</STRONG><BR></FONT><A href=\"mailto:allancariri@ig.com.br\"><FONT face=Verdana>allancariri@ig.com.br</FONT></A></P></p>
<p><P align=justify><FONT face=Verdana></FONT></P></p>
<p><P align=justify><FONT face=Verdana>(1)<BR><BR>Meu cidadão brasileiro<BR>Amigo e trabalhador<BR>Você que é eleitor<BR>Batalhador e ordeiro<BR>Querem fazê-lo cordeiro<BR>Turvar a sua visão<BR>Fazer manipulação<BR>Do voto que coisa feia<BR>É o canto de sereia<BR>Nos tempos de eleição</FONT></P></p>
<p><P align=justify><FONT face=Verdana></FONT></P></p>
<p><P align=justify><FONT face=Verdana>(2)</FONT></P></p>
<p><P align=justify><FONT face=Verdana>Conversa pra boi dormir<BR>Falou o poeta Xico<BR>Quem defende só o rico<BR>Tem precisão de iludir<BR>Pra o rebanho conduzir<BR>No fim lesar a nação<BR>Com tanta corrupção<BR>Que a nossa raiva incendeia<BR>É o canto de sereia<BR>Nos tempos de eleição</FONT></P></p>
<p><P align=justify><FONT face=Verdana></FONT></P></p>
<p><P align=justify><FONT face=Verdana>(3)<BR><BR>Por isso muito cuidado<BR>Veja quem está por trás<BR>Quem financia o rapaz<BR>Quem manda nesse danado<BR>Se merece ser votado<BR>Qual sua real missão<BR>Liberdade ou opressão<BR>Só a verdade clareia<BR>É o canto de sereia<BR>Nos tempos de eleição</FONT></P></p>
<p><P align=justify><FONT face=Verdana></FONT></P></p>
<p><P align=justify><FONT face=Verdana>(4)<BR><BR>Dão tijolo e camiseta<BR>E uma nova dentadura<BR>Compram voto que tronchura<BR>Tome curral e mutreta<BR>Querem mamar é na teta<BR>Nepotismo e armação<BR>É só isso o que farão<BR>Sem ter medo da cadeia<BR>É o canto de sereia<BR>Nos tempos de eleição</FONT></P></p>
<p><P align=justify><FONT face=Verdana></FONT></P></p>
<p><P align=justify><FONT face=Verdana>(5)<BR><BR>Usa o poder do dinheiro<BR>Pra consciências comprar<BR>Pra o voto manipular<BR>Assim age o embusteiro<BR>Candidato quadrilheiro<BR>Existe assim de montão<BR>Marqueteiro de plantão<BR>Este canalha falseia<BR>É o canto de sereia<BR>Nos tempos de eleição</FONT></P></p>
<p><P align=justify><FONT face=Verdana></FONT></P></p>
<p><P align=justify><FONT face=Verdana>(6)<BR><BR>Quer barrar todo avanço<BR>Destas lutas sociais<BR>Clientelistas demais<BR>Que não disfarçam este ranço<BR>De falar eu não me canso<BR>Desmascarar falastrão<BR>Mente na televisão<BR>Neste calhorda não creia<BR>É o canto de sereia<BR>Nos tempos de eleição</FONT></P></p>
<p><P align=justify><FONT face=Verdana></FONT></P></p>
<p><P align=justify><FONT face=Verdana>(7)<BR><BR>Promessas e mais promessas<BR>Que nunca serão cumpridas<BR>As multidões iludidas<BR>Se enganam ouvindo essas<BR>Eles escondem às pressas<BR>Os podres do seu patrão<BR>Num discurso de ilusão<BR>Onde a mentira campeia<BR>É o canto de sereia<BR>Nos tempos de eleição</FONT></P></p>
<p><P align=justify><FONT face=Verdana></FONT></P></p>
<p><P align=justify><FONT face=Verdana>(8)<BR></FONT><BR><FONT face=Verdana>A campanha é muito rica<BR></FONT><FONT face=Verdana>Tem muito show de artista<BR>Pra conseguir a conquista<BR>Depois na mão você fica<BR>Pois quem não identifica<BR>Quem é falso e poltrão<BR>Vai no fim ficar na mão<BR>Mesmo assim nem esperneia<BR>É o canto de sereia<BR>Nos tempos de eleição</FONT></P></p>
<p><P</p>
<p> align=justify><FONT face=Verdana></FONT></P></p>
<p><P align=justify><FONT face=Verdana>(9)<BR><BR>Escondendo seu passado<BR>Quem financia o partido<BR>É pelego empedernido<BR>Quer dar o golpe o safado<BR>No seu voto interessado<BR>Pra garantir a exclusão<BR>Disfarça a sua feição<BR>Feito aranha tece a teia<BR>É o canto de sereia<BR>Nos tempos de eleição</FONT></P></p>
<p><P align=justify><FONT face=Verdana></FONT></P></p>
<p><P align=justify><FONT face=Verdana>(10)<BR><BR>Perpetuar indigência<BR>Para manter o poder<BR>Consegue se eleger<BR>Dando esmola na emergência<BR>Exclusão é indecência<BR>A miséria escravidão<BR>Pois humilha o cidadão<BR>E o seu avanço freia<BR>É o canto de sereia<BR>Nos tempos de eleição</FONT></P> </p>
