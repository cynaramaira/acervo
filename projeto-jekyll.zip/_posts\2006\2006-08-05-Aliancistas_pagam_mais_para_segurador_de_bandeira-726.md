---
id: 12371899
data_publicacao: "2006-08-05 14:51:00"
data_alteracao: "None"
materia_tags: "dia da bandeira,pagamento,Pará,Seguradora Líder"
categoria: "Notícias"
titulo: "Aliancistas pagam mais para segurador de bandeira"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><BR><FONT face=Verdana>A militância paga de candidatos da coligação União por Pernambuco - do governador e candidato Mendonça Filho - anda rindo à toa. Explica-se: é a militância mais bem paga, até aqui, nestas eleições. </FONT></P></p>
<p><P><FONT face=Verdana>Cec?lia Ramos, repórter do Blog, fez uma cotação e constatou que os deputado federais e candidatos à reeleição Carlos Eduardo Cadoca (PMDB) e Joaquim Francisco (PFL) estão empatados no ranking de melhores pagadores. Cada militante deles ganha R$ 15, por dia, para segurar bandeiras pelas ruas do Recife ou em eventos, de segunda a sábado. </FONT></P></p>
<p><P><FONT face=Verdana>\"Dá para fazer até R$ 90, trabalhando de segunda a sábado\", disse um militante de Cadoca, durante inauguração do comitê de Geraldo Alckmin, sexta-feira, no Recife. </FONT></P></p>
<p><P><FONT face=Verdana>\"O deputado (Joaquim Francisco) disse que dava até para ganhar um salário m?nimo no final do mês. E se a gente trabalhar no domingo ganha por fora\", afirmou um militante do pefelista. </FONT></P></p>
<p><P><FONT face=Verdana>O deputado Raul Jungmann (PPS) paga um pouco menos, R$ 10, por dia. </FONT></P></p>
<p><P><FONT face=Verdana>Já os militantes do governador-candidato&nbsp;Mendonça Filho (PFL) estão com o discurso afinado: sustentam a tese de que seguram bandeira, vestem perucas e cantam os gritos de guerra pefelista&nbsp;por \"amor à causa\".&nbsp;\"Ninguém aqui recebe nada não.&nbsp;Todo mundo é voluntário\", disse uma militante.&nbsp;&nbsp;</FONT></P></p>
<p><P><FONT face=Verdana>Depois dos aliancistas, é o deputado federal Armando Monteiro Neto (PTB) - aliado de Humberto Costa (PT) -&nbsp;o melhor pagador. Seus militantes embolsam&nbsp;R$ 70 pelo trabalho&nbsp;da semana inteira (seis dias).<BR></FONT></P> </p>
