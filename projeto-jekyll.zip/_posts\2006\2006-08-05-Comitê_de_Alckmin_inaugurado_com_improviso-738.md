---
id: 12371911
data_publicacao: "2006-08-05 08:05:00"
data_alteracao: "None"
materia_tags: "geraldo Alckmin"
categoria: "Notícias"
titulo: "Comitê de Alckmin inaugurado com improviso"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>A inauguração do comitê de Geraldo Alckmin no Recife, ontem à noite, só não passou \"em brancas nuvens\" porque diante dos questionamentos dos jornalistas, o candidato a vice José Jorge (PFL) – organizador do espaço – conseguiu juntar o público que ainda restava no local e rapidamente improvisou uns discursos. </FONT></P></p>
<p><P><FONT face=Verdana>Eles não constavam no script. E quando finalmente foram inclu?dos já não contaram mais com as presenças de Jarbas Vasconcelos</p>
<p> e Mendonça Filho. José Jorge argumentou que os planos eram mesmo de resumir a inauguração do comitê apenas à uma visita. \"Não sou uma pessoa muito festiva\", explicou.</FONT></P></p>
<p><P><FONT face=Verdana>Leia o </FONT><A href=\"https://jc3.uol.com.br/jornal/\" target=_blank><B><I><U><FONT color=#0000ff><FONT face=Verdana>texto</FONT></B></I></U></FONT></A><FONT face=Verdana> completo em Pol?tica, no JC (assinantes JC e UOL).</FONT></P> </p>
