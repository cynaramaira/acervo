---
id: 12372041
data_publicacao: "2006-07-30 17:47:00"
data_alteracao: "None"
materia_tags: "agreste,estudo,Steven Mnuchin"
categoria: "Notícias"
titulo: "Teve de tudo no Agreste"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>No interior teve de tudo neste final de semana. Até Humberto+Armando+Romário. </FONT></P></p>
<p><P><FONT face=Verdana>Isso mesmo, mais Romário Dias, deputado do PFL, presidente da Assembléia Legislativa do Estado e doido para ser conselheiro do Tribunal de Contas.</FONT></P></p>
<p><P><FONT face=Verdana>No Agreste tem também Eduardo encobrindo a careca com um chapéu de couro -&nbsp;o de palha, só quando está na Zona da Mata, desfilando como herdeiro de Arraes.</FONT></P></p>
<p><P><FONT face=Verdana>Pois, naquela região, até as militâncias de Humberto e Eduardo se misturam no segundo lugar.</FONT></P></p>
<p><P><FONT face=Verdana>E Humberto, se tiver alguma queixa do processo pol?tico, do jogo bruto do processo pol?tico, que vá reclamar ao bispo.&nbsp; Pois, com o padre de lá, nem adiante levantar.</FONT></P> </p>
