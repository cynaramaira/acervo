---
id: 12372018
data_publicacao: "2006-08-01 08:57:00"
data_alteracao: "None"
materia_tags: "ética,parlamentares"
categoria: "Notícias"
titulo: "Conselho de ética processará 75 parlamentares"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>O balanço parcial apresentado ontem pela CPI das Sanguessugas mostra que pelo menos 75 dos 90 parlamentares investigados sob suspeita de terem se envolvido com a máfia das ambulâncias devem ter seus casos encaminhados ao Conselho de Ética. </FONT></P></p>
<p><P><FONT face=Verdana>O número é resultado do levantamento feito pela sub-relatoria de sistematização da investigação, que servirá de base para o relatório parcial. O documento seria apresentado quarta-feira, mas só deve ser conclu?do daqui a duas semanas.</FONT></P></p>
<p><P><FONT face=Verdana>A conclusão</p>
<p> do levantamento é de que a CPI já recebeu documentos que comprometem 54 acusados. Já outros 21 são acusados com base nos depoimentos ouvidos pela Justiça Federal. </FONT></P></p>
<p><P><FONT face=Verdana>O último grupo é formado basicamente pelos parlamentares a quem o empresário Luiz Antonio Vedoin disse ter pago propina em dinheiro vivo. A CPI pode ainda quebrar os seus sigilos bancários na tentativa de comprovar os repasses.</FONT></P></p>
<p><P><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Verdana; mso-bidi-font-family: Arial\">Leia <EM><B><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></B></EM> o texto completo (assinantes JC e UOL).<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></SPAN></P> </p>
