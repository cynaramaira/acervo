---
id: 12371917
data_publicacao: "2006-08-06 08:31:00"
data_alteracao: "None"
materia_tags: "candidatos,ministério"
categoria: "Notícias"
titulo: "Ministério Público implacável com os candidatos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Não são só os partidos que estão atentos às pisadas de bola dos concorrentes. Apesar da troca de tiros entre os candidatos, é o Ministério Público Eleitoral que tem sido o mais implacável com qualquer deslize dos postulantes ao governo do Estado. </FONT></P></p>
<p><P><FONT face=Verdana>Do in?cio do ano para cá, a instituição deu origem a oito representações no TRE – sete contra Mendonça Filho, Humberto Costa, Eduardo Campos ou aliados seus. A única exceção foi uma denúncia, já arquivada, de que o ex-secretário de Defesa Social João Braga (PV) estaria usando carros do governo em sua campanha para deputado estadual.</FONT></P></p>
<p><P><FONT face=Verdana>Neste quesito, Mendonça e os partidos da União por Pernambuco dividem com Eduardo e as siglas que o apóiam o posto de alvo preferencial. Foram três representações movidas pelo MPE contra cada um dos dois lados.</FONT></P></p>
<p><P><FONT face=Verdana>Leia o <STRONG><EM><A href=\"https://jc3.uol.com.br/jornal/\" target=_blank>texto</A></EM></STRONG> completo em Pol?tica, no JC (assinantes</p>
<p> JC e UOL).</FONT><FONT face=Verdana></P></FONT> </p>
