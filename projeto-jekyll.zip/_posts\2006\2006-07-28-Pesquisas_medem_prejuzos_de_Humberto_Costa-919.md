---
id: 12372092
data_publicacao: "2006-07-28 15:36:00"
data_alteracao: "None"
materia_tags: "Humberto Costa,pesquisas"
categoria: "Notícias"
titulo: "Pesquisas medem preju?zos de Humberto Costa"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Duas pesquisas eleitorais realizadas neste final de semana mostrarão se o escândalo das sanguessugas já causou algum preju?zo eleitoral para o ex-ministro Humberto Costa (PT), que disputa com Eduardo Campos (PSB) a segunda colocação nas intenções de voto para governador de Pernambuco - a liderança hoje é do governador Mendonça Filho (PFL).</FONT></P></p>
<p><P><FONT face=Verdana>Neste momento, o PSB está aplicando 1,5 mil questionários no Estado para medir intenções de voto e as expectativas sobre áreas espec?ficas como saúde e segurança pública. No meio dos questionários, há indagações&nbsp;sobre o caso da venda superfaturada de ambulâncias.</FONT></P></p>
<p><P><FONT face=Verdana>Os resultados chegam às mãos de Eduardo no domingo.</FONT></P></p>
<p><P><FONT face=Verdana>No mesmo dia, uma equipe do Ibope estará nas ruas para levantar as intenções de voto para a TV Globo. Segundo Jô Mazzarolo, diretora de jornalismo da Globo Nordeste, os números serão divulgados na terça-feira.</FONT></P> </p>
