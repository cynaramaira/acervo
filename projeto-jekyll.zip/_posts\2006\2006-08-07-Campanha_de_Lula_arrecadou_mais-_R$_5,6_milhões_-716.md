---
id: 12371889
data_publicacao: "2006-08-07 08:20:00"
data_alteracao: "None"
materia_tags: "animais,campanha,Lula"
categoria: "Notícias"
titulo: "Campanha de Lula arrecadou mais: R$ 5,6 milhões "
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=4></p>
<p><P></FONT><FONT face=Verdana>Do <STRONG>Jornal do Commercio<BR></STRONG>(com Agência Estado)</FONT></P></p>
<p><P><FONT face=Verdana>BRAS??LIA – O comando da campanha à reeleição do presidente Lula (PT) informou ao Tribunal Superior Eleitoral (TSE), ontem, ter gasto R$ 4,2 milhões no primeiro mês da campanha, valor que corresponde a mais que o dobro do montante declarado pelo seu principal adversário, Geraldo Alckmin (PSDB), cujas despesas foram de R$ 1,9 milhão.</FONT></P></p>
<p><P><FONT face=Verdana>(...)</FONT></P></p>
<p><P><FONT face=Verdana>Segundo o relatório da campanha do presidente Lula, o comitê financeiro gastou até agora R$ 4.196.168,07 e arrecadou R$ 5.686.558,00. </FONT></P></p>
<p><P><FONT face=Verdana>Em tese, o comitê petista teria hoje R$ 1.490.389,93 em caixa, mas o tesoureiro da campanha, José de Filippi Júnior, argumenta que o valor está comprometido para quitar contas pendentes. </FONT></P></p>
<p><P><FONT face=Verdana>(...)</FONT></P></p>
<p><P><FONT face=Verdana>Geraldo Alckmin informou que, por enquanto, os gastos foram maiores do que a arrecadação. </FONT><FONT face=Verdana>O seu comitê financeiro registrou receitas de R$ 1 322.697,68 e despesas de R$ 1.889.387,48. </FONT></P></p>
<p><P><FONT face=Verdana>O maior gasto da campanha foi de R$ 989.698,67, relativos a serviços prestados por terceiros. Com alimentação foram consumidos R$ 10.042,45 e com água, R$ 1.642,29. </FONT></P></p>
<p><P><FONT face=Verdana>As despesas com transporte e deslocamento foram de R$ 152.958,19. Ao solicitar o registro no TSE, Alckmin disse que espera gastar no máximo R$ 85.000.000 com a campanha.<BR></P></FONT> </p>
