---
id: 12372165
data_publicacao: "2006-07-24 20:12:00"
data_alteracao: "None"
materia_tags: "eduardo"
categoria: "Notícias"
titulo: "Eduardo faz caminhada com Alf"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Eduardo festejará na quinta-feira o apoio de Alf, o deputado estadual do PTB que migrou de Humberto Costa para a campanha dele.</P></p>
<p><P>Será à noite, em ??guas Compridas, em Olinda, com uma caminhada.</P></p>
<p><P>Eduardo também disse há pouco que Luiz Piauhylino (PDT), que desistiu de disputar novo mandato de deputado federal, ficará integrado à coordenação da campanha dele.</P> </p>
