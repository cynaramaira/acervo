---
id: 12372047
data_publicacao: "2006-07-30 15:39:00"
data_alteracao: "None"
materia_tags: "jarbas vasconcelos,mendonça,verão"
categoria: "Notícias"
titulo: "Jarbas e Mendonça verão o guia juntos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Cec?lia Ramos</STRONG><BR>Repórter do Blog</FONT></P></p>
<p><P><FONT face=Verdana>Jarbas Vasconcelos (PMDB) e Mendonça Filho (PFL) assistem ao primeiro programa do guia eleitoral da União por Pernambuco no dia 16 de agosto, no comitê da Rosa e Silva, no Recife.</FONT></P></p>
<p><P><FONT face=Verdana>A propaganda eleitoral na TV e no rádio começa dia 15, mas com a campanha presidencial.</FONT></P></p>
<p><P><FONT face=Verdana>O peemedebista, maior estrela da aliança e puxador de votos, é quem abre o v?deo, que tem coordenação do marqueteiro Antônio Lavareda, da MCI.</FONT></P> </p>
