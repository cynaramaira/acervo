---
id: 12372005
data_publicacao: "2006-08-01 17:19:00"
data_alteracao: "None"
materia_tags: "geraldo Alckmin,Lula,Teto"
categoria: "Notícias"
titulo: "Alckmin e Helo?sa chegaram no teto, diz equipe de Lula"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por<STRONG> ANDREZA MATAIS</STRONG></FONT><BR><FONT face=Verdana>da Folha Online<BR><BR>O crescimento dos candidatos à Presidência da República do PSDB, Geraldo Alckmin, e do PSOL, Helo?sa Helena, registrado por vários institutos de opinião até agora, não preocupa a campanha do presidente Luiz Inácio Lula da Silva. </FONT></P></p>
<p><P><FONT face=Verdana>Pesquisas internas indicaram que os dois candidatos estão atingindo seus tetos e que não tiram votos do presidente.<BR><BR>Na reunião da coordenação pol?tica da campanha de Lula ontem, no Palácio da Alvorada, avaliou-se que os votos no presidente estão bem consolidados, ao contrário dos seus opositores. \"Nossa expectativa é que o pessoal [Alckmin e Helo?sa Helena] está chegando ao teto e o Lula tende a crescer\", disse o presidente nacional do PSB, Roberto Amaral. </FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Para neutralizar Itamar, Lula quer&nbsp;Alencar em Minas </STRONG></FONT></P></p>
<p><P>Da <STRONG>Folha Online</STRONG></P></p>
<p><P><FONT face=Verdana>Para tentar neutralizar o apoio do ex-presidente Itamar Franco ao candidato do PSDB à Presidência, Geraldo Alckmin, a coordenação da campanha do presidente Luiz Inácio Lula da Silva recomendou que o vice, José Alencar, viaje mais para Minas Gerais.<BR><BR>Em reunião ontem à noite, ficou decidido que Lula e Alencar irão se dividir durante a campanha. A missão de Alencar é usar seu prest?gio para agregar votos em Minas, já o presidente terá como alvos São Paulo e Rio de Janeiro.</FONT></P> </p>
