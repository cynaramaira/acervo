---
id: 12372183
data_publicacao: "2006-07-23 13:42:00"
data_alteracao: "None"
materia_tags: "Brasília Teimosa,discurso,Lula"
categoria: "Notícias"
titulo: "Ouça aqui o discurso de Lula em Bras?lia Teimosa"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p> </p>
