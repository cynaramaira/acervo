---
id: 12372102
data_publicacao: "2006-07-28 08:54:00"
data_alteracao: "None"
materia_tags: "Lula"
categoria: "Notícias"
titulo: "A perspectiva é de dar uma goleada boa, diz Lula"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>O presidente Lula disse ontem, em entrevista à rádio CBN, que está numa posição mais confortável do que seu antecessor para disputar a reeleição. Sem citar o nome do ex-presidente Fernando Henrique Cardoso, apenas se referindo ao ano de 1998, Lula declarou que seu time está ganhando e a perspectiva é de \"dar uma goleada\". O presidente se referia à condição da economia.</FONT></P></p>
<p><P><FONT face=Verdana>\"A diferença dessa reeleição para a de 98, é que, em 98, quando o presidente foi reeleito, foi pego de surpresa com uma guinada do mercado que mudou o câmbio. Agora, estamos na estabilidade e a perspectiva é de dar uma goleada boa\", comentou.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></EM></STRONG> texto completo (assinantes JC e UOL).</FONT></P> </p>
