---
id: 12372023
data_publicacao: "2006-08-01 08:52:00"
data_alteracao: "None"
materia_tags: "Humberto Costa,Serrana"
categoria: "Notícias"
titulo: "Governistas só aceitam Humberto na CPI se Serra for"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <B>Jornal do Commercio</P></B></FONT></p>
<p><P><FONT face=Verdana>O aumento das evidências de ligação dos ex-ministros da Saúde, Humberto Costa (PT) e Saraiva Felipe (PMDB), com a máfia das ambulâncias, levou o relator da CPI das Sanguessugas, senador Amir Lando (PMDB-RO), a criar ontem uma sub-relatoria para investigar o Executivo. </FONT></P></p>
<p><P><FONT face=Verdana>A iniciativa provocou a reação dos governistas, que exigem que o ex-ministro José Serra(PSDB) também seja investigado.</FONT></P></p>
<p><P><FONT face=Verdana>A sub-relatoria vai investigar ainda os Ministérios da Educação e Ciência e Tecnologia. E pode chegar até a Casa Civil do governo Lula, pasta a quem estava ligada à Coordenação Pol?tica, responsável pela liberação de todas as emendas parlamentares. O sub-relator deverá ser o deputado Júlio Redecker(PSDB-RS).</FONT></P><FONT face=Verdana></p>
<p><P>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinantes JC e UOL).</P></FONT> </p>
