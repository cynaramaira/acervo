---
id: 12372312
data_publicacao: "2006-07-17 16:12:00"
data_alteracao: "None"
materia_tags: "jarbas vasconcelos,mendonça,reagendamentos"
categoria: "Notícias"
titulo: "Jarbas e Mendonça definem agenda conjunta"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Eles acertam até amanhã a programação de eventos de rua. O ex-governador quer mergulhar de cabeça na campanha de Mendonça Filho. Ele ficou animado com os resultados da pesquisa JC/Vox Populi, que lhe dá 66% das intenções de voto ao Senado e confere 35% ao governador (veja aqui<B> </B>os números para o <STRONG><A href=\"https://jc3.uol.com.br/blogs/jc/2006/07/17/index.php#106\">Senado</A></STRONG> e <STRONG><A href=\"https://jc3.uol.com.br/blogs/jc/2006/07/16/index.php#63\">Governo</A></STRONG>). </P></p>
<p><P>\"A União por Pernambuco vive um bom momento. O desafio agora é prolongar esse momento sem errar\", afirmou Jarbas Vasconcelos. Ele quer a aliança com os pés no chão: \"Não tem eleição tranqüila, garantida\". As prioridades, na opinião dele, são aprimorar a agenda de campanha, iniciar a campanha conjunta (Jarbas/Mendonça) e realizar um guia eleitoral competente.</P></FONT> </p>
