---
id: 12372148
data_publicacao: "2006-07-25 18:41:00"
data_alteracao: "None"
materia_tags: "estudo,governo,jair bolsoa"
categoria: "Notícias"
titulo: "No meu governo, eu sabia de tudo, diz Jarbas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Os repórteres que estão no comitê de Jarbas e Mendonça, no Recife, acabam de perguntar ao ex-governador como é essa história de que, no governo dele, sabia de tudo. </FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Jarbas afirmou isso no sábado passado&nbsp;para fazer ironia em relação ao que Lula tem dito sobre os escândalos&nbsp;envolvendo o governo federal.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Para complementar a pergunta, os jornalistas questionaram sobre se ele sabia da atuação de PMs da Casa Militar contra Dominici Mororó, advogado da artesã Maria do Socorro, pivô do mais importante confronto entre o prefeito João Paulo e o deputado Carlos Eduardo Cadoca, na disputa pela prefeitura do Recife, em 2004.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><o:p></o:p></FONT>&nbsp;</P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><STRONG>Resposta de Jarbas:</STRONG></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>“Eu prestei todos os esclarecimentos. É só rememorar a época. O serviço de inteligência prestou todos os esclarecimentos.???</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><STRONG>Rememorando</STRONG></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Para quem não lembra da história, veja o que foi publicado hoje no site da jornalista Divane Carvalho (</FONT><A href=\"https://www.divanecarvalho.com.br/\"><FONT face=Verdana>www.divanecarvalho.com.br</FONT></A><FONT face=Verdana>):</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN:</p>
<p> 0cm 0cm 0pt\"><STRONG><SPAN style=\"FONT-SIZE: 18pt; COLOR: #333399\"><FONT face=Verdana><FONT size=2>Sabia de tudo 1<o:p></o:p></FONT></FONT></SPAN></STRONG></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><SPAN style=\"COLOR: black\">Para provar que não é como o presidente Lula (PT) que nunca sabe de nada, Jarbas Vasconcelos afirmou no seu discurso, sábado passado, na inauguração do comitê majoritário da União por Pernambuco, que durante o seu governo não acontecia nada que ele não soubesse. A declaração empolgada do ex-governador deixou os petistas assanhad?ssimos. <BR><BR></SPAN><STRONG><SPAN style=\"FONT-SIZE: 18pt; COLOR: #333399\"><FONT size=2>Sabia de tudo 2</FONT></SPAN></STRONG></FONT><SPAN style=\"COLOR: black\"><BR><BR><FONT face=Verdana>E agora andam dizendo que, se Jarbas sabia de tudo, tomou conhecimento do que acontecia na Casa Militar, em 2004, quando três policiais militares seguiram Dominici Mororó, advogado da artesã Maria do Socorro, pivô da disputa entre João Paulo (PT) e Carlos Eduardo Cadoca Pereira (PMDB) em Bras?lia Teimosa, na campanha para prefeito do Recife.<BR><BR></FONT></SPAN><STRONG><SPAN style=\"FONT-SIZE: 18pt; COLOR: #333399\"><FONT face=Verdana size=2>Sabia de tudo 3</FONT></SPAN></STRONG><SPAN style=\"COLOR: black\"><BR><BR><FONT face=Verdana>Para quem não lembra: no dia 16 de setembro de 2004 os soldados Ivan Bezerra da Silva e Adalberto Leandro do Nascimento e o segundo sargento Melquisedeque Alves Monteiro foram presos quando seguiam Dominici Mororó que, temendo um seqüestro conseguiu chamar a pol?cia. Os três eram lotados na Casa Militar do Governo do Estado.</FONT></SPAN></P> </p>
