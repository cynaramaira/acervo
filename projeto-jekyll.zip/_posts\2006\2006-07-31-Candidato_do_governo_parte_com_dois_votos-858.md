---
id: 12372031
data_publicacao: "2006-07-31 17:31:00"
data_alteracao: "None"
materia_tags: "caixa dois,candidatos,governo,Votos Nulos"
categoria: "Notícias"
titulo: "Candidato do governo parte com dois votos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Fernando Cerqueira acabou de dar os primeiros votos dele, e de público: Pedro Henrique Alves (candidato do governo); Francisco Bandeira; e Jorge Neves.</FONT></P></p>
<p><P><FONT face=Verdana>No meio de uma discussão sobre votação secreta ou não, Bartolomeu Bueno também revelou que escolherá os mesmo candidatos de Cerqueira.</FONT></P></FONT> </p>
