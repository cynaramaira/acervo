---
id: 12372181
data_publicacao: "2006-07-23 14:27:00"
data_alteracao: "None"
materia_tags: "None"
categoria: "Notícias"
titulo: ""
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><STRONG>\"Queria ser reitor para ser chamado de magn?fico\"</STRONG></P></p>
<p><P>Luiz Inácio Lula da Silva, em reunião com intelectuais, agora há pouco, em Olinda</P> </p>
