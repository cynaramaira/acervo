---
id: 12371972
data_publicacao: "2006-08-03 06:58:00"
data_alteracao: "None"
materia_tags: "São João"
categoria: "Notícias"
titulo: "O Engenho São João é só o começo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Fernando Castilho</STRONG><BR></FONT><FONT face=Verdana>Colunista de Economia do JC</FONT></P></p>
<p><P><FONT face=Verdana>Independentemente do desfecho do cumprimento (ou não) da ordem de reintegração de posse do Engenho São João, onde estão 200 fam?lias produzindo absolutamente nada, é preciso entender que esse tipo de evento será cada vez mais freqüente nos próximos meses, com direito a eleições no meio.</FONT></P></p>
<p><P><FONT face=Verdana>Pode-se dizer que a reintegração de posse tornou-se um problema pol?tico entre a PM (que cumpre ordem de agir) e o MST (que compre ordem de reagir) e onde ambos poderiam produzir um confronto catastrófico. Mas deve-se dizer que, daqui para a frente, esse estresse social será rotina. E o aproveitamento pol?tico, também.</FONT></P></p>
<p><P><FONT face=Verdana>Tem a ver com a dificuldade do Incra em gerir a tramitação dos processos de desapropriação na Justiça. Ele agora perde ações e está se inviabilizando como gestor de novos assentamentos. E a disposição do setor sucroalcooleiro de retomar suas terras. Porque virou uma questão de estratégia para sua sobrevivência econômica. </FONT></P></p>
<p><P><FONT face=Verdana>Virou uma prioridade reocupar a Zona da Mata de Pernambuco com cana-de-açúcar. Vale para uma usina isolada e para um grupo como o Votorantim. O problema é que na região agora estão 14 grupos de movimentos sociais, que lideram 30 mil fam?lias. </FONT></P></p>
<p><P><FONT face=Verdana>O fato novo é a disposição dos donos da terras em brigar por elas. E todos sabem que a cada assentamento conclu?do, mais fam?lias ficam fora das terras regularizadas. A falência do nosso modelo de reforma agrária deixou de gerar mais produção. Agora pode gerar mais cadáveres.</FONT></P></p>
<p><P><FONT face=Verdana>Leia mais <STRONG><EM><A href=\"https://jc3.uol.com.br/blogs/jc/2006/08/02/index.php#452\" target=_blank>aqui</A></EM></STRONG> sobre o assunto.</FONT></P> </p>
