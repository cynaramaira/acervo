---
id: 12372280
data_publicacao: "2006-07-19 16:15:00"
data_alteracao: "None"
materia_tags: "Prefeitos"
categoria: "Notícias"
titulo: "CPI pode envolver 300 prefeitos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>É o que diz o deputado federal Raul Jungmann (PPS), vice-presidente da CPI das Sanguessugas. Os prefeitos, além de 105 parlamentares, devem ser indiciados pela comissão por envolvimento no escândalo das ambulâncias.</FONT></P></p>
<p><P><FONT face=Verdana>Ouça entrevista do deputado em Geraldo Freire, hoje cedo, na Rádio Jornal.</FONT></FONT></P> </p>
