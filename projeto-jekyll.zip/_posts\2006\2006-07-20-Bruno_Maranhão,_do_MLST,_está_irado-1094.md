---
id: 12372267
data_publicacao: "2006-07-20 10:58:00"
data_alteracao: "None"
materia_tags: "Bruno Covas,Emirados,esta,maranhão"
categoria: "Notícias"
titulo: "Bruno Maranhão, do MLST, está irado"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Está irado com o veto da cúpula do PT à subida dele no palanque de Lula, no com?cio programado para sábado, em Bras?lia Teimosa, no Recife. O comandante do Movimento</p>
<p> de Libertação dos Sem Terra foi afastado da executiva nacional do partido, há um mês, depois que os militantes do MLST promoveram um quebra-quebra na Câmara dos Deputados.</FONT></P></p>
<p><P><FONT face=Verdana>Há pouco, enquanto arrumava as malas em Bras?lia, Bruno falou com Cec?lia Ramos, repórter do <B>Blog</B>, por telefone. Foi enigmático nas respostas. \"Cec?lia, minha filha, eu sou profissional, tomei minhas providências sobre isso aqui em Bras?lia.\"</FONT></P></p>
<p><P><FONT face=Verdana>E se recusou a dizer se iria ou não ao com?cio. \"Não vou dar opinião sobre isso, não. Vou embarcar daqui a pouco, de 12 e meia. Deixa eu ir, eu tô arrumando as malas, se não eu perco meu avião. Eu chego no Recife três horas da tarde. Vá no aeroporto que eu vou falar tudo.\"</FONT></P></p>
<p><P><FONT face=Verdana>Inicialmente quem atendeu o telefone foi outra pessoa. Ela tentou se passar por Bruno Maranhão e chegou a responder por ele sobre o com?cio. \"Não penso em participar, não\", disse. Foi quando o l?der dos sem-terra tomou o telefone. </FONT></P></p>
<p><P><FONT face=Verdana>Ele vem num vôo da Gol e deve repetir o que disse ao Blog, em entrevista exclusiva (<B><A href=\"https://jc3.uol.com.br/blogs/jc/2006/07/18/index.php#117\">leia aqui</A></B>), no in?cio da semana. Depois de 38 dias preso, acusou a \"direita do Congresso\" e o presidente da Câmara, Aldo Rebelo (PCdoB-SP), de serem os verdadeiros responsáveis pelo quebra-quebra.</FONT></P></p>
<p><P><FONT face=Verdana>Em reportagem do JC, publicada hoje, o secretário nacional de comunicação do PT, Humberto Costa, diz que Bruno Maranhão está fora da lista dos convidados.</FONT></P></FONT> </p>
