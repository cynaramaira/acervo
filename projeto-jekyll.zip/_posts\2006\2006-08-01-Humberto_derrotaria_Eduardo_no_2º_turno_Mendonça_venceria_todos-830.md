---
id: 12372003
data_publicacao: "2006-08-01 19:17:00"
data_alteracao: "None"
materia_tags: "eduardo,Humberto Costa,mendonça,métodos contraceptivos,Saturno"
categoria: "Notícias"
titulo: "Humberto derrotaria Eduardo no 2º turno. Mendonça venceria todos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=Verdana><FONT size=2></p>
<p><P>Resultados sobre as eleições em Pernambuco, divulgados agora há pouco no NETV, da&nbsp;Globo.</P></p>
<p><P>Cenários de 2º</FONT></FONT><FONT face=Verdana> turno</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Cenário 1</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Mendonça Filho (PFL)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 44%</FONT></P></p>
<p><P><FONT face=Verdana>Humberto Costa (PT)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;36%</FONT></P></p>
<p><P><FONT face=Verdana>Brancos e nulos&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;10%</FONT></P></p>
<p><P><FONT face=Verdana>Não sabe, não opinou&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 10%</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Cenário 2</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Mendonça&nbsp;Filho&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 49%</FONT></P></p>
<p><P><FONT face=Verdana>Eduardo&nbsp;Campos&nbsp;(PSB)&nbsp;&nbsp;&nbsp;&nbsp; 27%</FONT></P></p>
<p><P><FONT face=Verdana>B</FONT><FONT face=Verdana>rancos e nulos&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 13%</FONT></P></p>
<p><P><FONT face=Verdana>Não sabe, não opinou&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 11%</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Cenário 3</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Humberto&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;44%</FONT></P></p>
<p><P><FONT</p>
<p> face=Verdana>Eduardo&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 28%</FONT></P></p>
<p><P><FONT face=Verdana>Brancos e nulos&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 15%</FONT></P></p>
<p><P><FONT face=Verdana>Não sabe, não opinou&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 13%</FONT></P> </p>
