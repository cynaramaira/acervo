---
id: 12371907
data_publicacao: "2006-08-05 10:00:00"
data_alteracao: "None"
materia_tags: "Prova"
categoria: "Notícias"
titulo: "Vedoin promete mais provas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>O empresário Luiz Antonio Vedoin prometeu entregar à CPI das Sanguessugas, até a próxima terça-feira, mais provas contra parlamentares e assessores que teriam participado do esquema de compra superfaturada de ambulâncias. </FONT></P></p>
<p><P><FONT face=Verdana>Depois de ser submetido ontem a uma acareação com Marcelo de Carvalho, ex-assessor do senador Ney Suassuana (PMDB-PB), e Ronildo Medeiros, outro integrante da máfia d&lt;WC&gt;a&lt;WC1&gt;s sanguessugas, Vedoin revelou ao relator da CPI, senador Amir Lando (PMDB-RO), e ao sub-relator de sistematização, deputado Carlos Sampaio (PSDB-SP), que teria localizado novos comprovantes de depósitos e cópias de cheques pagos a dois ou três envolvidos. Um deles pode ser o ex-assessor de Suassuna, que na acareação manteve sua versão de que não teria recebido propina de Vedoin ou de Ronildo.</FONT></P></p>
<p><P><FONT face=Verdana>Leia o </FONT><A href=\"https://jc3.uol.com.br/jornal/\" target=_blank><B><I><U><FONT color=#0000ff><FONT face=Verdana>texto</FONT></B></I></U></FONT></A><FONT face=Verdana> completo em Pol?tica, no JC (assinantes JC e UOL).</FONT></P> </p>
