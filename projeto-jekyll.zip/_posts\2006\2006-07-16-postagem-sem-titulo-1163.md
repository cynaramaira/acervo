---
id: 12372336
data_publicacao: "2006-07-16 12:34:00"
data_alteracao: "None"
materia_tags: "None"
categoria: "Charge"
titulo: ""
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p>A guerra entre Lula e Alckmin, segundo Humberto, do JC </p>
