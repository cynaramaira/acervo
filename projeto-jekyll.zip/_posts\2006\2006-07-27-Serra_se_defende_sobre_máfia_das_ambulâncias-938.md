---
id: 12372111
data_publicacao: "2006-07-27 20:05:00"
data_alteracao: "None"
materia_tags: "mafia,Serrana"
categoria: "Notícias"
titulo: "Serra se defende sobre máfia das ambulâncias"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=1></p>
<p><P><FONT face=Verdana size=2>Da <STRONG>Agência Estado</STRONG></FONT></P></FONT></p>
<p><P><FONT face=Verdana>O candidato a governador de São Paulo José Serra (PSDB), da Coligação Compromisso com São Paulo (PSDB-PFL-PPS-PTB), classificou hoje como \"uma ação pol?tico-eleitoral\" a divulgação de dados feita ontem (26) pelos ministros da Justiça, Márcio Thomaz Bastos, e da Controladoria-Geral da União (CGU), Jorge Hage, tentando comprometer a gestão do ex-presidente Fernando Henrique Cardoso nas denúncias das ambulâncias.<BR><BR>\"Não tenho o que comentar. Foi uma ação pol?tica dos ministros do governo Lula\", disse, em Itararé, a 330 quilômetros da capital paulista, na divisa com o Paraná, onde fez campanha hoje. \"A minha gestão no Ministério da Saúde já foi esquadrinhada. Minha gestão é amplamente conhecida e pode se investigar o quanto quiser\", insistiu.</FONT></P> </p>
