---
id: 12372169
data_publicacao: "2006-07-24 15:34:00"
data_alteracao: "None"
materia_tags: "eduardo, entrega, mendonça"
categoria: "Notícias"
titulo: "Internautas apostam em 2º turno entre Mendonça e Eduardo"
sutia: "None"
chapeu: "None"
autor: "jamildo"
imagem: "None"
---
<p>&nbsp;</p>
<p>Voc&ecirc; acha que haver&aacute; segundo turno nas elei&ccedil;&otilde;es de Pernambuco?</p>
<p>J&aacute; foram registrados 3.532 votos nos &uacute;ltimos cinco dias. Veja os resultados acumulados at&eacute; agora:</p>
<p>Sim, entre Mendon&ccedil;a e Eduardo 81% (2.872 votos)</p>
<p>Sim, entre Mendon&ccedil;a e Humberto 4% (146 votos)</p>
<p>Sim, entre Eduardo e Humberto 10% (355 votos)</p>
<p>N&atilde;o 5% (159 votos)</p>
<p>Vote, d&ecirc; sua opini&atilde;o na coluna ao lado.</p>
