---
id: 12372331
data_publicacao: "2006-07-16 16:53:00"
data_alteracao: "None"
materia_tags: "bloqueio judicial,briga,Goiana"
categoria: "Notícias"
titulo: "Disputa em Goiana termina em briga judicial"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>A chapa de Humberto Costa (PT) está em guerra na eleição para escolha do substituto do prefeito cassado Beto Gadelha (PSDB) - informa o repórter Clóvis Andrade, do JC. O candidato Edval Soares, do PTB de Armando Monteiro Neto, quer impugnar a candidatura de Henrique Fenelon, do PCdoB de Luciano Siqueira. Edval foi prefeito de Goiana até 2004 e acusa Fenelon, presidente da Câmara Municipal e prefeito interino, de ter feito campanha irregular pela manhã. A ju?za Mariza Silva Borges disse a mesma coisa a Cec?lia Ramos, repórter do blog. Edval apresentou pedido formal de investigação contra o candidato comunista. Por sinal, foi Edval quem conseguiu na Justiça a cassação de Beto Gadelha.</P></FONT> </p>
