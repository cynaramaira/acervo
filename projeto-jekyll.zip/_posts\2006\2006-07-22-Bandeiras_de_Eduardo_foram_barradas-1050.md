---
id: 12372223
data_publicacao: "2006-07-22 18:09:00"
data_alteracao: "None"
materia_tags: "eduardo"
categoria: "Notícias"
titulo: "Bandeiras de Eduardo foram barradas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>As bandeiras com madeira foram proibidas na avenida Bras?lia Formosa. Por isso, as de Eduardo foram barradas na entrada da área reservada ao com?cio.</P></p>
<p><P>Humberto saiu ganhando nas imagens para o guia eleitoral. As dele têm suporte de plástico. De um lado há o nome e o número dele. Do outro, nome e número de Lula.</P></p>
<p><P>&nbsp;</P> </p>
