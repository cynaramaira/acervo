---
id: 12372221
data_publicacao: "2006-07-22 17:54:00"
data_alteracao: "None"
materia_tags: "eduardo,Humberto Costa"
categoria: "Notícias"
titulo: "Os militantes de Humberto e Eduardo estão se estranhando"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Começou um empurra-empurra entre militantes de Humberto e Eduardo. Eles se estranharam depois que um dos cinco gigantescos balões colocados em Bras?lia Formosa caiu por causa do vento e da chuva.</FONT></P></p>
<p><P><FONT face=Verdana>Lula acabou de chegar.</FONT></P></FONT> </p>
