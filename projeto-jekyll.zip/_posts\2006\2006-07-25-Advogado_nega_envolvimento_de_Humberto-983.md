---
id: 12372156
data_publicacao: "2006-07-25 10:44:00"
data_alteracao: "None"
materia_tags: "Advogados,envolvimento,Humberto Costa"
categoria: "Notícias"
titulo: "Advogado nega envolvimento de Humberto"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do Jornal do Commercio</FONT></P></p>
<p><P><FONT face=Verdana>Defensor do empresário Darcy José Vedoin, denunciado como o cabeça da Máfia das Sanguessugas, e do filho Luiz Antônio Vedoin, o advogado Otto Medeiros afirmou, ontem à noite, ao <B>JC</B><B>, </B></B></I>por telefone, que o ex-ministro da Saúde Humberto Costa não foi citado pelos proprietários da Planan, a empresa que comandava os superfaturamentos nas compras de ambulância, por meio de emendas parlamentares. O dinheiro a mais era repartido com deputados e assessores. “O ex-ministro não foi citado. No depoimento de Luiz Antônio Vedoin não consta que ele tenha afirmado que fez repasse de dinheiro, nem que o ex-ministro tenha facilitado a liberação de recursos do Ministério (da Saúde)???, informou Otto. </FONT></P></p>
<p><P><FONT face=Verdana>O advogado revelou que está no depoimento que “pessoas procuraram os dois empresários se dizendo ligadas ao ex-ministro, mas que não há como se comprovar a ligação (entre as supostas pessoas e Humberto)???. Otto Medeiros afirmou, ainda, que Luiz Antônio foi “bem claro??? no depoimento, revelando que “foi procurar o ex-ministro, sendo bem recebido, mas que ele (Humberto) disse não (à liberação de recursos)???. </FONT></p>
<p><P><FONT face=Verdana>“É extremamente irresponsável se envolver um candidato a governador sem sequer ele ter sido citado???, repudiou Otto, definindo, porém, como precipitada a reação de Humberto ao programa Fantástico, chamando os Vedoin de “réu-confessos???.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><U><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></U></STRONG> reportagem completa (assinates JC e Uol).</FONT></P> </p>
