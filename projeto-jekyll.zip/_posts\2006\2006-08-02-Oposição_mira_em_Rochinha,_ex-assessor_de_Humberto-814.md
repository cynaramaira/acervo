---
id: 12371987
data_publicacao: "2006-08-02 08:38:00"
data_alteracao: "None"
materia_tags: "Humberto Costa,Oposição"
categoria: "Notícias"
titulo: "Oposição mira em Rochinha, ex-assessor de Humberto"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT color=#ff0000></p>
<p><P></FONT>Do<STRONG> Jornal do Commercio</STRONG><BR><BR><FONT face=Verdana>A CPI das Sanguessugas vivencia uma guerra entre governistas e oposição sobre as convocações dos ex-ministros. </FONT></P></p>
<p><P><FONT face=Verdana>Deputados petistas apresentaram requerimento para convocação do ex-ministro da Saúde José Serra, já que se cogita convocar os também ex-ministros da pasta Humberto Costa e Saraiva Felipe. </FONT></P></p>
<p><P><FONT face=Verdana>Do outro lado, o deputado Arnaldo Faria de Sá (PTB-SP) apresentou requerimento para convocar Francisco Rocha, o Rochinha, ex-braço direito de Humberto Costa e que seria o homem responsável pelas liberações de emendas na sua gestão. </FONT></P></p>
<p><P><FONT face=Verdana>Rochinha é amigo do presidente Lula e atualmente é o chefe-de-gabinete do coordenador nacional da campanha da reeleição do presidente. </FONT></P></p>
<p><P><FONT face=Verdana>\"O Rochinha é o cara que fazia o esquema de Humberto Costa e de José Airton Cirilo na Saúde. O governo está tentando e conseguindo controlar as investigações na CPI\", protestou Arnaldo Faria de Sá.</FONT></P> </p>
