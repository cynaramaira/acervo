---
id: 12372406
data_publicacao: "2006-07-18 09:29:00"
data_alteracao: "None"
materia_tags: "Bruno Covas,Rivaldo"
categoria: "Opinião"
titulo: "Aldo estava transtornado e inseguro (Bruno Maranhão/Exclusivo)"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p>&nbsp;</p>
<p><P>Após 38 dias preso, \"sem&nbsp;direito a&nbsp;ler jornais\",&nbsp;o l?der do Movimento de Libertação dos Sem-Terra (MLST), Bruno Maranhão, pernambucano filho de usineiros, decidiu falar sobre o quebra-quebra ocorrido no in?cio de junho na Câmara dos Deputados. Em entrevista exclusiva ao <B>Blog do JC</B>, por telefone, ele responsabiliza Aldo Rebelo e \"a direita do Congresso\" pelas prisões de 612 membros do movimento e pelo \"golpe de m?dia\" que, na opinião dele, pretende aprofundar um processo de criminalização dos movimentos sociais no Brasil. Maranhão antecipa aqui boa parte das explicações que pretende dar nesta terça-feira, às 10h, na entrevista</p>
<p> coletiva que concederá à imprensa.</P></p>
<p><P>Maranhão foi solto no sábado, por ordem da Justiça Federal, com mais 32 integrantes do MLST. Eles estavam presos no Complexo Penitenciário da Papuda, em Bras?lia, e responderão ao processo em liberdade.</P></p>
<p><P>&nbsp;</P><B></p>
<p><P>Blog - O que aconteceu naquele dia?</P></B></p>
<p><P>Agora a gente vai começar a esclarecer o que realmente aconteceu. O que houve foi uma ação com um sentido pac?fico e que teve um incidente num dos portões (da Câmara). A? começaram um processo de criminalização do MLST. Nós t?nhamos 700 pessoas no salão verde e 300 fora da Câmara. Esse pessoal ficou uma hora e meia lá e não quebrou nada. Alguns deputados, como Paulo Rubem (PT-PE), Fernando Ferro (PT-PE), Fernando Gabeira (PV-RJ), Ivan Valente (P-SOL-SP), José Múcio Monteiro (PTB-PE), achavam que eu deveria ir falar com Aldo (Rebelo, presidente da Câmara, do PCdoB-SP), que queria botar a tropa da pol?cia dentro do Congresso. Aldo estava transtornado e inseguro. Ele não teve a tranqüilidade e a firmeza de subir e conversar com as pessoas. Não conseguia ouvir o que eu dizia, que o movimento era pac?fico. Ele estava desesperado e me deu ordem de prisão. Eu disse que não levaria em consideração. Houve uma pressão muito grande em cima de Aldo. Apertaram tanto ele que ele estava quebrado.</P><B></p>
<p><P>Blog - Mas há provas de que o movimento causou o quebra-quebra.</P></B></p>
<p><P>Não, transformaram uma batalha num dos portões do Congresso num golpe de m?dia. Era uma batalha num dos portões do Anexo 2 (da Câmara) que não tinha mais de 15 companheiros nossos.</P><B></p>
<p><P>Blog - Se o quebra-quebra não foi provocado pelo pessoal do movimento, por quem foi?</P></B></p>
<p><P>Houve um enfrentamento jamais programado. Ali não tinha mais de 1%, 1,5% do conjunto de trabalhadores mobilizados em 10 estados da federação. Já havia estudantes no processo de embate com a segurança (do Congresso). Eu estava na sala de Nélson Pellegrino (PT-BA), quando me ligaram dizendo que havia um problema no Anexo 2. Eu disse \"sai dessa confusão dos estudantes e vai para outros portões\". Então me dirigi para o salão verde, onde havia 700 pessoas nossas. ??amos fazer uma cr?tica ao Congresso, cobrar democracia participativa e reforma agrária. Quer?amos que Aldo participasse. Eu tinha marcado com ele uma semana antes para falar do movimento, mas ele não pôde. Se você olhar as fitas vai ver que não tinha mais do que 15 companheiros do movimento.</P><B></p>
<p><P>Blog - O sr. quer dizer então que há uma armação contra o movimento que o sr. dirige?</P></B></p>
<p><P>Se o quarteto mágico não funcionou na seleção, tem um quarteto da direita que está funcionando. É Arthur Virg?lio (PSDB-AM), ??lvaro Dias (PSDB-PR), Jorge Bornhausen (PFL-SC) e Antônio Carlos Magalhães (PFL-BA) (todos senadores). Amanhã nós vamos explicar tudo isso a?. Nós vamos abrir um grande debate na sociedade para explicar isso a?. Nós fomos jogados na cadeia. Prenderam 612 companheiros. Eu só vi isso quando eu estive no golpe do Chile, onde Pinochet botou o pessoal no estádio de futebol.</P><B></p>
<p><P>Blog - A culpa de todo esse episódio foi então de Aldo Rebelo?</P></B></p>
<p><P>Não, a culpa não. A culpa desse episódio, centralmente, é da direita do Congresso. Porque no momento em que eles souberam que a gente ia fazer a ação, o que é que aconteceu? PSDB, PFL, a bancada ruralista...Isso me foi dito por alguns deputados. Eles disseram: \"Bruno não faça o ato agora, não, porque está havendo uma pressão muito grande em cima de Aldo. E a direita é que está lá.\" Eu fui lá conversar, dialogar com ele. Acontece que os caras chegaram a apertar tanto ele que ele já estava quebrado. O que achei ruim dele é de ele não ter, digamos assim, depois feito uma auto-cr?tica. Houve um erro porque o pessoal (do MLST) se envolveu num embate desnecessário. Agora, se você olhar as fitas não tem mais do que 15 companheiros nossos lá. Eu desafio nego mostrar mais do que isso. Como é que, em mil companheiros, 1,5% passa a ser o grande problema? Acho que isso a? é o grande debate da sociedade. Há uma tentativa de criminalização do movimento social, que é evidente.</P><B></p>
<p><P>Blog - E a fita com o pessoal dizendo que deveria quebrar?</P></B></p>
<p><P>Não, a fita não diz isso. Eu não vi a fita. A fita diz que é pra chegar no salão verde (principal salão da Câmara). Tem um documento nosso para Aldo falando que é pac?fica a manifestação nossa. O companheiro que estiver dizendo isso a? ele está contrariando o movimento e a gente vai condenar isso a?. Na fita eu soube que não tem isso. Agora ela está sendo passada centenas de vezes. Mas tem a filmagem que você sabe que é do próprio sistema de câmara que é do Congresso. Então nós vamos pedir per?cia para isso.</P><B></p>
<p><P>Blog - Como o sr. recebeu a not?cia do seu afastamento da direção nacional do PT?</P></B></p>
<p><P>Isso é uma discussão que vou ter. Tenho informações diferentes. Não quero comentar nada agora, só depois de me reunir com a direção. Não quero entrar nessa discussão. Vamos ter um processo de esclarecimentos. Topo deabater com seu Aldo, com quem quiser.</P> </p>
