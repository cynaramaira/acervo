---
id: 12372225
data_publicacao: "2006-07-22 13:20:00"
data_alteracao: "None"
materia_tags: "guerra,jarbas vasconcelos,mendonça"
categoria: "Notícias"
titulo: "Jarbas e Guerra poupam Mendonça dos ataques"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>A estratégia que ficou clara, agora há pouco, na inauguração do comitê da União por Pernambuco, no Recife, é esta:</FONT></P></p>
<p><P><FONT face=Verdana>Mendonça se apresenta como governador, acima de tudo e de todos, aquele que não se envolve com picuinhas eleitorais, com ataques aos adversários. A imagem que se quer dele (os marqueteiros querem) é a do gestor competente e moderno.</FONT></P></p>
<p><P><FONT face=Verdana>Em conversa com Jorge Cavalcanti, repórter do JC, isso ficou ainda mais claro. Mendonça se recusou a fazer qualquer comentário sobre o envolvimento de Humberto Costa (PT) no escândalo das sanguessugas. No discurso que havia feito minutos antes, nem de longe tratou da questão. Não atacou ninguém.</FONT></P></p>
<p><P><FONT face=Verdana>O papel de bater coube principalmente ao senador Sérgio Guerra (PSDB) e ao ex-governador Jarbas Vasconcelos (PMDB).</FONT></P></FONT> </p>
