---
id: 12372025
data_publicacao: "2006-07-31 22:51:00"
data_alteracao: "None"
materia_tags: "Justiça,poderosa,tribunal"
categoria: "Notícias"
titulo: "Um ritual de poder no Tribunal de Justiça"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>A escolha do novo desembargador do Tribunal de Justiça de Pernambuco foi selada numa votação secreta, conduzida pelo presidente da Corte, Fausto Freitas.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Contados os votos dos 33 desembargadores aptos a participar da eleição, veio a surpresa. Venceu Francisco Bandeira.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Bandeira é como um afilhado do senador Marco Maciel (PFL) e sócio do presidente da OAB, Júlio Oliveira.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Ele derrotou Pedro Henrique Alves, ex-assessor de Jarbas Vasconcelos e candidato do governo.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2></FONT></SPAN>&nbsp;</P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2>Quem ficou fora de todo o processo foi Jorge Neves, ex-presidente da Ordem dos Advogados do Brasil em Pernambuco. </FONT></SPAN></P></p>
<p><P><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2>Neves acabou preterido, apesar de ter sido o mais bem votado na eleição direta da OAB e na secreta do TJ.</FONT></SPAN></P></p>
<p><P><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\;</p>
<p> mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2>Para entender toda essa história, clique <STRONG><EM><A href=\"https://jc3.uol.com.br/blogs/jc/2006/07/31/index.php#385\">aqui</A></EM></STRONG>.</FONT></SPAN></P> </p>
