---
id: 12372163
data_publicacao: "2006-07-24 19:45:00"
data_alteracao: "None"
materia_tags: "eduardo,encontro"
categoria: "Notícias"
titulo: "O misterioso encontro com Eduardo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>O <STRONG>Blog</STRONG> está no Centro Social da Soledade, na Boa Vista, Recife, acompanhando um encontro popular com Eduardo Campos, candidato ao governo de Pernambuco pelo PSB.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Já perguntamos a&nbsp;20 pessoas o que é que elas estão fazendo ali. Nenhuma soube responder. A melhor explicação até agora foi a de um casal de Piedade: “Somos amigos da fam?lia de João Fernando Coutinho???.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>A de uma moça do bairro de Beberibe foi mais sincera: “Tem transporte de ida e volta, a gente veio???.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Todos eles sabiam apenas que iriam encontrar e ouvir Eduardo. Nada mais. Tem gente de Aguazinha e Vasco da Gama também. Há&nbsp;ônibus e uma van fazendo o leva-e-traz.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><o:p></o:p></FONT>&nbsp;</P><FONT face=Verdana><o:p></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Coutinho é deputado estadual e candidato à reeleição. Foi ele quem organizou o evento, com a ajuda da irmã, Lua.</FONT></P></o:p></FONT></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><o:p></o:p></FONT>&nbsp;</P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Os entrevistados asseguram, porém, que não receberam nada mais que o transporte de ida e volta e o cafezinho oferecido no local.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2></FONT></SPAN>&nbsp;</P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2>Oficialmente, o encontro é uma reunião do candidato com lideranças comunitárias da Região Metropolitana do Recife.</FONT></SPAN></P></p>
<p><P><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2>Eduardo acabou de chegar.</FONT></SPAN></P> </p>
