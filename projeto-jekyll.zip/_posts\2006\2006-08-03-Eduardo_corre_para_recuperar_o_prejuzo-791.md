---
id: 12371964
data_publicacao: "2006-08-03 12:27:00"
data_alteracao: "None"
materia_tags: "correios,eduardo"
categoria: "Notícias"
titulo: "Eduardo corre para recuperar o preju?zo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>O PSB e sua equipe da campanha ao governo de Pernambuco fazem um esforço adicional para tentar recuperar os preju?zos causados pela primeira pesquisa Ibope/TV Globo, divulgada anteontem.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>A pesquisa mostrou Eduardo Campos em terceiro lugar, dez pontos percentuais abaixo de Humberto Costa (PT) e 18&nbsp;atrás de Mendonça Filho (PFL).</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2>Ouça o que disse mais cedo o coordenador de comunicação da campanha de Eduardo, o jornalista Evaldo Costa, em entrevista a Geraldo Freire, na Rádio Jornal.</FONT></SPAN> </p>
