---
id: 12371980
data_publicacao: "2006-08-02 17:14:00"
data_alteracao: "None"
materia_tags: "Queixas"
categoria: "Notícias"
titulo: "Muito estranha a queixa do PSB"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 10pt\"><FONT face=Verdana><?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 10pt\"><FONT face=Verdana>Questionar os resultados da pesquisa Ibope/TV Globo é normal. Todo mundo ficou realmente surpreso com os números.<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 10pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 10pt\"><FONT face=Verdana>O problema é que o PSB está se queixando de o Ibope ter colocado seu candidato a governador apenas como Eduardo, e não como Eduardo Campos.<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 10pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 10pt\"><FONT face=Verdana>Ora, toda a propaganda dele está centrada no nome, sem sobrenome: “É Eduardo??? e “Lula É Eduardo???, por exemplo. O candidato também foi registrado apenas como Eduardo no Tribunal Regional Eleitoral. <o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 10pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 10pt\"><FONT face=Verdana>Agora está correndo para incluir o Campos nos registros do Tribunal. Fez este pedido&nbsp;nesta tarde.<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 10pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 10pt\"><FONT face=Verdana>Isso, enfim, é o que se chama de o <EM>jus esperniandi</EM> do PSB. O velho e bom direito de espernear.<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 10pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 10pt\"><FONT face=Verdana><STRONG>Leia&nbsp;nota&nbsp;abaixo para entender o caso</STRONG>.<o:p></o:p></FONT></SPAN></P> </p>
