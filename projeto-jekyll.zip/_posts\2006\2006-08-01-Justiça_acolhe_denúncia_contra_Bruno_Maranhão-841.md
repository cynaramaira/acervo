---
id: 12372014
data_publicacao: "2006-08-01 08:49:00"
data_alteracao: "None"
materia_tags: "Bruno Covas, Contran, Justiça"
categoria: "Notícias"
titulo: "Justiça acolhe denúncia contra Bruno Maranhão"
sutia: "None"
chapeu: "None"
autor: "jamildo"
imagem: "None"
---
<p>Do Jornal do Commercio</p>
<p>A Justi&ccedil;a Federal acolheu a den&uacute;ncia apresentada pelo Minist&eacute;rio P&uacute;blico Federal e instaurou a&ccedil;&atilde;o penal na qual 116 militantes do Movimento pela Liberta&ccedil;&atilde;o dos Sem Terra (MLST) s&atilde;o acusados de praticar crime pol?tico, com base na Lei de Seguran&ccedil;a Nacional, al&eacute;m de les&atilde;o corporal, dano contra o patrim&ocirc;nio p&uacute;blico e resist&ecirc;ncia a obedecer a ato legal de servidor p&uacute;blico.</p>
<p>A decis&atilde;o, do juiz Ricardo Augusto Soares Leite, da 10&ordf; Vara da Justi&ccedil;a Federal em Bras?lia, &eacute; de 24 de julho. As penas para os crimes dos quais os militantes s&atilde;o acusados podem chegar a seis anos de pris&atilde;o.</p>
<p>&nbsp;</p>
<p>O principal l?der do movimento, Bruno Maranh&atilde;o, dirigente do PT nacional que foi afastado do cargo (mobiliza&ccedil;&atilde;o popular) ap&oacute;s o epis&oacute;dio, foi apontado como o mentor intelectual da a&ccedil;&atilde;o que levou o grupo a invadir a C&acirc;mara dos Deputados, em 6 de junho. Se condenado pela Justi&ccedil;a, essa acusa&ccedil;&atilde;o pode levar ao agravamento de sua pena.</p>
