---
id: 12372075
data_publicacao: "2006-07-29 08:15:00"
data_alteracao: "None"
materia_tags: "None"
categoria: "Notícias"
titulo: ""
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana><STRONG>\"Gente que não botava nem gasolina nas viaturas policiais (quando era governo) vem falar de segurança? Não dá para discutir. Nesse tom, não dá para discutir\"</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Governador Mendonça Filho, rebatendo cr?ticas de Eduardo Campos sobre as falhas na segurança pública</FONT></P> </p>
