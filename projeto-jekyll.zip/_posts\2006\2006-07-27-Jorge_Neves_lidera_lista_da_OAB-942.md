---
id: 12372115
data_publicacao: "2006-07-27 06:40:00"
data_alteracao: "None"
materia_tags: "jorge jesus,liderança indígena,Lista,Mozart Neves"
categoria: "Notícias"
titulo: "Jorge Neves lidera lista da OAB"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>A OAB de Pernambuco concluiu a apuração dos votos para escolha dos seis nomes que serão encaminhados ao Tribunal de Justiça e, depois de selecionados três, ao governador Mendonça Filho para nomeação do novo desembargador estadual.</FONT></P></p>
<p><P><FONT face=Verdana>Veja os resultados oficiais:</FONT></P></p>
<p><P><FONT face=Verdana>1º Jorge Neves Batista&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1.381 </FONT></P></p>
<p><P><FONT face=Verdana>2º Francisco Bandeira&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1.264</FONT></P></p>
<p><P><FONT face=Verdana>3º Braga Sá&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1.102</FONT></P></p>
<p><P><FONT face=Verdana>4º Edgar Moury Fernandes&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1.085</FONT></P></p>
<p><P><FONT face=Verdana>5º Reinaldo Gueiros&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1.049</FONT></P></p>
<p><P><FONT face=Verdana>6º Pedro Henrique Alves&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 999</FONT></P></p>
<p><P><FONT face=Verdana>------------</FONT></P></p>
<p><P><FONT face=Verdana>7º Carlos Gil Rodrigues&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 948</FONT></P></p>
<p><P><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P><FONT face=Verdana>A lista sêxtupla passará por uma votação no plenário do Tribunal de Justiça, na próxima semana. Os desembargadores escolherão três nomes para Mendonça Filho nomear um.</FONT></P></p>
<p><P><FONT face=Verdana>Os favoritos agora são:</FONT></P><B></p>
<p><P><FONT face=Verdana>Pedro Henrique</FONT></P></B></p>
<p><P><FONT face=Verdana>Candidato do ex-governador Jarbas Vasconcelos, que ligou pessoalmente para algumas pessoas pedindo voto.</FONT></P><B></p>
<p><P><FONT face=Verdana>Francisco Bandeira</FONT></P></B></p>
<p><P><FONT face=Verdana>Nome ligado ao senador Marco Maciel, que mantém fortes laços com o Judiciário, e defendido pelo atual presidente da OAB, Júlio Oliveira.</FONT></P><B></p>
<p><P><FONT face=Verdana>Jorge Neves</FONT></P></B></p>
<p><P><FONT face=Verdana>Primeiro colocado, ex-presidente da OAB por três mandatos e de fam?lia com tradição no meio jur?dico.</FONT></P></p>
<p><P><FONT face=Verdana>As surpresas na eleição direta realizada pela OAB foram a sexta colocação de Pedro Henrique e a sétima de Carlos Gil – que era dado como certo entre os seis.</FONT></P> </p>
