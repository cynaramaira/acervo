---
id: 12372065
data_publicacao: "2006-07-31 08:40:00"
data_alteracao: "None"
materia_tags: "Contran,jarbas vasconcelos,Torcida Jovem"
categoria: "Notícias"
titulo: "Ela é bonita, jovem e contra Jarbas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Cláudia Vasconcelos</STRONG><BR>Repórter do Jornal do Commercio</FONT></P></p>
<p><P><FONT face=Verdana>Ela é uma das mais jovens candidatas a deputada estadual nestas eleições, milita pelo PSTU (Partido socialista dos Trabalhadores Unificado) há dois anos e tem como principal bandeira a educação pública de qualidade.</FONT></P></p>
<p><P><FONT face=Verdana>Estudante de geografia na Universidade Federal de Pernambuco, formada em jornalismo pela Universidade Católica, declarou modestos R$ 5 mil como gastos de campanha ao Tribunal Regional Eleitoral (TRE). </FONT></P></p>
<p><P><FONT face=Verdana>A candidatura de Renata Pontes de Queiroz, 22 anos recém completados, passaria despercebida não fosse um detalhe: ela é filha de Lúcia Pontes, dama-de-ferro durante os sete anos e três meses do governo Jarbas Vasconcelos e atual coordenadora-geral da campanha do peemedebista ao Senado. </FONT></P></p>
<p><P><FONT face=Verdana>O fato de abraçarem partidos de ideais totalmente opostos já rendeu dissabores pol?ticos, mas hoje não é mais problema, garante a jovem.</FONT></P></p>
<p><P><FONT face=Verdana>A pol?tica sempre esteve no cotidiano da fam?lia de Renata. Além da mãe, o pai, Ricardo Queiroz, sempre atuou na militância do PT e já foi secretário de Serviços Públicos da Prefeitura do Recife, na gestão de João Paulo. </FONT></P></p>
<p><P><FONT face=Verdana>Por causa disso, sempre nutriu simpatia pelo PT, e chegou a se engajar nas campanhas de João Paulo e do presidente Lula. Na Universidade Católica, onde ingressou em 2002, entrou para o movimento estudantil, causa que defende até hoje. A filiação ao PSTU veio dois anos mais tarde.</FONT></P></p>
<p><P><FONT face=Verdana>Renata faz questão de evitar, entretanto, qualquer comparação ou vinculação com a mãe e o pai no terreno pol?tico. </FONT></P></p>
<p><P><FONT face=Verdana>\"No começo, principalmente, minha decisão rendeu alguns problemas com minha mãe, mas com o tempo nossa relação amadureceu. Discordo completamente das idéias pol?ticas dela, mas tenho total entendimento de que não posso interferir na vida dela. E ela também não pode na minha. Minha diferença com minha mãe não é pessoal, é pol?tica\", ressaltou.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinante JC e UOL).</FONT></P> </p>
