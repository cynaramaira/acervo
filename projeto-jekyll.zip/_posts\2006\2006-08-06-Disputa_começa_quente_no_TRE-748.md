---
id: 12371921
data_publicacao: "2006-08-06 08:32:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Disputa começa quente no TRE"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Clóvis Andrade</STRONG><BR>Repórter de Pol?tica do JC</FONT></P></p>
<p><P><FONT face=Verdana>A campanha eleitoral deste ano está mais acirrada do que a disputa de 2002, tanto nas ruas como no Tribunal Regional Eleitoral (TRE). Se em seus discursos de campanha, ou por meio dos jornais e demais meios de comunicação, os candidatos não têm economizado ataques a seus adversários, o cenário não é diferente nas vias judiciais. </FONT></P></p>
<p><P><FONT face=Verdana>Do in?cio do ano até a última terça-feira, 1º de agosto, já haviam sido protocoladas na corte 18 representações, das quais 15 contestando, direta ou indiretamente, condutas dos três principais postulantes ao governo: Mendonça Filho (PFL), Humberto Costa (PT) e Eduardo Campos (PSB) ou de seus aliados. </FONT></P></p>
<p><P><FONT face=Verdana>Os números superam aqueles registrados no mesmo per?odo de 2002, quando foram contabilizadas 11 representações, mas apenas seis atingindo candidatos majoritários.</FONT></P></p>
<p><P><FONT face=Verdana>O que também impressiona é a quantidade de pedidos de investigação judicial eleitoral movidos até a semana passada. Foram oito, e somente uma não tem como alvo um dos três candidatos maiores ou seus partidos. Pode parecer pouco, mas não é, se comparado com 2002, quando as investigações promovidas pelo TRE não passaram de cinco, só que durante todo o ano e sobre qualquer assunto.</FONT></P></p>
<p><P><FONT face=Verdana>Leia o <STRONG><EM><A href=\"https://jc3.uol.com.br/jornal/\" target=_blank>texto</A></EM></STRONG> completo em Pol?tica, no JC (assinantes JC e UOL).</FONT></P> </p>
