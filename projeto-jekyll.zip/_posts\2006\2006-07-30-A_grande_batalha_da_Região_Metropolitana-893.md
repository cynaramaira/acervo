---
id: 12372066
data_publicacao: "2006-07-30 09:08:00"
data_alteracao: "None"
materia_tags: "Lagoa Grande,Metropolitana,Região"
categoria: "Notícias"
titulo: "A grande batalha da Região Metropolitana"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Sérgio Montenegro Filho<BR></STRONG></FONT><FONT face=Verdana>Repórter especial do JC</FONT></P></p>
<p><P><FONT face=Verdana>Apesar de oficializada desde o dia 6 de julho, somente na semana passada a campanha eleitoral em Pernambuco pegou fogo, alimentado pelo combust?vel da estratégia comum aos três principais candidatos ao governo do Estado de concentrar esforços no Recife e Região Metropolitana. </FONT></P></p>
<p><P><FONT face=Verdana>Bem mais que o simples interesse nos votos dos 42% do eleitorado concentrado nessa área, os candidatos – e sobretudo seus marqueteiros – estão de olho no efeito de \"pulverização\" que a campanha na RMR exerce sobre o restante do Estado. </FONT></P></p>
<p><P><FONT face=Verdana>Por isso mesmo, ativaram todos os mecanismos dispon?veis em cada coligação para preencher o ex?guo espaço composto por apenas 14, das 184 cidades pernambucanas, que integram o pol?gono denominado Grande Recife.</FONT></P></p>
<p><P><FONT face=Verdana>Quem bateu o centro da peleja pelos votos da RMR foi o governador Mendonça Filho (PFL). Ou melhor, seus aliados. Candidato da União por Pernambuco, ele tem reservado apenas as noites para fazer campanha, dedicando-se à administração do Estado pela manhã e à tarde. </FONT></P></p>
<p><P><FONT face=Verdana>No entanto, o fato de Mendonça ter recebido 33% das citações na última pesquisa de intenção de votos feita pelo Instituto Vox Populi e publicada com exclusividade pelo</p>
<p> JC no dia 16 de julho – contra 26% de Humberto Costa (PT/Melhor pra Pernambuco) e 20% de Eduardo Campos (PSB/Frente Popular de Pernambuco) – levou seus os aliados do governador-candidato a buscar estratégias para consolidar a liderança.</FONT></P></p>
<p><P><FONT face=Verdana>No in?cio da semana passada, o ex-governador Jarbas Vasconcelos (PMDB) – principal liderança da União por Pernambuco na Região Metropolitana – reuniu no comitê da coligação cerca de 200 representantes do movimento popular na área, fiéis a ele, e disparou recomendações expressas sobre a necessidade de total empenho para garantir a vitória do seu candidato.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinantes JC e UOL).</FONT></P> </p>
