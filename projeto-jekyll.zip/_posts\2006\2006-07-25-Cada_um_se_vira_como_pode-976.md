---
id: 12372149
data_publicacao: "2006-07-25 18:58:00"
data_alteracao: "None"
materia_tags: "como jogar,escada"
categoria: "Notícias"
titulo: "Cada um se vira como pode"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Limitados pela nova legislação, os candidatos fazem o que podem para chegar ao eleitor.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Eduardo Campos ressuscitou agora há pouco o velho caixote, bastante utilizado no passado, quando a oposição era pobre e sem estrutura.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2>Sobre a \"tribuna 40\", o candidato do PSB ao governo de Pernambuco fez um discurso relâmpago na Praça da Independência, mais conhecida como Pracinha do Diário, no centro do Recife.</FONT></SPAN> </p>
