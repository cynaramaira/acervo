---
id: 12372071
data_publicacao: "2006-07-29 10:30:00"
data_alteracao: "None"
materia_tags: "None"
categoria: "Notícias"
titulo: ""
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana><STRONG>\"Doutor Arraes está sepultado mas ainda é puxador de votos. Eu e ele somos os mitos do Recife\" </STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Prefeito Newton Carneiro, entusiasmado com a caminhada de Eduardo Campos em Jaboatão</FONT></P> </p>
