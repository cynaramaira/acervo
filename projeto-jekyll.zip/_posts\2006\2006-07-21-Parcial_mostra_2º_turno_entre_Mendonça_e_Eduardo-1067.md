---
id: 12372240
data_publicacao: "2006-07-21 16:49:00"
data_alteracao: "None"
materia_tags: "eduardo,entrega,mendonça,Mostra,Saturno"
categoria: "Notícias"
titulo: "Parcial mostra 2º turno entre Mendonça e Eduardo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Você acha que haverá segundo turno nas eleições de Pernambuco?</FONT></P></p>
<p><P><FONT face=Verdana>Já foram registrados 1.467 votos. Veja os resultados acumulados desde ontem.</FONT></P></FONT><FONT size=2></p>
<p><P><FONT face=Verdana>Sim, entre Mendonça e Eduardo&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 71% (1.038 votos)</FONT></P></p>
<p><P><FONT face=Verdana>Sim, entre Mendonça e Humberto&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4%&nbsp;&nbsp;&nbsp;&nbsp; (62 votos)</FONT></P></p>
<p><P><FONT face=Verdana>Sim, entre Eduardo e Humberto&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 17%&nbsp;&nbsp;&nbsp; (255 votos)</FONT></P></FONT><FONT size=2></FONT><FONT size=2></p>
<p><P><FONT face=Verdana>Não&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; 8%&nbsp;&nbsp;&nbsp; (112 votos)</FONT></P></p>
<p><P><FONT face=Verdana>Vote, dê sua opinião na coluna ao lado.</FONT></P></FONT> </p>
