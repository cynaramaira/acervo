---
id: 12371923
data_publicacao: "2006-08-06 06:00:00"
data_alteracao: "None"
materia_tags: "cerveja,Filme,Miguel Arraes"
categoria: "Notícias"
titulo: "Veja trechos do filme Miguel Arraes - O guerreiro do povo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><span style="font-family: Arial;"><span style="font-family: Verdana;">Por <strong>Paulo S&eacute;rgio Scarpa</strong><br /></span><span style="font-family: Verdana;">Colunista do Jornal do Commercio</span></span></p>
<p><span style="font-family: Verdana;">O DVD Miguel Arraes - O guerreiro do povo come&ccedil;a com uma confiss&atilde;o: "Meu objetivo sempre foi servir &agrave; popula&ccedil;&atilde;o nas suas necessidades", afirma o ex-governador. E termina com a cena do enterro, no Cemit&eacute;rio de Santo Amaro, com o caix&atilde;o aplaudido pela multid&atilde;o. </span></p>
<p><span style="font-family: Verdana;">Na trilha sonora, o lamento: "Volta, volta, Arraes". Entre a primeira e a &uacute;ltima, trechos de discursos e de entrevistas em Paris; as tr&ecirc;s campanhas vitoriosas para o governo do Estado; cenas da pris&atilde;o no Pal&aacute;cio do Governo, em abril de 1964; o retorno ao Recife com a anistia e o grande com?cio na Praia de Boa Viagem, em 1979; a volta &agrave; Ilha de Fernando de Noronha, j&aacute; governador pela segunda vez, em 1987, onde esteve preso antes de seguir para o ex?lio de 14 anos na Arg&eacute;lia. </span></p>
<p><span style="font-family: Verdana;">E a frase que se negou a ser um slogan, se transformou numa marca: "Eu tenho apenas duas m&atilde;os e o sentimento do mundo e certeza renovada na capacidade do povo de fazer hist&oacute;ria". </span></p>
<p><span style="font-family: Verdana;">O document&aacute;rio com 43 minutos foi dirigido por Andr&eacute; Salles e Paulo Henrique Fontenelle, com a colabora&ccedil;&atilde;o do diretor e filho Guel Arraes. E tem narra&ccedil;&atilde;o do ator Jos&eacute; Wilker, que participou na d&eacute;cada de 60 do Movimento de Cultura Popular (MCT), criado por Arraes quando na Prefeitura do Recife</span></p>
<p>(eleito em 1959) e que se estenderia por todo Pernambuco, revolucionando o ensino de uma forma nunca vista no Brasil.</p>
<p><span style="font-family: Verdana;">Leia <strong><em><a href="http://fivenews.sjcc.com.br/https:/jc3.uol.com.br/jornal/">texto</a></em></strong> completo em Pol?tica, no JC (assinantes JC e UOL).</span></p>
