---
id: 12372079
data_publicacao: "2006-07-30 09:27:00"
data_alteracao: "None"
materia_tags: "Colégio Salesiano"
categoria: "Colunistas"
titulo: "E a? ô meu freguês:/Mussarela ou calabresa? /
 Allan Sales"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por </FONT><STRONG><FONT face=Verdana>Allan Sales<BR></FONT></STRONG><A href=\"mailto:allancariri@ig.com.br\"><FONT face=Verdana>allancariri@ig.com.br</FONT></A></P></p>
<p><P><BR><FONT face=Verdana>(1)<BR><BR>Descobriram a mutreta<BR>Mas puseram vaselina<BR>Será esta nossa sina?<BR>Deputados de veneta<BR>Caixa dois e a mala preta<BR>E muita da safadeza<BR>Canalhice e esperteza<BR>Quando será nossa vez<BR>E a? ô meu freguês:<BR>Mussarela ou calabresa?</FONT></P></p>
<p><P><FONT face=Verdana>(2)<BR><BR>É um jogo conhecido<BR>Chamam corporativismo<BR>E sem noção de civismo<BR>O eleitor iludido<BR>Esse mundo está perdido<BR>E fazem sem sutileza<BR>Eita turminha coesa<BR>Até dancinha se fez<BR>E a? ô meu freguês:<BR>Mussarela ou calabresa?</FONT></P></p>
<p><P><FONT face=Verdana>(3)<BR><BR>CPI pra que então?<BR>A comissão indicar<BR>Eles não querem cassar<BR>O povo fica na mão<BR>Quem pegou o mensalão<BR>Escapou ô que beleza<BR>Acumulando riqueza<BR>Ali só dançaram três<BR>E a? ô meu freguês:<BR>Mussarela ou calabresa?</FONT></P></p>
<p><P><FONT face=Verdana>(4)<BR><BR>Esse povo arrumado<BR>Deputado federal<BR>Senador e coisa e tal<BR>Tem muito cabra safado<BR>O eleitor enganado<BR>Não vê ali a justeza<BR>Pois já puseram na mesa<BR>Como um garçom bem cortês<BR>E a? ô meu freguês:<BR>Mussarela ou calabresa?</FONT></P></p>
<p><P><FONT face=Verdana>(5)<BR><BR>E assim nós caminhamos<BR>No Brasil do populismo<BR>Parlamento com cinismo<BR>Assistimos e enojamos<BR>E assim pra onde vamos?<BR>Vamos fazer a limpeza<BR>E varrer essa torpeza<BR>Tamanha desfaçatez<BR>E a? ô meu freguês:<BR>Mussarela ou calabresa?</FONT></P></p>
<p><P><FONT face=Verdana>(6)<BR><BR>Assim a pirataria<BR>Continua em Bras?lia<BR>Parlamento é fam?lia?<BR>É máfia ou confraria?<BR>A geral patifaria<BR>A moral não é acesa<BR>O povo na incerteza<BR>Pois já é morta a Inês<BR>E a? ô meu freguês:<BR>Mussarela ou calabresa?</FONT></P></p>
<p><P><FONT face=Verdana>(7)<BR><BR>Armação de gente escrota<BR>Canalhas e vigaristas<BR>E não votam ali nas vistas<BR>Secreto: gente marota<BR>Que escrotidão da gota<BR>E na maior ligeireza<BR>Mas podem ter a surpresa<BR>A ilusão se desfez<BR>E a? ô meu freguês:<BR>Mussarela ou calabresa?</FONT></P></p>
<p><P><FONT face=Verdana>(8)<BR><BR>O voto em nossa mão<BR>Cidadão é eleitor<BR>Detona tal estupor<BR>Se escuta voz da razão<BR>Aposenta tal poltrão<BR>O voto sua defesa<BR>Façamos a correnteza<BR>Em busca da honradez<BR>E a? ô meu freguês:<BR>Mussarela ou calabresa?</FONT></P></p>
<p><P><FONT face=Verdana>(9)<BR><BR>Meu eleitor brasileiro<BR>O fim do voto secreto<BR>No parlamento incorreto<BR>Só é bom para matreiro<BR>Votemos no verdadeiro<BR>Aquele que tem a nobreza<BR>Representa com inteireza<BR>O voto de vosmicês<BR>E a? ô meu freguês:<BR>Mussarela ou calabresa?</FONT></P></p>
<p><P><FONT face=Verdana>(10)<BR><BR>E assim eu me despeço<BR>Do pessoal meu leitor<BR>Do cordel que tem valor<BR>Por ele me interesso<BR>O folheto que impresso<BR>Pra falar dessa baixeza<BR>Atitude de impureza<BR>De caráter a pequenez<BR>E a? ô meu freguês:<BR>Mussarela ou calabresa?</FONT></P> </p>
