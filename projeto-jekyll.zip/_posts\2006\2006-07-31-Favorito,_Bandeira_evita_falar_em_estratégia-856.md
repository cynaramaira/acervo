---
id: 12372029
data_publicacao: "2006-07-31 18:50:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Favorito, Bandeira evita falar em estratégia"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=\"Times New Roman\"></p>
<p><P><FONT face=Verdana>Francisco Bandeira ficou em segundo lugar nas duas primeiras etapas de escolha do novo desembargador do Tribunal de Justiça.</FONT></P></p>
<p><P><FONT face=Verdana>Agora é o favorito por causa das ligações com o PFL do governador Mendonça Filho, que nomeará o próximo membro do TJ, a partir da lista tr?plice eleita agora há pouco. Bandeira é como um afilhado do senador Marco Maciel.</FONT></P></p>
<p><P><FONT face=Verdana>Veja o que ele disse após acompanhar o processo de votação no TJ:</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Como o sr. recebe esse resultado?</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Recebo com muito orgulho e satisfação. Agora começa a terceira fase. Fausto Freitas (presidente do Tribunal) vai preparar a lista. Jorge Neves e Edgar Moury são excelentes colegas.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>E qual a estratégia para ser o nomeado?</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>A estratégia é secreta. Nenhum candidato tem o direito de ter expectativa. Eu desejava ter uma boa votação e tive.</FONT></P></FONT> </p>
