---
id: 12372019
data_publicacao: "2006-08-01 08:59:00"
data_alteracao: "None"
materia_tags: "partidos liberais"
categoria: "Notícias"
titulo: "Partidos ignoram escândalos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Os escândalos de caixa 2 de campanha desvendados no ano passado e o clamor popular por transparência no processo eleitoral deste ano parecem não ter sensibilizado os diretórios partidários em Pernambuco. </FONT></P></p>
<p><P><FONT face=Verdana>A Secretaria Judiciária do Tribunal Regional Eleitoral (TRE) divulgou ontem uma lista mostrando que a maioria das siglas descumpriu, em junho, a determinação legal de prestar contas do balancete mensal, discriminando suas receitas, gastos, créditos e débitos no per?odo. </FONT></P></p>
<p><P><FONT face=Verdana>Apenas 13 dos 29 partidos disponibilizaram as informações à corte, para que fossem divulgadas na internet.</FONT></P></p>
<p><P><FONT face=Verdana>Entre os inadimplentes estão o PT, PSB, PMDB e PTB, alguns dos maiores partidos no Estado.</FONT></P></p>
<p><P><SPAN style=\"FONT-SIZE: 10pt; FONT-FAMILY: Verdana; mso-bidi-font-family: Arial\">Leia <EM><B><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></B></EM> o texto completo (assinantes JC e UOL).<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></SPAN></P> </p>
