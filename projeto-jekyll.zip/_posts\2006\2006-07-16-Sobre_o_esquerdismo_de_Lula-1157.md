---
id: 12372330
data_publicacao: "2006-07-16 16:33:00"
data_alteracao: "None"
materia_tags: "Lula"
categoria: "Notícias"
titulo: "Sobre o esquerdismo de Lula"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>O deputado Renildo Calheiros e a prefeita Luciana Santos estão tentando&nbsp;traduzir a frase \"Nunca fui um esquerdista\", de Lula. Disseram há pouco a Clóvis Andrade, repórter de Pol?tica do JC, que o presidente falou como estadista, que apenas lembrou não ter origem na esquerda, mas no movimento sindical, e que governa para todos. Faz algum sentido. Renildo e Luciana estão em Goiana lutando com unhas e dentes para eleger o candidato a prefeito do partido deles, Henrique Fenelon (PCdoB), que está governando interinamente a cidade. Mais cedo, Fenelon foi duramente criticado pela ju?za eleitoral Mariza Silva Borges por fazer campanha e boca de urna.</P></FONT> </p>
