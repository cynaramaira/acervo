---
id: 12372021
data_publicacao: "2006-07-31 21:07:00"
data_alteracao: "None"
materia_tags: "Papa Francisco,teste"
categoria: "Notícias"
titulo: "Este é Francisco Bandeira de Mello"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p> </p>
