---
id: 12371931
data_publicacao: "2006-08-04 16:13:00"
data_alteracao: "None"
materia_tags: "geraldo Alckmin,Região"
categoria: "Notícias"
titulo: "Alckmin recebido por caciques da região"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Estão lá no centro de convenções, em Olinda, para ouvi-lo falar sobre um novo Nordeste: </FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><STRONG>Os tucanos</STRONG> Tasso Jereissati, Lúcio Alcântara e Cássio Cunha Lima.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><STRONG>Dos pefelistas</STRONG>, apareceram Marco Maciel, Antônio Carlos Magalhães, Paulo Souto, César Borges, João Alves e José Agripino Maia,</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><STRONG>Dos radicais livres</STRONG>, só Itamar Franco (ex-PMDB), seu braço direito Henrique Heagreves e o deputado Roberto Freire (PPS).</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Sim, claro, também apareceram o governador Mendonça Filho (PFL) e o ex Jarbas Vasconcelos (PMDB). </FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana></FONT>&nbsp;</P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Dez horas depois de Alckmin ter desembarcado em Pernambuco, eles foram lá ouvi-lo.</FONT></P> </p>
