---
id: 12372036
data_publicacao: "2006-07-31 15:23:00"
data_alteracao: "None"
materia_tags: "entrega,geraldo Alckmin,Lula,Saturno"
categoria: "Notícias"
titulo: "Internautas apostam no 2º turno entre Lula e Alckmin"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>É o que mostra resultado parcial da enquete realizada pelo <STRONG>Blog</STRONG>. Já foram registrados 262 votos. Veja os números:</FONT></P></p>
<p><P><FONT face=Verdana>Você acha que haverá segundo turno na eleição para presidente da República?</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Sim, entre Lula e Alckmin</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 126 (48%)</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Sim, entre Lula e Helo?sa Helena</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 43 (16%)</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Não</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;93 (35%)</FONT></P></p>
<p><P><FONT face=Verdana>Dê sua opinião, vote na coluna ao lado.</FONT></P> </p>
