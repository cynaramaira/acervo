---
id: 12372086
data_publicacao: "2006-07-30 11:10:00"
data_alteracao: "None"
materia_tags: "blogs jc,estreia,Frente Popular,Poesia"
categoria: "Notícias"
titulo: "Blog estréia seção sobre poesia popular"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>O Blog publica a partir de hoje uma seção semanal - de in?cio, aos domingos - dedicada à literatura de cordel, principalmente àqueles cordéis que tratam de pol?tica e de eleições. </FONT></P></p>
<p><P><FONT face=Verdana>Os folhetos publicados aqui vão ser selecionados pela jornalista e pesquisadora Maria Alice Amorim, especialista no assunto e pós-graduanda em comunicação e semiótica na PUC de São Paulo.</FONT></P></p>
<p><P><FONT face=Verdana>Para começar, publicamos abaixo um artigo de Alice sobre a história da literatura de cordel e como ela se mantém vigorosa e em ebulição, apesar de tantas vezes terem anunciado seu fim.</FONT></P></p>
<p><P><FONT face=Verdana>Nesta estréia, publicamos também três folhetos do músico, poeta e compositor Allan Sales. </FONT></P></p>
<p><P><FONT face=Verdana>Sales é natural do Crato (CE), radicado no Recife desde 1969 e há nove anos dedica-se ao cordel. Publicou mais de 230 textos sobre os mais variados assuntos, sendo os de humor e pol?ticos seus preferidos. O poeta é também membro e fundador da União dos Cordelistas de Pernambuco.</FONT></P></p>
<p><P><FONT face=Verdana>Boa leitura.</FONT></P> </p>
