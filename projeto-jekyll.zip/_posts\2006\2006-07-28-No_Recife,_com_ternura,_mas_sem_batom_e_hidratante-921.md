---
id: 12372094
data_publicacao: "2006-07-28 16:56:00"
data_alteracao: "None"
materia_tags: "Recife"
categoria: "Notícias"
titulo: "No Recife, com ternura, mas sem batom e hidratante"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Let?cia Lins, repórter de O Globo no Recife, ficou curiosa&nbsp;para saber o que HH carrega na mala dela nessas viagens pelo Brasil.</FONT></P></p>
<p><P><FONT face=Verdana>HH: \"Ah, um m</FONT><FONT face=Verdana>onte de blusinha branca, um ferrinho de passar pra nao dar trabalho a ninguém e essas coisas de mulher: xampu, sabonete, essas coisas\"</FONT></P></p>
<p><P><FONT face=Verdana>Let?cia: \"Mas nem um batonzinho, um hidratante?\"</FONT></P></p>
<p><P><FONT face=Verdana>HH: \"Não, eu esqueci. V</FONT><FONT face=\"Times New Roman\"><FONT face=Verdana>ou ficar oito dias fora de casa. Eu sempre ando com mochila nas costas, mas o meu filho viajou com minha mochila maior e ai eu tive que vir com a dele. Levo minhas coisas de trabalho, muita planilha da CPI.\"</FONT></FONT></P></p>
<p><P><FONT face=\"Times New Roman\"><FONT face=Verdana>HH percorreu hoje algumas favelas da cidade.</FONT></P></FONT> </p>
