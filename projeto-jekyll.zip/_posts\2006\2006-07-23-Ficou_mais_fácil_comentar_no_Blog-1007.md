---
id: 12372180
data_publicacao: "2006-07-23 15:33:00"
data_alteracao: "None"
materia_tags: "blogs jc,LotoFácil"
categoria: "Notícias"
titulo: "Ficou mais fácil comentar no Blog"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=Verdana>Fizemos mudanças no cadastro para simplificar o acesso àqueles que quiserem comentar not?cias postadas aqui. </FONT></p>
<p><P><FONT face=Verdana>Deixe seu comentário.</FONT></P> </p>
