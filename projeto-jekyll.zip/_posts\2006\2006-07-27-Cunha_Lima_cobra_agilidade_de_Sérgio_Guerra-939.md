---
id: 12372112
data_publicacao: "2006-07-27 20:08:00"
data_alteracao: "None"
materia_tags: "clima,cobra,guerra,sergio,thiago cunha"
categoria: "Notícias"
titulo: "Cunha Lima cobra agilidade de Sérgio Guerra"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Da <STRONG>Agência Estado</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>O comando pol?tico da campanha do candidato da coligação PSDB-PFL à Presidência da República, Geraldo Alckmin, afirma estar com dificuldades para arrecadar recursos financeiros, e isso vem-se refletindo no ânimo dos aliados nos Estados.<BR><BR>\"A campanha está muito devagar em todo o Pa?s, e isso me surpreendeu muito\", reconheceu o governador da Para?ba, Cássio Cunha Lima (PSDB), que cobrou hoje mais agilidade do coordenador-geral da campanha, senador Sérgio Guerra (PSDB-PE), e reclamou da falta de material de propaganda. </FONT></P></p>
<p><P><FONT face=Verdana>\"A arrecadação não está correspondendo\", admitiu o senador, que prometeu iniciar, na próxima semana, a distribuição de material para esquentar a campanha nos Estados.</FONT> <BR></P> </p>
