---
id: 12372001
data_publicacao: "2006-08-01 19:26:00"
data_alteracao: "None"
materia_tags: "jarbas vasconcelos,liderança indígena,Senado"
categoria: "Notícias"
titulo: "Jarbas lidera com 67% para o Senado"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Resultados sobre as eleições em Pernambuco, divulgados agora há pouco no NETV, da Globo.&nbsp;</P></FONT><B></p>
<p><P><FONT face=Verdana>Para senador:</FONT></P></B></p>
<p><P><FONT face=Verdana>Jarbas Vasconcelos (PMDB)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 67%</FONT></P></p>
<p><P><FONT face=Verdana>Jorge Gomes (PSB)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4%</FONT></P></p>
<p><P><FONT face=Verdana>Luciano Siqueira (PCdoB)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3%</FONT></P></p>
<p><P><FONT face=Verdana>Belarmino (PTdoB)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1%</FONT></P><FONT face=Verdana></p>
<p><P><FONT face=Verdana>Breno Rocha (PCO)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1%</FONT></P></p>
<p><P><FONT face=Verdana>Pedro Gondim (Prona), </FONT>Hélio Cabral (PSTU), </FONT><FONT face=Verdana>Delta Farias (PRTB) e Alu?sio Figueirôa (PCB) não atigiram 1%</FONT></P></p>
<p><P><FONT face=Verdana>Brancos e nulos&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;9%</FONT></P></p>
<p><P><FONT face=Verdana>Não sabe, não opinou&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;14%</FONT></P> </p>
