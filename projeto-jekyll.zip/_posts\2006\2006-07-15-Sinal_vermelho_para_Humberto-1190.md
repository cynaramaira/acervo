---
id: 12372363
data_publicacao: "2006-07-15 10:36:00"
data_alteracao: "None"
materia_tags: "Humberto Costa"
categoria: "Notícias"
titulo: "Sinal vermelho para Humberto"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Apesar do crescimento na intenção de voto estimulada, o sinal vermelho acendeu para Humberto Costa. Ele subiu um ponto e Eduardo caiu dois, mas essa evolução está dentro da margem de erro (3,5% para mais ou para menos). Além disso, Humberto apresenta maior rejeição que Eduardo e perde em todos os cenários de segundo turno, inclusive para o socialista.<BR></P> </p>
