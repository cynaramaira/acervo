---
id: 12372315
data_publicacao: "2006-07-17 12:51:00"
data_alteracao: "None"
materia_tags: "blogs jc"
categoria: "Notícias"
titulo: "Blog alcança 8,9 mil acessos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Em apenas dois dias, das 11h do sábado às 11h30 de hoje, tivemos 8.950 page views (contabiliza acessos diversos de uma única pessoa). Foram 7.279 apenas no final de semana, quando o volume registrado pelo JC OnLine é menos intenso. </P></p>
<p><P>Obrigado a tod@s.</P></FONT> </p>
