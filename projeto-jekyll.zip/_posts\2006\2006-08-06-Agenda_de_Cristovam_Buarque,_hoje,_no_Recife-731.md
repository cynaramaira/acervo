---
id: 12371904
data_publicacao: "2006-08-06 06:37:00"
data_alteracao: "None"
materia_tags: "Chico Buarque,reagendamentos,Recife"
categoria: "Notícias"
titulo: "Agenda de Cristovam Buarque, hoje, no Recife"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Às 8h30, café da manhã com Eg?dio Guerra e Breno Fernandes, no Atlante Plaza Hotel, em Boa Viagem</FONT></P></p>
<p><P><FONT face=Verdana>Às 9h, visita o ex-prefeito do Recife, Pelópidas da Silveira, 91 anos, na residência deste, no bairro de Parnamirim, no Recife</FONT></P></p>
<p><P><FONT face=Verdana>Às 10h, visita a comunidade Córrego do Joaquim</FONT></P></p>
<p><P><FONT face=Verdana>Às 12h, inaugura o seu comitê regional (sede do PDT), na Avenida Visconde de Suassuna, 689, Boa Vista</FONT></P></p>
<p><P><FONT face=Verdana>Às 14h, caminhada no Shopping Boa Vista</FONT><BR>&nbsp;</P> </p>
