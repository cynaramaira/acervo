---
id: 12372051
data_publicacao: "2006-07-30 08:19:00"
data_alteracao: "None"
materia_tags: "Humberto Costa,Mendonça Filho"
categoria: "Notícias"
titulo: "Humberto rebate ataques de Mendonça Filho"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Cec?lia Ramos</STRONG> e <STRONG>Mônica Crisóstomo</STRONG><BR>Repórteres do Blog e do Jornal do Commercio</FONT></P></p>
<p><P><FONT face=Verdana>O candidato do PT ao governo do Estado, Humberto Costa, rebateu ontem as declarações do governador-candidato Mendonça Filho (PFL), que chamou o petista de “desesperado??? e “aperreado???, em função da CPI das Sanguessugas, que investiga a compra superfaturada de ambulâncias com verbas de emendas do orçamento.</FONT></P></p>
<p><P><FONT face=Verdana>“O candidato do PFL disse aos jornais que eu estava<BR>desesperado. Eu não estou, não. Desesperado está o povo de Pernambuco, que tem escolas sucateadas, professores recebendo salário de miséria, saúde<BR>deficitária, falta de pol?tica de segurança???, listou Humberto, reforçando seu discurso contra o atual governo.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinantes JC e UOL).<BR></P></FONT> </p>
