---
id: 12372116
data_publicacao: "2006-07-27 10:43:00"
data_alteracao: "None"
materia_tags: "eduardo"
categoria: "Notícias"
titulo: "Só Eduardo revela quanto gastará com marqueteiros"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</B></I></STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Dos três principais palanques que disputam o governo do Estado </B></I>– os do governador-candidato Mendonça Filho (PFL) e dos ex-ministros Humberto Costa (PT) e Eduardo Campos (PSB) – apenas o do socialista informou ontem, 24 horas após solicitação do <B>JC</B>, quanto os marqueteiros da campanha vão ganhar com o seu trabalho, especialmente com a produção do guia eleitoral: R$ 1,5 milhão, valor apenas para o primeiro turno. </FONT></P></p>
<p><P><FONT face=Verdana>Nas duas outras frentes majoritárias foram usados vários argumentos para não soltar a informação, deixando claro que o assunto mantém-se como forte tabu nas campanhas, embora o discurso da transparência seja o mais usado pelos pol?ticos nos per?odos eleitorais. </FONT></P></p>
<p><P><FONT face=Verdana>Na coligação de Eduardo Campos, todo o trabalho está sendo comandado pela Link Propaganda, empresa de comunicação da Bahia dirigida pelos marqueteiros Raimundo Luedi e Edson Barbosa. O contrato de R$ 1,5 milhão será rediscutido se o socialista passar para o segundo turno.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><U><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></U></STRONG> o texto completo (assinantes JC e UOL).</FONT></P> </p>
