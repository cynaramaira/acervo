---
id: 12372095
data_publicacao: "2006-07-28 12:48:00"
data_alteracao: "None"
materia_tags: "Ana Arraes,candidatos,eduardo,Humberto Costa,Lula"
categoria: "Notícias"
titulo: "Humberto, neto de Arraes? Eduardo, candidato de Lula?"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Essa disputa entre Eduardo Campos (PSB) e Humberto Costa (PT) para mostrar quem é o candidato de Lula a governador de Pernambuco está dando um nó danado na cabeça dos eleitores de Garanhuns e Capoeiras, no Agreste do Estado.</FONT></P></p>
<p><P><FONT face=Verdana>Humberto anda por lá agora. Os panfletos dele acabaram se misturando aos de Eduardo. Resultado: tinha gente perguntando, com uma tremenda cara de surpresa, se Humberto era mesmo o neto de Arraes.</FONT></P></p>
<p><P><FONT face=Verdana>Conforme testemunhou Cec?lia Ramos, repórter do Blog, também houve quem dissesse que Eduardo não é o candidato de Lula, mas neto de Arraes.</FONT></P></p>
<p><P><FONT face=Verdana>Os petistas esperam resolver isso com a propaganda eleitoral no rádio e na TV, que começa dia 15. Esperam, claro, ver o eleitor associar Humberto a Lula e a seus 66% de intenção de voto no Estado, segundo a última JC/Vox Populi.</FONT></P></p>
<p><P><FONT face=Verdana>O pessoal de Eduardo quer a mesma coisa.</FONT></P> </p>
