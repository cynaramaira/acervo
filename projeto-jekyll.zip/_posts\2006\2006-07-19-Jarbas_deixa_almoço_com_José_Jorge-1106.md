---
id: 12372279
data_publicacao: "2006-07-19 13:44:00"
data_alteracao: "None"
materia_tags: "jarbas vasconcelos,jorge jesus,Louro José"
categoria: "Notícias"
titulo: "Jarbas deixa almoço com José Jorge"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>O ex-governador peemedebista não tolera atrasos. Durante 20 minutos esperou o senador José Jorge (PFL) na porta do Boi Preto, churrascaria em Boa Viagem, no Recife. É lá que Jorge, vice de Geraldo Alckmin, está sendo homenageado pelo Caxangá ??gape, uma confraria sem lenço nem documento que nas últimas semanas homenageou também Humberto Costa e Maur?cio Rands, do PT.</FONT></P></p>
<p><P><FONT face=Verdana>Jarbas esperou só Zé Jorge chegar para cumprimentá-lo, dar as costas e</p>
<p> cair fora sem nem dizer ciao. Alegou ter outros compromissos. Não disse quais. Mas, nos 20 minutos em que ficou ali, foi educado. Esteve o tempo inteiro à porta recepcionando as pessoas, conforme relato de Cec?lia Ramos, repórter do blog.</FONT></P></p>
<p><P><FONT face=Verdana>Neste momento, o deputado Oswaldo Coelho, do PFL de Petrolina, faz o discurso de saudação a Zé Jorge. Na platéia, todos os figurões do partido: o governador Mendonça Filho, o senador Marco Maciel, os deputados José Mendonça (o pai) e Romário Dias, além de Cadoca, que é do PMDB de Mendonça Filho.</FONT></P></FONT> </p>
