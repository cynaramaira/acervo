---
id: 12372318
data_publicacao: "2006-07-17 10:58:00"
data_alteracao: "None"
materia_tags: "jantar"
categoria: "Notícias"
titulo: "Jantar sem discursos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Foram cancelados os discursos programados para o jantar que a União por Pernambuco promove hoje, às 19h,&nbsp;para mais de 600 pessoas. A festa no Paço Alfândega tem como finalidade arrecadar fundos para as campanhas de Mendonça Filho e Jarbas Vasconcelos.<BR><BR>Cada conviva paga R$ 1 mil e tem direito a pato ao cravo e canela</FONT><FONT face=Arial size=2> com medalhões de filé, pene com frutos do mar, arroz com castanha e salada de folhas e legumes. Terá também a cheese cake com calda de amora na sobremesa.</P></FONT> </p>
