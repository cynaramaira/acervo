---
id: 12372352
data_publicacao: "2006-07-15 15:47:00"
data_alteracao: "None"
materia_tags: "Armando Monteiro,Humberto Costa"
categoria: "Notícias"
titulo: "Armando diz que Humberto cresce"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>A pesquisa JC/Vox Populi, publicada na edição deste domingo do Jornal do Commercio, ainda não refletiu a adesão dos trabalhistas à candidatura de Humberto, segundo Armando Monteiro Neto. \"As lideranças vieram, mas falta ainda o trabalho junto aos eleitores, que ainda vão se sensibilizar\", disse ele, há pouco, em conversa com Cec?lia Ramos, repórter do blog. Neto está em Arcoverde, onde participou de reunião com agricultores na Camara Municipal. </P></p>
<p><P>Para o deputado, a pesquisa confirma que a disputa estadual será definida em segundo turno e que o crescimento de Mendonça Filho era previs?vel, fruto da superexposição dele no cargo de governador. \"No campo das oposições continua o empate técnico, mas tende a favorecer Humberto\", pondera. </P> </p>
