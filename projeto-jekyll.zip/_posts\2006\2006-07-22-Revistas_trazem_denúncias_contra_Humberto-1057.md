---
id: 12372230
data_publicacao: "2006-07-22 12:27:00"
data_alteracao: "None"
materia_tags: "Contran,Humberto Costa"
categoria: "Notícias"
titulo: "Revistas trazem denúncias contra Humberto"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p>&nbsp;<FONT face=Verdana><STRONG>ÉPOCA</STRONG></FONT></p>
<p> </p>
<p><P><FONT face=Verdana size=3>Os companheiros sanguessugas</FONT></P></p>
<p><P><FONT face=Verdana size=1>O empresário que confessou liderar o esquema acusa petistas e o ex-ministro Humberto Costa de envolvimento na máfia das ambulâncias</FONT></P></p>
<p><P><FONT face=Verdana>Na semana passada, a CPI das Ambulâncias divulgou uma lista com 56 deputados e um senador acusados de envolvimento com a máfia das sanguessugas, nome dado ao esquema de desvio de recursos do Orçamento federal pela venda superfaturada de ambulâncias, ônibus escolares e equipamentos de informática. A lista foi preparada com base nas afirmações feitas em ju?zo pelo empresário Luiz Antônio Vedoin, acusado de ser chefe da quadrilha, e por meio de documentos entregues por ele à Justiça. Vedoin decidiu colaborar com a Justiça em troca das vantagens oferecidas pela delação premiada. Na relação divulgada pela CPI, um fato chamou a atenção: não havia nenhum parlamentar do PT. Em seu depoimento, porém, Vedoin afirmou como operou com pelo menos um deputado e uma senadora petistas. E - mais importante - contou como teria conseguido, durante o governo Lula, liberar recursos no Ministério da Saúde para comprar as ambulâncias superfaturadas, em troca do suposto pagamento de propina a dirigentes do PT. ÉPOCA teve acesso a trechos das declarações de Vedoin. Com base neles, montou uma relação dos petistas colocados sob suspeita. </FONT></P></p>
<p><P><FONT face=Verdana>Segundo afirmou Vedoin, o esquema das sanguessugas, na gestão petista, começou a funcionar no Ministério da Saúde em março de 2003. Ele disse ter feito, na ocasião, um acerto com o então presidente do PT no Ceará, José Airton Cirilo. O entendimento envolvia, afirmou Vedoin, a liberação pelo então ministro da Saúde, Humberto Costa, de R$ 8 milhões para a Planam - empresa de Vedoin responsável pelas vendas superfaturadas. Vedoin disse que essa liberação seria o pagamento por cem ambulâncias compradas no final do governo Fernando Henrique. De acordo com o empresário, Cirilo cobrou e levou R$ 400 mil pela intermediação. </FONT></P></p>
<p><P><FONT face=Verdana>Vedoin disse à Justiça ter entregado, entre agosto e setembro de 2002, as ambulâncias antes mesmo de receber o pagamento do Ministério da Saúde. Afirmou ter confiado que não ficaria na mão. Mas, segundo Vedoin, o dinheiro não saiu. Em 13 de fevereiro de 2003, um decreto do presidente Lula cancelou o pagamento das despesas empenhadas no ano anterior pelo governo FHC. </FONT></P><FONT size=2></p>
<p><P><FONT face=Verdana>Leia <B><U><A href=\"https://revistaepoca.globo.com/Revista/Epoca/0,,EDG74886-6009-427,00.html\" target=_blank>aqui</A></B></FONT></U><FONT face=Verdana> matéria completa da revista Época</FONT></P></p>
<p><P><FONT face=Verdana>------------------------------------------</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>VEJA</STRONG></FONT></P></p>
<p><P></FONT><FONT face=Verdana size=3>Era pior do que se pensava </FONT></P></p>
<p><P><FONT face=Verdana size=1>O chefe da máfia dos sanguessugas revela que seu esquema corrompeu sessenta prefeitos e 20% do Congresso e adentrou o gabinete de Humberto Costa</FONT></P></p>
<p><P><FONT face=Verdana>O caso da máfia dos sanguessugas já era, na semana passada, um dos maiores escândalos de corrupção descobertos no pa?s. Nada menos do que 57 parlamentares estavam sob suspeita de ter recebido suborno de uma empresa de ambulâncias, a Planam, para destinar recursos do Orçamento federal a prefeituras compradoras dos ve?culos. Na quinta-feira passada, porém, descobriu-se que tanto o número de envolvidos no esquema quanto o seu alcance haviam sido subestimados. Os parlamentares acusados de participar da máfia dos sanguessugas ultrapassam uma centena – o número exato é 112 –, e o Legislativo não é o único poder atingido por ela. </FONT></P></p>
<p><P><FONT face=Verdana>O rastro do suborno e do tráfico de influência alcança também o Executivo federal – mais precisamente a porta do gabinete do ex-ministro da Saúde Humberto Costa, hoje candidato ao governo de Pernambuco pelo PT. As revelações foram feitas pelo empresário Luiz Antônio Vedoin, um dos sócios da Planam, ao longo de uma série de depoimentos sigilosos prestados à Justiça Federal nas duas últimas semanas. </FONT></P><FONT size=2></p>
<p><P><FONT face=Verdana>Leia <U><STRONG><A href=\"https://veja.abril.uol.com.br/260706/p_056.html\" target=_blank>aqui</A></STRONG></FONT></U><FONT face=Verdana> matéria completa da revista Veja.</FONT></P></FONT> </p>
