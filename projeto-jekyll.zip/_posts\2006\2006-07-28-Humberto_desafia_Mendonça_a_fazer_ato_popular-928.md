---
id: 12372101
data_publicacao: "2006-07-28 08:24:00"
data_alteracao: "None"
materia_tags: "Frente Popular,Humberto Costa,mendonça"
categoria: "Notícias"
titulo: "Humberto desafia Mendonça a fazer ato popular"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Na maior manifestação de rua desde o in?cio da campanha, o candidato da frente Melhor pra Pernambuco, Humberto Costa, realizou, ontem, uma caminhada no centro do Recife – envolto em um mar de bandeiras e cerca 1,5 mil militantes –, que acabou em com?cio relâmpago, na Praça da Independência, quando o petista comparou o poder das ruas e praticamente desafiou o governador- e adversário Mendonça Filho a promover manifestação de igual dimensão. </FONT></P></p>
<p><P><FONT face=Verdana>\"Essa é a grande diferença que temos em relação ao candidato da direita. Mesmo com toda a máquina (o governo), ele não consegue colocar militância nas ruas\", provocou.</FONT></P> </p>
