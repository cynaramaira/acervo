---
id: 12372109
data_publicacao: "2006-07-27 20:54:00"
data_alteracao: "None"
materia_tags: "Anticorpos,Metropolitana,Recife,Região"
categoria: "Notícias"
titulo: "O corpo-a-corpo na Região Metropolitana do Recife"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Eduardo Campos (PSB) luta para ter seu nome associado ao de Lula e crescer nas pesquisas. Mas nas ruas do Recife ele só é visto como neto de Miguel Arraes.</FONT></P></p>
<p><P><FONT face=Verdana>\"Ele é bonito e cheiroso. O outro é jovem também, mas tem a cara cheia de buracos\", disse uma eleitora, com a sinceridade das ruas, depois de abraçar o socialista.</FONT></P></p>
<p><P><FONT face=Verdana>Na caminhada desta quinta, Humberto Costa (PT) também tentou ser simpático. Percorreu o centro da capital, encheu as avenidas de bandeiras e não largou o prefeito João Paulo.</FONT></P></p>
<p><P><FONT face=Verdana>Os petistas&nbsp;repetiram o mantra da salvação da campanha: Lula+Humberto+Luciano. É com ele que pretendem chegar ao segundo turno.</FONT></P> </p>
