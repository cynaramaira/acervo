---
id: 12371883
data_publicacao: "2006-08-07 10:09:00"
data_alteracao: "None"
materia_tags: "Contran,Estado,Propaganda Eleitoral"
categoria: "Notícias"
titulo: "Contra-propaganda eleitoral já fez muitas v?timas no Estado"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Pernambuco de A/Z</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Na eleição de 2002 a apreensão, por parte da Pol?cia, de cerca de 500 mil cartazes de contra-propaganda eleitoral envolvendo o prefeito do Recife, João Paulo, e o ex-governador Miguel Arraes, material que estava na sede da empresa Stampa Outdoor Ltda, gerou um grande bate-boca entre os pol?ticos. </FONT></P></p>
<p><P><FONT face=Verdana>Mas, esta não é a primeira vez que ocorre episódio dessa natureza em Pernambuco. A divulgação de panfletos anônimos é uma prática antiga e já vitimou muita gente.</FONT></P></p>
<p><P><FONT face=Verdana></FONT></P></p>
<p><P><FONT face=Verdana>(...)</FONT></P></p>
<p><P><FONT face=Verdana>Outro pol?tico que também sofreu na pele com material de propaganda fraudulenta foi o ex-governador do Estado, Jarbas Vasconcelos, que durante uma campanha foi acusado de \"bater no próprio pai\". </FONT></P></p>
<p><P><FONT face=Verdana>Já em 1986, foi Jarbas quem flagrou e fez com que a Pol?cia Federal prendesse um grupo de 27 pessoas que estavam colando nas ruas do Recife cartazes vermelhos com a foice e o martelo e o slogan do então candidato ao governo pela Oposição, Miguel Arraes -\"Ele está voltando\".</FONT></P></p>
<p><P><FONT face=Verdana>Leia mais <STRONG><EM><A href=\"https://www.pe-az.com.br/site_especial/politica/baixaria_campanha.htm\" target=_blank>aqui</A></EM></STRONG>.</FONT></P> </p>
