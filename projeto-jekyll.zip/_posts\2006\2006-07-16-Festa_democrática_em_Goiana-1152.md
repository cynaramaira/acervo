---
id: 12372325
data_publicacao: "2006-07-16 19:47:00"
data_alteracao: "None"
materia_tags: "festa,Goiana"
categoria: "Notícias"
titulo: "Festa democrática em Goiana"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p>Animada com a eleição do prefeito, a gatinha foi sem medo para a boca de urna. O pessoal nas ruas também não se intimidou. Nos bares, foi preciso lembrar da lei seca. Fenelon, com pinta de vitorioso, vai ser processado pelo desfile. E, no posto, antes de ser interditado, fila para receber gasolina de graça. </p>
