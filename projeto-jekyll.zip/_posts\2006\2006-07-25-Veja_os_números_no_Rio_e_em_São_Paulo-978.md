---
id: 12372151
data_publicacao: "2006-07-25 20:38:00"
data_alteracao: "None"
materia_tags: "cerveja,São Paulo"
categoria: "Notícias"
titulo: "Veja os números no Rio e em São Paulo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P style=\"LINE-HEIGHT: 12pt\"><B><SPAN style=\"FONT-SIZE: 9pt; COLOR: #2a2a2a; FONT-FAMILY: Arial\"><FONT face=Verdana><FONT size=2>1º turno<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></FONT></SPAN></B></P></p>
<p><P style=\"LINE-HEIGHT: 12pt\"><STRONG><SPAN style=\"FONT-WEIGHT:</p>
<p> normal; FONT-SIZE: 9pt; COLOR: #2a2a2a; FONT-FAMILY: Arial\"><o:p><FONT face=Verdana></FONT></o:p></SPAN></STRONG></P></p>
<p><P style=\"LINE-HEIGHT: 12pt\"><FONT face=Verdana><FONT size=2><SPAN><STRONG>Rio de Janeiro<o:p></o:p></STRONG></SPAN></FONT></FONT></P></p>
<p><P style=\"LINE-HEIGHT: 12pt\"><SPAN style=\"FONT-SIZE: 9pt; COLOR: #2a2a2a; FONT-FAMILY: Arial\"><FONT face=Verdana><FONT size=2>Sérgio Cabral (PMDB)<SPAN style=\"mso-tab-count: 1\">&nbsp; </SPAN><SPAN style=\"mso-tab-count: 1\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </SPAN>39%<o:p></o:p></FONT></FONT></SPAN></P></p>
<p><P style=\"LINE-HEIGHT: 12pt\"><SPAN lang=ES-TRAD style=\"FONT-SIZE: 9pt; COLOR: #2a2a2a; FONT-FAMILY: Arial; mso-ansi-language: ES-TRAD\"><FONT face=Verdana><FONT size=2>Marcelo Crivella (PRB)<SPAN style=\"mso-tab-count: 1\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</SPAN><SPAN style=\"mso-tab-count: 1\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</SPAN>17%<o:p></o:p></FONT></FONT></SPAN></P></p>
<p><P style=\"LINE-HEIGHT: 12pt\"><SPAN lang=EN-US style=\"FONT-SIZE: 9pt; COLOR: #2a2a2a; FONT-FAMILY: Arial; mso-ansi-language: EN-US\"><FONT face=Verdana><FONT size=2>Denise Frossard (PPS)&nbsp;&nbsp; <SPAN style=\"mso-tab-count: 2\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</SPAN><SPAN style=\"mso-spacerun: yes\">&nbsp;&nbsp;</SPAN>8%<o:p></o:p></FONT></FONT></SPAN></P></p>
<p><P style=\"LINE-HEIGHT: 12pt\"><SPAN style=\"FONT-SIZE: 9pt; COLOR: #2a2a2a; FONT-FAMILY: Arial\"><FONT face=Verdana><FONT size=2>Eduardo Paes (PSDB)&nbsp; &nbsp;<SPAN style=\"mso-tab-count: 1\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</SPAN><SPAN style=\"mso-tab-count: 1\">&nbsp;&nbsp;&nbsp;</SPAN>2%<o:p></o:p></FONT></FONT></SPAN></P></p>
<p><P style=\"LINE-HEIGHT: 12pt\"><SPAN style=\"FONT-SIZE: 9pt; COLOR: #2a2a2a; FONT-FAMILY: Arial\"><FONT face=Verdana><FONT size=2>&nbsp;<o:p></o:p></FONT></FONT></SPAN></P></p>
<p><P style=\"LINE-HEIGHT: 12pt\"><FONT face=Verdana><FONT size=2><SPAN><STRONG>São Paulo<o:p></o:p></STRONG></SPAN></FONT></FONT></P></p>
<p><P style=\"LINE-HEIGHT: 12pt\"><FONT face=Verdana><FONT size=2><SPAN style=\"FONT-SIZE: 9pt; COLOR: #2a2a2a; FONT-FAMILY: Arial\">&nbsp;</SPAN><SPAN style=\"FONT-SIZE: 9pt; COLOR: #2a2a2a; FONT-FAMILY: Arial\">José Serra (PSDB)<SPAN style=\"mso-tab-count: 1\">&nbsp; </SPAN><SPAN style=\"mso-tab-count: 1\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </SPAN>46%<o:p></o:p></SPAN></FONT></FONT></P></p>
<p><P style=\"LINE-HEIGHT: 12pt\"><SPAN style=\"FONT-SIZE: 9pt; COLOR: #2a2a2a; FONT-FAMILY: Arial\"><FONT face=Verdana><FONT size=2>Aloizio Mercadante (PT-SP)<SPAN style=\"mso-tab-count: 1\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </SPAN>13%<o:p></o:p></FONT></FONT></SPAN></P></p>
<p><P style=\"LINE-HEIGHT: 12pt\"><SPAN style=\"FONT-SIZE: 9pt; COLOR: #2a2a2a; FONT-FAMILY: Arial\"><FONT face=Verdana><FONT size=2>Orestes Quércia (PMDB)<SPAN style=\"mso-tab-count: 2\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</SPAN><SPAN style=\"mso-spacerun: yes\">&nbsp; </SPAN>9%<o:p></o:p></FONT></FONT></SPAN></P></p>
<p><P style=\"LINE-HEIGHT: 12pt\"><FONT face=Verdana><FONT size=2><SPAN style=\"FONT-SIZE: 9pt; COLOR: #2a2a2a; FONT-FAMILY: Arial\">&nbsp;</SPAN><SPAN style=\"FONT-SIZE: 9pt; COLOR: #2a2a2a; FONT-FAMILY: Arial\">A margem de erro é de dois pontos percentuais para mais e para menos.</SPAN></FONT></FONT></P> </p>
