---
id: 12372113
data_publicacao: "2006-07-27 19:09:00"
data_alteracao: "None"
materia_tags: "candidatos,Debate,Desembargadores"
categoria: "Notícias"
titulo: "Candidatos a desembargador evitam
 debate"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Nenhum dos seis escolhidos pela OAB compareceu hoje ao debate organizado pela associação dos magistrados de Pernambuco, Amepe, conforme apurou Jorge Cavalcanti, repórter do JC. </FONT></P></p>
<p><P><FONT face=Verdana>Eles foram convidados para discutir a seleção do novo membro do Tribunal de Justiça, mas passaram longe.</FONT></P></p>
<p><P><FONT face=Verdana>Niguém quer relação com a Amepe neste momento. A entidade combate duramente o nepotismo no Judiciário. Isso contraria os desembargadores, interessados em manter privilégios para parentes.</FONT></P></p>
<p><P><FONT face=Verdana>São os desembargadores que vão escolher três dos seis eleitos pela OAB para compor a lista tr?plice a ser encaminhada ao governador Mendonça Filho. Caberá a Mendonça selecionar um e nomeá-lo como 37º membro do TJ.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><U><EM><A href=\"https://jc3.uol.com.br/blogs/jc/2006/07/27/index.php#307\">aqui</A></EM></U></STRONG> sobre a eleição da OAB.</FONT></P> </p>
