---
id: 12372010
data_publicacao: "2006-08-01 12:30:00"
data_alteracao: "None"
materia_tags: "Chico Buarque,geraldo Alckmin,milton bivar,pernambuco"
categoria: "Notícias"
titulo: "Alckmin, Buarque e Bivar em Pernambuco"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Com quase seis milhões de eleitores,&nbsp;o Estado é roteiro obrigatório para os candidatos a presidente da República.</FONT></P></p>
<p><P><FONT face=Verdana>Saiba do roteiro dos três em reportagem de Glauce Correia, da JC/CBN.</FONT></P> </p>
