---
id: 12372239
data_publicacao: "2006-07-21 17:36:00"
data_alteracao: "None"
materia_tags: "Humberto Costa"
categoria: "Notícias"
titulo: "Guia começa com Oswaldo e termina com Humberto"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Acaba de sair a divisão do tempo do guia eleitoral na TV e no rádio em Pernambuco, informa Clóvis Andrade, repórter do JC. </FONT></P></p>
<p><P><FONT face=Verdana>O guia começa em 15 de agosto e passa 45 dias no ar. Segundas, quartas e sextas teremos programas para governador, senador e deputado estadual. Terças, quintas e sábados, para federal e presidente da República.</FONT></P></p>
<p><P><FONT face=Verdana>Veja com ficou a divisão, pela ordem do primeiro dia, para governador:</FONT></P></p>
<p><P><FONT face=Verdana></FONT></P></p>
<p><P><FONT face=Verdana>Oswaldo Alves (PCO)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 44\"</FONT></P></p>
<p><P><FONT face=Verdana>Kátia Teles (PSTU)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 44\"</FONT></P></p>
<p><P><FONT face=Verdana>Edilson Silva (P-SOL)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;44\"</FONT></P></p>
<p><P><FONT face=Verdana>Eduardo Campos (PSB)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3\57\"</FONT></P></p>
<p><P><FONT face=Verdana>Mendonça (PFL)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 7\ 8\"</FONT></P></p>
<p><P><FONT face=Verdana>Clóvis Corrêa (Prona)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 54\"</FONT></P></p>
<p><P><FONT face=Verdana>Luiz Vidal (PSDC)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 46\"</FONT></P></p>
<p><P><FONT face=Verdana>Rivaldo Soares (PSL)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 46\"</FONT></P></p>
<p><P><FONT face=Verdana>Humberto Costa (PT)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4\16\"</FONT></P></p>
<p><P><FONT face=Verdana>----------------------------------</FONT></P></p>
<p><P><FONT face=Verdana>O filé do guia, porém, serão as inserções de 30 segundos. Elas pegam o eleitor desprevenido, no intervalo do que está assistindo ou ouvindo. P</FONT><FONT face=Verdana>oderão ser agrupadas em 1 minuto ou divididas em duas de 15 segundos. A distribuição, nos 45 dias, será a seguinte:</FONT></P></p>
<p><P><FONT face=Verdana>Oswaldo Alves (PCO)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 20</FONT></P></p>
<p><P><FONT face=Verdana>Kátia Teles (PSTU)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 20</FONT></P></p>
<p><P><FONT face=Verdana>Edilson Silva (P-SOL)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;20</FONT></P></p>
<p><P><FONT face=Verdana>Eduardo Campos (PSB)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 107</FONT></P></p>
<p><P><FONT face=Verdana>Mendonça (PFL)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 193</FONT></P></p>
<p><P><FONT face=Verdana>Clóvis Corrêa (Prona)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 24</FONT></P></p>
<p><P><FONT face=Verdana>Luiz Vidal (PSDC)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 21</FONT></P></p>
<p><P><FONT face=Verdana>Rivaldo Soares (PSL)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 20</FONT></P></p>
<p><P><FONT face=Verdana>Humberto Costa (PT)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 115</FONT></P></FONT> </p>
