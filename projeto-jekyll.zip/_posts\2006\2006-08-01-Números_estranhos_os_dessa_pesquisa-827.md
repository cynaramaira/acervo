---
id: 12372000
data_publicacao: "2006-08-01 19:32:00"
data_alteracao: "None"
materia_tags: "pesquisa"
categoria: "Notícias"
titulo: "Números estranhos os dessa pesquisa"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Os resultados da pesquisa da TV Globo contrariam todos os levantamentos feitos até agora.</FONT></P></p>
<p><P><FONT face=Verdana>Não surgiram, nas últimas semanas, fatos pol?ticos que pudessem alterar significativamente o quadro na disputa pelo governo de Pernambuco.</FONT></P></p>
<p><P><FONT face=Verdana>Houve o envolvimento de Humberto com o escândalo das sanguessugas. Mas, nesse caso, na pior das hipóteses,&nbsp;a interferência poderia ser no sentido de reduzir as intenções de voto dele.</FONT></P></p>
<p><P><FONT face=Verdana>Na verdade, a&nbsp;expectativa de todos&nbsp;era de que houvesse uma alteração pouco significativa do quadro eleitoral. Jamais se&nbsp;imaginou um distanciamento do petista em relação a Eduardo.</FONT></P></p>
<p><P><FONT face=Verdana>Na&nbsp;JC/Vox Populi, Mendonça aparece com 35%; Humberto com 22%; e Eduardo, 21%. Veja <STRONG><EM><A href=\"https://jc3.uol.com.br/especiais/eleicoes2006/2006/07/25/not_368.php\">aqui</A></EM></STRONG> os resultados divulgados em 15 de julho.</FONT></P></p>
<p><P><FONT face=Verdana>Outros institutos, contratados por&nbsp;jornais locais, e pesquisas internas, dos próprios candidatos, mostravam também um empate entre Humberto e Eduardo. </FONT></P></p>
<p><P><FONT face=Verdana>A distância entre os dois&nbsp;e Mendonça, nesses levantamentos, era&nbsp;semelhante à mostrada no Ibope/TV Globo (Mendonça 32%, Humberto 24%).</FONT></P></p>
<p><P><FONT face=Verdana>Inclusive, pesquisa feita neste final de semana pelo PSB mostra Eduardo na frente de Humberto.</FONT></P></p>
<p><P><FONT face=Verdana>Definitivamente, é preciso um novo mergulho nos números - em todos os números -&nbsp;para se descobrir o que ocorreu.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Correção</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Por conta de um equ?voco meu na primeira nota postada, republico a metodologia da Ibope/TV Globo:</FONT></P></p>
<p><P><STRONG><FONT face=Verdana>METODOLOGIA</FONT></STRONG></P></p>
<p><P><FONT face=Verdana>O levantamento foi realizado entre os dias 29 e 31 de julho. Foram ouvidas 1.806 pessoas em 78 munic?pios pernambucanos. A margem de erro é de dois pontos percentuais para mais ou para menos. A pesquisa foi registrada no Tribunal Regional Eleitoral com o número 11112/2006.<BR></FONT></P> </p>
