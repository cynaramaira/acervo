---
id: 12372076
data_publicacao: "2006-07-29 10:34:00"
data_alteracao: "None"
materia_tags: "dinheiro,esta,Liberação,Lula"
categoria: "Notícias"
titulo: "Lula libera dinheiro para o Sul, onde está mal"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=Verdana></p>
<p><P>Do <STRONG>Jornal do Commercio</STRONG></P></p>
<p><P>Na véspera de o presidente Luiz Inácio Lula da Silva (PT) desembarcar no Rio Grande do Sul e Santa Catarina para cumprir uma agenda de candidato à reeleição, a ministra da Casa Civil, Dilma Rousseff, anunciou ontem a expansão de financiamento administrado pelo Banco do Brasil que beneficia setores empresariais da região. </P></p>
<p><P>É justamente na Região Sul onde o presidente Lula tem o menor percentual de intenções de votos. O governo aumentou dos atuais R$ 400 milhões para R$ 1 bilhão o volume de financiamento da linha FAT-Giro Setorial – recursos do Fundo de Amparo ao Trabalhador – e incluiu novos setores como beneficiários.</P></p>
<p><P>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinantes JC e UOL).</P></FONT> </p>
