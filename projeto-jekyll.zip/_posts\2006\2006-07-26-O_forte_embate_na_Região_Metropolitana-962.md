---
id: 12372135
data_publicacao: "2006-07-26 12:08:00"
data_alteracao: "None"
materia_tags: "Forte Orange,Metropolitana,Região"
categoria: "Notícias"
titulo: "O forte embate na Região Metropolitana"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Humberto Costa (PT) e Mendonça Filho (PFL) decidiram centrar fogo nos próximos dias na área metropolitana, onde estão mais de 40% dos eleitores de Pernambuco. Veja nas reportagens do Jornal do Commercio de hoje: </P></p>
<p><P><STRONG>Jarbas injeta ânimo à militância </STRONG></P></p>
<p><P>A campanha do governador e candidato à reeleição Mendonça Filho (PFL) vai ganhar um ritmo intenso na Região Metropolitana do Recife depois da reunião de ontem à noite, no comitê central, com 200 l?deres comunitários que atuam nessa área. </P></p>
<p><P>A injeção de ânimo a esses agentes considerados eficientes multiplicadores de voto foi dada por ninguém menos do que o ex-governador Jarbas Vasconcelos (PMDB) – que tem forte liderança pol?tica e eleitoral na região – e se mostrou disposto a encabeçar, sozinho, uma ofensiva pela Região Metropolitana nos turnos da manhã e tarde, per?odo que Mendonça decidiu reservar para as funções administrativas. </P></p>
<p><P>Jarbas nunca foi tão enfático no est?mulo à militância como ontem. Chamou a atenção para o fato de que mais de 40% do eleitorado estão na área metropolitana e enfatizou a necessidade de estimular os eleitores a não anularem o voto. O ex-governador chamou a atenção para a apatia que, segundo ele, toma conta da população por estar desacreditada na classe pol?tica em função dos escândalos. </P></p>
<p><P><STRONG>Humberto deflagra nova etapa na campanha </STRONG></P></p>
<p><P>A militância do PT e a coordenação da campanha da frente Melhor pra Pernambuco ao governo do Estado, Humberto Costa, deflagram hoje a principal estratégica da candidatura para a Região Metropolitana do Recife (RMR). </P></p>
<p><P>A frente começa a por em prática a ocupação gradual e permanente de bairros, avenidas, ruas e cidades, por meio de atos públicos, com?cios-relâmpagos, bandeiraços, caminhadas em feiras e mercados e porta a porta. </P></p>
<p><P>A coordenação da coligação decidiu que o momento, agora, é de dar prioridade ao Grande Recife, região na qual se apresenta em segundo lugar nas pesquisas, abaixo do governador-candidato Mendonça Filho (PFL). Para dar visibilidade múltipla a Humberto e massificar a campanha, a tática definida é promover mais de um ato por dia, pontapé será dado no Recife com um bandeiraço, hoje, na Avenida Conde da Boa Vista. </P></p>
<p><P>Disposta ainda a tomar a iniciativa para neutralizar qualquer ameaça de dano à candidatura de Humberto, em razão das denúncias da revista Veja de favorecimento do petista à Máfia das Sanguessugas, quando no Ministério da Saúde – o que foi desmentido pelo advogado Otto Medeiros, defensor dos empresários Darcy e Luiz Antônio Vedoin, donos da Planam e mentores do esquema –, a coordenação decidiu marcar o in?cio da estratégia com uma grande mobilização. </P></p>
<p><P>A frente agendou para amanhã, a partir das 16h, a primeira caminhada, com a presença da majoritária, dos candidatos proporcionais e do l?der da ex-Frente Trabalhista, Armando Monteiro Neto. </P></p>
<p><P>A idéia é realizar uma caminhada que repercuta, percorrendo as Ruas da Imperatriz e Nova até a Praça da Independência. \"Preparamos uma intensa campanha de rua. Vamos priorizar a RMR e dedicar os finais de semana ao interior\", detalhou Gustavo Couto, da coordenação da campanha.</P> </p>
