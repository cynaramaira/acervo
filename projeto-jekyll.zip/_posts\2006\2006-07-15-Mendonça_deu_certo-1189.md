---
id: 12372362
data_publicacao: "2006-07-15 10:37:00"
data_alteracao: "None"
materia_tags: "mendonça"
categoria: "Notícias"
titulo: "Mendonça deu certo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Desde a posse, o governador demonstrou estar preparado para enfrentar a oposição. Vem conseguindo se capitalizar com a bem-sucedida gestão de Jarbas Vasconcelos nas áreas econômica (investimentos em infra-estrutura), administrativa (reorganização do Estado) e pol?tica (manutenção da ampla aliança que o elegeu). </P></p>
<p><P>Mendonça também se preparou para a herança maldita da violência, da incapacidade gerencial na Saúde e na Educação. Com ações pontuais e eficazes, como as de redução do número de homic?dios, pôde esvaziar significativamente a agenda negativa da oposição.</P></p>
<p><P>Tudo isso, porém, não seria suficiente para crescer nas pesquisas caso não explorasse ao máximo a função de chefe de Estado - essa zona cinzenta entre o candidato e o gestor. Como governador, cumpriu uma eficiente agenda administrativa por regiões que poderiam multiplicar seu capital pol?tico e dar visibilidade a ele como l?der e candidato à reeleição. Em três meses e meio, percorreu cerca de uma centena de munic?pios. Esteve insistentemente em Petrolina e no São Francisco, onde a aliança sofreu sucessivas derrotas.</P></p>
<p><P>Por fim, investiu de forma pesada em publicidade governamental para gravar na cabeça do pernambucano que ele representa a continuidade com mudança, que é exatamente aquilo que os eleitores desejam: continuidade em relação ao que está dando certo há sete anos e meio, mas com avanços naquilo que fracassou, como a Segurança Pública.</P></p>
<p><P>Erros significativos até agora, só os da oposição.</P></p>
<p><P>Mas é preciso serenidade para projetar o futuro. A campanha efetivamente ainda não começou. Falta a propaganda eleitoral.&nbsp;O guia significa um choque de realidade na disputa. Falta também ver o peso que terão Jarbas, Lula e João Paulo nessa guerra. E quem poderá ser beneficiado por um ou por outro. No in?cio da tarde,mostraremos os números sobre a força dos três como cabos eleitorais.<BR></P> </p>
