---
id: 12372294
data_publicacao: "2006-07-18 17:00:00"
data_alteracao: "None"
materia_tags: "atriz"
categoria: "Notícias"
titulo: "Atriz diz que jantaria com a filha"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>A bela e comportada Patr?cia França está aqui, ao lado, participando de um bate-papo na internet, no JC OnLine. </P></p>
<p><P>Disse que gastaria os mesmos R$ 1 mil reais pagos pelos&nbsp;convivas do jantar de Jarbas e Mendonça Filho em um jantar com a filha, em Orlando, nos EUA.</P></p>
<p><P>E você? Com quem jantaria por R$ 1 mil?</P></p>
<p><P>Dê sua opinião aqui abaixo, na seção comentários.</P> </p>
