---
id: 12372074
data_publicacao: "2006-07-29 08:00:00"
data_alteracao: "None"
materia_tags: "Humberto Costa,mendonça,natação"
categoria: "Notícias"
titulo: "É desespero de Humberto, ataca Mendonça"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>O governador e candidato à reeleição Mendonça Filho (PFL) emitiu sinais ontem de que não vai mais se limitar ao discurso administrativo – como vinha fazendo até agora – principalmente diante das provocações dos adversários que engrossam o tom contra o governista. Embora sua reação tenha sido fruto de questionamentos dos jornalistas que o acompanharam em eventos de campanha, ontem à noite, no munic?pio de Ipojuca, o governador fugiu ao seu estilo habitual. </FONT></P></p>
<p><P><FONT face=Verdana>E revidou as provocações do candidato do PT, Humberto Costa, e as cobranças do candidato socialista Edurado Campos (PSB).</FONT></P></p>
<p><P><FONT face=Verdana>Valendo-se de uma boa dose de ironia, Mendonça Filho disse que enxergava \"muito desespero\" do candidato petista quando este cobrava-lhe explicações de supostas irregularidades ocorridas no governo Jarbas Vasconcelos (PMDB) – gestões em que Mendonça ocupava a função de vice-governador – e ainda o desafiava a reproduzir o público alcançado por ele (Humberto) numa caminhada realizada no Centro do Recife, na quinta-feira.</FONT></P></p>
<p><P><FONT face=Verdana>\"Tem gente que está muito preocupado e aperreado. E tem motivos para isso. É o desespero chegando. Ele (Humberto) deve estar muito desesperado. Deve ter sido muito incômodo para ele os últimos dias. Ele talvez não esteja dormindo direito ou coisa desse tipo\", ironizou.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinantes JC e UOL).</FONT></P> </p>
