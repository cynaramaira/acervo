---
id: 12372227
data_publicacao: "2006-07-22 12:31:00"
data_alteracao: "None"
materia_tags: "animais,jarbas vasconcelos,mendonça,natação,pernambuco"
categoria: "Notícias"
titulo: "Mendonça é o mais limpo para Pernambuco, ataca Jarbas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>O ex-governador bateu duro na oposição e fez referências diretas a Humberto Costa (PT), no discurso que acaba de proferir na inauguração do comitê cental da União por Pernambuco, no Recife.</P></p>
<p><P>Segundo Jorge Cavalcanit, repórter do JC, Jarbas Vasconcelos (PMDB) disparou:</P></p>
<p><P>\"Mendonça é o melhor e o mais limpo para Pernambuco. Não devemos votar em sanguessugas, ladrões e em gente que não presta\".</P> </p>
