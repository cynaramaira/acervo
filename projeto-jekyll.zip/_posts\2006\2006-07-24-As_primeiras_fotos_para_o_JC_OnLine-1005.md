---
id: 12372178
data_publicacao: "2006-07-24 11:00:00"
data_alteracao: "None"
materia_tags: "fotos,JC Online"
categoria: "Notícias"
titulo: "As primeiras fotos para o JC OnLine"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Candidata a deputada estadual pelo PSB de Eduardo Campos, Débora Daggy fez este ensaio exclusivo para o JC OnLine quatro anos e meio atrás, quando ficou famosa por namorar o então governador Jarbas Vasconcelos (PMDB).</FONT></P> </p>
