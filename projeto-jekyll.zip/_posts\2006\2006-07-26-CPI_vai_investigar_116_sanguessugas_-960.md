---
id: 12372133
data_publicacao: "2006-07-26 12:20:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "CPI vai investigar 116 sanguessugas "
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>SÃO PAULO – A CPI dos Sanguessugas divulgou ontem um número</p>
<p> de 116 congressistas e ex-congressistas investigados por suposto envolvimento com a máfia da venda de ambulâncias superfaturadas. Entre eles está o deputado e ex-ministro da Saúde Saraiva Felipe (PMDB-MG). Felipe terá que explicar à comissão a sua relação com a ex-servidora do ministério Maria da Penha Lino, apontada como o braço da quadrilha no Executivo. </FONT></P></p>
<p><P><FONT face=Verdana>Na lista dos 116 investigados, os que atualmente possuem mandato somam 87 deputados federais e três senadores, o que representa 15% do Congresso Nacional. A CPI chegou aos 90 congressistas investigados por meio de duas triagens: 57 são alvos de inquéritos comandados pelo Supremo Tribunal Federal, sendo que seus nomes já eram conhecidos, e os outros 33, que tiveram os nomes revelados ontem, surgiram nos depoimentos à Justiça de Luiz Antonio Trevisan Vedoin e de seu pai, Darci Vedoin, da Planam, empresa que chefiaria a máfia ao superfaturar a venda de ambulâncias a prefeituras. </FONT></P></p>
<p><P><FONT face=Verdana>Entre os novos nomes, que foram notificados ontem, estão os dos senadores Magno Malta (PL-ES) e Serys Slhessarenko (PT-MT), e dos deputados Marcos de Jesus (PFL-PE) e Paulo Magalhães (PFL-BA), sobrinho do senador Antônio Carlos Magalhães (PFL-BA).</FONT></P><FONT face=Verdana></p>
<p><P>Leia <STRONG><U><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></U></STRONG> o texto completo (assinantes JC e UOL).</P></FONT> </p>
