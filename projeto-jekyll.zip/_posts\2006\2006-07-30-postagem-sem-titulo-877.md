---
id: 12372050
data_publicacao: "2006-07-30 13:34:00"
data_alteracao: "None"
materia_tags: "None"
categoria: "Notícias"
titulo: ""
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana><STRONG>“Há sete anos que esse pessoal fica com essa conversa de que pegou o Estado falido. Mas isso não cola mais e só mostra o completo despreparo deles. Essa farsa vai acabar. Eu não quero que o governador deixe o governo para bater boca. Mas ele vai deixar o Palácio no dia 1º de janeiro porque eu vou ganhar essa eleição???</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Eduardo Campos, candidato do PSB ao governo de Pernambuco, rebatendo ataques de Mendonça Filho (PFL), que disputa a reeleição</FONT></P> </p>
