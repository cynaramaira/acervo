---
id: 12372002
data_publicacao: "2006-08-01 19:13:00"
data_alteracao: "None"
materia_tags: "eduardo,Humberto Costa"
categoria: "Notícias"
titulo: "Humberto abre 10 pontos sobre Eduardo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Resultados sobre as eleições em Pernambuco, divulgados agora há pouco no NETV, da Globo. </FONT></P></p>
<p><P><FONT face=Verdana>Mendonça Filho (PFL)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 32%</FONT></P></p>
<p><P><FONT face=Verdana>Humberto Costa (PT)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 24%</FONT></P></p>
<p><P><FONT face=Verdana>Eduardo Campos (PSB)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 14%</FONT></P></p>
<p><P><FONT face=Verdana>Os demais - Clóvis Corrêa (Prona), Kátia Telles (PSTU), Luiz Vidal (PSDC), Rivaldo Soares (PSL) e Renê Patriota (PV) tiveram 1%, cada</FONT></P></p>
<p><P><FONT face=Verdana>Oswaldo Alves (PCO) não conseguiu atingir&nbsp;1%</FONT></P></p>
<p><P><FONT face=Verdana>Brancos e nulos&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 10%</FONT></P></p>
<p><P><FONT face=Verdana>Não sabe e não opiniou&nbsp;&nbsp;&nbsp;&nbsp; 14%</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>METODOLOGIA</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>O levantamento foi realizado entre os dias 29 e 31 de julho. Foram ouvidas 1.806 pessoas em 78 munic?pios pernambucanos. A margem de erro é de dois pontos percentuais para mais ou para menos. A pesquisa foi registrada no Tribunal Regional Eleitoral com o número 11112/2006.<BR></P></FONT> </p>
