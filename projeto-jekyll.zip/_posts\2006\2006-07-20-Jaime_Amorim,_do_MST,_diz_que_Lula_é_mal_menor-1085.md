---
id: 12372258
data_publicacao: "2006-07-20 12:26:00"
data_alteracao: "None"
materia_tags: "jaime lerner,Lula,minist,odacy amorim"
categoria: "Notícias"
titulo: "Jaime Amorim, do MST, diz que Lula é mal menor"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>O l?der dos sem-terra em Pernambuco pretende participar do com?cio de Lula, no sábado, em Bras?lia Teimosa, no Recife, mas está desmotivado. \"Vamos estar na campanha, mas não é com a mesma motivação de 2002\", disse ele, em entrevista a Carlos Moraes, logo cedo, no programa de Geraldo Freire, na Rádio Jornal.</FONT></P></p>
<p><P><FONT face=Verdana>Amorim afirmou que o MST defende o voto em Lula para evitar o \"mal pior\", que é Geraldo Alckmin (PSDB), ex-governador de São Paulo e principal adversário do presidente. Ele também defendeu o governo com relação à reforma agrária. Argumentou que o governo não tem conseguido fazer mais porque o Estado brasileiro não está preparado para isso.</FONT></P></p>
<p><P><FONT face=Verdana>Ouça a entrevista, que começa com explicações sobre o conflito no Engenho São João, em São Lourenço da Mata, Região Metropolitana do Recife.</FONT></P></FONT> </p>
