---
id: 12372049
data_publicacao: "2006-07-30 12:00:00"
data_alteracao: "None"
materia_tags: "jarbas vasconcelos,mendonça,variantes"
categoria: "Notícias"
titulo: "Mendonça diz que só existe o antes e o depois Jarbas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>CARUARU – Com discursos articulados, revelando que a estratégia da União por Pernambuco é propagar a idéia de uma divisão no Estado entre o antes e o depois dos governos Jarbas Vasconcelos</p>
<p> (PMDB), os candidatos da chapa governista realizaram, ontem, nesta cidade, a 120 quilômetros do Recife, uma grande caminhada com?cio, no qual os focos foram o último governo Miguel Arraes e os escândalos no governo Lula. </FONT></P></p>
<p><P><FONT face=Verdana>“Essa eleição vai dizer se Pernambuco quer voltar a um&nbsp; passado nebuloso ou consolidar um processo de mudança rumo ao desenvolvimento???, afirmou o candidato à reeleição, Mendonça Filho (PFL), depois de afirmar que Jarbas encontrou o Estado “no fundo do poço???. </FONT></P></p>
<p><P><FONT face=Verdana>Na terra dos candidatos a vice e ao Senado na chapa de Eduardo Campos (PSB), João Lyra Neto e Jorge Gomes, respectivamente, os organizadores do ato garantiram ter feito o maior ato da campanha até o momento, e estimaram em oito mil pessoas o total de presentes. </FONT></P></p>
<p><P><FONT face=Verdana>Reforçando a distinção dos palanques, o pefelista ressaltou que o seu “é limpo, honrado e trabalha para continuar avançando em Pernambuco???.</FONT></P> </p>
