---
id: 12372091
data_publicacao: "2006-07-28 19:21:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Bilhete à senadora HH"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT</p>
<p> face=Verdana>Do ex-blog de <STRONG>Cesar Maia</STRONG><BR>(prefeito do Rio, PFL)</FONT></P></p>
<p><P><FONT face=Verdana>Cara senadora,</FONT></P></p>
<p><P><FONT face=Verdana>Aqui no Rio é tiro n\água. Pesquisa na Capital do GPP, no sábado e domingo, com 1.200 eleitores nos mostra o seguinte:<BR><BR>1. Avaliação da administração da governadora Rosinha Garotinho: Bom 15,5%. Mais ou Menos 29,5%. Ruim 53,4%.<BR><BR>2. Você prefere que o Rio continue a ser administrado pelo partido e grupo pol?tico do ex-governador Garotinho? Sim 23,1%. Não 65,7%. Não respondeu 11,2%.<BR><BR>Ah...já sei, senadora, o que vai dizer: Por que o Sergio Cabral está na frente no Rio? Vou falar só da Capital onde mais pessoas sabem a resposta abaixo: (qual desses candidatos é o candidato do partido e grupo pol?tico do ex-governador Garotinho ?). Não sabe+outro nome, (que não o de Cabral): 69,9%. A resposta certa, Sergio Cabral foi dada por 30,1%.</FONT></P></p>
<p><P><FONT face=Verdana>Envie Garotinho para ser coordenador de sua campanha bem longe do Rio! Envie ele de terninho pentecostal com gravatinha aleluia da loja que vende fraldas superfaturadas! PT, desculpe, PSOL, saudações.<BR><BR></FONT><B><FONT face=Verdana>Folha de SP<BR></FONT></P></B></p>
<p><P><FONT face=Verdana>Após dizer que ficaria \"neutro\", Garotinho declara apoio a Helo?sa<BR><BR>O ex-governador do Rio Anthony Garotinho e o grupo que, sob o comando do economista Carlos Lessa, preparava o programa econômico do PMDB aderiram à candidatura de Helo?sa Helena (P-SOL) à Presidência. Por meio do assessor Carlos Rayel, Garotinho confirmou a intenção de votar na senadora.</FONT></P> </p>
