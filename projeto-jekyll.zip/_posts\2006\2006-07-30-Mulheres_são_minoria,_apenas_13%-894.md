---
id: 12372067
data_publicacao: "2006-07-30 08:15:00"
data_alteracao: "None"
materia_tags: "minoria,mulheres,são"
categoria: "Notícias"
titulo: "Mulheres são minoria, apenas 13%"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Os registros do Tribunal Regional Eleitoral (TRE) mostram que as mulheres candidatas são franca minoria na disputa pelos cargos proporcionais. Seja entre os candidatos a deputados federais ou estaduais, as mulheres representam apenas 13% do total dos candidatos. </FONT></P></p>
<p><P><FONT face=Verdana>No caso da briga por um mandato na Assembléia Legislativa, existem 64 mulheres na disputa contra 435 homens. Na disputa por um mandato federal, são apenas 29 mulheres contra 185 candidatos do sexo masculino.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinantes JC e UOL).</FONT></P> </p>
