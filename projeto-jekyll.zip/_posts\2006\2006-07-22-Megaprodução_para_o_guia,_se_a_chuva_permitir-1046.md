---
id: 12372219
data_publicacao: "2006-07-22 17:35:00"
data_alteracao: "None"
materia_tags: "chuva"
categoria: "Notícias"
titulo: "Megaprodução para o guia, se a chuva permitir"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>A chuva começou.</FONT></P></p>
<p><P><FONT face=Verdana>Tem uma baita estrutura de produção do guia eleitoral de Humberto Costa montada na frente do palco do com?cio de Lula. Há um cercado com uma megagrua, aquele gindaste que permite a realização de imagens aéreas em movimento. Poucas pessoas poderão ir até aquele lugar. </FONT></P></p>
<p><P><FONT face=Verdana>A maior parte do espaço foi reservado para o pessoal da Videotape, produtora de Humberto. A organização diz que a produtora está emprestada para o guia eleitoral de Lula.</FONT></P></p>
<p><P><FONT face=Verdana>Este é o primeiro com?cio e o primeiro ato de rua da campanha de reeleição do presidente.</FONT></P></FONT> </p>
