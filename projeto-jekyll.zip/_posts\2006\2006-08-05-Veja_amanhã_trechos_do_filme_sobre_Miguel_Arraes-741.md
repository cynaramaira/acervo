---
id: 12371914
data_publicacao: "2006-08-05 14:00:00"
data_alteracao: "None"
materia_tags: "cerveja,Filme,Miguel Arraes"
categoria: "Notícias"
titulo: "Veja amanhã trechos do filme sobre Miguel Arraes"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Arial><FONT face=Verdana>O Blog&nbsp;disponibiliza amanhã, a partir das 6h, dois trechos do filme Miguel Arraes - O guerreiro do povo. Conheça um pouco mais:</FONT></FONT></P></p>
<p><P><FONT face=Arial><FONT face=Verdana>Por <STRONG>Paulo Sérgio Scarpa</STRONG><BR></FONT><FONT face=Verdana>Colunista do Jornal do Commercio</FONT></P></p>
<p><P><FONT face=Verdana>O DVD Miguel Arraes - O guerreiro do povo começa com uma confissão: \"Meu objetivo sempre foi servir à população nas suas necessidades\", afirma o ex-governador. E termina com a cena do enterro, no Cemitério de Santo Amaro, com o caixão aplaudido pela multidão. </FONT></P></p>
<p><P><FONT face=Verdana>(...)</FONT></P></p>
<p><P><FONT face=Verdana>O documentário com 43 minutos foi dirigido por André Salles e Paulo Henrique Fontenelle, com a colaboração do diretor e filho Guel Arraes. E tem narração do ator José Wilker, que participou na década de 60 do Movimento de Cultura Popular (MCT), criado por Arraes quando na Prefeitura do Recife (eleito em 1959) e que se estenderia por todo Pernambuco, revolucionando o ensino de uma forma nunca vista no Brasil. </FONT></P></FONT> </p>
