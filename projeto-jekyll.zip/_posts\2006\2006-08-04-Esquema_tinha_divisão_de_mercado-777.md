---
id: 12371950
data_publicacao: "2006-08-04 06:49:00"
data_alteracao: "None"
materia_tags: "esquema criminoso,Mercado,Quarentinha"
categoria: "Notícias"
titulo: "Esquema tinha divisão de mercado"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Jamildo Melo</STRONG> e <STRONG>Jorge Cavalcanti</STRONG><BR></FONT><FONT face=Verdana>Repórteres de Pol?tica do JC</FONT></P></p>
<p><P><FONT face=Verdana>A Pol?cia Federal vai investigar outras sete empresas que atuavam no mercado de liberação de emendas parlamentares para a compra de ve?culos especiais, entre elas a KM Empreendimentos LTDA, situada no munic?pio de Jaboatão dos Guararapes, na Região Metropolitana do Recife.</FONT></P></p>
<p><P><FONT face=Verdana>De acordo com o depoimento do sócio-proprietário da Planam, Luiz Antônio Vedoin, prestado ontem à CPI das Sanguessugas, as empresas faziam reserva de mercado e a KM detia a maior parte dos negócios com as prefeituras do Nordeste.</FONT></P></p>
<p><P><FONT face=Verdana>Segundo o vice-presidente da CPI, deputado Raul Jungmann (PPS), Vedoin afirmou que a Planam – pivô do esquema da Máfia das Ambulâncias – não entrava em algumas regiões por respeito ao acordo de participação em licitações com as demais empresas. </FONT></P></p>
<p><P><FONT face=Verdana>\"Ela (a KM) é a Planam de Pernambuco\", afirmou Jungmann. Segundo o parlamentar, a empresa também atuava no fornecimento de unidades para os programas de inclusão digital. </FONT></P></p>
<p><P><FONT face=Verdana>Jungmann contou ainda que, ao responder se havia mais algum parlamentar pernambucano citado no esquema fraudulento além do deputado Marcos de Jesus (PFL), o empresário foi taxativo: \"Conosco não, porque a KM dominava tudo. A gente não dividia mercado com ela\". Vedoin citou mais duas empresas nominalmente: Delta e Leal Máquinas, que atuariam em outras regiões.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://jc3.uol.com.br/jornal/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinates JC e UOL).</FONT></P> </p>
