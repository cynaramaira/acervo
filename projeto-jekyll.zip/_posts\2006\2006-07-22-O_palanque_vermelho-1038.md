---
id: 12372211
data_publicacao: "2006-07-22 20:09:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "O palanque vermelho"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>O com?cio marcou o in?cio da campanha de rua à reeleição de Lula. Terminou há pouco.</P></p>
<p><P>Humberto e Eduardo estiveram o tempo inteiro juntos e ao lado do presidente. Mas embaixo a guerra de slogans e logomarcas era intensa.</P></p>
<p><P>Ariano deu o espetáculo dele e Lula avisou à oposição que não receberá os ataques calado.</P> </p>
