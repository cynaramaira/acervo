---
id: 12371993
data_publicacao: "2006-08-02 08:20:00"
data_alteracao: "None"
materia_tags: "candidatos,reagendamentos"
categoria: "Notícias"
titulo: "A agenda dos candidatos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana><STRONG>MENDONÇA FILHO (PFL)</STRONG></FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Às 19h</STRONG>,&nbsp;reúne-se com Jarbas&nbsp;Vasconcelos (candidato ao Senado) e lideranças religiosas no terreiro do Pai Moacir, na rua Madri, sem número, Ipsep, Recife.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Às 20h30</STRONG>,&nbsp;tem reunião com lideranças pol?ticas de Olinda, ligadas à deputada estadual Jacilda Urquisa, no Espaço Dayse</p>
<p> </FONT><FONT face=Verdana>Nogueira, na avenida Carlos de Lima Cavalcanti.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>HUMBERTO COSTA (PT)</STRONG></FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Às 18h</STRONG>, participa de plenária com militantes do Recife, na quadra do Clube Internacional.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Às 19h30</STRONG>, realiza caminhada no Recife, saindo da Praça da Torre com destino ao casarão do Cordeiro.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>EDUARDO CAMPOS (PSB)</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Está em Bras?lia, devido a compromissos na Câmara Federal. Só retorna amanhã.</FONT></P> </p>
