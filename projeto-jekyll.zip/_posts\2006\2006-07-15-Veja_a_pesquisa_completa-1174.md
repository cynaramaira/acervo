---
id: 12372347
data_publicacao: "2006-07-15 19:39:00"
data_alteracao: "None"
materia_tags: "cerveja,pesquisa"
categoria: "Notícias"
titulo: "Veja a pesquisa completa"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>No site de eleições do JC. Clique <A href=\"https://jc3.uol.com.br/especiais/eleicoes2006/2006/07/15/not_249.php\" target=_blank>aqui</A> para ver.</P> </p>
