---
id: 12371994
data_publicacao: "2006-08-01 21:52:00"
data_alteracao: "None"
materia_tags: "internada,pesquisa,resultado"
categoria: "Notícias"
titulo: "PSB revela resultado de pesquisa interna"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT color=#545454 size=2></p>
<p><P><FONT face=Verdana>Para contrapor os números divulgados pela pesquisa&nbsp;Ibope/TV Globo, o PSB&nbsp;garante&nbsp;ter uma pesquisa interna, com 1.500 questionários, realizada no mesmo per?odo da do Ibope, mas que aponta cenários bem diferentes. </FONT></P></p>
<p><P><FONT face=Verdana>Segundo a assessoria de imprensa do partido,&nbsp;o levantamento dos socialistas aponta os seguintes números:</FONT></P><FONT color=#545454 size=2></p>
<p><P><FONT face=Verdana>Pesquisa estimulada (quando apresenta as opções):</FONT></P></p>
<p><P><FONT face=Verdana>MENDONÇA FILHO (PFL)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 32,1%</FONT></P></p>
<p><P><FONT face=Verdana>EDUARDO CAMPOS (PSB)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 24,2%</FONT></P></p>
<p><P><FONT face=Verdana>HUMBERTO COSTA&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;20,8%</FONT></P></p>
<p><P><FONT face=Verdana>Pesquisa espontânea:</FONT></P></p>
<p><P></FONT><FONT face=Verdana size=2>MENDONÇA FILHO (PFL)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 13,6%</FONT></P></p>
<p><P><FONT face=Verdana size=2>EDUARDO CAMPOS (PSB)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 8,7%</FONT></P></p>
<p><P><FONT size=2><FONT face=Verdana>HUMBERTO COSTA&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 4,6%</FONT></FONT></P></p>
<p><P><FONT face=Verdana size=2>Ainda segundo a assessoria de Eduardo Campos, a pesquisa interna do PSB será devidamente registrada, informa Jorge Cavalcanti, repórter do <STRONG>JC</STRONG>. (Ver tópico 6 da nota do PSB à Imprensa, abaixo).</FONT></P></p>
<p><P><FONT size=2></FONT><BR>&nbsp;</P></FONT><B><FONT face=Arial size=2></B></FONT> </p>
