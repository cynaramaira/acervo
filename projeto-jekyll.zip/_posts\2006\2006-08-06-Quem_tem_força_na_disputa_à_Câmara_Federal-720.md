---
id: 12371893
data_publicacao: "2006-08-06 14:08:00"
data_alteracao: "None"
materia_tags: "Câmara,esquema criminoso,Força-Tarefa,Jorge Federal"
categoria: "Notícias"
titulo: "Quem tem força na disputa à Câmara Federal"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Inaldo Sampaio</STRONG><BR>Colunista de Pol?tica do JC</FONT></P></p>
<p><P><FONT face=Verdana>Oito coligações partidárias disputam as 25 vagas a que Pernambuco tem direito na Câmara Federal, que é formada por 513 parlamentares, porém somente as três maiores deverão eleger representantes: União pelo Avanço de Pernambuco (PMDB/PFL/PSDB/PPS), Pernambuco Melhor (PT/PTB/PCdoB/PMN/PAN/PRB) e Frente Popular de Pernambuco (PSB/PL/PDT/PP/PSC). </FONT></P></p>
<p><P><FONT face=Verdana>As outras cinco coligações são constitu?das por partidos nanicos e não deverão atingir o quociente eleitoral, sem o que não terão direito de ocupar vaga naquela Casa. Obtém-se o quociente eleitoral dividindo-se o número de votos válidos para a Câmara Federal pelo total de cadeiras que estão em jogo (25). </FONT></P></p>
<p><P><FONT face=Verdana>Calcula-se que serão apurados nessas eleições cerca de quatro milhões de votos válidos. Dividindo-se esses votos por 25, obtém-se o quociente eleitoral: 160 mil. Significa que por cada 160 mil votos que o partido ou a coligação obtiver, terá direito a uma cadeira. Os eleitos serão aqueles que obtiverem mais votos no partido ou na coligação, em ordem decrescente.</FONT></P><FONT face=Verdana></p>
<p><P>Leia <STRONG><EM><A href=\"https://jc3.uol.com.br/jornal/2006/08/06/not_195516.php\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinantes JC e UOL).</P></FONT> </p>
