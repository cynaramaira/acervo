---
id: 12372045
data_publicacao: "2006-07-31 07:14:00"
data_alteracao: "None"
materia_tags: "eduardo,mendonça"
categoria: "Notícias"
titulo: "Mendonça e Eduardo evitam se encontrar"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Mônica Crisóstomo</STRONG><BR>Repórter de Pol?tica do JC</FONT></P></p>
<p><P><FONT face=Verdana>GARANHUNS - A última noite da 16ª edição do Festival de Inverno de Garanhuns, no sábado, foi o cenário escolhido pelo deputado federal Eduardo Campos (PSB) e o governador Mendonça Filho (PFL) - adversários na briga majoritária nas eleições de outubro – para encerrar as atividades de campanha em munic?pios do Agreste, realizadas durante todo o fim de semana. Acompanhado por assessores, aliados pol?ticos e alguns militantes os postulantes aproveitaram para circular entre o público, distribuir acenos e apertos de mão.</FONT></P></p>
<p><P><FONT face=Verdana>A dupla, que tem protagonizado uma dura e crescente troca de farpas manteve distância. Mendonça Filho foi o primeiro a chegar, por volta das 23h30. Apesar de ter sido convidado para vários camarotes, onde costumava estar em anos anteriores (entre os quais o da prefeitura e de empresas privadas), o pefelista preferiu permanecer nas barracas montadas no entorno da praça Guadalajara. </FONT></P></p>
<p><P><FONT face=Verdana>Horas antes, Mendonça esteve reunido, em um jantar, com lideranças pol?ticas da região. O evento foi organizado pelo prefeito Luiz Carlos (PMDB) – o mesmo que no dia anterior fez discurso em defesa da candidatura do presidente Luiz Inácio Lula da Silva (PT), na inauguração do comitê local da campanha dos deputados Maur?cio Rands (federal) e Roberto Leandro (estadual), ambos do PT e candidatos à reeleição. </FONT></P></p>
<p><P><FONT face=Verdana>Eduardo chegou por volta da meia-noite. Apesar da previsão de que circularia pela praça, o candidato acabou seguindo direto para o camarote de um aliado pol?tico.</p>
<p> Fontes ligadas ao deputado confirmaram que o cancelamento aconteceu para evitar um eventual encontro com Mendonça Filho e sua comitiva. Horas antes, à tarde, dos dois haviam feitas duras cr?ticas um ao outro.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assiantes JC e UOL).</FONT></P> </p>
