---
id: 12372125
data_publicacao: "2006-07-26 20:08:00"
data_alteracao: "None"
materia_tags: "Antifa,Atlético-GO,dinheiro,pedro manta"
categoria: "Notícias"
titulo: "Pedro Eugênio considera anti-ético aplicar dinheiro no BNB"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Sobre nota publicada mais cedo, a assessoria do petista informou que:</FONT></P></p>
<p><P><FONT face=Verdana>O candidato a deputado federal, Pedro Eugênio (PT), explica que nunca aplicou no Banco do Nordeste do Brasil, porque como então diretor do BNB (2003/06)&nbsp; considera anti-ético esse tipo de ação. </FONT></P></p>
<p><P><FONT face=Verdana>O petista preferiu evitar conflitos particulares de aplicação com a instituição.<BR></P></FONT> </p>
