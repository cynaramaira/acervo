---
id: 12372322
data_publicacao: "2006-07-17 08:50:00"
data_alteracao: "None"
materia_tags: "Itaquitinga"
categoria: "Notícias"
titulo: "Aqui os internautas falam"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Republiquei alguns posts, principalmente aquele com o t?tulo \"Internauta rebate declaração de Humberto\", por causa do debate surgido na seção de comentários e por conta das cr?ticas feitas a mim e ao jornal.</P></p>
<p><P>Este espaço aqui é democrático, será aberto para temas e pontos de vista diversos. Essa foi a determinação</p>
<p> que recebi da direção da empresa, que deseja ter equil?brio na cobertura em todo o Sistema Jornal do Commercio de Comunicação. Com certeza, ao longo da campanha, que será apaixonada e intensa aqui em Pernambuco, muitos vão dizer que somos do cordão azul ou do encarnado.</P></p>
<p><P>Querida Carolina, este blog não é braço auxiliar da campanha de ninguém. Pode ter certeza que há uma legião de militantes me chamando de petista. Outra deve estar surgindo para me carimbar como mendoncista. É isso mesmo. A campanha nem começou ainda. Vamos ver como tudo isso estará daqui a dois meses.</P></p>
<p><P>Tenham certeza de que tudo o que for feito aqui levará em consideração apenas os marcos do bom jornalismo, nada mais. As cr?ticas a Laurindo Ferreira, diretor adjunto de redação do JC, sobre o parentesco dele com Nádia Ferreira, assessora de Mendonça, são absurdas. Ambos são profissionais de primeira linha, sérios. Tive a felicidade conhecê-los há 14 anos.</P></p>
<p><P>Tem mais. Será que podemos tachar de petista a deputada Luciana Genro, que fundou o P-SOL, faz oposição agressiva ao governo federal e é filha do ministro Tarso Genro, ex-presidente do PT e um dos principais assessores de Lula? E Renildo Calheiros, l?der do PCdoB na Câmara, será ele peemedebista fisiológico por ser irmão de Renan Calheiros, presidente do Senado?</P></p>
<p><P>É preciso, isto sim, abrir a cabeça para discutir Pernambuco sem medo. Sem medo quer dizer aceitar que os outros possam expressar suas opiniões, inclusive aquelas diferentes das nossas.</P></FONT> </p>
