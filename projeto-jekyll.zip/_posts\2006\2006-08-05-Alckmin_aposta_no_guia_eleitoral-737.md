---
id: 12371910
data_publicacao: "2006-08-05 08:00:00"
data_alteracao: "None"
materia_tags: "apostas,fundo eleitoral,geraldo Alckmin"
categoria: "Notícias"
titulo: "Alckmin aposta no guia eleitoral"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=Verdana></p>
<p><P>Do <STRONG>Jornal do Commercio</STRONG></P></FONT></p>
<p><P><FONT face=Verdana>Os maiores l?deres nacionais do PSDB e do PFL, à exceção do ex-presidente da República e presidente de honra tucano, Fernando Henrique Cardoso, que não compareceu ao Recife ontem, revelaram que a aposta da candidatura Geraldo Alckmin está toda jogada no guia eleitoral de TV e rádio, que começa no próximo dia 15. </FONT></P></p>
<p><P><FONT face=Verdana>Pefelistas e tucanos asseguraram que a campanha será propositiva, rejeitando a expectativa de agressividade, mas deixaram claro que vão mostrar os escândalos gerados no governo Lula. \"De nossa parte, não haverá baixo n?vel. Será propositivo, mas não vamos deixar de falar das irregularidades\", sinalizou o presidente do PSDB, Tasso Jereissati.</FONT></P></p>
<p><P><FONT face=Verdana>Leia o <STRONG><EM><A href=\"https://jc3.uol.com.br/jornal/\" target=_blank>texto</A></EM></STRONG> completo em Pol?tica, no JC (assinantes JC e UOL).</FONT></P> </p>
