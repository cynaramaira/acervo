---
id: 12372134
data_publicacao: "2006-07-26 11:18:00"
data_alteracao: "None"
materia_tags: "None"
categoria: "Notícias"
titulo: ""
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><STRONG>\"Vamos reimplantá-la, a Sudene\"</STRONG></P></p>
<p><P>Geraldo Alckmin, candidato à presidência da República pelo PSDB de Fernando Henrique Cardoso, que fechou a autarquia</P> </p>
