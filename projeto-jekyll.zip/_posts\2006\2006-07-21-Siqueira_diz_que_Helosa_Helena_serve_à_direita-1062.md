---
id: 12372235
data_publicacao: "2006-07-21 20:13:00"
data_alteracao: "None"
materia_tags: "Fafy Siqueira,Federal Reserve"
categoria: "Notícias"
titulo: "Siqueira diz que Helo?sa Helena serve à direita"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Do blog de <A href=\"https://www.lucianosiqueira.blogspot.com/\" target=_blank><STRONG>Luciano Siqueira</STRONG></A> </P></p>
<p><P>Na luta pol?tica, como na vida, nenhum fato, nem atitude, se encerra em si mesmo. Tudo se relaciona, tem nexo e conseqüências. Há mais de um ano a m?dia confere espaços privilegiados à senadora Heloisa Helena (PSOL-AL), desde que ela se voltou, com virulência comparável à de ACM, Artur Virg?lio e outros da mesma estirpe, contra o presidente Lula e o PT.</P></p>
<p><P>Fotos como a que ilustra esse o comentário são quase diárias: a senadora vibra ao lado dos seus neo-aliados pefelistas e tucanos. Tem sentido, portanto, a algazarra que a direita faz no momento no sentido de inflar a candidatura da senadora à presidência da República, com o propósito expl?cito de forçar a realização de um segundo turno – conforme as exultantes declarações de Alckmin e José Jorge. </P></p>
<p><P>Assim, o presidente Lula é cercado por um duplo bombardeio – pela direita, e à “esquerda???. Cabe a pergunta: a quem serve Heloisa Helena?</P> </p>
