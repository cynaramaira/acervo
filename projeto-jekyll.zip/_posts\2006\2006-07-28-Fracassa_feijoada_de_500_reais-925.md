---
id: 12372098
data_publicacao: "2006-07-28 12:23:00"
data_alteracao: "None"
materia_tags: "cereais"
categoria: "Notícias"
titulo: "Fracassa feijoada de 500 reais"
sutia: "None"
chapeu: "None"
autor: "jamildo"
imagem: "None"
---
<p>Fracassou o almo&ccedil;o de ades&atilde;o destinado a arrecadar fundos para a campanha de Inoc&ecirc;ncio Oliveira (PL) a deputado federal.</p>
<p>&Eacute; uma feijoada por R$ 500, no Musique, em Boa Viagem, zona sul do Recife.</p>
<p>A casa tem lugar para 500 pessoas, mas foram vendidos cerca de 50 ingressos, segundo Jorge Cavalcanti, rep&oacute;rter do JC.</p>
<p>O maior comprador at&eacute; agora &eacute; a rede de laborat&oacute;rios Cerpe, que pagou R$ 5 mil por dez ingressos.</p>
