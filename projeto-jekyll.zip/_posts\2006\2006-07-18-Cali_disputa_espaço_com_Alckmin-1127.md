---
id: 12372300
data_publicacao: "2006-07-18 11:47:00"
data_alteracao: "None"
materia_tags: "Califórnia,espaço,geraldo Alckmin"
categoria: "Notícias"
titulo: "Cali disputa espaço com Alckmin"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>A campanha eleitoral deste ano não vai&nbsp;dar certo na Rua Barão de Itamaracá, no Espinheiro, no Recife. </P></p>
<p><P>O ex-presidente da Infraero, Carlos Wilson Campos (PT),&nbsp;inaugura ali, no começo da noite, o comitê da campanha dele a deputado federal.</P></p>
<p><P>O problema é que na frente do imóvel vai funcionar o comitê em Pernambuco do presidenciável tucano Geraldo Alckmin, principal adversário de Lula, amigo-irmão de Wilson.</P></p>
<p><P>&nbsp;</P> </p>
