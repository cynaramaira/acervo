---
id: 12372244
data_publicacao: "2006-07-20 21:57:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "TSE abarrotado de consultas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>(Do site Contas Abertas)</FONT></P></p>
<p><P><FONT face=Verdana>As dúvidas sobre o que é permitido nas campanhas pol?ticas desse ano continuam no ar. As interrogações não ficam restritas aos eleitores. Partidos pol?ticos e candidatos também parecem perdidos com as novas regras. </FONT></P></p>
<p><P><FONT face=Verdana>As consultas ao TSE sobre o que vale ou não para as eleições deste ano aumentaram de maneira significativa se comparado a per?odos anteriores.<BR><BR>Com o in?cio de campanha oficial, as perguntas vindas dos órgãos nacionais de partidos pol?ticos e autoridades de jurisdição federal envolvem em maior número as ações eleitorais. </FONT></P></p>
<p><P><FONT face=Verdana>Segundo Assessoria do TSE, os ministros consideram que algumas consultas são desnecessárias e apenas constituem um método dos candidatos de tentarem desviar a legislação que, segundo o TSE, está clara na maioria dos pontos.</FONT></P></p>
<p><P><FONT face=Verdana>Leia texto completo no <STRONG><A href=\"https://contasabertas.uol.com.br/noticias/detalhes_noticias.asp?auto=1445\" target=_blank>Contas Abertas</A></STRONG>.</FONT></P> </p>
