---
id: 12372062
data_publicacao: "2006-07-29 12:06:00"
data_alteracao: "None"
materia_tags: "Conselho de Ética,eduardo,Humberto Costa"
categoria: "Notícias"
titulo: "Humberto e Eduardo se misturam em Bom Conselho"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Humberto Costa (PT) e Eduardo Campos (PSB) andam tão colados na disputa pelo governo de Pernambuco que terminaram fazendo, há pouco, uma caminhada quase conjunta na feira livre&nbsp;de Bom Conselho, no Agreste, a 275Km do Recife.</P></p>
<p><P>Eles distribuiam panfletos e se apresentavam aos eleitores, segundo Cec?lia Ramos, repórter do <STRONG>Blog</STRONG>. Um separado do outro por apenas duas barracas.</P></p>
<p><P>As militâncias, pagas ou não, acabaram se misturando. Por sorte todo mundo mostrou-se comportado, nada de rusgas.</P></p>
<p><P>Muita gente ficou confusa por causa dos panfletos semelhantes, trazendo as fotos deles ao lado de Lula.</P></p>
<p><P>Humberto teve 22% na última pesquisa de intenção de voto realizada pelo Vox Populi com exclusividade para o JC. Eduardo recebeu 21%.</P></p>
<p><P>À frente deles ficou o governador Mendonça Filho (PFL), com 35%.</P> </p>
