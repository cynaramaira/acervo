---
id: 12372100
data_publicacao: "2006-07-28 09:15:00"
data_alteracao: "None"
materia_tags: "cidades,esta"
categoria: "Notícias"
titulo: "Eymael também está na cidade"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Em seu segundo dia de campanha ao governo nas ruas, o vereador do Recife, Luiz Vidal (PSDC), terá a companhia do candidato à Presidência da República da sua legenda, José Maria Eymael, que chegou à cidade por volta da meia-noite. </FONT></P></p>
<p><P><FONT face=Verdana>Vidal e Eymael, que veio de carro da Para?ba onde participou de atos de campanha, começam o roteiro por uma visita protocolar a um seminário que será realizado pelo Sindicato dos Policiais Civis de Pernambuco (Sinpol), numa pousada em Olinda.</FONT></P></p>
<p><P><FONT face=Verdana>\"Queremos dar ênfase ao problema da segurança, por isso escolhemos privilegiar os policiais civis. É uma medida psicológica para melhorar a auto-estima deles. Recebi a informação de que é a primeira vez que um candidato a presidente visita, nestas eleições, esse tipo de sindicato\", disse Vidal, por telefone, ao <STRONG>JC</STRONG>.</FONT></P></p>
<p><P><FONT face=Verdana>À exemplo da candidata do P-SOL à presidência, senadora Heloisa Helena, que também estará hoje no Recife fazendo campanha, Eymael e Vidal farão uma caminhada pelo centro. </FONT></P></p>
<p><P><FONT face=Verdana>A diferença é que a dos democratas-cristãos será pela manhã, enquanto a da socialista acontecerá à tarde. Às 10h30, Eymael e Vidal sairão da praça da Independência, seguindo pela Rua Duque de Caxias até a Rua da Praia. Depois do almoço, Eymael segue de avião para a Bahia onde também vai participar de atos de campanha.</FONT></P> </p>
