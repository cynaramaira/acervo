---
id: 12371997
data_publicacao: "2006-08-01 20:30:00"
data_alteracao: "None"
materia_tags: "Humberto Costa"
categoria: "Notícias"
titulo: "Humberto diz que espera crescer mais"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>O candidato a governador pelo PT está no Rio de Janeiro, avaliando uma pesquisa com a MP5, do jornalista Augusto Fonseca, responsável pelo marketing da campanha dele.</FONT></P></p>
<p><P><FONT face=Verdana>Por meio da assessoria de imprensa, Humberto divulgou agora a seguinte nota: </FONT></P></p>
<p><P><FONT face=Verdana><STRONG>NOTA À IMPRENSA </STRONG></FONT></P></p>
<p><P><FONT face=Verdana>O candidato ao Governo de Pernambuco pela coligação Melhor pra Pernambuco (PT, PCdoB, PTB, PMN, PAN e PRB), Humberto Costa, tem as seguintes considerações a fazer sobre a pesquisa Ibope/Datafolha, divulgada esta noite, pela Rede Globo Nordeste:</FONT></P></p>
<p><P><FONT face=Verdana>I – Humberto se mostrou contente com o resultado, já que, para ele, as pesquisas refletem o atual momento da campanha. Ele diz que ainda é cedo para falar em definição, mas que</p>
<p> o que ficou mais claro na pesquisa é a grande tendência de haver um segundo turno. Para Humberto, por maior que tenha sido o esforço, o governador-candidato Mendonça Filho não conseguiu capitalizar a popularidade do seu antecessor. </FONT></P></p>
<p><P><FONT face=Verdana>II – O candidato da coligação Melhor pra Pernambuco diz que a pesquisa confirma o potencial de crescimento que a sua candidatura possui. Ele lembra que jamais largou com um percentual tão alto nas disputas majoritárias anteriores. Humberto acredita que, com o in?cio do guia eleitoral, a população vai passar a conhecer seus projetos e a tendência é que sua candidatura cresça ainda mais. </FONT></P></p>
<p><P><FONT face=Verdana>III – Humberto Costa deixa claro que esse é o momento da militância da coligação Melhor pra Pernambuco manter os pés no chão e redobrar os esforços. Ele lembra que ainda faltam cerca de 60 dias para as eleições e reafirma que o quadro não está definido. Para o candidato da Melhor pra Pernambuco, sua militância já demonstrou em eleições anteriores ser a mais organizada e consciente e a única que pode realmente fazer a diferença.</FONT> </P> </p>
