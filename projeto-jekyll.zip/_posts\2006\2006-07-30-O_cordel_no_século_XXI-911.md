---
id: 12372084
data_publicacao: "2006-07-30 11:09:00"
data_alteracao: "None"
materia_tags: "Nando Cordel"
categoria: "Notícias"
titulo: "O cordel no século XXI"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Maria Alice Amorim</STRONG><BR></FONT><FONT face=Verdana>Jornalista e pesquisadora</FONT></P></p>
<p><P align=left><FONT face=Verdana></FONT></P></p>
<p><P align=left><FONT face=Verdana>Embora se tenha anunciado tantas vezes o fim da literatura de cordel, sobretudo com o vertiginoso avanço tecnológico dos meios de comunicação de massa, a realidade é que o folheto se mantém vigoroso neste in?cio de século XXI. Uma prova de tal vigor são os t?tulos surgidos, em todo o pa?s, a partir dos fatos e desdobramentos do trágico <I>11 de setembro</I>, e a conseqüente aceitação do público, apesar de a m?dia ter explorado o assunto à exaustão. Longe de serem método ineficaz de comunicação ou desprovidos de valor literário, os folhetos sobre os atentados atra?ram a atenção de leitores e ouvintes, da m?dia impressa e eletrônica, levando, inclusive, à produção de matérias, artigos e reportagens. No folheto de circunstância, o fato jornal?stico ganha contornos próprios com a versificação e o charme da linguagem poética: em sintonia com as demandas contemporâneas, recheado de humor e ironia, mistura-se tradição, modernidade e os prazeres da arte.</FONT></P></p>
<p><P align=left><FONT face=Verdana><STRONG>Leia&nbsp;texto completo na coluna ao lado, na seção artigos.</STRONG></FONT></P> </p>
