---
id: 12394789
data_publicacao: "2006-05-22 20:00:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Alienação do terreno de Jiquiá renderá à FUNCEF R$ 7,34 milhões"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><p>Em reuni&atilde;o extraordin&aacute;ria realizada hoje (22/05), o Conselho Deliberativo aprovou a aliena&ccedil;&atilde;o do terreno da FUNCEF localizado no bairro de Jiqui&aacute;, em Recife (PE), pelo valor nominal de R$ 17,1 milh&otilde;es. O neg&oacute;cio, que render&aacute; &agrave; Funda&ccedil;&atilde;o um lucro cont&aacute;bil de R$ 7,34 milh&otilde;es, ser&aacute; fechado com a empresa Itacon Empreendimentos mediante permuta financeira de 5% sobre o Valor Geral de Vendas (VGV).</p></p>
<p><p>Segundo o diretor Imobili&aacute;rio, Jorge Arraes, caso as unidades n&atilde;o sejam todas vendidas, a FUNCEF ter&aacute;, al&eacute;m das garantias reais previstas em contrato, a garantia adicional de recebimento do valor de avalia&ccedil;&atilde;o do terreno.</p></p>
<p><p>Al&eacute;m de economicamente vantajosa para a FUNCEF, a proposta atende &agrave;s exig&ecirc;ncias da Resolu&ccedil;&atilde;o n&ordm;. 3.121 do Conselho Monet&aacute;rio Nacional (CMN), que obriga os fundos de pens&atilde;o a vender todos os terrenos n&atilde;o edificados da sua carteira e ao plano de enquadramento aprovado pela Secretaria de Previd&ecirc;ncia Complementar (SPC).</p></p>
<p><p>Formado por duas glebas e com &aacute;rea total de 333 mil 454 m&sup2;, o terreno vive sob constante amea&ccedil;a de invas&atilde;o. No local, ser&atilde;o constru&iacute;dos 252 pr&eacute;dios, com 4 apartamentos por andar, distribu&iacute;dos em 21 condom&iacute;nios.</p></p>
<p><p>As obras ser&atilde;o acompanhadas e supervisionadas pela equipe t&eacute;cnica da Diretoria Imobili&aacute;ria (DIMOB). O contrato de compromisso de compra e venda do im&oacute;vel entre a FUNCEF e a empresa Itacon dever&aacute; ser assinado no pr&oacute;ximo m&ecirc;s.</p></p>
<p><p>Comunica&ccedil;&atilde;o da FUNCEF</p> </p>
