---
id: 12372358
data_publicacao: "2006-07-15 12:03:00"
data_alteracao: "None"
materia_tags: "jarbas vasconcelos"
categoria: "Notícias"
titulo: "Jarbas cauteloso"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Em conversa por telefone agora há pouco com Cec?lia Ramos, repórter do blog, o ex-governador lembrou que ainda faltam 80 dias para a eleição. Por isso, Mendonça precisa manter o ritmo de trabalho, que, segundo ele, vem dando certo. Apesar da cautela, Jarbas considerou o resultado “muito bom??? e que os números refletem uma percepção dos pernambucanos sobre o comportamento e o desempenho de Mendonça à frente do governo.</P> </p>
