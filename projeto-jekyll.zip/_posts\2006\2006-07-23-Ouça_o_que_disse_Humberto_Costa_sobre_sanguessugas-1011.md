---
id: 12372184
data_publicacao: "2006-07-23 13:46:00"
data_alteracao: "None"
materia_tags: "Humberto Costa"
categoria: "Notícias"
titulo: "Ouça o que disse Humberto Costa sobre sanguessugas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p> </p>
