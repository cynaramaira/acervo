---
id: 12372117
data_publicacao: "2006-07-27 10:51:00"
data_alteracao: "None"
materia_tags: "Débora Dantas,registro"
categoria: "Notícias"
titulo: "Débora Daggy pode perder o registro"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Clóvis Andrade</STRONG><BR>Repórter do JC</FONT> </p>
<p><P><FONT face=Verdana>O prazo para que partidos e coligações protocolassem pedidos de registro de candidaturas no Tribunal Regional Eleitoral (TRE), visando a eleição de outubro, expirou há mais de 20 dias, mas a desatenção de muitos na hora de fazer a solicitação ainda gera confusão. </FONT></p>
<p><P><FONT face=Verdana>O TRE publica no Diário Oficial de amanhã os nomes de 333 candidatos que até o in?cio da noite de ontem ainda não haviam apresentado parte da documentação obrigatória para concorrer, dando 72 horas para que regularizem suas situações. Caso não atendam ao chamado, os retardatários poderão ficar de fora da disputa.</FONT> </p>
<p><P><FONT face=Verdana>Leia <STRONG><U><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></U></STRONG> reportagem completa (assinantes JC e UOL).</FONT> </p>
<p><P><FONT face=Verdana><STRONG>Comentário meu</STRONG>:</FONT> </p>
<p><P><FONT face=Verdana>Entre os 333 está Débora Daggy, modelo, miss Pernambuco 2001 e ex-namorada de Jarbas Vasconcelos. </FONT></p>
<p><P><FONT face=Verdana>Ela é candidata a deputada estadual pelo PSB de Eduardo Campos, arquiinimigo de Jarbas. <STRONG><U><A href=\"https://jc3.uol.com.br/blogs/jc/2006/07/24/index.php#248\">Veja aqui</A></U></STRONG> ensaio fotográfio de Débora, publicado pelo <STRONG>Blog </STRONG>na segunda-feira.</FONT></P> </p>
