---
id: 12371960
data_publicacao: "2006-08-03 15:33:00"
data_alteracao: "None"
materia_tags: "Humberto Costa,Pará"
categoria: "Notícias"
titulo: "Para salvar Humberto"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG><EM><A href=\"https://www.noblat.com.br/\" target=_blank>blog</A></EM></STRONG> de Noblat</FONT></P></p>
<p><P><FONT face=Verdana>Se necessário, o PT entregará a cabeça de José Airton Cirilo, membro do seu Diretório Nacional, para tentar salvar a cabeça do ex-ministro Humberto Costa, Secretário Nacional de Comunicação do partido e candidato ao governo de Pernambuco.</FONT></P></p>
<p><P><FONT face=Verdana>Há pouco, o senador Sibá Machado (PT-AC) deixou a sala da Superintendência da Pol?cia Federal onde a CPI dos Sanguessugas toma o depoimento do empresário Luiz Antonio Vedoin, o cabeça do esquema da venda superfaturada de ambulâncias. E disse:</FONT></P></p>
<p><P><FONT face=Verdana>- Vedoin está sendo muiro rancoroso com Humberto Costa. Nós lembramos a ele que seu pai, Darci, disse à Pol?cia que nunca esteve com Humberto e que nada sabe que possa implicá-lo no esquema dos sanguessugas. Ele acabou concordando.</FONT></P> </p>
