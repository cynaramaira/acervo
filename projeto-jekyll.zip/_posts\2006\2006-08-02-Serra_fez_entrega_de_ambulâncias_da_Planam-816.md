---
id: 12371989
data_publicacao: "2006-08-02 09:15:00"
data_alteracao: "None"
materia_tags: "entrega,Serrana"
categoria: "Notícias"
titulo: "Serra fez entrega de ambulâncias da Planam"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Da <STRONG>Folha de S.Paulo<BR></STRONG></FONT><FONT face=Verdana><BR>No depoimento, Darci Vedoin disse que, em 2000, o então ministro da Saúde José Serra teria participado da entrega de cerca de 50 ambulâncias compradas da Planam, mas não fez nenhuma acusação a Serra.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Comentário meu:</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Este parágrafo é o último da reportagem que trata de poss?veis ligações entre Antônio Alves, o ex-chefe de gabinete de Humberto Costa, com a máfia das sanguessugas.</P></p>
<p><P><BR></P></FONT><FONT face=Verdana></p>
<p><P>Leia <STRONG><EM><A href=\"https://www1.folha.uol.com.br/fsp/brasil/fc0208200602.htm\" target=_blank>aqui</A></EM></STRONG> texto completo (assinantes).</P></FONT> </p>
