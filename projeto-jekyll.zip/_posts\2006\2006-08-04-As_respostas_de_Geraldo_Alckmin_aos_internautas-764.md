---
id: 12371937
data_publicacao: "2006-08-04 13:29:00"
data_alteracao: "None"
materia_tags: "geraldo Alckmin"
categoria: "Notícias"
titulo: "As respostas de Geraldo Alckmin aos internautas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Daqui a pouco vamos postar tudo o que o presidenciável tucano disse em resposta a vocês que nos enviaram&nbsp;perguntas ontem e hoje.</FONT></P></p>
<p><P><FONT face=Verdana>Tem coisas muito interessantes.</FONT></P> </p>
