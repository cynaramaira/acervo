---
id: 12371897
data_publicacao: "2006-08-06 09:30:00"
data_alteracao: "None"
materia_tags: "AmCentral,emprego,geraldo Alckmin,Serasa"
categoria: "Notícias"
titulo: "Geração de emprego será tema central do guia de Alckmin"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=Verdana></p>
<p><P>Por <STRONG>Cec?lia Ramos</STRONG><BR>Repórter do Blog</P></FONT><FONT face=\"Times</p>
<p> New Roman\"></p>
<p><P><FONT face=Verdana>Quanto à propaganda eleitoral de Geraldo Alckmin, que vai ao ar no dia 15, o tema central será a geração de emprego e renda. \"Vamos mostrar que o desafio é promover crescimento da economia com desenvolvimento social\", explicou o economista João Carlos de Souza Meirelles, coordenador do programa de governo do tucano. </FONT></P></p>
<p><P><FONT face=Verdana>De acordo com o próprio Alckmin, em visita ao Jornal do Commercio, na última sexta-feira, o seu guia eleitoral será propositivo, mas sem esquecer os escândalos de corrupção envolvendo o Governo Lula. </FONT></P></p>
<p><P><FONT face=Verdana>\"O guia vai mostrar primeiro o candidato, o que nós ja fizemos, e depois o propositivo, dizendo que podemos avançar ainda mais. Essa (a corrupção) não será a questão central\", garantiu o tucano. </FONT></P></p>
<p><P><FONT face=Verdana>Na passagem de Alckmin pelo Recife, o ex-governador e candidato ao Senado, Jarbas Vasconcelos (PMDB) e o ex-presidente da República, Itamar Franco (ex-PMDB), gravaram mensagens para o programa do presidenciável. </FONT></P></p>
<p><P><FONT face=Verdana>Jarbas destacou o papel de Alckmin como governador de São Paulo, enalteceu o ajuste fiscal promovido naquele estado, apontou resultados positivos na saúde e no combate à violência.Ele também elogiou a decisão do presidenciável tucano de vir a Pernambuco lançar um programa espec?fico para o Nordeste. Itamar ressaltou o curr?culo do tucano, enfatizando-o como um \"l?der pol?tico honesto\".</FONT></P></FONT> </p>
