---
id: 12371978
data_publicacao: "2006-08-02 18:45:00"
data_alteracao: "None"
materia_tags: "Ibope,Mesa Diretora,Terror"
categoria: "Notícias"
titulo: "Houve um erro estratégico do PSB, diz diretora do Ibope"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>O <STRONG>Blog</STRONG> acaba de conversar, por telefone, com Márcia Cavallari, diretora do Ibope Opinião, em São Paulo. </FONT></P></p>
<p><P><FONT face=Verdana>Ela admite que a pesquisa divulgada ontem pela TV Globo Nordeste pode ter apresentado preju?zo para Eduardo Campos, candidato a governador pelo PSB. </FONT></P></p>
<p><P><FONT face=Verdana>Ele aparece com 14%, em terceiro lugar, atrás do petista Humberto Costa (24%) e do pefelista Mendonça Filho (32%). Veja <STRONG><EM><A href=\"https://jc3.uol.com.br/blogs/jc/2006/08/01/index.php#430\">aqui</A></EM></STRONG> os números.</FONT></P></p>
<p><P><FONT face=Verdana>Mas Cavallari rejeita qualquer acusação de que o Ibope tenha cometido erro. Se houve um equ?voco, diz ela, foi do PSB, ao inscrever seu candidato no TRE apenas como Eduardo, sem o Campos. \"Foi um erro estratégico\", avalia.</FONT></P></p>
<p><P><FONT face=Verdana>O Ibope também não fará uma nova pesquisa para avaliar se houve ou não preju?zo. E só haverá mudanças na forma de entrevistar os eleitores caso o PSB consiga acrescentar o Campos ao Eduardo, como foi pedido hoje pelo partido ao TRE.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>A entrevista:</STRONG></FONT></P></p>
<p><P><FONT face=Verdana><STRONG>As queixas do PSB procedem?</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>O erro não é nosso, é deles. Porque se você for no TRE o nome do Eduardo está só Eduardo. É a maneira como ele escolheu para aparecer na urna eletrônica. E o Ibope, em todas as suas pesquisas, utiliza a variação nominal registrada para aparecer na urna. A gente está fazendo exatamente como ele se registrou. O fato é que, por ele ter se registrado apenas como Eduardo, é provável que os eleitores não o tenham reconhecido como sendo Eduardo Campos.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Isso é poss?vel?</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>É poss?vel, sim. Por isso, ele pode ter tido um preju?zo, vamos dizer assim, no sentido de que as pessoas não o identificaram como Eduardo Campos. Na verdade o uso do nome Eduardo foi um erro estratégico do PSB. Ele é conhecido politicamente a? a vida inteira como Eduardo Campos, agora se registra como Eduardo? É claro que o problema desaparece a partir do momento em que a campanha fica mais intensa e que as pessoas comecem a associar Eduardo do Eduardo Campos. Quando começar a aparecer na televisão. Agora, hoje, quando você coloca um disco para os eleitores se posicionarem e você tem ali Mendonça, Humberto Costa, Eduardo e mais sete outros nomes, o eleitor pode ficar em dúvida se aquele Eduardo é o Eduardo Campos.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Os números podem estar realmente distorcidos?</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>É, mas acontece que a pesquisa do Ibope não tem nada de errado. Existe essa hipótese de que ele pode ter obtido um pouco menos de intenção de votos na pesquisa por essa não identificação do eleitor com o nome Eduardo.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>E esse pedido deles para que se faça uma revisão, isso é poss?vel?</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Não tem como fazer revisão porque a pesquisa está correta. Na verdade o que vai ter que ser feito...primeiro, o seguinte: a gente tem um contrato com a TV Globo de exclusividade de divulgação. Então só a TV pode divulgar a pesquisa Ibope. Não posso fazer para outro ve?culo, para um partido, nem uma outra entidade.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Não haveria possibilidade de realizar uma nova pesquisa para ver se houve esse preju?zo?</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Não, neste momento, não. A? tem que ver o seguinte. Se até a próxima pesquisa o nome dele tiver sido alterado para Eduardo Campos, a gente vai entrar com o nome como está registrado. Na nossa metodologia, para que a pesquisa</p>
<p> se aproxime o máximo poss?vel da realidade, a gente usa exatamente o nome como eles pedem para aparecer na urna eletrônica. Foi uma decisão estratégica equivocada deles de usar só como Eduardo. E, mesmo agora, você vai refazer como Eduardo Campos? E os outros vão reclamar porque ele não está registrado assim.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Quando sairá a próxima?</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Não posso dizer. A gente não divulga, até para os candidatos não fazerem nenhuma ação espec?fica por conta dessa data de divulgação.</FONT></P> </p>
