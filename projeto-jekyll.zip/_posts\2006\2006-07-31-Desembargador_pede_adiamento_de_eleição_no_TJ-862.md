---
id: 12372035
data_publicacao: "2006-07-31 17:20:00"
data_alteracao: "None"
materia_tags: "Adiamento,Desembargadores,eleição"
categoria: "Notícias"
titulo: "Desembargador pede adiamento de eleição no TJ"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Fernando Cerqueira pediu adiamento da votação da lista tr?plice. O pedido deve ser rejeitado. </FONT></P></p>
<p><P><FONT face=Verdana>Cerqueira disse que só conhece quatro dos seis nomes da lista sêxtupla apresentada pela OAB. Por isso, queria mais uns dias para avaliar os dois desconhecidos para ele.</FONT></P></p>
<p><P><FONT face=Verdana>O TJ vota neste momento os nomes que integrarão a lista tr?plice a ser encaminhada ao governador Mendonça Filho (PFL) para nomeação do novo desembargador.</FONT></P></p>
<p><P><FONT face=Verdana>Leia mais na nota <EM>Os três poderes de Jarbas e Mendonça</EM>, publicada abaixo.</FONT></P> </p>
