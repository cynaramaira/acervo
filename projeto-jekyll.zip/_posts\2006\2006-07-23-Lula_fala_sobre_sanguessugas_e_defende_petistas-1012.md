---
id: 12372185
data_publicacao: "2006-07-23 14:30:00"
data_alteracao: "None"
materia_tags: "Lula"
categoria: "Notícias"
titulo: "Lula fala sobre sanguessugas e defende petistas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p> </p>
