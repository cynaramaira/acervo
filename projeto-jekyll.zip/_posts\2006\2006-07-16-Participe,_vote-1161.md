---
id: 12372334
data_publicacao: "2006-07-16 17:44:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Participe, vote"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Você acha que haverá caixa 2 nestas eleições?<BR><BR>Dê sua opinião na coluna ao lado. </P></p>
<p><P>Das pessoas que visitaram o blog desde ontem, 160 votaram. O resultado parcial é o seguinte:</P></p>
<p><P>Sim&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 95%</P></p>
<p><P>Não&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5%</P> </p>
