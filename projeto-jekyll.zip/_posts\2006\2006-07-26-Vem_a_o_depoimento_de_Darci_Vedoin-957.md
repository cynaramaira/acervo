---
id: 12372130
data_publicacao: "2006-07-26 19:30:00"
data_alteracao: "None"
materia_tags: "depoimento"
categoria: "Notícias"
titulo: "Vem a? o depoimento de Darci Vedoin"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>A CPI das Sanguessugas deve esquentar entre hoje e amanhã, conforme fonte ouvida há pouco por Cec?lia Ramos, repórter do <STRONG>Blog</STRONG>.</FONT></P></p>
<p><P><FONT face=Verdana>Cópias dos depoimentos de Darci Vedoin e Ronildo Medeiros, sócios da Planam, chegam às mãos dos membros da comissão e, com certeza, começarão a ser vazados para a imprensa. </FONT><FONT face=Verdana>Mais gente deverá ser implicada no escândalo da compra superfaturada de ambulâncias.</FONT></P></p>
<p><P><FONT face=Verdana>Darci fez o mesmo que o filho Luiz Antônio Trevisan Vedoin. Passou dias prestando depoimentos ao Ministério Público Federal com esperança</p>
<p> de obter os benef?cios da delação premiada - redução da pena se ajudar nas investigações.</FONT></P> </p>
