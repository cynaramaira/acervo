---
id: 12371970
data_publicacao: "2006-08-03 06:51:00"
data_alteracao: "None"
materia_tags: "votos"
categoria: "Notícias"
titulo: "No terreiro de Pai Moacir, sob as bênçãos de Oxum"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><span style="font-family: Verdana;">L&aacute; estiveram ontem &agrave; noite, no Ipsep, na periferia do Recife, Jarbas Vasconcelos (PMDB) e Mendon&ccedil;a Filho (PFL). </span></p>
<p><span style="font-family: Verdana;">Foram cabalar votos e fechar o corpo. Conversaram com a comunidade e receberam prote&ccedil;&atilde;o para a guerra eleitoral, que nem come&ccedil;ou ainda.</span></p>
<p><span style="font-family: Verdana;">Jarbas saiu de l&aacute; com um presente de Pai Moacir: uma bela imagem de Oxum. </span></p>
<p><span style="font-family: Verdana;">Os filhos deste orix&aacute;, segundo o site <strong><em><a href="https://www.umbandaracional.com.br/oxum.html" target="_blank" rel="noopener noreferrer">Umbanda Racional</a></em></strong>, s&atilde;o assim:</span></p>
<p><span style="font-family: ';"><span style="font-family: Verdana;">T&ecirc;m imagem doce, que esconde uma determina&ccedil;&atilde;o forte e uma ambi&ccedil;&atilde;o bastante marcante. T&ecirc;m uma tend&ecirc;ncia para engordar, gostam da vida social, das festas e dos prazeres em geral. </span></span></p>
<p><span style="font-family: Verdana;">O sexo &eacute; importante para os filhos de Oxum. Eles tendem a ter uma vida sexual intensa e significativa.</span></p>
