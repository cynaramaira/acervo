---
id: 12372309
data_publicacao: "2006-07-17 18:03:00"
data_alteracao: "None"
materia_tags: "regras"
categoria: "Notícias"
titulo: "Regras para os comentários"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Bem </FONT><A href=\"mailto:amig@s\"><U><FONT color=#0000ff size=2>amig@s</U></FONT></A><FONT size=2>,</P></p>
<p><P>Reintroduzimos o espaço para comentários, mas agora, por questões legais e de respeito à legislação vigente no pa?s, decidimos introduzir um cadastro para que os internautas sejam identificados e assumam a responsabilidade pelo que dizem.</P></p>
<p><P>O comentário é de total responsabilidade do internauta que o inseriu. O Blog do JC reserva-se o direito de não publicar mensagens contendo palavras de baixo calão, publicidade, calúnia, injúria, difamação ou qualquer conduta que possa ser considerada criminosa.</P></p>
<p><P>Também reserva-se o direito de, a qualquer tempo e a seu critério, retirar mensagens que possam ferir normas legais ou as regras deste blog.</P></FONT> </p>
