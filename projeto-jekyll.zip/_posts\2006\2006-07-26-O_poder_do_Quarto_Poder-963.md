---
id: 12372136
data_publicacao: "2006-07-26 10:37:00"
data_alteracao: "None"
materia_tags: "poderosa"
categoria: "Notícias"
titulo: "O poder do Quarto Poder"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 10pt\"><FONT face=Verdana>Por <STRONG>Sérgio Montenegro Filho<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></STRONG></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 10pt\"><FONT face=Verdana>Repórter especial de Pol?tica do JC<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 10pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT size=2><SPAN style=\"FONT-SIZE: 9pt; FONT-FAMILY: Verdana\">O Brasil é mesmo um pa?s sui generis. Embalados pelo aroma da pizza, centenas de maus pol?ticos correm às urnas em outubro para brigar por uma - ou mais uma - chance de abocanhar uma fatia de poder. Parece que de nada adiantaram meses de manchetes, denúncias e investigações sobre o mensalão e o uso de dinheiro de caixa dois para financiar campanhas. Até porque, embora absolutamente mal explicado, o assunto já praticamente sumiu das páginas, sucedido por outro mais quente. É, lamentavelmente, a regra da m?dia.</SPAN><SPAN style=\"FONT-SIZE: 10pt\"><o:p></o:p></SPAN></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 10pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></SPAN></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><SPAN style=\"FONT-SIZE: 10pt\"><FONT face=Verdana>Leia <STRONG><U><A href=\"https://jc3.uol.com.br/2006/07/25/not_116053.php\" target=_blank>aqui</A></U></STRONG> o artigo completo.</FONT></SPAN></P> </p>
