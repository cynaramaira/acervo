---
id: 12372303
data_publicacao: "2006-07-18 09:30:00"
data_alteracao: "None"
materia_tags: "interior,Lula"
categoria: "Notícias"
titulo: "Lula com 74% no Interior"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>É o que mostra pesquisa publicada hoje no Jornal do Commercio. De acordo com os dados analisados por Sérgio Montenegro Filho, repórter especial de Pol?tica, o presidente Lula está, em todo o Estado, 50 pontos percentuais à frente de seu principal concorrente, o ex-governador de São Paulo Geraldo Alckmin (PSDB).</P></p>
<p><P>Na Região Metropolitana do Recife, Lula tem 38 pontos mais que Alckmin (56% a 18%).</P></p>
<p><P>Nas outras três regiões do Estado, Lula se apresenta com impressionantes 74% das intenções de voto em cada uma delas.</P></p>
<p><P>Daqui a pouco analisaremos melhor como esses números podem interferir na disputa pelo governo de Pernambuco.</P></p>
<p><P>Veja os <B><A href=\"https://jc3.uol.com.br/especiais/eleicoes2006/2006/07/18/not_266.php\">dados completos</A> </B>no site JC nas Eleições 2006.</P></FONT> </p>
