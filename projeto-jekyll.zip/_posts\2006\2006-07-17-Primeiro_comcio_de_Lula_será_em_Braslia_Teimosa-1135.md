---
id: 12372308
data_publicacao: "2006-07-17 18:18:00"
data_alteracao: "None"
materia_tags: "Brasília Teimosa,Lula,Primeiro Turno,Serasa"
categoria: "Notícias"
titulo: "Primeiro com?cio de Lula será em Bras?lia Teimosa"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>O blog confirmou agora com uma fonte do PT. O presidente inicia a campanha à reeleição no sábado, às 17h, com um com?cio em Bras?lia Teimosa, no Recife. </P></p>
<p><P>Os detalhes do evento foram discutidos há pouco em reunião, na sede do PCdoB,&nbsp;com a coordenação da campanha do ex-ministro&nbsp;Humberto Costa,&nbsp;formada pelo prefeito João Paulo, o vereador Dilson Peixoto, o deputado estadual Augusto César, a prefeita de Olinda, Luciana Santos, o vice-prefeito do Recife, Luciano Siqueira,&nbsp;e o presidente estadual do PCdoB, Alanir Cardoso.</P><FONT size=2></p>
<p><P>A escolha do local foi sugestão do próprio Lula, repassada hoje pelo presidente do PT, Ricardo Berzoini.</P></p>
<p><P>Bras?lia Teimosa tem um significado especial para Lula. Ele visitou o bairro pela primeira vez como presidente ainda em janeiro de 2003, poucos dias</p>
<p> após a posse. Na época, prometeu urbanizá-lo e construir casas populares para 435 fam?lias que viviam em palafitas, à beira-mar.</P></p>
<p><P>As fam?lias foram transferidas e o local onde viviam transformou-se na avenida Bras?lia Formosa, onde ocorrerá o com?cio. Elas hoje moram&nbsp;no Cordeiro,&nbsp;outro bairro do Recife, em um conjunto habitacional com 22 edf?cios e 56 casas.</P></p>
<p><P>Lula poderá ir também a Caetés, onde nasceu, no Agreste do Estado, a 252Km do Recife. A decisão será tomada até amanhã, depois que Lula desembarcar no Brasil.</P></FONT></FONT> </p>
