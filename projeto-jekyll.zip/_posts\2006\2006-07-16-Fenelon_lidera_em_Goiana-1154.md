---
id: 12372327
data_publicacao: "2006-07-16 18:22:00"
data_alteracao: "None"
materia_tags: "Goiana,liderança indígena"
categoria: "Notícias"
titulo: "Fenelon lidera em Goiana"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Foram abertas até agora 28% das urnas da 25ª zona eleitoral do munic?pio. Essa é a maior das duas zonas de Goiana. Reúne cerca de 70% do eleitorado.&nbsp;O que foi apurado até agora está dividido da seguinte forma:</P></p>
<p><P>Fenelon&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 40%</P></p>
<p><P>Edval&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;35%</P></p>
<p><P>&nbsp;</P> </p>
