---
id: 12371955
data_publicacao: "2006-08-03 18:52:00"
data_alteracao: "None"
materia_tags: "pernambuco"
categoria: "Notícias"
titulo: "A KM é a Planam de Pernambuco"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Podem surgir mais pernambucanos envolvidos com o esquema das sanguessugas. Descobriu-se hoje uma conexão em Pernambuco ligada diretamente aos escândalos denunciados pela CPI.</FONT></P></p>
<p><P><FONT face=Verdana>Em depoimento prestado em Bras?lia, hoje, o empresário Luiz Antônio Vedoin, l?der do esquema, falou da empresa KM Empreendimentos LTDA, instalada em Jaboatão dos Guararapes e gozando de benef?cios fiscais do Estado.</FONT></P></p>
<p><P><FONT face=Verdana>Em conversa agora há pouco com Jamildo Melo, repórter especial do JC, o vice-presidente da CPI, deputado Raul Jungmann (PPS-PE), revelou o que disse Luiz Vedoin.</FONT></P></p>
<p><P><FONT face=Verdana>O empresário respondia à seguinte questão apresentada pelo também deputado pernambucano Fernando Ferro (PT): Tem mais gente da bancada de Pernambuco envolvida no escândalo? (Até agora só surgiu o nome do deputado Marcos de Jesus – PFL).</FONT></P></p>
<p><P><FONT face=Verdana>Vedoin teria respondido: \"Conosco, não! A KM domina tudo. Ela faz o mesmo que nós fazemos e nós não entramos, é uma coisa fechada, ela tem reserva, a gente respeita e não entra\".</FONT></P><FONT face=Verdana></p>
<p><P>Para Jungmann, a KM \"é a Planam de Pernambuco\". A Planam é a empresa de Vedoin, instalada em 19 estados e voltada exclusivamente para a venda de ambulâncias superfaturadas a instituições públicas.</P></FONT> </p>
