---
id: 12371995
data_publicacao: "2006-08-01 21:30:00"
data_alteracao: "None"
materia_tags: "eduardo campos,são"
categoria: "Notícias"
titulo: "Eduardo Campos diz que números são estranhos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Ele está em Bras?lia, onde fica até quinta-feira devido a compromissos na Câmara Federal. </FONT></P></p>
<p><P><FONT face=Verdana>Por meio da assessoria de imprensa,&nbsp;Eduardo divulgou agora a seguinte nota:</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>NOTA&nbsp;À IMPRENSA</STRONG><BR><BR>O candidato a governador da Frente Popular de Pernambuco, Eduardo Campos, vem a público para fazer as seguintes considerações:<BR><BR><BR>1. São no m?nimo estranhos os números da pesquisa de intenção de voto&nbsp;para governador de Pernambuco divulgados na noite desta terça-feira, 01/08, pela Rede Globo.<BR></P></FONT><FONT face=Verdana></FONT></p>
<p><P><FONT face=Verdana>2. Produzida pelo Ibope, a pesquisa apresenta resultado incoerente com os números apurados por todas as outras organizações que têm realizado&nbsp;sondagens sistemáticas na presente campanha eleitoral de Pernambuco.<BR></FONT><FONT face=Verdana></FONT></P></p>
<p><P><FONT face=Verdana>3. Mais do que isso: há um claro conflito entre os dados do Ibope e os divulgados por todos os institutos e por todos os órgãos da imprensa até agora.<BR><BR>4. Acrescente-se que pesquisas realizadas por encomenda da própria Frente Popular de Pernambuco, numa série histórica originada em abril do ano passado, mostram nossa candidatura em franca ascensão, diferentemente do que&nbsp;ocorre com os demais concorrentes, cujos percentuais se encontram em queda&nbsp;ou sem evolução.<BR><BR>5. A distorção dos números do Ibope levou a Frente Popular acionar sua equipe de especialistas, tendo sido detectado em análise preliminar poss?vel&nbsp;falha na elaboração do questionário, cujos efeitos estão sendo<BR>dimensionados.<BR><BR>6. Sem preju?zos de questionamentos técnicos e jur?dicos que venha a fazer oportunamente, a Frente Popular tomou a decisão de registrar e&nbsp;divulgar os dados das pesquisas realizadas para controle interno. Também&nbsp;decidiu encomendar sondagem de opinião a instituto de renome nacional, a&nbsp;qual será registrada para publicação com a maior brevidade poss?vel.<BR><BR>7. Por fim, reafirmamos nossa convicção de que, por mais importantes que sejam para orientar candidatos e eleitores, nenhuma pesquisa substitui a&nbsp;vontade popular, expressa nas urnas em outubro próximo.<BR><BR><BR></P></FONT> </p>
