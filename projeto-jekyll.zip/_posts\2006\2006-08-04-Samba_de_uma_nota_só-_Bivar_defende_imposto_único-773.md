---
id: 12371946
data_publicacao: "2006-08-04 08:00:00"
data_alteracao: "None"
materia_tags: "imposto,milton bivar,Samba"
categoria: "Notícias"
titulo: "Samba de uma nota só: Bivar defende imposto único"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Por <STRONG>Arthur Cunha</STRONG><BR>Repórter do JC</P></p>
<p><P>Sem o apoio de três partidos que formam a base de sustentação da sua candidatura no Estado - PTdoB, PTC e PRP, que anunciaram desligamento -, o candidato do PSL à Presidência da República, Luciano Bivar, inaugurou o seu comitê de campanha na Praça de Boa Viagem, ontem à noite. </P></p>
<p><P>Fazendo uso de discurso um repetitivo, que já foi exaustivamente proferido desde o in?cio da sua candidatura, Bivar voltou a defender a criação de um imposto único, uma medida econômica que, para ele, trará conseqüências positivas para o âmbito social.</P></FONT> </p>
