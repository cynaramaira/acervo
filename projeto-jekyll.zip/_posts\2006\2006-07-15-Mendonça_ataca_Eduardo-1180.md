---
id: 12372353
data_publicacao: "2006-07-15 15:07:00"
data_alteracao: "None"
materia_tags: "eduardo,mendonça,natação"
categoria: "Notícias"
titulo: "Mendonça ataca Eduardo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Eduardo disse hoje cedo em Vitória de Santo Antão, na Região Metropolitana do Recife, que está tranqüilo em relação ao resultado da pesquisa JC/Vox Populi porque a soma das intenções de voto da oposição leva a disputa para o 2º turno. Em conversa com Jamildo Melo, repórter especial do JC, mostrou-se confiante na derrota de Mendonça na prorrogação. Há pouco, no almoço na casa do vice prefeito de Lagoa de Itaenga, o governador rebateu: \"Quando o sujeito é fraco, faz essas comparações\".</P></p>
<p><P>&nbsp;</P> </p>
