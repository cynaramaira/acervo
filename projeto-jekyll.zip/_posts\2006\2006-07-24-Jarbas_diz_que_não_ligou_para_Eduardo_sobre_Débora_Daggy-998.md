---
id: 12372171
data_publicacao: "2006-07-24 15:24:00"
data_alteracao: "None"
materia_tags: "Débora Dantas,eduardo,jarbas vasconcelos,Naomi Campbell"
categoria: "Notícias"
titulo: "Jarbas diz que não ligou para Eduardo sobre Débora Daggy"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Nota repassada há pouco pela assessoria de imprensa do ex-governador:</FONT></P></p>
<p><P><FONT face=Verdana>O ex-governador Jarbas Vasconcelos afirma que é mentira a informação, publicada pelo Blog do JC, de que ele teria ligado para o deputado Eduardo Campos, em setembro do ano passado, para tratar da candidatura de Débora Daggy à Assembléia Legislativa. \"Não faz parte da minha história misturar pol?tica com vida pessoal de ninguém. Além disso, não existiu nenhum contato com Eduardo para tratar do assunto, nem direto, nem por intermédio de quem quer que seja\" .</FONT></P><B></p>
<p><P><FONT face=Verdana>Comentário meu:</FONT></P></B></p>
<p><P><FONT face=Verdana>Diante da negativa de Jarbas, ouvimos novamente as fontes da informação. Elas garantem ter testemunhado o próprio Eduardo revelando o contato com Jarbas.</FONT></P> </p>
