---
id: 12372159
data_publicacao: "2006-07-24 21:37:00"
data_alteracao: "None"
materia_tags: "eduardo campos,Humberto Costa,katia abreu"
categoria: "Colunistas"
titulo: "Nem a oligarquia de Jarbas/Mendonça nem a parceria neoliberal de Humberto e Eduardo Campos (Kátia Telles)"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>O PSTU participa das eleições com o objetivo de estimular e apoiar as lutas sociais dos trabalhadores, camponeses, juventude e setores populares buscando a construção de um governo dos trabalhadores da cidade e do campo rumo à edificação do socialismo com democracia. </FONT></P></p>
<p><P><FONT face=Verdana>Votar em Helo?sa Helena para Presidente da República e em Kátia Telles para Governadora significa contribuir para que os trabalhadores construam um movimento de esquerda socialista alternativo às desilusões geradas pelos governos de Lula e do PT cujo apoio popular foi obtido com o objetivo de mudar o Brasil e ao contrário aprofundaram o projeto neoliberal de FHC ditado pelo FMI, Banco Mundial e principalmente pelo imperialismo norte-americano, a exemplo do pagamento das d?vidas externa e interna, da reforma da previdência, das pol?ticas sociais populistas, do apoio ao grande empresariado como no caso do agronegócio, do envio </FONT><FONT face=Verdana>de tropas ao Haiti, das privatizações e da corrupção do mensalão.</FONT></P></p>
<p><P><FONT face=Verdana>Aqui em Pernambuco, votar nos candidatos do PSTU é votar contra Jarbas e Mendonça, é votar contra o falso desenvolvimento jarbista que beneficia somente um punhado de empresários em detrimento do orçamento social. No Estado cresce o desemprego que já é dos maiores do pa?s e a violência é assustadora vitimando principalmente as mulheres e a população pobre, negra e desempregada. O caso das 7 mortes da Rua Velha produto da falta de pol?tica habitacional é o exemplo do falso desenvolvimento jarbista.</FONT></P></p>
<p><P><FONT face=Verdana>Derrotar Jarbas/Mendonça é derrotar a pol?tica de sucateamento da saúde e da educação públicas. Agora nas vésperas das eleições o PT e o PCdoB querem ser oposição, mas João Paulo-PT e Luciana Santos-PCdoB também são cúmplices de Jarbas já que passaram quatro anos fazendo parcerias para atacar os kombeiros, despejar os sem tetos, aumentar as passagens de ônibus e arrochar os salários e cortar os direitos dos servidores. Assim caso, sejam eleitos, Humberto-PT e Eduardo Campos-PSB não farão nada diferente de Jarbas e Mendonça.</FONT></P></p>
<p><P><FONT face=Verdana>O PSTU acredita que somente a luta organizada dos trabalhadores muda a vida, mas apresenta um programa anti-imperialista e anti-capitalista nas eleições e chama todos os setores explorados e oprimidos, v?timas desta sociedade exploradora, a se unirem nas lutas contra o imperialismo e seus governos.</FONT></P></p>
<p><P><FONT face=Verdana>1. Por um plano emergencial de obras públicas para gerar emprego, construir habitação, escolas e hospitais públicos</FONT></P></p>
<p><P><FONT face=Verdana>2. Reestatização da CELPE sem indenização</FONT></P></p>
<p><P><FONT face=Verdana>3. Reforma agrária sob o controle dos trabalhadores</FONT></P></p>
<p><P><FONT face=Verdana>4. Não pagamento das d?vidas externa e interna aos especuladores</FONT></P><FONT face=Verdana></p>
<p><P>5. Por um poder para os trabalhadores da cidade e do campo através dos conselhos populares.</P></FONT> </p>
