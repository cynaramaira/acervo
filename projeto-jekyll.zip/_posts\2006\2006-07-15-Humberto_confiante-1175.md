---
id: 12372348
data_publicacao: "2006-07-15 19:51:00"
data_alteracao: "None"
materia_tags: "Humberto Costa"
categoria: "Notícias"
titulo: "Humberto confiante"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Humberto Costa acaba de dizer a Cec?lia Ramos, repórter do blog, que achou muito bom o resultado da pesquisa JC/Vox Populi, em que ele aparece empatado com Eduardo Campos, 14 pontos abaixo de Mendonça Filho. Para ele, os números mostram que haverá segundo turno e que o governador já atingiu seu n?vel máximo de crescimento. \"Depois de ter usado de todos os artif?cios dispon?veis para crescer, Mendoncinha deve parar nesses 35%\", avaliou, por telefone, de Serra Talhada, onde acaba de chegar. </P></p>
<p><P>O jogo começa agora, na opinião de Costa. Ele espera crescer mais com o engajamento maior dos petebistas ligados a Armando Monteiro Neto e ressaltou que agora está à frente de Eduardo Campos, revertendo tendência da pesquisa anterior. \"Nós temos mais chances de chegar\".</P></p>
<p><P>Humberto espera se consolidar como segundo colocado nas pesquisas, reforçando a agenda dele na Zona da Mata, única região do Estado onde, segundo a JC/Vox Populi, perde para Eduardo (26% a 17%). </P></p>
<p><P>O petista também espera crescer com sua vinculação à imagem do presidente Lula. A maioria do eleitorado, diz Humberto, sabe que o candidato de Jarbas Vasconcelos é Mendonça Filho, mas ainda não identificou o \"candidato de Lula\". \"Quando a gente começar a martelar isso, vamos crescer\". </P> </p>
