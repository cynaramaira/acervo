---
id: 12372214
data_publicacao: "2006-07-22 18:11:00"
data_alteracao: "None"
materia_tags: "Armando Monteiro,eduardo campos"
categoria: "Notícias"
titulo: "Militantes de Armando Monteiro acusados de estourar balões de Eduardo Campos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>O pessoal de Eduardo diz que a turma de Armando, aliada de Humberto, estourou três dos cinco balões gigantescos colocados na Bras?lia Formosa. Todos eles acabaram sendo recolhidos.</P></p>
<p><P>A acusação acabou gerando o empurra-empurra. Os ânimos estão mais contidos, por enquanto.</P> </p>
