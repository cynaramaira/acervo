---
id: 12371940
data_publicacao: "2006-08-04 11:53:00"
data_alteracao: "None"
materia_tags: "Falta,geraldo Alckmin"
categoria: "Notícias"
titulo: "Alckmin nega irritação com falta de empenho dos aliados"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>Geraldo Freire perguntou agora se Alckmin tem reclamação a fazer sobre a falta de empenho na campanha dele dos aliados&nbsp; em Pernambuco.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\" /><o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>“Tô muito feliz. Não tenho muita preocupação, vai crescer (ele, nas pesquisas).&nbsp;A propaganda eleitoral começa em 15 de agosto e a? cresce. Acredito que vamos para o segundo turno. O eleitor é muito sábio, ele leva a eleição para&nbsp;o segundo turno para ter mais clareza, mais segurança???.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>A aliança liderada pelo ex-governador Jarbas Vasconcelos (PMDB) e pelo governador Mendonça Filho (PFL) é acusada de não se empenhar na campanha de Alckmin por conta dos altos ?ndices de intenção de voto de Lula no Estado.</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>&nbsp;<o:p></o:p></FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana>A lógica da aliança é simples. Mendonça Filho disputa a reeleição e tem em torno de 35%. Lula soma 66%. Alckmin tem 16% (JC/Vox Populi).</FONT></P></p>
<p><P class=MsoNormal style=\"MARGIN: 0cm 0cm 0pt\"><FONT face=Verdana><o:p></o:p></FONT>&nbsp;</P><SPAN style=\"FONT-SIZE: 12pt; FONT-FAMILY: \Times New Roman\; mso-fareast-font-family: \Times New Roman\; mso-ansi-language: PT-BR; mso-fareast-language: PT-BR; mso-bidi-language: AR-SA\"><FONT face=Verdana size=2>Ou seja, boa parte dos eleitores de Mendonça vota em Lula e não em Alckmin. Por isso não é prudente se posicionar de forma mais firme em favor do tucano.</FONT></SPAN> </p>
