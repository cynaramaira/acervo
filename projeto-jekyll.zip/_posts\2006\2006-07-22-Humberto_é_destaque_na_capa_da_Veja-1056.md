---
id: 12372229
data_publicacao: "2006-07-22 12:17:00"
data_alteracao: "None"
materia_tags: "cerveja,Google Destaques,Humberto Costa,Macapá"
categoria: "Notícias"
titulo: "Humberto é destaque na capa da Veja"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p> </p>
