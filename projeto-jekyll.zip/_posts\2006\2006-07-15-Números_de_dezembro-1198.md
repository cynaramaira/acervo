---
id: 12372371
data_publicacao: "2006-07-15 10:00:00"
data_alteracao: "None"
materia_tags: "dezembro"
categoria: "Notícias"
titulo: "Números de dezembro"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><STRONG><A href=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/info_voxpopuli_dez05.gif\" target=_blank>Clique aqui</A></STRONG> para ampliar a imagem</P></p>
<p><P>A primeira pesquisa JC/Vox Populi foi publicada em 4 de dezembro de 2005. Não pode ser comparada com a de hoje porque, na época, não havia ainda candidatos definidos. Até então, Mendonça e Sérgio Guerra disputavam a indicação da aliança jarbista. Humberto lutava para superar João Paulo. Armando e Inocêncio continuavam no páreo.</P></p>
<p><P>Mas algumas idéias podem ser tiradas dela. Desde dezembro, Mendonça cresceu bastante, 19 pontos (de 16% para 35%). Conseguiu aproveitar a visibilidade do cargo de governador e superar a soma de intenções de votos dos três pré-candidatos da aliança (Mendonça, Guerra e Inocêncio tinham 26%).</P></p>
<p><P>Humberto ganhou pouqu?ssimo com a sa?da de João Paulo e de Armando do páreo. Os três juntos tinham 39%. Eduardo também cresceu pouco com Inocêncio e com as parcelas recebidas de Armando e João Paulo.</P></p>
<p><P>Tal como se apresenta hoje, O jogo continua embolado. Ele ainda aponta para o segundo turno com vaga garantida para Mendonça e batalhas ainda mais sangrentas entre Humberto e Eduardo, que tentarão chegar à prorrogação.</P></p>
<p><P>&nbsp;</P> </p>
