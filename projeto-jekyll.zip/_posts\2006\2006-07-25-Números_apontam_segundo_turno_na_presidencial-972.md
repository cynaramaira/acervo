---
id: 12372145
data_publicacao: "2006-07-25 16:27:00"
data_alteracao: "None"
materia_tags: "segundo turno"
categoria: "Notícias"
titulo: "Números apontam segundo turno na presidencial"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana size=2>Do <STRONG><U><A href=\"https://www.noblat.com.br/\" target=_blank>blog</A></U> </STRONG>de Noblat</P></p>
<p><P>O candidato Geraldo Alckmin acaba de receber em São Lu?s do Maranhão, onde se encontra, os principais números da mais recente pesquisa eleitoral do IBOPE que deverá ser divulgada ainda hoje pelo Jornal Nacional da Rede Globo.</P></p>
<p><P>* Lula cai dos 48% registrados em pesquisa aplicada entre 5 e 7 de junho passado para 41%;</P></p>
<p><P>* Alckmin sobe de 19% para 30%;</P></p>
<p><P>* Helo?sa Helena sobe de 6% para 9% ou 10%.</P></p>
<p><P>A soma dos votos obtidos por Cristovam Buarque, do PDT e pelos demais candidatos assegurariam o segundo turno caso a eleição presidencial tivesse ocorrido nos últimos dias.</P></p>
<p><P>Neste momento, Alckmin está trancado na biblioteca da casa do senador José Sarney na praia do Calhau com os senadores José Jorge, seu vice, Edson Lobão (PFL-MA) e Roseana Sarney (PFL-MA), candidata ao governo do Estado.</P></p>
<p><P>Trata-se de uma visita de cortesia de Alckmin a Roseana. Sairá de lá sem o apoio dela. Por ora, Roseana segue sem apoiar nenhum candidato a presidente. </P></p>
<p><P>O PSDB de Alckmin no Maranhão apóia a candidatura ao governo de Aderson Lago. E o PT de Lula apóia a de Edson Vidigal (PSB), ex-presidente do Superior Tribunal de Justiça.</P></p>
<p><P>Roseana e o pai dela são alvos de pesados ataques desferidos pelo PT local, Vidigal e o governador José Reinaldo, do PTB. O senador Sarney (PMDB-AP) apóia a reeleição de Lula. Mas parte do PFL de Roseana começa a apoiar Alckmin.</P></p>
<p><P>José Reinaldo ajuda como pode a candidatura ao governo do Amapá do ex-senador João Capiberibe, desafeto de Sarney. </P></FONT> </p>
