---
id: 12372069
data_publicacao: "2006-07-30 08:00:00"
data_alteracao: "None"
materia_tags: "candidatos,entrega,Maioria,são,servidores públicos"
categoria: "Notícias"
titulo: "Servidores são maioria entre candidatos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Jamildo Melo</STRONG><BR>Repórter especial do JC</FONT></P></p>
<p><P><FONT face=Verdana>Os funcionários públicos, de todos os n?veis, formam a categoria profissional com o maior número de candidatos nas eleições proporcionais de 2006 em Pernambuco. Levantamento do JC feito nos registros do Tribunal Regional Eleitoral (TRE) mostra que o número de candidatos servidores soma 95, em meio às 713 candidaturas oficiais, representando 13,32% do total de concorrentes. </FONT></P></p>
<p><P><FONT face=Verdana>A maior concentração está na disputa federal, onde existem 36 postulantes que se declaram funcionários públicos, em meio a 214 candidatos, representando uma participação de 17%. No plano estadual, os servidores que são candidatos somam 12%. São 59 candidatos que se declaram funcionários públicos, entre 499 postulantes a um mandato estadual.</FONT></P></p>
<p><P><FONT face=Verdana>A legislação eleitoral garante aos funcionários públicos o direito de se afastar do trabalho três meses antes do pleito, mantendo o salário integral, sob o pretexto de desincompatibilização do cargo. </FONT></P></p>
<p><P><FONT face=Verdana>Desde o dia 1º de julho, portanto, os órgãos são obrigados a dispensar os candidatos registrados oficialmente. A novidade deste ano é que a cada dia 10 do mês eles terão que prestar contas de suas atividades, com o objetivo de justificar a ausência para a atividade pol?tica.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinantes JC e UOL).</FONT></P> </p>
