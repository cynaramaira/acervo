---
id: 12372260
data_publicacao: "2006-07-20 15:35:00"
data_alteracao: "None"
materia_tags: "Bruno Covas,esta,maranhão"
categoria: "Notícias"
titulo: "Bruno Maranhão está de volta"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Bruno Maranhão acabou de desembarcar, vindo de Bras?lia. No aeroporto, uns 20 familiares e amigos o abraçam e comemoram seu retorno. Entre eles, a mãe, Gisella, de 87 anos. V?tima de AVC e presa a uma cadeira de rodas, ela&nbsp;esteve em&nbsp;Bras?lia, dias atrás, só para visitar o filho, na prisão, onde passou&nbsp;38 dias.</FONT></P></p>
<p><P><FONT face=Verdana>Quem também está lá é o</FONT><FONT face=Verdana>&nbsp;ex-presidente da Infraero, Carlos Wilson Campos,&nbsp;membro do diretório nacional do PT e amigo-irmão do presidente Lula.</FONT></P></p>
<p><P><FONT face=Verdana>Wilson não quer saber de problemas com o PT. Diz que está lá por conta da amizade de 30 anos com a fam?lia. Recusa-se a falar sobre o veto do partido à presença do l?der do MLST no palanque de Lula, no com?cio de sábado, em Bras?lia Teimosa, no Recife. Também não comenta a decisão do PT de afastar Bruno Maranhão da executiva nacional, depois do quebra-quebra na Câmara dos Deputados.</FONT></P></FONT> </p>
