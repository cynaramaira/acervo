---
id: 12372316
data_publicacao: "2006-07-17 13:58:00"
data_alteracao: "None"
materia_tags: "jarbas vasconcelos,liderança indígena"
categoria: "Notícias"
titulo: "Jarbas lidera com 32% de folga"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>A pesquisa JC/Vox Populi traz um dado curioso sobre a corrida ao Senado, como informa Sérgio Montenegro Filho, repórter especial do JC. A soma dos ?ndices dos adversários de Jarbas, mais os eleitores que pretendem votar em branco ou anular o voto (14%) e os indecisos (11%) totaliza 34%.&nbsp;Pouco mais da&nbsp;metade do percentual do ex-governador (66%).</P></p>
<p><TABLE cellSpacing=1 cellPadding=3 width=500 bgColor=#6ca7a6 border=0></p>
<p><TBODY></p>
<p><TR bgColor=#e0e4e5></p>
<p><TD><IMG height=20 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_titulo.gif\" width=144></TD></TR></p>
<p><TR bgColor=#e0e4e5></p>
<p><TD><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1>INTENÇÃO DE VOTO ESTIMULADA<BR></FONT></STRONG></p>
<p><TABLE cellSpacing=0 cellPadding=5 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD bgColor=#6ca7a6><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=2><EM>Se a eleição de senador de Pernambuco fosse hoje, em qual deles o sr(a). votaria?</EM></FONT></STRONG></TD></TR></TBODY></TABLE></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee></p>
<p><TABLE cellSpacing=10 cellPadding=0 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR vAlign=bottom align=middle bgColor=#c1d2cd></p>
<p><TD><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>66%</FONT></STRONG><BR><IMG height=120 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_bg_barra.gif\" width=30></FONT></TD></p>
<p><TD><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>4%</FONT></STRONG><BR><IMG height=15 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_bg_barra.gif\" width=30></FONT></TD></p>
<p><TD><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>3%</FONT></STRONG><BR><IMG height=10 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_bg_barra.gif\" width=30></FONT></TD></p>
<p><TD><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>1%</FONT></STRONG><BR><IMG height=5 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_bg_barra.gif\" width=30></FONT></TD></p>
<p><TD><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>1%</FONT></STRONG><BR><IMG height=5 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_bg_barra.gif\" width=30></FONT></TD></p>
<p><TD><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>0%</FONT></STRONG></FONT></TD></p>
<p><TD><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>0%</FONT></STRONG></FONT></TD></TR></p>
<p><TR></p>
<p><TD></p>
<p><DIV align=center><IMG height=50 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/send_jarbas.gif\" width=50 border=1></DIV></TD></p>
<p><TD></p>
<p><DIV align=center><IMG height=50 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/send_jorge_gomes.gif\" width=50 border=1></DIV></TD></p>
<p><TD></p>
<p><DIV align=center><IMG height=50 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/send_luciano_siqueira.gif\" width=50 border=1></DIV></TD></p>
<p><TD></p>
<p><DIV align=center><IMG height=50 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/send_helio_cabral.gif\" width=50 border=1></DIV></TD></p>
<p><TD></p>
<p><DIV align=center><IMG height=50 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/send_belarmino.gif\" width=50 border=1></DIV></TD></p>
<p><TD></p>
<p><DIV align=center><IMG height=50 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/send_gondim.gif\" width=50 border=1></DIV></TD></p>
<p><TD></p>
<p><DIV align=center><IMG height=50 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/send_breno.gif\" width=50 border=1></DIV></TD></TR></p>
<p><TR></p>
<p><TD><FONT face=\"Arial, Helvetica, sans-serif\" size=1>Jarbas Vasconcelos<BR>(PMDB) <BR></FONT></TD></p>
<p><TD><FONT face=\"Arial, Helvetica, sans-serif\" size=1>Jorge Gomes<BR>(PSB)</FONT></TD></p>
<p><TD><FONT face=\"Arial, Helvetica, sans-serif\" size=1>Luciano Siqueira<BR>(PT) </FONT></TD></p>
<p><TD><FONT</p>
<p> face=\"Arial, Helvetica, sans-serif\" size=1>Hélio Cabral <BR>(PSTU) </FONT></TD></p>
<p><TD><FONT face=\"Arial, Helvetica, sans-serif\" size=1>Belarmino Soares<BR>(PTdoB) </FONT></TD></p>
<p><TD><FONT face=\"Arial, Helvetica, sans-serif\" size=1>Pedro Gondim<BR>(Prona) </FONT></TD></p>
<p><TD><FONT face=\"Arial, Helvetica, sans-serif\" size=1>Breno Rocha<BR>(PCO) </FONT></TD></TR></TBODY></TABLE></p>
<p><TABLE cellSpacing=5 cellPadding=0 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD width=\"50%\"></p>
<p><TABLE borderColor=#6ca7a6 cellSpacing=1 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD bgColor=#ffffff></p>
<p><TABLE cellSpacing=0 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>Branco/Nulo</STRONG></FONT></TD></p>
<p><TD align=right><IMG height=20 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_bg_barra2.gif\" width=80 align=absMiddle><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>14%</FONT></STRONG></FONT></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></p>
<p><TD width=\"50%\"></p>
<p><TABLE borderColor=#6ca7a6 cellSpacing=1 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD bgColor=#ffffff></p>
<p><TABLE cellSpacing=0 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>Não sabe/<BR>Não respondeu</STRONG></FONT></TD></p>
<p><TD align=right><IMG height=20 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/pesq_bg_barra2.gif\" width=70 align=absMiddle><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>11%</FONT></STRONG></FONT></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#000000 size=1><STRONG>CRUZAMENTO POR REGIÃO</STRONG></FONT><BR></p>
<p><TABLE cellSpacing=4 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR bgColor=#006666></p>
<p><TD>&nbsp;</TD></p>
<p><TD width=60></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>Capital/RM</FONT></STRONG></DIV></TD></p>
<p><TD width=60></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>Agreste</FONT></STRONG></DIV></TD></p>
<p><TD width=60></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>Mata</FONT></STRONG></DIV></TD></p>
<p><TD width=60></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>Sertão/ São Francisco</FONT></STRONG></DIV></TD></p>
<p><TD width=50></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=1>Total</FONT></STRONG></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1>Jarbas Vasconcelos (PMDB) </FONT></STRONG></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>66%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>58%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>70%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>72%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>66%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1>Jorge Gomes (PSB)</FONT></STRONG></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>3%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>8%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>2%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>1%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>4%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1>Luciano Siqueira (PT) </FONT></STRONG></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>4%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>2%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>4%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>2%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>3%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>Outros</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>2%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>2%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>2%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>-</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>2%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>Branco/ Nulo</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>16%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>19%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>17%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>3%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>14%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG>NS / NR</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>8%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>13%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>6%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>22%</FONT></STRONG></FONT></DIV></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>11%</FONT></STRONG></FONT></DIV></TD></TR></TBODY></TABLE></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#000000 size=1><STRONG>INTENÇÃO DE VOTO ESPONTÂNEA</STRONG></FONT> </p>
<p><TABLE cellSpacing=4 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR bgColor=#006666></p>
<p><TD colSpan=2></p>
<p><DIV align=center><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#ffffff size=2><EM>Se a eleição de senador de Pernamuco fosse hoje, em quem o sr(a). votaria?</EM></FONT></STRONG></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2><STRONG>Jarbas Vasconcelos</STRONG></FONT></TD></p>
<p><TD align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>15%</FONT></STRONG></FONT></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT</p>
<p> face=\"Verdana, Arial, Helvetica, sans-serif\" size=2><STRONG>Luciano Siqueira</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>1%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2><STRONG>Jorge Gomes</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>1%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2><STRONG>José Queiroz</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>-</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2><STRONG>Outros com menos de 0,5% de citação</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>1%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2><STRONG>Branco/ Nulo</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>13%</FONT></STRONG></FONT></DIV></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=2><STRONG>NS / NR</STRONG></FONT></TD></p>
<p><TD></p>
<p><DIV align=right><FONT color=#eaf0ee><STRONG><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#cc0000 size=2>69%</FONT></STRONG></FONT></DIV></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE> </p>
