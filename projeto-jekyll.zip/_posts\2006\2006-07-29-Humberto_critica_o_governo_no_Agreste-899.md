---
id: 12372072
data_publicacao: "2006-07-29 09:30:00"
data_alteracao: "None"
materia_tags: "agreste,crítica,governo,Humberto Costa"
categoria: "Notícias"
titulo: "Humberto critica o governo no Agreste"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Mônica Crisóstomo</STRONG><BR>Repórter do Jornal do Commercio</FONT></P></p>
<p><P><FONT face=Verdana>Um dia depois de desafiar o governador Mendonça Filho (PFL) a mostrar, nas ruas, um poder maior de manifestação de sua militância, o candidato do PT ao governo estadual, Humberto Costa (PT) voltou a provocar o adversário. </FONT></P></p>
<p><P><FONT face=Verdana>Ontem, o petista, acompanhado por um grupo de aliados, cumpriu agenda de campanha em três munic?pios do Agreste Setentrional onde os prefeitos apóiam a candidatura do pefelista. </FONT></P></p>
<p><P><FONT face=Verdana>No entanto, a única militância presente aos atos foi do deputado estadual e candidata à reeleição Iza?as Régis (PTB). </FONT></P></p>
<p><P><FONT face=Verdana>Nos discursos, criticou a administração estadual e deixou claro que apesar das exigências do presidente Luiz Inácio Lula da Silva (PT) - para evitar choques com o palanque do também postulante a governador, Eduardo Campos (PSB) - não abre mão de se apresentar à população como sendo o \"leg?timo\" candidato de Lula.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></EM></STRONG> texto completo (assinantes JC e UOL).</FONT></P> </p>
