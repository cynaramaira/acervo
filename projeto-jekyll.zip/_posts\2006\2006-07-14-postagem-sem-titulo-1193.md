---
id: 12372366
data_publicacao: "2006-07-14 21:50:00"
data_alteracao: "None"
materia_tags: "None"
categoria: "Charge"
titulo: ""
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>&nbsp;</P> </p>
