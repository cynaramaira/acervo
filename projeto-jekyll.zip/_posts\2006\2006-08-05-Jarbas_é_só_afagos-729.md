---
id: 12371902
data_publicacao: "2006-08-05 19:06:00"
data_alteracao: "None"
materia_tags: "jarbas vasconcelos"
categoria: "Notícias"
titulo: "Jarbas é só afagos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>O ex-governador Jarbas Vasconcelos (PMDB), candidato ao Senado,&nbsp;não se fez de rogado e, bem à vontade, fez afagos&nbsp;até em um ratinho, na sua passagem pelo Mercado da Madalena, hoje pela manhã. </FONT></P></p>
<p><P><FONT face=Verdana>O peemedebista tomou café da manhã no local, na companhia do governador-candidato Mendonça Filho (PFL). Comeram macaxeira, bode guizado e tomaram até uma cervejinha... </FONT></P></p>
<p><P><FONT face=Verdana>Jarbas aproveitou para fazer compras e saiu de lá com sacolas cheias.&nbsp;Levou peixe cioba, costela de porco e carne de sol.</FONT></P> </p>
