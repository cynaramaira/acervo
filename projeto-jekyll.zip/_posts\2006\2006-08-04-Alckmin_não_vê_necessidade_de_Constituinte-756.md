---
id: 12371929
data_publicacao: "2006-08-04 18:22:00"
data_alteracao: "None"
materia_tags: "geraldo Alckmin,Naomi Campbell"
categoria: "Notícias"
titulo: "Alckmin não vê necessidade de Constituinte"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Isabelle Figueirôa</STRONG><BR>Do JC OnLine</FONT></P></p>
<p><P><FONT face=\"Times New Roman\"><FONT face=Verdana>Nem com?cios, nem caminhadas. O candidato à Presidência da República Geraldo Alckmin (PSDB) voltou a Pernambuco para lançar o projeto \"Caminhos para um Novo Nordeste\", durante um seminário na tarde desta sexta-feira (4). </FONT></FONT></P></p>
<p><P><FONT face=\"Times New Roman\"><FONT face=Verdana>Com o Teatro Beberibe do Centro de Convenções, em Olinda, lotado com mais de 500 pessoas, Alckmin soltou uma pergunta no ar, seguida de uma insinuação, referindo-se à proposta do adversário Lula (PT) de convocar uma nova constituinte: \"O que justificaria nós paralisarmos o Pa?s para fazer uma nova constituinte? Não há nenhuma necessidade de fazer uma nova constituinte para colocar ladrão na cadeia\".</FONT></P></p>
<p><P><FONT face=Verdana>Sobre o tom do guia eleitoral da campanha pró-Alckmin, o senador Marco Maciel (PFL-PE) afirmou que o programa é o momento em que o eleitor analisa a conduta do candidato. \"Nós estamos com uma proposta e vamos trabalhar essa proposta, mas faremos cr?ticas (ao governo Lula) no momento certo\", disse. </FONT></P></p>
<p><P><FONT face=Verdana>Mas o presidente nacional do PSDB, senador Tasso Jereissati (CE), foi mais enfático com relação ao teor da propaganda pol?tica: \"Nós não vamos omitir nada. Faremos um programa altamente propositivo, apresentando idéias e propostas, mas não podemos omitir as irregularidades [dos adversários]. É imposs?vel ignorar essa avalanche de escândalos\".</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://jc3.uol.com.br/especiais/eleicoes2006/2006/08/04/not_428.php\" target=_blank>aqui</A></EM></STRONG> o texto completo.</FONT></P></FONT> </p>
