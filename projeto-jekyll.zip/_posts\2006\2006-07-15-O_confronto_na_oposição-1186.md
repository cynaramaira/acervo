---
id: 12372359
data_publicacao: "2006-07-15 12:19:00"
data_alteracao: "None"
materia_tags: "confronto,Oposição"
categoria: "Notícias"
titulo: "O confronto na oposição"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p>Raul Jungmann diz que a oposição a Mendonça está pagando um preço elevado pela fragmentação e os freqüentes conflitos entre Humberto e Eduardo. Um deles poderá ser obrigado a sair do páreo antes do 1º turno. A JC/Vox Populi, na opinião do deputado, mostra que o governador passou para outro patamar, descolando-se dos dois e forçando a disputa a uma nova polarização, como acontece historicamente no Estado. <BR> </p>
