---
id: 12371900
data_publicacao: "2006-08-05 17:15:00"
data_alteracao: "None"
materia_tags: "Lula"
categoria: "Notícias"
titulo: "Cristovam teme autoritarismo de Lula"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=Verdana></p>
<p><P><BR>Por Angela Lacerda<BR>Da Agência Estado</P></p>
<p><P>O candidato a presidente da República pelo PDT, Cristovam Buarque, reforçou neste sábado, no Recife, seu temor diante de \"uma tendência de golpe autoritário\", pelo presidente Lula (PT), ao comentar a<BR>proposta do presidente de convocar uma Assembléia Nacional Constituinte.</P></p>
<p><P>\"Vejo essa iniciativa como uma polegada antes de uma tentativa de golpe\", avaliou ele, durante almoço de confraternização com amigos, simpatizantes<BR>e defensores da sua candidatura, em uma churrascaria da cidade. </P></p>
<p><P>O perigo é maior, segundo ele, no caso de o presidente ser reeleito no primeiro turno das eleições. \"Imagine um presidente sair com cerca de 50 milhões de votos e com um congresso constituinte\", observou. \"Ele vai<BR>ditar a constituição porque tem o poder de liderança e tem o poder executivo que pode corromper através das práticas mensaleiras que já se viu no passado\". </P></p>
<p><P>Para Cristovam, neste momento, uma constituição subordinada ao presidente é um \"suic?dio institucional\", é caminhar para o autoritarismo, com a possibilidade de o primeiro artigo a ser discutido ser mais uma eleição para o presidente que for eleito.</FONT><BR></P> </p>
