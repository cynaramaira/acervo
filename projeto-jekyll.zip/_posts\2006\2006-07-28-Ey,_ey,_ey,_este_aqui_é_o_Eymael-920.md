---
id: 12372093
data_publicacao: "2006-07-28 16:45:00"
data_alteracao: "None"
materia_tags: "Eugene Levy,Itaquitinga"
categoria: "Notícias"
titulo: "Ey, ey, ey, este aqui é o Eymael"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>O presidenciável José Maria Eymael não conseguiu arrastar multidões hoje pelas ruas do Recife, mas foi simpático.</P></p>
<p><P>Ele percorreu o centro da cidade acompanhado do candidato a governador pelo PSDC, vereador Luiz Vidal.</P> </p>
