---
id: 12372329
data_publicacao: "2006-07-16 16:03:00"
data_alteracao: "None"
materia_tags: "josé teles"
categoria: "Notícias"
titulo: "Eles estão nas ruas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Sem apoio do PT, o deputado Paulo Rubem Santiago não se faz de rogado. Produz o próprio guia eleitoral. Já Eduardo, Humberto e Mendonça têm que gastar muita sola de sapato e perfume no interior.</P> </p>
