---
id: 12372270
data_publicacao: "2006-07-20 07:45:00"
data_alteracao: "None"
materia_tags: "None"
categoria: "Notícias"
titulo: ""
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>\"<STRONG>Heloisa Helena pode nos ajudar a ir para o segundo turno. Ela vai crescer e isto é importante para garantirmos o segundo turno</STRONG>\"</P></p>
<p><P>Senador José Jorge (PFL), vice de Geraldo Alckmin (PSDB), ao comentar pesquisa Datafolha em que Helena cresce de 6% para 10%</P> </p>
