---
id: 12372078
data_publicacao: "2006-07-29 08:30:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Eu sou a pimentinha no encalço do chuchu"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>JAMILDO MELO</STRONG><BR>Repórter especial do JC</FONT></P></p>
<p><P><FONT face=Verdana>A senadora e candidata a presidente pelo P-SOL, Heloisa Helena, encerrou ontem sua visita ao Recife, em discurso na Praça do Carmo, disparando cr?ticas contra o presidente Lula (PT) e o candidato tucano, Geraldo Alckmim (PSDB/SP), seus dois principais adversários na corrida eleitoral. Depois de afirmar que a turma do presidente da República passa o tempo todo mentindo, para as populações pobres, afirmando que ela iria acabar com o programa Bolsa-Fam?lia, a candidata atacou Lula com ironia, misto de promessa eleitoral e provocação.</FONT></P></p>
<p><P><FONT face=Verdana>\"Imagina só, acabar com o Bolsa-Fam?lia ? O que eu quero acabar é com o Bolsa-Banqueiro, esse programa que dá mais de R$ 610 mil por fam?lia em média por especulador brasileiro. Tenham certeza que vamos acabar com a farra deles e não com os R$ 52,00 das fam?lias pobres\", declarou, sob aplausos, em um breve discurso de apenas dez minutos, antes de seguir para o interior de São Paulo.</FONT></P></p>
<p><P><FONT face=Verdana>Na cr?tica ao tucano, HH disse que o PSDB e o PFL serão surpreendidos com seu desempenho nas pesquisas, enquanto esperam apenas que seu crescimento ajude o tucano Alckmim a passar para o segundo turno. \"A gente está só no encalço do chuchu. Eu sou a pimentinha no encalço do chuchu, para passar dele e ir logo para o segundo turno\", ironizou, arrancando gargalhadas da pequena platéia, formada por militantes do PSTU e P-SOL.</FONT></P></p>
<p><P><FONT face=Verdana>Ex-militante do PT, de onde foi expulsa logo no in?cio do governo Lula, em 2003, por discordar da reforma da Previdência e a taxação dos inativos, a senadora acusou ainda o Palácio do Planalto de estar muito preocupado com o seu crescimento nas pesquisas, atualmente. \"A gente sabe que eles estão muito preocupados. Cada pontinho que a gente sobe nas pesquisas já é um desespero, uma histeria. Eu acho tão feio isso. Essa inveja é muito horrorosa\", criticou, despertando risos.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinantes JC e UOL).</FONT></P> </p>
