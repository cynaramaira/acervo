---
id: 12372106
data_publicacao: "2006-07-28 11:09:00"
data_alteracao: "None"
materia_tags: "debates,direito,Lula,Naomi Campbell"
categoria: "Notícias"
titulo: "HH diz que Lula não tem direito de faltar a debates"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Helo?sa Helena,&nbsp;do</p>
<p> P-SOL, não admite falar que a candidatura dela não é para vencer. \"Vim aqui para ganhar, não sou masoquista\", disse há pouco a Cláudia Vasconcelos, repórter do JC, ao deixar a Ilha de Deus, na Imbiribeira, periferia do Recife.</FONT></P></p>
<p><P><FONT face=Verdana>HH também criticou Lula por ter decidido não participar de debates com os outros presidenciáveis. </FONT></P></p>
<p><P><FONT face=Verdana>\"Nenhum candidato é maior que outro para se negar a participar de debates. A população tem o direito de saber o que os candidatos pensam\", defendeu, entre os três candidatos a governador que estão com ela em Pernambuco: Edilson Silva (P-SOL), Kátia Telles (PSTU) e Renê Patriota, do PV, cuja candidatura está sub júdice.</FONT></P> </p>
