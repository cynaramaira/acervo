---
id: 12372046
data_publicacao: "2006-07-31 09:04:00"
data_alteracao: "None"
materia_tags: "jarbas vasconcelos,mendonça"
categoria: "Notícias"
titulo: "Os três poderes de Jarbas e Mendonça"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Será escolhido hoje mais um membro do Tribunal de Justiça de Pernambuco. É o 37º desembargador, cargo vago desde o in?cio do ano, em função da aposentadoria de Dário Rocha.</FONT></P></p>
<p><P><FONT face=Verdana>Em sete anos e sete meses de gestão, este será o oitavo membro do Poder Judiciário nomeado pela dupla Jarbas Vasconcelos (PMDB)/Mendonça Filho (PFL). Nenhum outro governo nomeou tantos desembargadores quanto o atual.</FONT></P></p>
<p><P><FONT face=Verdana>-------------------------------</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>NOMEADOS PARA O JUDICI??RIO</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Dos sete escolhidos por Jarbas, apenas um, Nélson Santiago, já falecido, não está em atividade. Os demais são:</FONT></P></p>
<p><P><FONT face=Verdana>* Helena Caúla Reis</FONT></P></p>
<p><P><FONT face=Verdana>* Fernando Eduardo de Miranda Ferreira</FONT></P></p>
<p><P><FONT face=Verdana>* Alderita Ramos de Oliveira</FONT></P></p>
<p><P><FONT face=Verdana>* Romero de Oliveira Andrade</FONT></P></p>
<p><P><FONT face=Verdana>* Cândido José da Fonte Saraiva de Moraes</FONT></P></p>
<p><P><FONT face=Verdana>* Gustavo Augusto Rodrigues de Lima</FONT></P></p>
<p><P><FONT face=Verdana>-------------------------------</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>INFLUÊNCIA DO EXECUTIVO NO TJ</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Mas a influência do governo sobre o Judiciário é maior. A aliança União por Pernambuco, que tem Mendonça como candidato à reeleição e Jarbas ao Senado, responde por cerca de um quarto dos membros do TJ.</FONT></P></p>
<p><P><FONT face=Verdana>O presidente do Tribunal, Fausto Freitas, é um deles. Foi nomeado durante o governo de Joaquim Francisco, hoje deputado federal pelo PFL e candidato à reeleição.</FONT></P></p>
<p><P><FONT face=Verdana>O próprio Freitas é ex-deputado estadual. Cumpriu quase dois mandatos pelo PFL antes de chegar ao Judiciário. O chefe de gabinete dele, Flávio Régis, é um pefelista histórico. Foi vereador do Recife pelo partido.</FONT></P></p>
<p><P><FONT face=Verdana>-------------------------------</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>CAMPANHA ABERTA POR PEDRO HENRIQUE</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Pois bem. Fausto Freitas, segundo governistas de primeira linha, faz parte da tropa de choque do Palácio das Princesas que trabalha para eleger Pedro Henrique Alves, ex-procurador geral adjunto do Estado, como novo desembargador.</FONT></P></p>
<p><P><FONT face=Verdana>O processo de escolha é o seguinte. A Ordem dos Advogados em Pernambuco realizou uma eleição para escolher seis nomes a serem encaminhados ao TJ.</FONT></P></p>
<p><P><FONT face=Verdana>Pedro Henrique ficou em sexto. Por pouco não era eliminado. <STRONG><EM><A href=\"https://jc3.uol.com.br/blogs/jc/2006/07/28/index.php#316\">Veja aqui</A></EM></STRONG> o resultado da eleição na OAB.</FONT></P></p>
<p><P><FONT face=Verdana>No TJ haverá outra eleição. Desta vez para definir uma lista tr?plice que será encaminhada a Mendonça Filho para escolha e nomeação do novo desembargador.</FONT></P></p>
<p><P><FONT face=Verdana>O TJ deve realizar hoje a votação. Os 36 desembargadores podem votar. A luta agora é conseguir incluir Pedro Henrique entre os três. Mesmo que fique em terceiro. Não importa.</FONT></P></p>
<p><P><FONT face=Verdana>Pois, pois. Fausto Freitas cabala votos para PH num mega mutirão governista. Nos últimos dias, o presidente estadual do PMDB, Dorany Sampaio, esteve mergulhado no corpo-a-corpo com os desembargadores. Outros auxiliares de Jarbas e Mendonça não fazem outra coisa.</FONT></P></p>
<p><P><FONT face=Verdana>Jarbas e Mendonça também atuam pessoalmente. O governador, inclusive, já avisou a Francisco Bandeira, que ficou em segundo lugar na lista dos seis, que ele não será o nomeado, mesmo que figure em primeiro na relação dos três, que sairá do TJ.</FONT></P></p>
<p><P><FONT face=Verdana>Bandeira é como um afilhado para o senador Marco Maciel (PFL).</FONT></P></p>
<p><P><FONT face=Verdana>Os governistas esperam ter cerca de 18 votos para garantir a vaga de PH. Ele ficaria em terceiro. Os dois primeiros – Jorge Neves ou Bandeira ou Edgar Moury Neto – devem ter entre 20 e 25 votos.</FONT></P></p>
<p><P><FONT face=Verdana>-------------------------------</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>PERSPECTIVAS DE AMPLO PODER</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Com a indicação para o TJ, os governistas consolidam um amplo leque de poder no Estado.</FONT></P></p>
<p><P><FONT face=Verdana>Eles já estão no governo há quase oito anos. Têm uma perspectiva extremamente favorável de conseguir mais quatro para Mendonça.</FONT></P></p>
<p><P><FONT face=Verdana>Também contam com maioria no Poder Legislativo. Maioria na Assembléia, maioria dos deputados federais e toda a bancada de senadores - são três: Marco Maciel, Sérgio Guerra e José Jorge. </FONT></P></p>
<p><P><FONT face=Verdana>Em 2007, Jarbas deve substituir Jorge, que encerra o mandato de oito anos. Maciel e Guerra têm mais quatro anos.</FONT></P><FONT face=Verdana></p>
<p><P>Se alguém acha que eles se contentam com isso, esse alguém está enganado. Em 2008, a aliança quer recuperar o Recife e as principais prefeituras da Região Metropolitana.</P></FONT> </p>
