---
id: 12372118
data_publicacao: "2006-07-27 11:17:00"
data_alteracao: "None"
materia_tags: "confronto,entrega,Humberto Costa"
categoria: "Notícias"
titulo: "O novo confronto entre ACM e Humberto"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>O senador Antônio Carlos Magalhães (PFL-BA) fez fortes cr?ticas ao ex-ministro Humberto Costa (PT), candidato ao governo de Pernambuco. </FONT></P></p>
<p><P><FONT face=Verdana>ACM disse em Bras?lia que Humberto é \"vampiro\" e deve responder sobre o escândalo das sanguessugas, de compra superfaturada de ambulâncias. Fez os ataques para defender o ex-ministro da Saúde José Serra (PSDB), em cuja gestão se iniciou o esquema de corrupção.</FONT></P></p>
<p><P><FONT face=Verdana>Humberto rebateu chamando ACM de \"leviano e irresponsável\". Voltou a dizer que já foi inocentado no caso das sanguessugas e que pensa em processar o senador baiano.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Ouça o bate-boca</STRONG> em reportagem de Romualdo de Souza, correspondente da Rádio Jornal em Bras?lia, veiculada no programa de Geraldo Freire, hoje pela manhã.</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Comentário meu:</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>ACM não engole Humberto desde a campanha&nbsp;para</p>
<p> prefeito, em&nbsp;2004, quando o ex-ministro percorreu uma série de munic?pios baianos para dar apoio aos candidatos do PT.</FONT></P></p>
<p><P><FONT face=Verdana>ACM também enfrenta na Bahia&nbsp;forte oposição de um grupo de sanitaristas que fizeram parte da gestão do ex-ministro.</FONT></P> </p>
