---
id: 12372207
data_publicacao: "2006-07-23 12:00:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Coronéis de Fancaria"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Por IVANILDO SAMPAIO<BR></FONT><FONT face=Verdana>Diretor de Redação do Jornal do Commercio</FONT></P></p>
<p><P><FONT face=Verdana>Mal começou oficialmente a campanha eleitoral e a Imprensa, como um todo, está sendo acusada, como em vezes anteriores, de ser a responsável pelo mau desempenho de alguns candidatos, tão pobres de votos quanto indigentes de idéias. A oscilação do desempenho a cada rodada de pesquisa eleitoral, quando uns crescem e outros caem, é vista, sempre, como uma trama maquiavélica para ajudar um candidato em detrimento de outro. Jogam-se suspeitas sobre os jornais, os jornalistas, os institutos de pesquisa. Todos, na visão pequena desses inconformados, reunidos numa tenebrosa aliança para proteger quem lidera a intenção de votos, não importa a que partido ou coligação pertença, nem que esta liderança seja temporária e retrate uma realidade de momento. É como se dissessem: \"Há Imprensa livre? Sou contra. Se não estão com a minha candidatura, estão contra mim\".</FONT></P></p>
<p><P><FONT face=Verdana>Tem sido assim a cada pleito – e vai continuar enquanto certos candidatos não amadurecerem como pol?ticos e como cidadãos e continuarem se comportando como pequenos coronéis de fancaria, escondendo-se sob o manto da própria mediocridade.</FONT></P></p>
<p><P><FONT face=Verdana>O <B>Jornal do Commercio</B> está acostumado a isso – a tentativas de intimidação, ameaças veladas, choro pequeno de quem é repudiado pelo eleitorado. Desde 1987, quando teve seu controle acionário adquirido pelos atuais proprietários, este Jornal, pelos seus diretores e sua redação,</p>
<p> e por determinação do seu presidente, vem acompanhando com absoluta isenção cada pleito desde então realizado, testemunhando a alternância de poder, tanto em n?vel municipal quanto estadual e federal, como compete aos regimes democráticos.</FONT></P></p>
<p><P><FONT face=Verdana>Acompanhou a ascensão e queda de Fernando Collor, viu Fernando Henrique derrotar Lula da Silva e ter seu candidato por ele derrotado, cobriu passo a passo cada eleição estadual de Pernambuco e municipal do Recife, com a troca de poder entre as mais diversas legendas e coligações. E conseguiu, sempre, desagradar a cada facção perdedora, embora durante o processo desagradasse também aos futuros vencedores. Mas, nenhuma vez, enquanto instituição, nem o Jornal nem os demais ve?culos do Sistema deixaram de se pautar pelo equil?brio, pela isenção, pela seriedade e pela ética, o que não se pode dizer de alguns atores do nosso universo pol?tico, envolvidos em escândalos dos mais diversos tamanhos e feitios. Patrocinaram lambanças que – entendemos também – em nada ajuda resgata-las e relembrar.</FONT></P></p>
<p><P><FONT face=Verdana>Finalmente, que fique claro de uma vez por todas: o compromisso desse Jornal é com a fidelidade aos fatos, com o respeito aos nossos leitores, com a nossa tradição de informar com isenção, com ética e com honestidade, atributos que nem sempre estão presentes na vida privada de muitos pretendentes a uma carreira na vida pública.</FONT></P></FONT> </p>
