---
id: 12372008
data_publicacao: "2006-08-01 16:44:00"
data_alteracao: "None"
materia_tags: "bares,Congresso,Lula,restaurantes"
categoria: "Notícias"
titulo: "Lula abre congresso de bares e restaurantes"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por<STRONG> Fredy Krause<BR></STRONG>Agência Estado</FONT></P></p>
<p><P><FONT face=Verdana>O presidente Luiz Inácio Lula da Silva abre hoje, às 18h30, no Centro de Convenções Ulysses Guimarães, em Bras?lia, o 18º Congresso Nacional da Associação Brasileira de Bares e Restaurantes (Abrasel), promovido pela Agência Internacional Privada para o Desenvolvimento do Mercado de Alimentos (Fispal) e pelo Sebrae, paralelamente ao \"28º Congresso Nacional da Abrasel - Os Saberes da Gastronomia\". </FONT></P></p>
<p><P><FONT face=Verdana>(...)</FONT></P></p>
<p><P><FONT face=Verdana>Na solenidade de abertura do evento, Lula receberá das mãos do presidente da Abrasel nacional, Paulo Solmucci Junior, um cheque R$ 115.376,00 destinado ao Fome Zero. O dinheiro foi arrecadado com o recolhimento de R$ 1 por prato vendido durante o Festival Gastronômico Brasil Sabor, realizado em todo Pa?s, de 17 de março a 23 de abril últimos.</FONT></P> </p>
