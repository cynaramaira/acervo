---
id: 12372037
data_publicacao: "2006-07-31 16:47:00"
data_alteracao: "None"
materia_tags: "problemas auditivos"
categoria: "Notícias"
titulo: "Estivemos fora do ar por problemas técnicos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p>Perdão, <A href=\"mailto:amig@s\">amig@s</A>. </p>
