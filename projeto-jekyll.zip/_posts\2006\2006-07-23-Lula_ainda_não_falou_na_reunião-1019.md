---
id: 12372192
data_publicacao: "2006-07-23 12:20:00"
data_alteracao: "None"
materia_tags: "Lula,Naomi Campbell,reunião"
categoria: "Notícias"
titulo: "Lula ainda não falou na reunião"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>O presidente chegou cedo à Academia Santa Gertrudes, em Olinda. Divide a mesa com Ciro Gomes, Aldo Rebelo, dona Mariza, Luciana Santos e Ricardo Berzoini.</P> </p>
