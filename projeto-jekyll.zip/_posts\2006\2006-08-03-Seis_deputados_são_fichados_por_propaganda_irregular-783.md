---
id: 12371956
data_publicacao: "2006-08-03 20:34:00"
data_alteracao: "None"
materia_tags: "deputados,Éramos Seis,Irregularidades,Propaganda Eleitoral,são"
categoria: "Notícias"
titulo: "Seis deputados são fichados por propaganda irregular"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>O Ministério Público Eleitoral entrou,&nbsp;hoje,&nbsp;com representações contra seis candidatos a deputado estadual e federal por propaganda irregular. </FONT><FONT face=Verdana>São eles: Roberto Magalhães (PFL), Carlos Wilson Campos (PT), S?lvio Costa (PMN), Eduardo da Fonte (PP), Silvio Costa Filho (PMN) e André Luis Farias, o Alf (PTB).</FONT></P></p>
<p><P><FONT face=Verdana>Carlos Wilson, Eduardo da Fonte e Alf serão notificados por afixar placas com mais de quatro metros quadrados -&nbsp;o que se configura como outdoor e é proibido pela lei eleitoral. </FONT></P></p>
<p><P><FONT face=Verdana>Roberto Magalhães, S?lvio Costa e S?lvio Costa Filho, incorreram no erro da propaganda em locais de uso público. O pefelista colocou placas em padaria e borracharia. Os S?lvio - pai e filho - pintaram muro de um hospital psiquiátrico, no Centro do Recife.</FONT></P></p>
<p><P><FONT face=Verdana>Todos terão 24 horas, a contar da notificação pelo Tribunal Regional Eleitoral (TRE), para retirar as propagandas irregulares. Em caso de descumprimento, a multa&nbsp;varia de&nbsp;R$ 2 mil a R$ 15 mil. As informações são de Cláudia Vasconcelos, repórter de Pol?tica do JC.</FONT></P> </p>
