---
id: 12372011
data_publicacao: "2006-08-01 13:07:00"
data_alteracao: "None"
materia_tags: "beneficiários,eleição,mendonça"
categoria: "Notícias"
titulo: "A dois meses da eleição, Mendonça beneficia taxistas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>O governador e candidato à reeleição lançou um pacote fiscal que deverá favorecer nada menos que 10 mil taxistas de todo o Estado.</FONT></P></p>
<p><P><FONT face=Verdana>Eles poderão renovar a frota com isenção do ICMS num tempo mais curto.</FONT></P></p>
<p><P><FONT face=Verdana>É mais uma medida de um conjunto de bondades que Mendonça vem implementando em plena corrida eleitoral, a exemplo da</FONT><FONT face=Verdana> redução em R$ 0,05 nas tarifas de ônibus da Região Metropolitana do Recife.</FONT></P></p>
<p><P><FONT face=Verdana>Ouça a entrevista que o governador concedeu a Geraldo Freire, na <EM>Rádio Jornal</EM>.</FONT></P> </p>
