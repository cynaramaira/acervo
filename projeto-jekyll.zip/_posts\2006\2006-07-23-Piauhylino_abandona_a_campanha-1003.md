---
id: 12372176
data_publicacao: "2006-07-23 17:02:00"
data_alteracao: "None"
materia_tags: "campanha"
categoria: "Notícias"
titulo: "Piauhylino abandona a campanha"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>O deputado federal Luiz Piauhylino de Mello Monteiro, 59, acabou fazer um anúncio no m?nimo inusitado a Sérgio Montenegro Filho, repórter especial do JC. Disse que está deixando a pol?tica e não concorrerá à reeleição.</FONT></P></p>
<p><P><FONT face=Verdana>Sócio de uma das maiores bancas de advocacia de Pernambuco, Piauhylino disse que não tem como aceitar a confusão que a nova legislação eleitoral impôs aos candidatos neste ano.</FONT></P></p>
<p><P><FONT face=Verdana>\"Meu principal deputado estadual (Augusto César) é vice de Humberto e eu estou ao lado de Eduardo. Sou advogado e reconheço a lei da verticalização, mas não quero ser punido por estar subindo em palanques que não poderia subir\", desabafou há pouco.</FONT></P></p>
<p><P><FONT face=Verdana>Piau, como é conhecido, diz que a confusão resultante da lei é enorme: 40% das bases dele apóiam Humberto Costa para governador; 30%, Eduardo Campos; e 30%, Mendonça Filho. </FONT></P></p>
<p><P><FONT face=Verdana>O deputado começou sua vida parlamentar quando foi suplente do senador Mansueto de Lavor (já falecido), nos anos 80. Em 1988 e 1989, assumiu por um ano o mandato de Mansueto. Ocupa uma cadeira na Câmara há quatro legislaturas, 15 anos. Chegou lá pela primeira vez como federal em 1991.</FONT></P></p>
<p><P><FONT face=Verdana>Nesses anos todos, passou pelo PSB, PSDB, PTB e PDT. \"Vou continuar na pol?tica e no PDT\", garante ele.</FONT></P></FONT> </p>
