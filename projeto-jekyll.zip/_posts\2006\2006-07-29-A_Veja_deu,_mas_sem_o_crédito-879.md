---
id: 12372052
data_publicacao: "2006-07-29 17:30:00"
data_alteracao: "None"
materia_tags: "cerveja,crédito"
categoria: "Notícias"
titulo: "A Veja deu, mas sem o crédito"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>A edição desta semana da revista Veja, que começou a circular hoje, publica entrevista com a modelo Débora Daggy, 21 anos, que revelou com exclusividade ao <STRONG>Blog</STRONG>, na segunda-feira, ter namorado com Jarbas Vasconcelos quando tinha apenas 16 (e ele 58).</FONT></P></p>
<p><P><FONT face=Verdana>Faltou a&nbsp;revista dar o crédito ao <STRONG>Blog</STRONG>. Veja <STRONG><EM><A href=\"https://jc3.uol.com.br/blogs/jc/2006/07/24/index.php#248\">aqui</A></EM></STRONG> o que publicamos sobre Débora Daggy.</FONT></P> </p>
