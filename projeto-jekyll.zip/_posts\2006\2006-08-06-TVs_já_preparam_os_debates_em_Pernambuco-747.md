---
id: 12371920
data_publicacao: "2006-08-06 08:00:00"
data_alteracao: "None"
materia_tags: "debates,pernambuco"
categoria: "Notícias"
titulo: "TVs já preparam os debates em Pernambuco"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>As emissoras de televisão pernambucanas já começam a se mobilizar para promover os debates com os candidatos ao governo do Estado. </P></p>
<p><P>A primeira a levar os dez postulantes ao Palácio do Campo das Princesas para confronto ao vivo é a TV Nova (canal 22, UHF), no próximo dia 14, um dia antes do in?cio do guia eleitoral no rádio e TV. </P></p>
<p><P>Em setembro, a Rede Globo (canal 13) já marcou o debate para o dia 29, dois dias antes da eleição.</P></p>
<p><P>As diretorias de jornalismo das TVs Tribuna (canal 4), Clube (canal 9) e Estação TV (canal 14, UHF) informaram que ainda estão estudando como serão os debates. No entanto, as datas permanecem em aberto. </P></p>
<p><P>Já a TV Jornal, do Sistema Jornal do Commercio de Comunicação, investirá em entrevistas individuais com os dez candidatos ao governo, a partir do dia 21 deste mês. Serão veiculadas no TV Jornal Manhã, apresentado por Marcus Bezerra. O debate só acontecerá se houver segundo turno.</P></p>
<p><P>Leia o <STRONG><EM><A href=\"https://jc3.uol.com.br/jornal/\">texto</A></EM></STRONG> completo em Pol?tica, no JC (assinantes JC e UOL).</P></FONT> </p>
