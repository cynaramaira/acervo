---
id: 12371896
data_publicacao: "2006-08-06 13:06:00"
data_alteracao: "None"
materia_tags: "entrega,geraldo Alckmin,Lula,Saturno"
categoria: "Notícias"
titulo: "Internautas divididos sobre 2º turno entre Lula e Alckmin"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Este é o resultado final da enquete que o <STRONG>Blog</STRONG> realizou sobre a eleição presidencial. Foram registrados, no total, 560 votos. Veja os números:</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Você acha que haverá segundo turno na eleição para presidente da República?</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Não&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 252 (45%)</FONT></P></p>
<p><P><FONT face=Verdana>Sim, entre Lula e Alckmin&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 234 (42%)</FONT></P></p>
<p><P><FONT face=Verdana>Sim, entre Lula e Helo?sa Helena&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;74 (13%)</FONT></P></p>
<p><P><FONT face=Verdana>Com esses resultados, encerramos a enquete e iniciamos outra sobre os debates eleitorais.</FONT></P></p>
<p><P><FONT face=Verdana>A questão agora é a seguinte:</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Você acha que Lula, Jarbas e Mendonça Filho devem participar dos debates no primeiro turno?</STRONG></FONT></P><FONT face=Verdana></p>
<p><P>Participe, dê sua opinião na coluna ao lado.</P></FONT> </p>
