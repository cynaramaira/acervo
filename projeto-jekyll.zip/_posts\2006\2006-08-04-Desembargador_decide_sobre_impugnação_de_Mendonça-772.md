---
id: 12371945
data_publicacao: "2006-08-04 07:40:00"
data_alteracao: "None"
materia_tags: "Desembargadores,impugnação,mendonça"
categoria: "Notícias"
titulo: "Desembargador decide sobre impugnação de Mendonça"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=Arial></p>
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>O desembargador corregedor do Tribunal Regional Eleitoral (TRE), Carlos Moraes, ainda não confirmou se vai levar a julgamento a representação do PT que pede a inelegibilidade do candidato ao governo do Estado Mendonça Filho, o PFL e a coligação União por Pernambuco (PFL/PSDB/PMDB/PPS). </FONT></P></p>
<p><P><FONT face=Verdana>O procurador geral eleitoral Fernando Araújo havia acatado, no começo desta semana, a ação do PT, que acusa o programa partidário do PFL de misturar campanha com ações institucionais do governador. O desembargador tem as opções de levar a matéria a votação no pleno do tribunal ou julgá-la improcedente.</FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://jc3.uol.com.br/jornal/\" target=_blank>aqui</A></EM></STRONG> o texto completo (assinates JC e UOL).</FONT></P></FONT> </p>
