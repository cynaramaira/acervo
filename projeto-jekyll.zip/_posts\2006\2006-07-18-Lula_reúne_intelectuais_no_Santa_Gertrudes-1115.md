---
id: 12372288
data_publicacao: "2006-07-18 21:00:00"
data_alteracao: "None"
materia_tags: "Lula,santa cruz"
categoria: "Notícias"
titulo: "Lula reúne intelectuais no Santa Gertrudes"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>A reunião de Lula com cerca de 200 personalidades do Nordeste, entre artistas, intelectuais, empresários e l?deres de áreas como saúde e educação acontecerá no auditório da Academia Santa Gertrudes, na Cidade Alta, em Olinda. </P></p>
<p><P>O local foi confirmado agora pelo presidente estadual do PT, Dilson Peixoto, durante a inauguração do comitê de Carlos Wilson Campos (PT), no bairro do Espinheiro, no Recife.</P></FONT> </p>
