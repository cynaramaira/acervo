---
id: 12372141
data_publicacao: "2006-07-25 11:39:00"
data_alteracao: "None"
materia_tags: "bragantino,Day Mesquita"
categoria: "Notícias"
titulo: "Braga escapou, desta vez"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do Jornal do Commercio</FONT></P></p>
<p><P><FONT face=Verdana>Fotos e depoimentos testemunhais não foram suficientes para que o pleno do Tribunal Regional Eleitoral (TRE) cassasse o registro da candidatura a deputado estadual do ex-secretário de Defesa Social João Braga (PV). Por unanimidade, os desembargadores resolveram ontem arquivar a representação interposta pelo Ministério Público Eleitoral que o acusava de utilizar carros da Secretaria de Ressocialização do Estado (Seres) e do Corpo de Bombeiros para transportar militantes à sede do PV, no dia 26 de junho, quando lançou-se ao pleito de outubro. O motivo alegado pelos magistrados foi o da falta de provas.</FONT></P></p>
<p><P><FONT face=Verdana>O procurador eleitoral, Fernando Araújo, foi contundente na sua argumentação. Lembrou que a legislação eleitoral considera “conduta vedada??? a utilização de bens públicos por candidatos, partidos ou coligações e mostrou no plenário fotos da sede do PV e das placas dos referidos ve?culos. Em seguida, citou trechos dos depoimentos de testemunhas que teriam ido ao local e constatado a presença dos carros, ou que os teriam visto deixar a Seres carregando vários servidores. “Os carros são públicos. O que estavam fazendo lá na sede do PV????, questionou, defendendo que o ex-secretário fosse impedido de concorrer. </FONT></p>
<p><P><FONT face=Verdana>Ao ler seu voto, o relator do processo, desembargador Bartolomeu Bueno, teve entendimento contrário. Ele considerou que as fotos não provavam que os carros se encontravam nas proximidades da sede do partido e disse que “mesmo se estivessem, em nenhum momento se falou que Braga fez uso dos ve?culos???. “Se tivesse de haver alguma representação seria contra outra pessoa, não contra Braga ou contra o PV. Além do mais, o representado não faz mais parte da administração e essa conduta vedada não diz respeito a ele???, julgou. </FONT></p>
<p><P><FONT face=Verdana>Em resposta, Araújo ainda tentou argumentar que, por ser ex-secretário, Braga teria ainda influência entre os ocupantes de cargos públicos. “Não sejamos ingênuos. Ele é ligado ao governador (Mendonça Filho) e leva vantagem sobre os concorrentes sim???, acrescentou, mas sem sucesso. O pleno seguiu a opinião do relator.</FONT></P> </p>
