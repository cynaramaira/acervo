---
id: 12372313
data_publicacao: "2006-07-17 17:12:00"
data_alteracao: "None"
materia_tags: "campanha,Ciro Gomes,jorge jesus,Naomi Campbell,pesquisa,Texto-Base"
categoria: "Notícias"
titulo: "Não farei campanha com base em pesquisa, diz Jorge Gomes"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>O candidato do PSB ao Senado considerou positivos os resultados da JC/Vox Populi, que o apontam como segundo colocado, com 4% das intenções de voto, contra 3% de Luciano Siqueira (PCdoB) e 66% de Jarbas Vasconcelos (PMDB). </P></p>
<p><P>\"Meu nome só foi colocada no dia 30, então eu não tive tempo de trabalhar minha candidatura. Entrei por último nessa disputa e mesmo assim apareço em segundo\", avaliou há pouco, em conversa com Cec?lia Ramos, repórter do blog. </P></p>
<p><P>O socialista nega que esteja no páreo apenas para reforçar a candidatura de Eduardo Campos (PSB). \"Vim para ganhar e não vou fazer minha campanha com base em pesquisa\", assegurou.</P></p>
<p><P>Gomes lembrou que já tem um ficha extensa de serviços prestados a Pernambuco. Foi vice-governador de Miguel Arraes (1995-1998), prefeito de Caruaru e é hoje deputado federal. Ele preferiu não avaliar as razões que levam Jarbas a ter 66% das intenções de voto.</P></p>
<p><P>O blog também está tentando falar com Luciano Siqueira, candidato ao Senado na chapa de Humberto Costa (PT).</P></FONT> </p>
