---
id: 12372298
data_publicacao: "2006-07-18 10:07:00"
data_alteracao: "None"
materia_tags: "Eleitor,pernambuco"
categoria: "Notícias"
titulo: "Conheça o perfil do eleitor de Pernambuco"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Apenas 2,32% deles têm curso superior e 31,5%&nbsp;só cursaram o 1º grau, conforme esta reportagem de Antônio Martins, exibida logo cedo no TV Jornal Manhã. Veja o v?deo.</P> </p>
