---
id: 12372259
data_publicacao: "2006-07-20 14:42:00"
data_alteracao: "None"
materia_tags: "pernambuco,Saturno"
categoria: "Notícias"
titulo: "Você acha que haverá 2º turno em Pernambuco?"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Então vote na enquete postada ao lado. Trinta e&nbsp;sete pessoas já votaram. </P></p>
<p><P>O resultado parcial é o seguinte:&nbsp;15 acham que o segundo turno ocorrerá entre Mendonça e Humberto; 10 apostam em Mendonça X Eduardo; e apenas uma imagina Eduardo X Humberto. Onze pessoas não acreditam na hipótese de 2º turno.</P> </p>
