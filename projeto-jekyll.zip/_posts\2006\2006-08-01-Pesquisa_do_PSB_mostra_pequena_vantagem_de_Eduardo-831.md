---
id: 12372004
data_publicacao: "2006-08-01 18:28:00"
data_alteracao: "None"
materia_tags: "eduardo,Mostra,pequenas indústrias,pesquisa"
categoria: "Notícias"
titulo: "Pesquisa do PSB mostra pequena vantagem de Eduardo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Os jornalistas baianos Edson Barbosa e Raimundo Luedy, da Link Propaganda, que comandam a equipe de marketing de Eduardo Campos (PSB), estão debruçados sobre os números da pesquisa que acabam de realizar.</FONT></P></p>
<p><P><FONT face=Verdana>Esse levantamento, feito no sábado, domingo e segunda-feira, com 1,5 mil questionários, irá nortear o trabalho do guia eleitoral.</FONT></P></p>
<p><P><FONT face=Verdana>Os números completos serão analisados com Eduardo na quinta-feira.</FONT></P></p>
<p><P><FONT face=Verdana>Segundo uma fonte do comando da campanha, que conversou há pouco com Cec?lia Ramos, repórter do <STRONG>Blog</STRONG>, Eduardo ultrapassou Humberto Costa em três pontos percentuais. Mas os dois continuam muito próximos, na faixa entre 20% e 24%, contra um pouco mais de 30% de Mendonça Filho (PFL).</FONT></P> </p>
