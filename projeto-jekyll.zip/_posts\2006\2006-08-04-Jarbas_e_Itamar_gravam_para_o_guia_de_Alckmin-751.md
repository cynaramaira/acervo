---
id: 12371924
data_publicacao: "2006-08-04 19:33:00"
data_alteracao: "None"
materia_tags: "geraldo Alckmin,Itamaraty,jarbas vasconcelos"
categoria: "Notícias"
titulo: "Jarbas e Itamar gravam para o guia de Alckmin"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>A&nbsp;equipe de TV da campanha de Geraldo Alckmin aproveitou o final do almoço no Mourisco, em Olinda,&nbsp;para registrar mensagens de Jarbas Vasconcelos e Itamar Franco para a propaganda eleitoral.</FONT></P></p>
<p><P><FONT face=Verdana>Conforme apurou Cec?lia Ramos, repórter do Blog, Jarbas destacou o papel de Alckmin como governador de São Paulo, enalteceu o ajuste fiscal promovido naquele estado, apontou resultados positivos na saúde e no combate à violência.</FONT></P></p>
<p><P><FONT face=Verdana>Ele também elogiou a decisão do presidenciável tucano de vir a Pernambuco lançar um programa espec?fico para o Nordeste.</FONT></P></p>
<p><P><FONT face=Verdana>Itamar destacou o curr?culo e&nbsp;falou de&nbsp;Alckmin como um l?der pol?tico honesto. Afirmou ainda que tem total confiança de que o paulista é a melhor opção para governar o pa?s.</FONT></P> </p>
