---
id: 12371919
data_publicacao: "2006-08-05 07:33:00"
data_alteracao: "None"
materia_tags: "Contran,justiça eleitoral"
categoria: "Notícias"
titulo: "PSB protesta contra decisão da Justiça Eleitoral"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG>Jornal do Commercio</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>O presidente do PSB em Pernambuco e candidato a deputado estadual Milton Coelho driblou a Justiça Eleitoral ao contra-atacar, ontem, a coligação União por Pernambuco, do candidato a governador Mendonça Filho. Fez circular panfletos em que afirma que \"Mendonça Filho ri da violência e ainda quer botar na cadeia quem denuncia o descaso com a segurança\". </FONT></P></p>
<p><P><FONT face=Verdana>O socialista rebateu a ação que a União por Pernambuco move contra ele no Tribunal Regional Eleitoral (TRE), acusando-o de difamar o pefelista com panfletos distribu?dos na última terça-feira, nos quais Coelho afirma que o executivo estadual é o \"governo da violência\".</FONT></P></p>
<p><P><FONT face=Verdana>Os novos panfletos começaram a passar de mão em mão no mesmo dia em que o juiz Marco Maggi, do TRE, concedeu liminar favorável à União por Pernambuco (PFL/PSDB/PMDB/PPS). Até que o mérito seja julgado pelo pleno do TRE, a decisão fica mantida. </FONT></P></p>
<p><P><FONT face=Verdana>Em caso de desobediência, a multa diária é de R$ 5 mil. Entretanto, a punição não vale para os novos materiais que Milton Coelho está colocando nas ruas.</FONT></P></p>
<p><P><FONT face=Verdana>Leia o <STRONG><EM><A href=\"https://jc3.uol.com.br/jornal/\" target=_blank>texto</A></EM></STRONG> completo em Pol?tica, no JC (assinantes JC e UOL).</FONT></P> </p>
