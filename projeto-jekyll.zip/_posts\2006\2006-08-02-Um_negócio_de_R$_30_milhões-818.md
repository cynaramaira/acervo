---
id: 12371991
data_publicacao: "2006-08-02 10:38:00"
data_alteracao: "None"
materia_tags: "negócio"
categoria: "Notícias"
titulo: "Um negócio de R$ 30 milhões"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=Verdana></p>
<p><P>Por <STRONG>Lúcio Vaz</STRONG> e <STRONG>Marcelo Rocha</STRONG><BR>Do Correio Braziliense</P></FONT></p>
<p><P><FONT face=Verdana>O empresário Darci Vedoin, um dos l?deres da máfia das ambulâncias, afirmou à Justiça Federal que o petista José Airton Cirilo teria fechado um \"acerto prévio\" com o então ministro da Saúde, Humberto Costa, prevendo a liberação de cerca de R$ 30 milhões de recursos extra-orçamentários para a aquisição de unidades móveis e equipamentos médico-hospitalares, mediante o pagamento de uma comissão de 15% das licitações executadas. </FONT></P></p>
<p><P><FONT face=Verdana>Teriam sido destinados R$ 6 milhões para munic?pios e entidades do Ceará, R$ 14 milhões para o governo do Piau? e R$ 10 milhões para o governo do Mato Grosso do Sul. </FONT></P></p>
<p><P><FONT face=Verdana>O empresário Ronildo Medeiros confirmou a existência desses acordos e acrescentou que também teria sido feito um acerto com a prefeitura de Campinas. </FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Humberto Costa contra-ataca<BR></STRONG><BR>A assessoria do ex-ministro da Saúde Humberto Costa afirmou ontem que o petista não foi informado sobre o conteúdo dos novos depoimentos recebidos pela CPI dos Sanguessugas. </FONT></P></p>
<p><P><FONT face=Verdana>Reiterou declarações anteriores de que ele não tem qualquer envolvimento com o escândalo e que está à disposição da comissão para prestar os esclarecimentos necessários, mas defendeu que todos os ex-ministros dos últimos cinco anos sejam convocados, o que incluiria seu antecessor Saraiva Felipe (PMDB-MG), o candidato tucano à Prefeitura de São Paulo, José Serra, e Barjas Negri, também do PSDB. <BR><BR>Humberto Costa ressaltou ainda que as irregularidades atribu?das à máfia dos sanguessugas tiveram in?cio durante a gestão do ex-presidente Fernando Henrique Cardoso, e que a investigação da Pol?cia Federal que desbaratou o esquema ocorreu na administração do presidente Luiz Inácio Lula da Silva. </FONT></P></p>
<p><P><FONT face=Verdana>Sobre José A?rton Cirilo, afirmou que encontrou com ele apenas para tratar de questões pol?tico-partidárias e que \"o dirigente petista nunca esteve autorizado a falar em meu nome ou do ministério\". <BR></FONT><FONT face=Verdana><BR>Leia <STRONG><EM><A href=\"https://www.correioweb.com.br/\"</p>
<p> target=_blank>aqui</A></EM></STRONG> o texto completo (assinantes).</P></FONT> </p>
