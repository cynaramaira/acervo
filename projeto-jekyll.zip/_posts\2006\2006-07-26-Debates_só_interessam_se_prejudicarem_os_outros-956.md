---
id: 12372129
data_publicacao: "2006-07-26 18:10:00"
data_alteracao: "None"
materia_tags: "debates"
categoria: "Notícias"
titulo: "Debates só interessam se prejudicarem os outros"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Bras?lia (Agência Estado) - O senador José Jorge (PFL-PE), candidato a vice-presidente da República na chapa de Geraldo Alckmin (PSDB), criticou duramente a anunciada tendência do presidente Luiz Inácio Lula da Silva de não participar de debates com outros candidatos no primeiro turno das eleições. </FONT></P></p>
<p><P><FONT face=Verdana>\"Essa posição é uma mistura de medo com despreparo. Ele não deve se sentir preparado para responder a questões tão graves que pesam sobre seu governo, como mensalão e sanguessuga\", disse o candidato a vice.</FONT></P></p>
<p><P><STRONG><FONT face=Verdana>Comentário meu:</FONT></STRONG></P></p>
<p><P><FONT face=Verdana>Esse é um jogo de perde-perde para o cidadão. Porque o senador não atacará Jarbas Vasconcelos e Mendonça Filho, em Pernambuco, que tendem a não participar de debates, repetindo Lula.</FONT></P></p>
<p><P><FONT face=Verdana>Aqui, quem deve atacar a postura de Jarbas e Mendonça são os aliados de Lula - Eduardo Campos e Humberto Costa. </FONT></P></p>
<p><P><FONT face=Verdana>Ou seja, todos esses sujeitos - governistas ou não - assumem posturas de acordo com cada situação e conveniência. Você está perdido, caro eleitor.</FONT></P> </p>
