---
id: 12372038
data_publicacao: "2006-07-31 13:22:00"
data_alteracao: "None"
materia_tags: "chegada,Humberto Costa,investigação,tecnologia"
categoria: "Notícias"
titulo: "CPI quer convocar Humberto Costa. Investigação chega à Ciência e Tecnologia"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=Verdana>Por<STRONG> FELIPE RECONDO<BR></STRONG>da <STRONG><EM><A href=\"https://www1.folha.uol.com.br/folha/brasil/ult96u80858.shtml\">Folha Online</A></EM></STRONG>, em Bras?lia<BR><BR>O relator da CPI dos Sanguessugas, senador Amir Lando (PMDB-RO), decidiu hoje estender as investigações da comissão ao Executivo, inclusive com a convocação dos ex-ministros e assessores da pasta.<BR><BR>Uma sub-relatoria será criada para cuidar do assunto e caberá ao parlamentar indicado para dirigir as investigações definir quais ex-ministros deverão ser convocados. Essa sub-relatoria deve investigar também a atuação da Máfia dos Sanguessugas nos ministérios das Comunicações e da Ciência e Tecnologia.<BR><BR>O surgimento dos nomes de ministros provocou divergências na CPI. Os oposicionistas querem restringir os depoimentos aos ex-ministros do governo Luiz Inácio Lula da Silva --Saraiva Felipe (PMDB-MG) e Humberto Costa. Os governistas querem convocar também o ex-ministro José Serra, candidato do PSDB ao governo de São Paulo.</FONT> </p>
