---
id: 12372241
data_publicacao: "2006-07-21 13:47:00"
data_alteracao: "None"
materia_tags: "Humberto Costa"
categoria: "Notícias"
titulo: "Humberto sobreviverá?"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Começou mais uma fase complicad?ssima para a candidatura do ex-ministro da Saúde Humberto Costa (PT) ao governo de Pernambuco.</FONT></P></p>
<p><P><FONT face=Verdana>Ele foi jogado no centro do palco principal da CPI das Sanguessugas. Vem sendo obrigado a explicar suas relações com os principais personagens do escândalo na compra de ambulâncias.</FONT></P></p>
<p><P><FONT face=Verdana>É dif?cil avaliar neste momento qual será o impacto na sucessão estadual dessa relação de Humberto com a CPI. Tudo depende do que realmente venha a surgir e a ser comprovado e de como os eleitores receberão as not?cias.</FONT></P></p>
<p><P><FONT face=Verdana>Incialmente, o impacto maior é sobre o dia-a-dia da campanha do próprio Humberto. Com a repercussão do que foi dito até agora, ele está sendo obrigado a dedicar boa parte do tempo a pesquisar arquivos, datas e audiências da época em que era ministro. Tudo isso para preparar respostas à imprensa.</FONT></P></p>
<p><P><FONT face=Verdana>Também haverá impacto sobre o guia eleitoral. O escândalo das sanguessugas deverá ser usado pela equipe de Mendonça Filho (PFL) contra o ex-ministro. É not?cia fresca para reacender casos como o da Operação Vampiro, que já seriam utilizados como arma para desgastá-lo.</FONT></P></FONT> </p>
