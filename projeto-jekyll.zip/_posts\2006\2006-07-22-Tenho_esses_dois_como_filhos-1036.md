---
id: 12372209
data_publicacao: "2006-07-22 20:04:00"
data_alteracao: "None"
materia_tags: "como jogar"
categoria: "Notícias"
titulo: "Tenho esses dois como filhos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Lula falou meia hora. Terminou o discurso com um frase para Eduardo e Humberto:</FONT></P></p>
<p><P><FONT face=Verdana>\"Eu tenho esses dois meninos aqui como filhos\", disse, dirigindo-se para os dois: \"Por favor, vamos fazer com que tenha valido a pena o povo confiar na gente.\"</FONT></P></p>
<p><P><FONT face=Verdana>Ele está descendo do palanque para falar com a imprensa.</FONT></P></FONT> </p>
