---
id: 12372338
data_publicacao: "2006-07-16 15:23:00"
data_alteracao: "None"
materia_tags: "Armando Monteiro,Debate,jarbas vasconcelos"
categoria: "Notícias"
titulo: "Armando quer debate com Jarbas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Fora da disputa pelo governo, o deputado Armando Monteiro Neto&nbsp;decidiu se dedicar à luta contra a eleição de Jarbas Vasconcelos ao Senado. E os números da pesquisa JC/Vox Populi, que o Jornal do Commercio publica amanhã com exclusividade, mostram que será um luta dific?lima. Jarbas matém os quase 60 pontos percentuais de vantagem sobre os demais concorrentes.</P></p>
<p><P>\"Ninguém vai se eleger na sombra, ninguém é imbat?vel. Ele vai ter que discutir os problemas de Pernambuco e explicar por que deixou de fazer tantas coisas em tantos lugares. Por que o Estado vive em tanta insegurança? Ele não está solidário com Lula\", acaba de dizer Monteiro, durante discurso para cerca de 250 pessoas, em Bu?que, no Agreste, ao lado de Humberto e Luciano Siqueira, conforme informações de Ayrton Maciel, repórter de Pol?tica do JC, que acompanha a comitiva petista.</P></FONT> </p>
