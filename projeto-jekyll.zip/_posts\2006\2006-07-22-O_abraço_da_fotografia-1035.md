---
id: 12372208
data_publicacao: "2006-07-22 19:43:00"
data_alteracao: "None"
materia_tags: "Fotografia"
categoria: "Notícias"
titulo: "O abraço da fotografia"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p> </p>
