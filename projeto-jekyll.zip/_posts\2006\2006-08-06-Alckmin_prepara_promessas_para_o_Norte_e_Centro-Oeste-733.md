---
id: 12371906
data_publicacao: "2006-08-06 09:00:00"
data_alteracao: "None"
materia_tags: "geraldo Alckmin,litoral norte,preparação"
categoria: "Notícias"
titulo: "Alckmin prepara promessas para o Norte e Centro-Oeste"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Cec?lia Ramos</STRONG><BR>Repórter do Blog</FONT></P></p>
<p><P><FONT face=Verdana>Depois de passar pelo Recife, na última sexta-feira, para lançar seu plano de desenvolvimento para o Nordeste, o candidato a presidente Geraldo Alckmin (PSDB) fará o mesmo nas regiões Norte (Amazônia) e Centro-Oeste. </FONT></P></p>
<p><P><FONT face=Verdana>Para tanto, uma equipe de cerca de 350 pessoas - maioria de técnicos - trabalha intensamente no programa de governo do tucano, viajando os nove estados brasileiros para discutir as peculiaridades e deficiências locais e elaborar propostas focadas em cada região. </FONT></P></p>
<p><P><FONT face=Verdana>O plano do presidenciável terá 30 cap?tulos e está em fase de fechamento. \"Até o dia 15 o programa estará pronto. Nossa meta é que ele tenha esse documento completo com o in?cio do horário eleitoral\", antecipou o coordenador geral do programa de governo de Geraldo Alckmin, o economista João Carlos de Souza Meirelles, que esteve no Recife, na última sexta, acompanhando a comitiva tucana.</FONT></P></p>
<p><P><FONT face=Verdana>O Sul e o Sudeste também terão programas espec?ficos, mas, segundo Meirelles, o presidenciável não irá promover eventos espec?ficos para lançá-los. \"A prioridade é o Norte e o Nordeste, que apresentam ?ndices negativos de desenvolvimento regional. O presidente Lula vem enganando os nordestinos. Nós desafiamos Lula a mostrar o que ele fez realmente para o Nordeste. Cadê a Transposição do São Francisco, Transnordestina e Refinaria? Não sa?ram do papel\", provocou o economista, que deixou a secretaria estadual de Desenvolvimneto Econômico e Ciência e Tecnologia de São Paulo - gestão Alckmin - para se dedicar ao programa. </FONT></P></p>
<p><P><FONT face=Verdana>Além do plano batizado de \"Novo Nordeste\", apresentado no Recife, Meirelles adiantou ainda que também estão prontas as propostas de Alckmin para a área da Educação e em fase de finalização as de Saúde, Segurança Pública e Cultura. </FONT></P></p>
<p><P><FONT face=Verdana>\"O carro-chefe é a pol?tica social, porque é o que o Brasil está precisando. Na educação, por exemplo, o Governo Lula pecou brutalmente. Nem o Fundeb conseguiu aprovar\", atacou. Entre as promessas do presidenciável tucano para a área da Educação está a reformulação e ampliação do Programa de Ensino Profissionalizante, o Proep, criado no Governo Fernando Henrique Cardoso (PSDB). </FONT></P></p>
<p><P><FONT face=Verdana>\"Lula parou inteiramente esse programa. Só liberou uma bobagem de verba neste ano eleitoral\", diz Meirelles. Segundo ele, se eleito, Alckmin terá ainda como \"prioridade nacional\" o ensino técnico de 2º Grau e o combate à evasão escolar. A inovação, continuou o economista, será a criação de faculdades de tecnologia, com ciclo curto mas de n?vel superior. Também estão inclusos investimentos no ensino infantil - segundo o economista, \"letra morta\" no atual governo, e qualificação de professores em todo pa?s.</FONT></P> </p>
