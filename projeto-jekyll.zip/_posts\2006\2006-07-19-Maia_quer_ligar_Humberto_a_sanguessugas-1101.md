---
id: 12372274
data_publicacao: "2006-07-19 21:05:00"
data_alteracao: "None"
materia_tags: "Humberto Costa,rodrigo maia"
categoria: "Notícias"
titulo: "Maia quer ligar Humberto a sanguessugas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Bras?lia <FONT face=Verdana>(Folha Online) </FONT>- O PSDB e o PFL tentaram vincular hoje o esquema dos sanguessugas ao governo federal. Na lista divulgada ontem de 57 supostos envolvidos com a máfia das ambulâncias aparecem três parlamentares do PSDB e quatro do PFL. Nenhum parlamentar do PT é citado no esquema.<BR><BR>Mesmo assim, a oposição argumenta que nenhum esquema de corrupção do Legislativo pode ocorrer sem a ajuda do Executivo. \"O PT está no Poder Executivo. Não se pode realizar uma operação desse tamanho sem o Executivo\", disse o prefeito do Rio, Cesar Maia (PFL).<BR><BR>Sem mencionar nomes, ele afirmou que ficou \"chocado\" porque a CPI ainda não convocou um membro do PT para depor. Esse petista, segundo Maia, seria responsável pela conexão entre o ex-ministro da Saúde Humberto Costa e a Planam - empresa envolvida com a máfia das ambulâncias. O nome desse petista, de acordo com Maia, foi revelado pelo empresário Luiz Antonio Trevisan Vedoin em depoimento para a Justiça do Mato Grosso.</FONT></P></p>
<p><P><FONT face=Verdana>No Recife, Humberto Costa disse ao Jornal do Commercio que vai processar Cesar Maia e qualquer um que faça contra ele acusações</p>
<p> caluniosas. Ele argumentou que a máfia das ambulâncias existe desde a gestão de José Serra no ministério de Fernando Henrique Cardoso, adversários do PT. E que nem por isso está acusando Serra de envolvimento com a máfia.</FONT></P></FONT> </p>
