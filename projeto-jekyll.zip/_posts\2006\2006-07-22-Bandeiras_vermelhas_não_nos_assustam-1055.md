---
id: 12372228
data_publicacao: "2006-07-22 12:38:00"
data_alteracao: "None"
materia_tags: "Naomi Campbell"
categoria: "Notícias"
titulo: "Bandeiras vermelhas não nos assustam"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Foi o que acabou de dizer o senador Sérgio Guerra (PSDB), coordenador geral da campanha de Geraldo Alckmin, na inauguração do comitê de Mendonça Filho (PFL) e Jarbas (PMDB), no Recife.</FONT></P></p>
<p><P><FONT face=Verdana>\"As bandeiras estão contaminadas pela corrupção, sanguessugas, mensalinho e mensalão\", acrescentou.</FONT></P> </p>
