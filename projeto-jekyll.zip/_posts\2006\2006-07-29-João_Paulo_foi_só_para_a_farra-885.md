---
id: 12372058
data_publicacao: "2006-07-29 12:36:00"
data_alteracao: "None"
materia_tags: "joão d,Paulo"
categoria: "Notícias"
titulo: "João Paulo foi só para a farra"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>O prefeito do Recife, coordenador estadual da campanha de Humberto Costa (PT) a governador, passou apenas a noite em Garanhuns,</p>
<p> no festival de inverno.</P></p>
<p><P>Ele já voltou para casa. Certamente não pôde ficar para a programação da campanha de Humberto no Agreste, nas cidades vizinhas.</P></p>
<p><P>O petista permanece na companhia de Armando Neto.</P> </p>
