---
id: 12372373
data_publicacao: "2006-07-15 08:04:00"
data_alteracao: "None"
materia_tags: "PM,presos"
categoria: "Notícias"
titulo: "102 PMs, seis presos e muito medo"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p>O cinegrafista é do guia. O resto, do Estado. </p>
