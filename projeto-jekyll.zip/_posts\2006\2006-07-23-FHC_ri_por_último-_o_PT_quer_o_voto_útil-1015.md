---
id: 12372188
data_publicacao: "2006-07-23 16:06:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "FHC ri por último: o PT quer o voto útil"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por Elio Gaspari<BR>No JC de hoje</FONT></P></p>
<p><P><FONT face=Verdana>Fernando Henrique Cardoso já viu de tudo, mas faltava-lhe ver o PT defendendo um tipo deformado de “voto útil???. A chegada de Helo?sa Helena ao patamar dos 10% indica que sua candidatura poderá determinar a realização de um segundo turno, entre Nosso Guia e Geraldo Alckmin. Diante disso, reapareceu uma velha gambiarra: não se deve votar na senadora porque ela ajuda o candidato tucano, levando-o para um segundo turno no qual poderá derrotar Lula.</FONT></P><FONT face=Verdana></p>
<p><P>Sem entrar no mérito da candidatura de Helo?sa Helena, essa construção é um balaio de falsidades. A maior delas pressupõe que se deva reeleger Lula no primeiro</p>
<p> turno porque, se houver uma segunda rodada, ele pode perder. Como os eleitores do segundo turno são os mesmos do primeiro, uma derrota de Lula não poderá ser considerada conseqüência dos votos dados à ex-petista. Lula vencerá se tiver mais votos que Alckmin e perderá se tiver menos. O resto é parolagem.</P></p>
<p><P>É da professora Marilena Chau? uma severa condenação do “voto útil???. Ela a fez num artigo de outubro de 1985, às vésperas da eleição em que Fernando Henrique Cardoso (PMDB) e Jânio Quadros (PFL) disputavam a prefeitura de São Paulo. Naquele tempo não havia segundo turno, o que dava um toque de letalidade às pequenas candidaturas. O PT recusou-se a apoiar FHC e lançou Eduardo Suplicy. Argumentava-se que essa decisão poderia eleger Jânio. (Suplicy teve 827 mil votos e Jânio bateu o Pr?ncipe por uma diferença de 141 mil).</P></FONT> </p>
