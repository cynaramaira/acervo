---
id: 12372248
data_publicacao: "2006-07-21 10:46:00"
data_alteracao: "None"
materia_tags: "governo,Piauí"
categoria: "Notícias"
titulo: "Ligações com o governo do Piau"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Da Folha de S.Paulo</FONT></P></p>
<p><P><FONT face=Verdana>BRAS??LIA - O empresário Luiz Antonio Trevisan Vedoin, suposto l?der da quadrilha dos sanguessugas, disse em depoimento à Justiça Federal de Mato Grosso que teria negociado a venda de ambulâncias com o governo do Piau?, Estado governado por Wellington Dias (PT), mediante pagamento de propina ao petista José Airton Cirilo.<BR><BR>Cirilo, candidato derrotado ao governo do Ceará pelo PT em 2002 e ex-diretor da ANTT (Agência Nacional de Transportes Terrestres), teria recebido o dinheiro (não fica claro quanto) da suposta negociação no Piau? por meio de dois intermediários: José Caubi Diniz e Raimundo Lacerda Filho, sobrinho de Cirilo.<BR><BR>(...) A Folha apurou com três integrantes da CPI dos Sanguessugas que o esquema no Piau? seria similar ao que Cirilo teria implementado para liberar verbas do Ministério da Saúde, então comandado pelo petista Humberto Costa, hoje candidato ao governo de Pernambuco, para que prefeitos adquirissem 130 ambulâncias em 2003.</FONT></P></p>
<p><P><FONT face=Verdana>Esse esquema também foi revelado por Vedoin.<BR><BR>(...) A Secretaria de Saúde do Piau? negou quaisquer irregularidades na compra de ambulâncias pelo governo do Estado.<BR><BR>Leia <STRONG><A href=\"https://www.uol.com.br/fsp\" target=_blank>aqui</A></STRONG> texto completo (só para assinantes)</FONT></P> </p>
