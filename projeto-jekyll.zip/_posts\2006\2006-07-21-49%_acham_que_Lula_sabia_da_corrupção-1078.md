---
id: 12372251
data_publicacao: "2006-07-21 07:35:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "49% acham que Lula sabia da corrupção"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>Por Sérgio Montenegro Filho<BR></FONT><FONT face=Verdana>Repórter especial do JC</FONT></P></p>
<p><P></FONT><FONT face=Verdana>Embora lidere a corrida sucessória, o presidente Lula ainda enfrenta a desconfiança de metade da população de Pernambuco em relação à corrupção no governo. </FONT></P></p>
<p><P><FONT face=Verdana>De acordo com a pesquisa JC/Vox Populi, 49% dos pernambucanos acreditam que Lula tinha conhecimento das irregularidades na sua administração, que desaguaram em escândalos e na demissão de ministros e auxiliares. </FONT></P></p>
<p><P><FONT face=Verdana>Mas outros 38% dos entrevistados preferiram dar um voto de confiança ao presidente, afirmando que ele não sabia do que se passava nos bastidores do governo. </FONT></P></p>
<p><P><FONT face=Verdana>Na pesquisa anterior, realizada em maio, 50% dos pernambucanos avaliaram que Lula tinha conhecimento dos atos de corrupção, enquanto 35% disseram que ele não sabia e 15% não opinaram. </FONT></P></p>
<p><P><FONT face=Verdana>Quando o Vox Populi solicitou uma comparação entre a corrupção no atual governo e na gestão anterior, de Fernando Henrique Cardoso (PSDB), 31% dos entrevistados disseram que o n?vel aumentou, 25% acham que diminuiu, e 36% avaliaram que a situação continua como antes. </FONT></P></p>
<p><P><FONT face=Verdana>O Vox Populi ouviu 800 pessoas, nos dias 7 e 8 de julho, em 38 munic?pios de Pernambuco. O intervalo de confiança é de 95% e a margem de erro média de 3,5 pontos percentuais, para mais ou para menos. A pesquisa foi registrada no TRE-PE no dia 07 de julho de 2006, sob o número 8898/2006. </FONT></P><FONT face=Verdana size=2></p>
<p><P>Veja <B><A href=\"https://jc3.uol.com.br/especiais/eleicoes2006/\" target=_blank>aqui</A></B> os números da pesquisa.</P></FONT> </p>
