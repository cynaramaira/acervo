---
id: 12371971
data_publicacao: "2006-08-03 06:59:00"
data_alteracao: "None"
materia_tags: "aprovados,defesa,jorge jesus,Marcos Pontes"
categoria: "Notícias"
titulo: "PFL aprova defesa de Marcos de Jesus"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Por <STRONG>Jorge Cavalcanti</STRONG><BR>Repórter do Jornal do Commercio</FONT></P></p>
<p><P><FONT face=Verdana>No dia que a Executiva nacional do PFL decidiu abrir</p>
<p> processo disciplinar contra os parlamentares do partido que forem citados no relatório preliminar da CPI dos Sanguessugas, o presidente estadual da sigla, deputado federal André de Paula, aprovou, ontem, a defesa apresentada internamente pelo deputado Marcos de Jesus, único pefelista pernambucano citado na Máfia da Ambulâncias. </FONT></P></p>
<p><P><FONT face=Verdana>\"As provas dele desmontam a principal acusação feita até agora. A defesa é consistente até que surjam fatos novos\", disse o dirigente. O empresário Luiz Antônio Vedoin, dono da Planam, empresa que comandava o esquema de compra dos ve?culos superfaturados, disse, em depoimento à Pol?cia Federal, que foi ao gabinete de Marcos pagar uma propina de R$ 24 mil ao parlamentar referente à aquisição de unidades móveis de saúde, no dia 20 de outubro de 2004. </FONT></P></p>
<p><P><FONT face=Verdana>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A> </EM></STRONG>o texto completo (assinantes JC e UOL).</FONT></P> </p>
