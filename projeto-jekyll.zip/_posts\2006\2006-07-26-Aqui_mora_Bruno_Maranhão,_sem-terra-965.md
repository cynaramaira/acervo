---
id: 12372138
data_publicacao: "2006-07-26 08:59:00"
data_alteracao: "None"
materia_tags: "Bruno Covas,Itaquitinga,maranhão,Terra"
categoria: "Notícias"
titulo: "Aqui mora Bruno Maranhão, sem-terra"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><p>Não falta espaço no colorido apartamento do mais célebre l?der do Movimento de Libertação dos Sem-Terra (MLST). <!--?xml:namespace prefix = o ns = \"urn:schemas-microsoft-com:office:office\"</p>
<p> ?--></p></p>
<p><p>É um belo um-por-andar-com-200-metros-quadrados, cujo endereço preciso - peço desculpas - não vou dar para não atrair a cobiça dos sem-teto.</p></p>
<p><p>Digamos apenas que fica em Casa Forte, bairro dos mais chiques e ricos do Recife, bem perto da mansão onde viveu até pouco tempo atrás, com a mãe, no Parnamirim (últimas fotos).</p></p>
<p><p>Herdeiro de usineiros, Bruno Maranhão, 66 anos, decidiu abrir seu apartamento nesta terça-feira para uma conversa com a imprensa. Estava acompanhado de Mônica Martins, coordenadora do MLST em Ita?ba, no interior de Pernambuco.</p></p>
<p><p>Na entrevista, voltou a eximir o MLST da responsabilidade pelo quebra-quebra promovido na Câmara dos Deputados no in?cio de junho.</p></p>
<p><p>&nbsp;</p></p>
<p><p>Por causa do incidente, esteve preso na Penitenciária da Papuda, em Bras?lia, durante 38 dias. Também foi afastado da executiva nacional do Partido dos Trabalhadores e da campanha de Lula.</p></p>
<p><p>Foi orientado a não comparecer ao último com?cio do presidente, em Bras?lia Teimosa, no sábado, para não atrapalhá-lo.</p></p>
