---
id: 12372126
data_publicacao: "2006-07-26 21:53:00"
data_alteracao: "None"
materia_tags: "cerveja"
categoria: "Notícias"
titulo: "O blog errou. Veja os números corretos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=Verdana></p>
<p><P>A informação divulgada há pouco pelo <STRONG>Blog</STRONG> estava incorreta. Os números eram extraoficiais e foram repassados como definitivos. A seguir o resultado oficial,&nbsp;apresentado pela assessoria de imprensa da OAB:</P></FONT></p>
<p><P><FONT face=Verdana>1º Jorge Neves Batista&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1.381 </FONT></P></p>
<p><P><FONT face=Verdana>2º Francisco Bandeira&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1.264</FONT></P></p>
<p><P><FONT face=Verdana>3º Braga Sá&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1.102</FONT></P></p>
<p><P><FONT face=Verdana>4º Edgar Moury Fernandes&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1.085</FONT></P></p>
<p><P><FONT face=Verdana>5º Reinaldo Gueiros&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1.049</FONT></P></p>
<p><P><FONT face=Verdana>6º Pedro Henrique Alves&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 999</FONT></P></p>
<p><P><FONT face=Verdana>------------</FONT></P></p>
<p><P><FONT face=Verdana>7º Carlos Gil Rodrigues&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 948</FONT></P></p>
<p><P><FONT face=Verdana>Ao invés de quinto, o candidato do ex-governador Jarbas Vasconcelos chegou em sexto lugar.</FONT></P> </p>
