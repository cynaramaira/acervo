---
id: 12371962
data_publicacao: "2006-08-03 13:15:00"
data_alteracao: "None"
materia_tags: "Cirilo Mota,Paulo,Rubem Fonseca"
categoria: "Notícias"
titulo: "Paulo Rubem quer expulsar Cirilo do PT"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Do <STRONG><EM><A href=\"https://www.noblat.com.br/\" target=_blank>blog</A></EM></STRONG> de <STRONG>Noblat</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Está ficando mais feia a coisa, informa <B>Gustavo Noblat</B>, repórter do blog.</FONT></P></p>
<p><P><FONT face=Verdana>O deputado Paulo Rubem Santiago (PT-PE) acaba de dizer depois de ter ouvido parte do depoimento do empresário Luiz Antonio Vedoin à CPI dos Sanguessugas reunida em uma sala do da Superintendência da Pol?cia Federal em Bras?lia:</FONT></P></p>
<p><P><FONT face=Verdana>- Há ind?cios suficientes para que seja aberto dentro do PT processo disciplinar para expulsar José Airton Cirilo.</FONT></P></p>
<p><P><FONT face=Verdana>Cirilo foi candidato ao governo do Ceará em 2002. À Justiça Federal do Mato Grosso, Vedoin disse que Cirilo conseguiu junto ao então ministro Humberto Costa, da Saúde, a liberação de dinheiro que o governo devia à Planan.</FONT></P> </p>
