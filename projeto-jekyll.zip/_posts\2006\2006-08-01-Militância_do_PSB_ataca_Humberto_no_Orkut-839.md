---
id: 12372012
data_publicacao: "2006-08-01 16:09:00"
data_alteracao: "None"
materia_tags: "Humberto Costa,natação,orkut"
categoria: "Notícias"
titulo: "Militância do PSB ataca Humberto no Orkut"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Está uma guerra desigual para Humberto Costa (PT) no Orkut, a comunidade de amigos na internet.</FONT></P></p>
<p><P><FONT face=Verdana>A favor dele há apenas duas comunidades: \"Humberto Costa governador\", com 646 membros, e \"Pernambuco quer Humberto Costa\", 6 membros.</FONT></P></p>
<p><P><FONT face=Verdana>Contra ele, tem outras duas. A maior chama-se \"Eu odeio o Humberto Costa\" e conta com 30 participantes. Ela foi criada por Danilo de Jesus Oliveira, em cuja página pessoal não há referências aos demais candidatos.</FONT></P></p>
<p><P><FONT face=Verdana>Problema maior, porém, é \"Humberto Costa o Vampirão\", com 5 integrantes. </FONT></P></p>
<p><P><FONT face=Verdana>Ela foi criada por um rapaz chamado Carlos Rangel Wendell, em cuja página pessoal há três comunidades favoráveis ao PSB de Eduardo Campos. São elas: \"Eu voto 40 – Eduardo Campos 2006\"; \"Juventude 40 – Eduardo Campos\"; e \"Soldado Moisés\", a do deputado estadual e candidato à reeleição.</FONT></P></p>
<p><P><FONT face=Verdana>Eduardo Campos tem 13 comunidades favoráveis à candidatura dele. A maior (\"Eu voto 40 – Eduardo Campos 2006) tem 1.217 membros.</FONT></P></p>
<p><P><FONT face=Verdana>Contra o socialista há uma só: \"Eu Odeio Eduardo Campos\" (17 membros), criada por Manoela Spinna, que define seu perfil pol?tico como \"muito conservador, de direita\".</FONT></P></p>
<p><P><FONT face=Verdana>Na página pessoal de Spinna, há uma série de comunidades favoráveis a Mendonça Filho, Jarbas Vasconcelos, ao PFL, a Geraldo Alckmin e até a Helo?sa Helena. Tem, entre outras, a \"Eu amo ACM\", com 588 admiradores do senador baiano.</FONT></P></p>
<p><P><FONT face=Verdana>O número de comunidades favoráveis a Mendonça Filho é maior que o de Eduardo e Humberto. A principal delas, \"Mendonça Filho governador 25\", soma 2.540 participantes.</FONT></P></p>
<p><P><FONT face=Verdana>Contra o governador, há apenas duas: \"Eu odeio Mendonça Filho\" (62) e \"Mendonça Filho da p.\" (59). </FONT></P></p>
<p><P><FONT face=Verdana>Esta última foi criada pelo professor Marcos Lima (Aratu), que se diz liberal, de esquerda, mas não aponta preferências diretas em relação aos candidatos de oposição.</FONT></P> </p>
