---
id: 12372343
data_publicacao: "2006-07-16 10:00:00"
data_alteracao: "None"
materia_tags: "Lula"
categoria: "Notícias"
titulo: "Lula reúne empresariado"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>O presidente tem encontro marcado com l?deres empresariais na próxima quarta-feira, no Palácio do Planalto. Preocupado com o crescimento de Alckmin nas pesquisas, quer prospectar os sentimentos da classe. Já vem conversando com o deputado Armando Monteiro Neto, presidente da CNI.</P> </p>
