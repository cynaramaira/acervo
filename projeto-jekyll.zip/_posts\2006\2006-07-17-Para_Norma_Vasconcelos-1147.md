---
id: 12372320
data_publicacao: "2006-07-17 09:35:00"
data_alteracao: "None"
materia_tags: "jarbas vasconcelos,norma,Pará"
categoria: "Notícias"
titulo: "Para Norma Vasconcelos"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>A chapa de Eduardo é fraca e caseira por razões objetivas. Ela está limitada a Caruaru e agrega apenas mais um partido, o PDT de João Lyra Neto. Foi fechada às pressas, na última hora, porque era a única opção que restava. Jorge Gomes e João Lyra são dois homens públicos respeitáveis e não fiz obsrevações pessoais.</P></p>
<p><P>A de Humberto soma mais. Consolida o apoio do PCdoB, que administra Olinda e poderia estar com Eduardo por conta das relações históricas com o PSB. Também agrega o PTB e abre espaços no Sertão, onde Augusto César tem suas bases.</P></p>
<p><P>No caso de Mendonça, a mesma coisa. Individualmente, Evandro Avelar não agrega absolutamente nada, a não ser o voto dele e da fam?lia. Mas ele é a representação na chapa do PSDB, este, sim, forte e com bastante inserção no Estado.</P></p>
<p><P>Norma, o que comentamos aqui não é pessoal. É pol?tica. Evandro, Jorge, João, Luciano, Augusto e Jarbas, em princ?pio, não me interessam como pessoas f?sicas, mas como l?deres pol?ticos.</P></FONT> </p>
