---
id: 12372027
data_publicacao: "2006-07-31 19:06:00"
data_alteracao: "None"
materia_tags: "Papa Francisco"
categoria: "Notícias"
titulo: "Francisco Bandeira é o escolhido"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>Fausto Freitas, presidente do Tribunal de Justiça de Pernambuco, está neste momento no Palácio das Princesas para entregar a lista tr?plice ao governador Mendonça Filho.</FONT></P></p>
<p><P><FONT face=Verdana>Mendonça mandou chamar Francisco Bandeira para convidá-lo a assumir a vaga do 37º desembargador do TJ.</FONT></P> </p>
