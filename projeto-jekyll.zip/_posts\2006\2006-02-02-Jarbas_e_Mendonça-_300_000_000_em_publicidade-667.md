---
id: 12371840
data_publicacao: "2006-02-02 14:30:00"
data_alteracao: "None"
materia_tags: "jarbas vasconcelos,mendonça,sem publicidade"
categoria: "Notícias"
titulo: "Jarbas e Mendonça: 300.000.000 em publicidade"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT face=\"Times New Roman\"></p>
<p><P><FONT face=Verdana>Este é o balanço de sete anos e meio de governo.</FONT></P></p>
<p><P><FONT face=Verdana>Foram R$ 290,9 milhões desde 1999, nas duas gestões comandadas por Jarbas Vasconcelos (PMDB) e Mendonça Filho (PFL).</FONT></P></p>
<p><P><FONT face=Verdana>Os números não incluem o que a administração indireta aplicou no primeiro semestre deste ano, que ainda não está dispon?vel. Com a indireta, os gastos devem superar os R$ 300 milhões.</FONT></P></p>
<p><P><FONT face=Verdana>Os dados foram levantados por fontes ligadas à oposição, com acesso ao Sistema de Administração Financeira para Estados e Munic?pios. O Siafem não está aberto a qualquer um.</FONT></P></p>
<p><P><FONT face=Verdana>Tudo o que se gastou em publicidade seria suficiente para construir uma nova BR-232,&nbsp;maior obra das gestões Jarbas/Mendonça.</FONT></P></p>
<p><P><FONT face=Verdana>A duplicação do principal trecho da BR, entre Recife e Caruaru, custou R$ 422 milhões, segundo dados da secretaria estadual de Infra-estrutura.</FONT></P></p>
<p><P><FONT face=Verdana>Mas esse custo inclui desde a elaboração dos projetos técnicos às desapropriações no caminho.</FONT></P></p>
<p><P><FONT face=Verdana>Os cerca de R$ 300 milhões da publicidade foram usados principalmente para consolidar a marca positiva da gestão.</FONT></P></p>
<p><P><FONT face=Verdana>Eles dariam também para realizar um novo Promata, cujo orçamento soma US$ 150 milhões (ou cerca de R$ 326 milhões – com o dólar cotado a R$ 2,175).</FONT></P></p>
<p><P><FONT face=Verdana>O Promata, conforme define o próprio governo do Estado em seu <STRONG><EM><A href=\"https://www.promata.pe.gov.br/\" target=_blank>site</A></EM></STRONG>, deve melhorar a qualidade de vida de 1,2 milhão de pessoas:</FONT></P></FONT><FONT face=Verdana></p>
<p><P>\"O programa objetiva promover a inclusão social e estimular o desenvolvimento da região com base na sustentabilidade, através de um conjunto de ações integradas nas áreas de saúde, educação, infra-estrutura, diversificação econômica e meio-ambiente. Visa garantir mais qualidade de vida para 1,2 milhão de habitantes da Zona da Mata, na transformação dos históricos indicadores de pobreza e desigualdades sociais que há séculos marcam a região.\"</P></FONT></p>
<p><P><FONT face=Verdana>A t?tulo de comparação, para que você tenha uma idéia do que significam os R$ 300 milhões, vão aqui mais alguns números:</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Gastos executados em 2005:</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Vigilância Sanitária: </FONT></P></p>
<p><P><FONT face=Verdana><STRONG>R$ 15.889.406,88</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Vigilância epidemiológica: </FONT></P></p>
<p><P><FONT face=Verdana><STRONG>R$ 12.019.987,84</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Assistência à criança e ao adolescente: </FONT></P></p>
<p><P><FONT face=Verdana><STRONG>R$ 16.711.779,27</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Valores previstos no orçamento de 2006 para investimentos:</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Na Defesa Social</STRONG> – R$ 55 milhões</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Na Saúde</STRONG> – R$ 120 milhões</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Na Educação</STRONG> – R$ 110 milhões</FONT></P></p>
<p><P><FONT face=Verdana>Daqui a pouco, publicaremos o que diz o governo sobre os números, detalhados</p>
<p> a seguir:</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>Publicidade governamental</STRONG></FONT></P></p>
<p><P><FONT face=Verdana>Ano&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Adm.Dir&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Adm.Ind&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Total </FONT></P></p>
<p><P><FONT face=Verdana>99&nbsp;&nbsp;&nbsp;&nbsp;12.982.275,33&nbsp;&nbsp;&nbsp;&nbsp;5.040.265,02&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;18.022.540,35 </FONT></P></p>
<p><P><FONT face=Verdana>00&nbsp;&nbsp;&nbsp; 14.287.133,36&nbsp;&nbsp;&nbsp;&nbsp;7.773.901,33&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;22.061.034,69 </FONT></P></p>
<p><P><FONT face=Verdana>01&nbsp;&nbsp;&nbsp; 18.775.593,74&nbsp;&nbsp;&nbsp; 10.381.085,60&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;29.156.679,34 </FONT></P></p>
<p><P><FONT face=Verdana>02&nbsp;&nbsp;&nbsp;&nbsp;22.977.386,56&nbsp;&nbsp;&nbsp;&nbsp;21.340.163,53&nbsp;&nbsp;&nbsp;&nbsp; 44.317.550,09 </FONT></P></p>
<p><P><FONT face=Verdana>03&nbsp;&nbsp;&nbsp; 23.943.002,00&nbsp;&nbsp;&nbsp; 17.821.176,28&nbsp;&nbsp;&nbsp;&nbsp; 41.764.178,28 </FONT></P></p>
<p><P><FONT face=Verdana>04&nbsp;&nbsp;&nbsp; 32.829.279,61&nbsp;&nbsp;&nbsp; 20.960.337,86&nbsp;&nbsp;&nbsp;&nbsp; 53.789.617,47 </FONT></P></p>
<p><P><FONT face=Verdana>05&nbsp;&nbsp;&nbsp; 37.979.822,27&nbsp;&nbsp;&nbsp; 22.233.519,24&nbsp;&nbsp;&nbsp;&nbsp; 60.213.341,51</FONT></P></p>
<p><P><FONT face=Verdana>06&nbsp;&nbsp;&nbsp; 21.658.585,11&nbsp;&nbsp;&nbsp; (Não dispon?vel)</FONT></P></p>
<p><P><FONT face=Verdana><STRONG>TOTAL</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 290.983.527,46</P></FONT> </p>
