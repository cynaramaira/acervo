---
id: 12372202
data_publicacao: "2006-07-23 10:45:00"
data_alteracao: "None"
materia_tags: "Ciro Gomes,Doações,governo,Lula,nordeste"
categoria: "Notícias"
titulo: "Ciro defende ações do governo Lula no Nordeste"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P><FONT face=Verdana>O ex-ministro está dando uma palestra neste momento, na Academia Santa Gertrudes, em Olinda, para uma platéia de intelectuais, celebridades, empresários e pol?ticos do Nordeste simpáticos à candidatura de Lula à reeleição.</FONT></P></p>
<p><P><FONT face=Verdana>O trabalho do governo na região, garante Ciro Gomes, tem três eixos fundamentais. Um é o de ação social, com distribuição de renda (Bolsa Fam?lia). Outro, dar competitividade à economia da região (novas condições log?siticas, infra-estrutura, capacitação de mão-de-obra e projetos de inovação cient?fica e tecnológica). Por fim, há a preocupação com a gestão ambiental (aqui entra também a transposição do São Francisco).</FONT></P></p>
<p><P><FONT face=Verdana>\"Vai demorar muito para essa elite de nariz torcido, que deixou um legado escravista, reconhecer esse trabalho\", disparou ele, em meio a um monte de frases de efeito e palavras engraçadas, que divertem a platéia.</FONT></P></p>
<p><P><FONT face=Verdana>Na mesa, ouvindo Ciro, estão Lula e dona Mariza, Ricardo Berzoini (coordenador da campanha e presidente do PT), Aldo Rebelo (presidente da Câmara) e a prefeita Luciana Santos.</FONT></P></p>
<p><P><FONT face=Verdana>Na platéia, Eduardo e Humberto - juntinhos de novo - e figuras como a economista Tânia Bacelar, o músico Fred 04 (da banda Mundo Livre S/A) e&nbsp;o sempre presente Ariano Suassuna, entre outros.</FONT></P></FONT> </p>
