---
id: 12372342
data_publicacao: "2006-07-16 06:03:00"
data_alteracao: "None"
materia_tags: "Goiana,prefeito"
categoria: "Notícias"
titulo: "Goiana escolhe novo prefeito"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Os 51,5 mil eleitores de Goiana, na Zona da Mata Norte do Estado, voltam às urnas hoje para escolher novamente o prefeito e vice, durante eleição suplementar, convocada depois da cassação de Beto Gadelha, condenado por propaganda irregular e abuso de poder econômico, como informa Cláudia Vasconcelos, repórter do Jornal do Commercio (www.jc.com.br), em matéria publicada na edição deste domingo. Saiba um pouco mais sobre quem são os candidatos na disputa.</P></p>
<p><TABLE cellSpacing=1 cellPadding=3 width=500 bgColor=#6ca7a6 border=0></p>
<p><TBODY></p>
<p><TR bgColor=#e0e4e5></p>
<p><TD><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" color=#006666 size=2><EM><STRONG>Perfil dos candidatos</STRONG></EM></FONT></TD></TR></p>
<p><TR></p>
<p><TD bgColor=#eaf0ee><STRONG></STRONG></p>
<p><TABLE cellSpacing=5 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD width=\"30%\"></p>
<p><TABLE cellSpacing=5 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD vAlign=top width=\"4%\"><IMG height=60 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/foto_edvaldo_soares.gif\" width=60 align=middle border=1></TD></p>
<p><TD width=\"96%\"><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG><FONT size=2><EM>Edval Soares (PTB)</EM></FONT></STRONG><EM><FONT size=2><BR>Foi prefeito entre 2000 e 2004, e faz parte da coligaçãoque entrou com o pedido de cassação de Beto Gadelha. Na campanha, valorizou os atos dos seus quatro anos de gestão, principalmente construção de escolas, centros profissionalizantes e postos de saúde nas áreas mais pobres.</FONT></EM><BR></FONT></TD></TR></TBODY></TABLE></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD></p>
<p><TABLE cellSpacing=5 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD vAlign=top width=\"4%\"><IMG height=60 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/foto_ana_silveira.gif\" width=60 align=middle border=1></TD></p>
<p><TD width=\"96%\"><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG><FONT size=2><EM>Ana Silveira (PDT)</EM></FONT></STRONG><EM><FONT size=2><BR>Vereadora correligionária do prefeito cassado Beto Gadelha(PSDB), Ana desfruta da popularidade do aliado para tentar ser a primeira mulher a ocupar o cargo em Goiana. Tem como candidato a vice Betinho, filhio de Beto, e tem como bandeiras saúde, educação e geração de emprego.</FONT></EM></FONT></TD></TR></TBODY></TABLE></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD height=79></p>
<p><TABLE cellSpacing=5 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD vAlign=top width=\"4%\"><IMG height=60 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/foto_ezildo_gadelha.gif\" width=60 align=middle border=1></TD></p>
<p><TD width=\"96%\"><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG><FONT size=2><EM>Ezildo GAdelha (PPS)</EM></FONT></STRONG><EM><FONT size=2><BR>Advogado, se auto-entitulou o candidado com a campanha mais modesta. Priorizou as visitas de porta em porta nos bairros, e aposta na \"vontade dos eleitores\" mudar o panorama pol?tico para alçar vôos mais altos rumos à prefeitura.</FONT></EM></FONT></TD></TR></TBODY></TABLE></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD></p>
<p><TABLE cellSpacing=5 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD vAlign=top width=\"10%\"><IMG height=60 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/foto_paulo_veloso.gif\" width=60 align=middle border=1></TD></p>
<p><TD width=\"90%\"><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG><FONT size=2><EM>Paulo Veloso (PT)</EM></FONT></STRONG><EM><FONT size=2><BR>O médico levanta a bandeira da renovação pol?tica e pretende implantar um estilo de gestão com planejamento participativo, modelo popularizado pelo PT. Se for eleito, as prioridades dele serão a saúde, geração de empregos e investimentos da educação profissionalizante.</FONT></EM></FONT></TD></TR></TBODY></TABLE></TD></TR></p>
<p><TR bgColor=#c1d2cd></p>
<p><TD></p>
<p><TABLE cellSpacing=5 cellPadding=2 width=\"100%\" border=0></p>
<p><TBODY></p>
<p><TR></p>
<p><TD vAlign=top width=\"4%\"><IMG height=60 src=\"https://www2.uol.com.br/JC/sites/blogdaseleicoes/imagens/foto_henrique_fenelon.gif\" width=60 align=middle border=1></TD></p>
<p><TD width=\"96%\"></p>
<p><P><FONT face=\"Verdana, Arial, Helvetica, sans-serif\" size=1><STRONG><FONT size=2><EM>Henrique Fenelon (PC do B)</EM></FONT></STRONG><EM><FONT size=2><BR>Nos 40 dias em que esteve à frente da prefeitura como interino, o presidente da Câmara de Goiana afirmou que fez mais obras que o antecessor, como a pavimentação de estradas e a reativação do São João da cidade. Acredita que esse é o maior trunfo de sua campanha.</FONT></EM></FONT></P></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE> </p>
