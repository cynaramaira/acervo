---
id: 12372070
data_publicacao: "2006-07-29 09:10:00"
data_alteracao: "None"
materia_tags: "eduardo,Metropolitana"
categoria: "Notícias"
titulo: "O reforço de Eduardo na Metropolitana "
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Do <STRONG>Jornal do Commercio</STRONG> </P></p>
<p><P>Em meio à estratégia de priorizar a campanha na Região Metropolitana do Recife, o candidato a governador da Frente Popular, deputado federal Eduardo Campos (PSB), realizou caminhadas ontem em Jaboatão dos Guararapes, segundo colégio eleitoral do Estado. </P></p>
<p><P>Ao lado do prefeito da cidade, Newton Carneiro (PSB), o ex-ministro da Ciência e Tecnologia visitou, pela manhã, a feira de Cavaleiro. Depois Newton e sua filha, Elina Carneiro (PSB) - candidata a deputada estadual e ex-secretária municipal de Articulação Pol?tica -, convocaram os funcionários, que ocupam cargos comissionados na prefeitura, a participar de um almoço-adesão, no Recanto Gaúcho, Candeias, em torno de Eduardo. </P></p>
<p><P>Em seguida, a comitiva fez um porta a porta na comunidade de Suvaco da Cobra, no bairro de Barra de Jangada, um dos mais violentos e carentes de Jaboatão, onde moram 20 mil pessoas.</P></p>
<p><P>Leia <STRONG><EM><A href=\"https://www.jc.com.br/\" target=_blank>aqui</A></EM></STRONG> a cobertura completa (assinantes JC e UOL).</P> </p>
