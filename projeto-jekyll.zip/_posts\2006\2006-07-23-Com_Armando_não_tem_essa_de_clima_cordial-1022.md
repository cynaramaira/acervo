---
id: 12372195
data_publicacao: "2006-07-23 11:41:00"
data_alteracao: "None"
materia_tags: "Armando Monteiro,clima,Naomi Campbell,recessão"
categoria: "Notícias"
titulo: "Com Armando não tem essa de clima cordial"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>O deputado federal Armando Monteiro Neto (PTB) acaba de quebrar o clima de cordialidade entre Eduardo e Humberto.</P></p>
<p><P>Presidente da Confederação Nacional da Indústria,&nbsp;Neto está falando neste momento para os 280 intelectuais, l?deres sindicais e pol?ticos do Nordeste reunidos com Lula.</P></p>
<p><P>Logo de in?cio fez questão de não citar Eduardo Campos. Saudou apenas Humberto Costa, candidato dele ao governo de Pernambuco.</P></p>
<p><P>Armando se desentendeu com Eduardo nos últimos meses, quando o PSB avançou com tudo sobre as bases do PTB no interior. Armando ainda era pré-candidato a governador. Não havia desistido para apoiar Humberto.</P> </p>
