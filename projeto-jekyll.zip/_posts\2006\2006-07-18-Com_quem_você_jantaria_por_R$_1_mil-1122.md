---
id: 12372295
data_publicacao: "2006-07-18 14:03:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "Com quem você jantaria por R$ 1 mil?"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>Fechadas as contas do jantar de Jarbas e Mendonça, que arrecadou R$ 1,132 milhão, o blog quer saber: você pagaria R$ 1 mil para jantar com quem?</P></p>
<p><P>Foi esse o valor pago por cada um dos 1.132 convivas do jantar realizado ontem pela União por Pernambuco, no Arcádia do Paço Alfândega, endereço chique do Recife, para arrecadar fundos para as campanhas de Jarbas e Mendonça.</P></p>
<p><P>Diga aqui, abaixo, na seção para comentários. Mais tarde divulgaremos as respostas.</P> </p>
