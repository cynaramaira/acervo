---
id: 12371908
data_publicacao: "2006-08-05 08:57:00"
data_alteracao: "None"
materia_tags: "Humberto Costa"
categoria: "Notícias"
titulo: "Comando da Fetape reforça Humberto"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P></p>
<p><P><FONT face=Verdana></FONT></P><FONT face=Verdana>Com mais de 1,5 milhão de agricultores sindicalizados, a Federação dos Trabalhadores da Agricultura de Pernambuco (Fetape) simpatiza com dois candidatos a governador: Humberto Costa (PT) e Eduardo Campos (PSB). </FONT></p>
<p><P></P></p>
<p><P><FONT face=Verdana>Mas esta suposta imparcialidade chega ao fim com a reeleição, neste final de semana, do atual presidente da entidade, Aristides Santos, durante o 7º congresso estadual da entidade, que ocorre no Centro de Convenções da UFPE. </FONT></P></p>
<p><P><FONT face=Verdana>Ele conseguiu aparar as arestas internas e formar uma chapa única, impondo as cores de seu partido: o PT. Na composição da nova diretoria, o PSB – antes muito forte na Fetape por conta da ligação da entidade com o ex-governador Miguel Arraes – perdeu espaço. </FONT></P></p>
<p><P><FONT face=Verdana>Dos nove membros, só fica com um: o ex-presidente José Rodrigues, que está isolado. Antes, os socialistas tinham três diretorias. Para manter as aparências, Aristides convidou Humberto e Eduardo para participarem, ontem à noite, da abertura do evento.</FONT></P></p>
<p><P><FONT face=Verdana>Leia o </FONT><A href=\"https://jc3.uol.com.br/jornal/\" target=_blank><B><I><U><FONT color=#0000ff><FONT face=Verdana>texto</FONT></B></I></U></FONT></A><FONT face=Verdana> completo em Pol?tica, no JC (assinantes JC e UOL).</FONT></P> </p>
