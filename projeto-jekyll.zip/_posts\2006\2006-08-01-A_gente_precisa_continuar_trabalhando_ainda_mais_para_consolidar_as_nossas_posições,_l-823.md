---
id: 12371996
data_publicacao: "2006-08-01 21:01:00"
data_alteracao: "None"
materia_tags: "gente,jarbas vasconcelos,Pará"
categoria: "Notícias"
titulo: "A gente precisa continuar trabalhando ainda mais para consolidar as nossas posições, lembra Jarbas"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=5></p>
<p><P><FONT face=Verdana size=2>O ex-governador Jarbas Vasconcelos (PMDB), candidato ao&nbsp;Senado,&nbsp;comemorou o resultado da pesquisa&nbsp;Ibope/TV Globo, que o coloca com 67% das intenções de voto. Ele lembrou, porém,&nbsp;</FONT><FONT face=Verdana size=2>que é preciso continuar trabalhando para consolidar posições.</FONT></P></p>
<p><P><FONT face=Verdana size=2>Por meio da assessoria de imprensa,&nbsp;Jarbas divulgou&nbsp;há pouco&nbsp;a seguinte nota: </FONT></P></p>
<p><P><FONT face=Verdana size=2><STRONG>NOTA À IMPRENSA:</STRONG></FONT></P></p>
<p><P><FONT face=Verdana size=2>\"É um resultado muito bom para a União, a dois meses da eleição e a 15 dias do in?cio do guia eleitoral. Mas a gente precisa continuar trabalhando ainda mais para consolidar as nossas posições, a de Mendonça e a minha. O resultado da pesquisa Ibope, bem como os de outros levantamentos já divulgados pela Imprensa, é uma demonstração de que os pernambucanos reconhecem os avanços obtidos de 99 para cá e que Mendonça é o melhor nome para que Pernambuco não ande para trás\". </FONT></P></p>
<p><P><FONT face=Verdana size=2></FONT>&nbsp;</P></FONT> </p>
