---
id: 12371982
data_publicacao: "2006-08-02 15:38:00"
data_alteracao: "None"
materia_tags: "fundo eleitoral,São João"
categoria: "Notícias"
titulo: "Um guia eleitoral fantasma no Engenho São João"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P><FONT face=Verdana>É&nbsp;tensa e extremamente politizada a situação no Engenho São João, área de 270 hectares, em São Lourenço da Mata, Região Metropolitana do Recife, ocupada por cerca de 300 fam?lias sem-terra.</FONT></P></p>
<p><P><FONT face=Verdana>A Pol?cia Militar foi enviada ao local para cumprir ordem de desocupação. Há 325 homens cercando o acampamento Chico Mendes, segundo Eduardo Machado, repórter do Jornal do Commercio. Tem PMs do Batalhão de Choque, do 20º Batalhão, da Rádio Patrulha e da Companhia Independente de Operações Especiais.</FONT></P></p>
<p><P><FONT face=Verdana>O <STRONG>Blog</STRONG> está tentando descobrir para quem trabalha uma equipe de TV que filma toda a operação desde cedo. Com certeza colhe imagens para o guia eleitoral. A equipe diz&nbsp;não saber para quem trabalha.&nbsp;</FONT></P></p>
<p><P><FONT face=Verdana>Assessores do governador Mendonça Filho (PFL) garantem que a equipe não é deles (há repórter, cinegrafista e motorista). O pessoal de Humberto Costa (PT) e de Eduardo Campos diz a mesma coisa.</FONT></P></p>
<p><P><FONT face=Verdana>\"Não é nosso, não. Tem um cinegrafista de bermuda. Já disseram que é de um canal de televisão, mas eu nunca vi cinegrafista trabalhando de bermuda\", explicou há pouco Roberto Leandro, deputado estadual do PT que está no Engenho tentando negociar uma sa?da pac?fica para o conflito. Ele teme um confronto sangrento.</FONT></P></p>
<p><P><FONT face=Verdana>Leandro acusou o juiz José Gilmar da Silva, responsável por determinar a desocupação, de assumir posição pol?tica contra o PT, chamando os sem-terra de \"petistas\".</FONT></P> </p>
