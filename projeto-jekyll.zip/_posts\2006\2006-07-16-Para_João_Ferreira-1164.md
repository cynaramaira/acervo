---
id: 12372337
data_publicacao: "2006-07-16 15:13:00"
data_alteracao: "None"
materia_tags: "fred ferreira,joão d,Pará"
categoria: "Notícias"
titulo: "Para João Ferreira"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Amigo, acho que você não entendeu a ironia na nota Jantar de meio milhão, postada abaixo. Fiz um paralelo com aquela frase do governador Cláudio Lembo sobre \"a elite branca\". Não há nada de preconceituoso no que eu disse. Afinal, à exceção da elite branca, quem não é mestiço neste pa?s?</P></FONT> </p>
