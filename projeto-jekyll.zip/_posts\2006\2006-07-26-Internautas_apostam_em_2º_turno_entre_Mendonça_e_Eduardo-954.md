---
id: 12372127
data_publicacao: "2006-07-26 16:09:00"
data_alteracao: "None"
materia_tags: "eduardo, entrega, mendonça"
categoria: "Notícias"
titulo: "Internautas apostam em 2º turno entre Mendonça e Eduardo"
sutia: "None"
chapeu: "None"
autor: "jamildo"
imagem: "None"
---
<p>&nbsp;</p>
<p>Com 3.773 votos, a enquete do Blog terminou da seguinte forma:</p>
<p>Voc&ecirc; acha que haver&aacute; segundo turno nas elei&ccedil;&otilde;es para governador de Pernambuco?</p>
<p>Sim, entre Mendon&ccedil;a e Eduardo 2.999 votos (79%)</p>
<p>Sim, entre Mendon&ccedil;a e Humberto 187 votos (5%)</p>
<p>Sim, entre Eduardo e Humberto 376 votos (10%)</p>
<p>N&atilde;o 211 votos (6%)</p>
<p>-------------------------------------</p>
<p>NOVA ENQUENTE</p>
<p>Voc&ecirc; acha que haver&aacute; segundo turno na elei&ccedil;&atilde;o para presidente da Rep&uacute;blica?</p>
<p>Acabamos de post&aacute;-la. D&ecirc; sua opini&atilde;o, vote na coluna ao lado.</p>
