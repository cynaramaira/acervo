---
id: 12372283
data_publicacao: "2006-07-19 02:48:00"
data_alteracao: "None"
materia_tags: "governo,Lula,Maioria"
categoria: "Notícias"
titulo: "Lula é maior que o governo dele"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>Os números do JC/Vox Populi, publicados hoje no Jornal do Commercio, mostram que o presidente, como candidato, é mais popular que o governo dele. Em Pernambuco, segundo a pesquisa, Lula tem 66% de intenções de voto. A administração federal, porém, é aprovada por 54% da população. Ela é avaliada como ótima por 17% dos entrevistados e boa por 37%.</P></p>
<p><P>O governo é considerado regular por uma parcela inferior da população em relação ao governo Mendonça Filho. A gestão federal tem 34% de regular. A de Mendonça, 46%.</P></p>
<p><P>Veja os números completos no site do <B><A href=\"https://jc3.uol.com.br/especiais/eleicoes2006/\" target=_blank>JC Eleições 2006</A></B>.</P></FONT> </p>
