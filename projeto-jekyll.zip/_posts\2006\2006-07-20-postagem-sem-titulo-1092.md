---
id: 12372265
data_publicacao: "2006-07-20 09:43:00"
data_alteracao: "None"
materia_tags: "None"
categoria: "Charge"
titulo: ""
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><P>O escândalo das sanguessugas, segundo Humberto, do JC. Tem gente doida para colocar o carimbo do Samu nessa ambulância e associá-la a Humberto, do PT.</P> </p>
