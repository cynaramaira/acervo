---
id: 12372282
data_publicacao: "2006-07-19 18:01:00"
data_alteracao: "None"
materia_tags: ""
categoria: "Notícias"
titulo: "A reação indignada do PSB"
sutia: "None"
chapeu: "None"
autor: "None"
imagem: "None"
---
<p><FONT size=2></p>
<p><P>O PSB ficou indignado com texto publicado abaixo sobre a tese da renúncia de Eduardo Campos, que circula no meio pol?tico e que interessa a importantes setores da aliança de Mendonça Filho. Leia o <B><A href=\"https://jc3.uol.com.br/blogs/jc/2006/07/19/index.php#141\">texto</A></B> postado mais cedo.</P></p>
<p><P>Ninguém no partido quer falar oficialmente sobre o assunto. Propus uma entrevista com Eduardo Campos ou com Milton Coelho, presidente do PSB. Nenhum deles aceitou.</P></p>
<p><P>Aqueles com quem conversei disseram, de maneira mais do que enfática, que não vão falar sobre algo inexistente, que Eduardo jamais renunciaria, que a tese é fantasiosa e só interessa a determinados grupos pol?ticos.</P></p>
<p><P>Disseram também que Eduardo está em ascensão, tem chances reais de vencer a eleição, empata com Humberto em praticamente todas as regiões do Estado, vence na Zona da Mata e está a apenas seis pontos percentuais dele na Região Metropolitana do Recife, onde o PT detém maior força eleitoral.</P></p>
<p><P>Ressaltaram principalmente que Eduardo vence Humberto no segundo turno e está muito bem estruturado no Estado. No final da semana, o vereador Danilo Cabral, coordenador geral da campanha, falava no apoio de cerca de 58 prefeitos, 75 vices, 130 ex-prefeitos e 800 vereadores.</P></FONT> </p>
